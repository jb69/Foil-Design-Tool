# Reading the output: console lines, notices and warnings

Everything the features print, what it means, and what to change. Field names in *italics* are dialog labels (see parameters.md).

## Console lines

Turn on *Log inputs* on a feature to get its `*_INPUTS` line. Every line starts with `toolVersion=`; the Feature Studio header carries the build number.

| Line | From | What it says |
|---|---|---|
| `WING_INPUTS`, `STAB_INPUTS`, `MAST_INPUTS`, `FUSELAGE_INPUTS`, `PERFORMANCE_INPUTS`, `MOLD_INPUTS` | each feature | Every input as `key=value`. `STAB_INPUTS` has `height_mm` (typed: seat offset from the fuselage centreline) and `pivotZ_mm` (where the stab pivot ended up). |
| `===== FOIL PERFORMANCE =====` ... `===== END =====` | Foil performance | The full report, then the CSV. |
| `FUSELAGE_SEAT` | Foil fuselage | The seat on the stab and the tapped holes made, or the conflict and its fix. |
| `MAST_FILLET` | Foil mast | Seam edges found where the mast meets the plate, and the fillet attempt that worked. |
| `UD_CAP_PLIES` | Foil mold | Cut list per cap: ply, length, width at root, width at the end. |
| `UD_TABS` | Foil mold (mast) | Tab plies per face, their size, fold position and interleave. |
| `LAYUP` | Foil mold | Laminate volume and cured mass, skins, UD caps, tow, resin, what to buy. |
| `STIFFNESS` | Foil mold | Deflection and cap stress; mast: stress at the plate and at the worst point, bolt tension, junction, plate bending. |
| `STAB_CONES` | Foil mold (stab) | Bolt cones made and their positions. |
| `MAST_PLUG` | Foil mold (mast) | The pod plug's cores and depth. |
| (warning) countersink deeper than the section | Foil stabiliser, and the mold's cone note | A bolt's countersink leaves under 1 mm of laminate (an M5 is 2.9 mm deep; a bolt in a 3 mm root tail cannot take it): move it forward with *Bolt 1 at* or *Bolt pitch*, a smaller *Bolt*, or *Countersink* off. The mold then shows a flat disc instead of a cone there. |
| (warning) socket as half cores | Foil mold (wing) | *Socket plug* is off with the wing's Tube socket on: the halves mold the bore with a seam and meeting pins; turn Socket plug on in the Tube socket group. |
| `MAST_PLATE` | Foil mold (mast) | The plate measured off the part (length x width x thickness) against the Foil mast's numbers; says when direct edits were found and the tray followed them, or when it could not measure and used the nominal plate. |
| `TEMPLATES` | Foil mold | Order of shapes on the template plate and each one's cut count. |

## Foil stabiliser notice

- **Seat line.** "seat plane 4 mm below the fuselage centreline (Z …), pivot at Z …". With the pad on top the seat must be at or below the centreline; with the pad underneath, at or above. A WARNING in this line names the sign to use.
- **Fixed interface.** "flat from … mm, full width to …, tail to …": positions from the stab pivot. They stay the same for every stab with the same Arm, so any stab fits the same fuselage.
- **Interface warnings.** "Flat start is ahead of the leading edge", "the trailing edge is behind Tail start", "Tail end is inside the root": the geometry is held so it still builds, but the interface is no longer fixed. Move the named field, or accept it for a stab that only ever fits its own fuselage.
- **Bolts.** "2 M5 bolt holes 5.4 mm at 0 mm from the pivot, pitch 35 mm, 2 countersunk 11.2 mm on the underside". A skipped bolt is off the root; change *Bolt 1 at* or *Bolt pitch*.
- **Tail volume and decalage** appear when a wing is above. See targets.md.

## FUSELAGE_SEAT

- `seats on the stab's mount contour, X a-b, pad plane Z … (d mm under the axis)` with `n of n tapped holes d mm for Mx`: working.
- `stab seat on top, X a-b at Z …`: the stab sits on top (*Mount side* Bottom). A flat into the top of the body is normal.
- The block that fills between the tube and the seat is the stab's own since build 198 (*Block to body* in the stab's Mount pad group); the stab's notice reports it: `block to the body … (cheeks beside it)`, `(fills … mm under it)`, or `no block to the body needed (the fuselage's flat at the pad face is … mm wide)`.

| Conflict | Fix |
|---|---|
| pad plane above the fuselage centreline, nothing to seat on | Foil stabiliser *Height* 0 or below (−4 typical) |
| stab's underside below the centreline (pad underneath) | *Height* 0 or above (+4 typical) |
| pad plane below the tube, the stab's Block to body carries it | valid; set *Height* nearer 0 for a flush seat |
| flat seat on the tube only x mm wide | turn the stab's *Block to body* on (cheeks beside the tube), or *Height* closer to 0 |
| stab's clearance hole not bigger than the tapping drill | only with *Bolt* = Custom: fix the two hole sizes, or pick a named bolt |
| stab bolt at X skipped, off the seat | *Bolt 1 at* or *Bolt pitch* on the stab |
| parallel section runs into the tail taper | move the mast forward, the stab aft, or reduce *Parallel aft* |
| mast base not on the tube / mast leading edge outside the body | move the mast (*Mast X*) or change *Base height* |
| Mast pocket on but no Foil mast | add Foil mast above, or turn *Mast pocket* off |

Errors that stop the fuselage: no tube socket on the wing (turn *Tube socket* on), no stab above it, stab feature older than the fuselage (paste the whole Feature Studio again), no room between socket and tail (longer *Arm* or more *Overhang*).

## Foil mast

- Notice: height, chord and taper, thickness law, the root fillet result, pod summary, plate.
- `MAST_FILLET: ... OK: long edges only, no propagation at 12 mm` is normal: Onshape fillets the section but not its 0.8 mm trailing edge line, which is left as a small notch. "ROOT FILLET FAILED" lists every attempt; lower *Root fillet* or add a manual fillet above Foil mold.
- Errors: thickness outside 4-25 % of chord (*Thickness* (Foil mast), *Top thick*); countersink deeper than the plate (*Plate thick* or a smaller *Bolt*); plate too narrow or too short for the bolts; bolt heads would hit the mast (*Track spacing* or smaller *Bolt*); pod doesn't fit the mast height (*Pod height*); fairing doesn't fit (*Fairing length*, *Nose start %*, *Aft extension*).

## Foil mold

Mold notice: block size, number of tiles and bed size, keys, plugs, cones, pinch-off, then the LAYUP and STIFFNESS summaries. Mast: "plate tray ... from the plate as modelled" means the tray pocket was sized from the part; fillets, chamfers and outline changes made to the plate above the mold are in it, and the bolt pins stay on the Foil mast's pattern (move bolts in the mast's dialog, not by editing holes).

**LAYUP** example: `layup 1036 cm3, 1.59 kg cured at Vf 50% | skin 2 x 200 gsm each face: 0.43 m2, 92 g | UD caps 300 gsm, 40% chord: 15 plies per cap at the root to 4 at the tip (cut 2 of each), 819 mm long | tow 800 tex: 600 g | resin 596 g in the part, mix 834 g | buy 0.53 m2 woven, 1.27 m2 UD`.

- Ply counts are **per cap**: cut every UD strip twice, one per face.
- "skins + UD caps exceed the part": lower *Cap thick %*, *Cap width %* or *Skin plies*.
- Mast: the plate's woven fill, cap run-out and tab plies are included. "tabs take more than the tow core at the plate": fewer *Tab plies* or a larger *Top thick*.

**STIFFNESS**, wing or stab: `4 g: tip deflection 6.5 mm (1.6 mm at 1 g), root EI 2459 N m2, root cap stress 137 MPa`. The load is the spanwise moment Foil performance published at its *Load factor g*; without Foil performance above, there's no check.

**STIFFNESS**, mast: `mast side 1 g at the fuselage, plate fixed: F=932 N, deflection at the fuselage 53 mm, cap stress at the plate 198 MPa, worst 243 MPa at 494 mm, track bolt tension 3.9 kN each, junction: cap force 38.5 kN, shear 2.1 MPa over 47 mm x (1 + 2 x 4 tabs), allow 15, needs 6 mm, plate bending 96 MPa, fillet 12 mm`.

- The worst point is often where the thickening starts, not the plate. To flatten it, start *Thicken from %* lower or raise *Thickness* (Foil mast).
- Junction shear over its allowable means the caps would peel off the plate: more *Tab plies*, longer *Cap run-out*, thicker *Top thick*, or a wider plate.
- 1 g of the whole mass sideways is a severe case; a hard carve is roughly 0.3-0.5 g. The rider picks *Mast side g*.

| Mold warning or error | Fix |
|---|---|
| tip section only x mm thick where the cap starts | Foil wing / stab: turn *Min tip* on, or raise *End ratio* or *Tip thick %* |
| expected n upper and m lower tiles, found … | usually harmless after a skipped key; inspect the bodies if pieces look wrong |
| block taller than the usable print height | lower *Base thickness* or the tip drop, or a taller printer |
| pinch-off groove skipped | the mold is complete; add a groove by hand or turn *Pinch-off groove* off |
| n keys skipped where a seam crosses the plug channel | normal; the neighbouring keys locate the tiles |
| Could not cut the cavity into the UPPER / LOWER half | first check the tip thickness as above; then more *Split stations* and a higher *Tip bias*; then confirm the Source model matches the selected part |
| Source model not found / feature older than this Foil mold | add the source feature above, or paste the whole Feature Studio again |
| key size errors | keep *Pin dia*, *Key dia* and *Key height* inside *Base thickness* − 4 mm and *Flange width* − 4 mm |
| pad underneath in the design: molded upside down | expected for a stab that sits on top of the fuselage; turn the finished part over |

## Foil performance warnings

| Warning | Meaning and first fix |
|---|---|
| wing stalls at take-off speed | raise *Take-off km/h*, or more area / CL max; see levers.md |
| take-off within 15 % of stall | the same, less urgent |
| stab CL above 0.8 in range | stab near its own stall: larger stab or change its incidence |
| cavitation number below 1.5 | thinner, less cambered sections or more depth; check with XFoil |
| depth under 2 MAC | free surface not modelled; results optimistic |
| no Foil mast / fuselage above this feature | move Foil performance below them in the feature list |
| wing / stab polar used outside its Re range | the polar's CL max is extrapolated; add a polar at nearer Reynolds numbers |
| motor pod or prop can never be submerged | lower *Pod height*, smaller *Prop dia* |
| full power cannot hold take-off speed | more *Current lim A*, *Gear ratio* or *Prop dia* |
| cruise needs more than the current limit / full throttle | more cells, lower *Prop P/D*, or a smaller foil |
| pitch-unstable under power / static margin under power only x % | lower *Pod height*, longer *Arm*, more stab area or decalage; run pitch_sweep.py |

## Joints and mounts (builds 185-205)

Wing notice fragments by *Joint*:

- `tube socket: … mm tube, nacelle …` / `square socket: w x h mm bore (corners R …), nacelle …`: the two sockets, held by countersunk bolts through the nacelle's top (*Bolts*, *Bolt*, *Bolt pitch*); *Bore corner* rounds the square bore like extruded bar.
- `flat hub w x l mm from X … (square back), … mm fillet round the join to X …`: the hub, a D in plan with its pocket open through the square back; `(no join fillet: …)` names why a fillet could not be built (hub too close to the trailing edge, off the wing); `JOIN FILLET FAILED` should not happen and wants the WING_INPUTS line.
- `flat mount: n x M6 countersunk through holes … least laminate under a head x mm`: bolts straight down through the wing onto a bar; a skipped bolt is outside the root chord.

Stab notice fragments: `mount pad on top / underneath, face h mm off the skin`, `(no pad body: the section's own flat is the seat …)` when *Pad height* 0 sits on a flat side, `(square front at Flat start, no ramp)` with *Front ramp* off, and the block lines above.

Wing mold: `socket plug = the bore as modelled (2 cores) on a … handle`, `n bolt shanks cleared through the nacelle's walls, the countersinks molded by the upper half`, `hub molded as modelled (pocket, fillet, holes): n tapered cones …`, `flat mount: n through holes mold as pins from both halves`. A plug built from 0 cores means the bore is not open at the rear face or a hole off the wing's pattern still ties it to a half.

Stab mold: `pad underneath in the design: molded upside down` appears only with the pad's tail fairing on; otherwise the mold keeps the stab's orientation.
