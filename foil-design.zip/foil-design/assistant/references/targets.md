# Targets and typical ranges

Rules of thumb for judging tool output. They are starting ranges drawn from common practice and the tool's own tooltips, not certified figures; brands and riders differ. Always weigh them against the user's stated goal.

## Front wing by discipline

| Discipline | Area cm^2 | Aspect ratio | Take-off km/h | Cruise km/h | Notes |
|---|---|---|---|---|---|
| Pump / downwind | 900-1500 | 9-14+ | 8-12 | 12-18 | Glide and low induced drag matter most; high AR, thin-ish sections |
| SUP / surf | 1200-2500 | 4-7 | 10-14 | 14-22 | Turning and low-speed lift; lower AR, more sweep and anhedral |
| Wing (winging) | 900-1800 | 6-10 | 12-16 | 18-28 | All-round compromise |
| Windfoil | 700-1200 | 6-10 | 12-18 | 25-35 | Higher speed; cavitation starts to matter |
| Kite race | 300-700 | 8-12 | 15-25 | 30-45+ | Small, thin, high speed; cavitation governs section choice |
| eFoil | 1000-2000 | 5-9 | 12-16 | 18-25 | Efficiency at cruise sets range; beginners want large area |

Scale area with mass: roughly proportional to total mass for the same take-off speed.

Fourth production range (Lift, 2026; design notes): area in in² (with cm²), span and AR per front wing, area and rear-fuselage length per back wing, M6 mast 14 mm, nothing else. One outline family (superellipse n 1.5, end 0.22, leading edge swept 50-155 mm aft at the tip); anhedral measured from true rear renders: flat centre 20 % of half span, then straight 5.5-6.5 deg, tip drop 3.4-3.7 % of span (Drop shape Power, exp 1, Drop from 20, Drop to 90); camber in Lift's words: HA-X and LCX low, Havoc/Vario/Florence medium, Surf/Camber Pro/old HA high; Vario Twist and Grubb tips = washout 1-2 deg (the only production washout statement); fuselage split at the mast (front stub 260-315 mm plus a rear piece of 140-250 mm sold with the back wing; arm chosen by the back wing); stab / wing 0.11 to 0.28; Carve tails pitched down more than Glide.

Third production range (AXIS, 2026; design notes): designer-stated camber 2.5 % on ART, ART Pro and Spitfire, 3.5 % on PNG, rears about 1 % inverted, mast symmetric; tip section symmetric (Tip profile with Tip camber 0); wings set at 1 deg to the fuselage, rears at 1.5 deg down; thickness from published volumes 10.5-12 % on every current series (Tempo 7-11); outlines near-elliptic with pointed tips on surf wings, square-tipped tapers on glide and race wings; Skinny stabs tuned by chord at a fixed 360 mm span (AR 8-18); Power Carbon mast 140 x 20 mm at the plate to 125 x 14.5 at the foot, PRO 13.5 mm.

Second production range (Code Foils, 2026; design notes): span, area and AR only. Front wings hold one AR per series: S all-round 9.5, X surf 8.2, R downwind 13, Kanga pump 9 to 13 at a fixed 1300 mm span; tails AR 8.1 to 10.8 (the AR series keeps a 42 mm chord and changes span only), R tails 10.8, Race tails 15 to 16; fuselages 420 to 540 mm, shorter than AFS's 650 to 680; Black Series mast 105 x 13.6 to 14.2 mm, tapered and thickened to the plate. Stab / wing 0.14 to 0.18 on their pairings, tail volume 0.8 to 1.0.

Measured production range (AFS, 2026; the project's design notes have every number): thickness 11-13 % of root chord on every front wing whatever the AR (9-10.6 on the Evo and Pure), so millimetres follow chord; AR 6.3 learning (Flyer), 7.5-8 all-round (Evo), 9 surf/carving (Silk V2), 11 all-terrain and dockstart (Enduro), 12-13 HA freeride (Evo HA), 14-16 downwind (Ultra). Outlines: superellipse n 1.7-2.1 at low AR, 1.4 with raked tips (sweep 7-8 % of span at exponent 3-4) for surf and all-terrain, double taper (break 35 %, mid 0.83) on the HA freeride wing. Straight trailing edge (Align line % 70-90) on surf, race and downwind wings; straight-ish leading edge (17 %) on HA freeride. LE bumps only on pumping/dockstart/surf wings: pitch 53-63 mm, height 5-6.6, 15-85 % of half span. Winglets only on the HA downwind wing and the carving stab. Weight about 0.75 kg per 1000 cm². Use these as the sanity check when a user's design sits outside the table above.

## Section

| Item | Typical |
|---|---|
| Camber % | 3-4 pump/SUP/surf, 2-3 wing/eFoil/wind, 1.5-2.5 kite; stab 0 (or -1 to -2 inverted) |
| Root thick % | 11-14 front wing (AFS: 11-13 at every AR; 9-10.6 on their all-round and race wings), 8-10 high speed, 8-11 stab (AFS stabs are 4.5-7.4 mm thick, 6-11 % of chord); a full-base stab (Double taper) runs thinner at the root than outboard, 7-8 % root / 9 % tip, so the wide root carrying the bolts is not a bump (AFS U Carve: 5 mm on a 68 mm root, 7.4 %) |
| Profile | NACA 4-digit for anything parametric; E817/E818 the DIY hydrofoil standards; NACA 63-412 laminar; Clark Y flat-bottomed, the easy one to lay up and check flat, and on a stab its flat face mates to the fuselage (Invert on). All four have Built-in polars |
| Section CL max input | 1.0-1.2 for 8-10 % thick low camber, 1.2-1.4 for 12 % with 2-3 % camber, 1.4-1.6 for 14 % with 4 % camber; lower on small stabs (low Reynolds number) |

## Stabiliser and pitch

| Item | Target | Why |
|---|---|---|
| Stab area / wing area | 0.15-0.22; AFS pair at 0.14-0.17 with 650-680 mm fuselages and AR 8-14 stabs (tail volume 0.65-0.8) | Below: weak pitch damping; above: extra drag |
| Stab AR and pairing (AFS) | 8 with learning wings, 9-10 surf and carving, 14 downwind; shim half a degree to a degree between pairings, i.e. about 1 deg of Decalage | Higher-aspect stab with higher-aspect wing |
| Stab planform | Superellipse n 2.5-4, or Double taper Break 20-30 % / Mid 0.55-0.7 / Tip 0.15-0.3 / Blend 8-15 with Tip cap = Rounded + plan for the full-base outline of current production stabs (U Carve 130: 30 / 0.60 / 0.23 / 10, cap 18 mm at 30 %, AR 10, Align 0, Sweep tip 25) | Full base: the mount and both bolts sit in the wide root, and the outer stab can be high aspect |
| Tail volume | about 0.5-0.8 | Estimate for typical foils; higher = more stable and damped, slower to pitch |
| Arm | 550-800 mm (short 450-550 surf, long 700-900+ pump) | Longer = more stable, less pitchy |
| Geometric decalage | 1.5-3 deg | Sets how much stance shifts with speed (see levers) |
| Stab CL across the speed range | within about +/-0.5; warning above 0.8 | Stab near its own stall is unpredictable |
| Static margin at take-off speed | positive; under about 5 % MAC feels twitchy | Lowest point of the range. With Propulsion on and a motor pod, judge static_margin_powered_pct instead - a high thrust line lowers it |
| Stance shift take-off to max speed | tens of mm is normal; over about 100 mm is a lot to move | Depends on decalage and camber |
| Board attitude (alpha) at cruise | within a few degrees of level | Riders dislike riding nose-up or nose-down |

## Performance sanity

| Item | Guide |
|---|---|
| Take-off % of CL max | under 80-85 %; 100 % = cannot fly at that speed |
| Stall vs take-off speed | stall roughly 15-25 % below intended take-off |
| L/D wing + stab only | high-teens to mid-20s for efficient designs at best-L/D speed. With a real Foil mast + Foil fuselage present, expect roughly 5-10 points lower at cruise once their drag is added - always quote which one a number is; the notice splits out mast and fuselage/pod drag |
| Other cm^2 | 1-4 - junctions, the wing socket nacelle, fittings, bolt heads only. Do NOT put the mast, fuselage or motor pod here: Foil performance computes their drag directly from Foil mast / Foil fuselage |
| Cavitation number at max speed | should exceed the section's -Cp min; below about 1.5 check with XFoil |
| Depth / MAC | above 2 to avoid free-surface effects |

## Structure

| Item | Guide |
|---|---|
| Load factor | 3 general, 4-5 pumping/jumps/hard landings, 6+ kite freestyle |
| Cap stress | 300-500 MPa wet-laid UD carbon with margin, 600-900 prepreg |
| Cap thickness | comfortable under about 20 % of the root section depth; if more, thicken the root section, widen the caps or accept a lower load factor |


## Propulsion and powered trim (eFoil / foil assist)

Full guide and sanity checks: propulsion.md. The headline targets:

| Item | Guide |
|---|---|
| Powered static margin | >= 5 % MAC from the lowest speed the motor is used while foiling (usually take-off) |
| Cruise throttle | 40-70 %; over 85 % at cruise leaves little margin |
| Cruise motor current | a third to a half of the limit or less |
| Static thrust | several times cruise drag (ploughing before lift-off is not modelled) |
| Foil-assist pod-out depth | >= 2 MAC or it is not a real mode (the tool then calls the layout eFoil) |


## Mast, joint and molds

| Item | Guide |
|---|---|
| Mast side load case (*Mast side g*) | 0.3-0.5 g of all-up mass is a hard carve; 1 g is a severe design case |
| Mast deflection at 1 g | tens of mm is typical for a carbon mast; halve it by adding about 40 % to the section thickness |
| Mast cap stress | worst point, not only the plate, under about 225 MPa (factor of 2 on wet-laid UD) |
| Mast plate junction shear | under the allowable (Shear allow / 2); 3-5 tab plies per face usually gets it well under |
| Mast thickening | start it near the waterline at ride depth: it adds stiffness with no wetted thickness |
| Wing tip deflection at the load factor | a few % of the half span at most; stiffer feels more direct |
| Minimum tip thickness | 1 mm or more molds reliably (*Min tip* on) |
| Stab seat | *Height* -3 to -5 mm with the pad on top, +3 to +5 with it underneath |
| Stab bolts | M5 or M6 for small stabs, M6 to M8 for large |
| Mast section (AFS) | constant top to bottom: chord 105-135 mm, thickness 10-13 % of chord (12.3-16 mm), 65-95 cm, 1.3-2.3 kg; UHM carbon quoted at up to twice standard stiffness |
| Fuselage (AFS) | 650-680 mm, 32.5 mm carbon or 27 mm titanium (23 % less drag, 30 % stiffer, twice the weight), two stab positions |
| Mold tiles | fewer is better; each seam is a line to fair on the part |
| Clark Y incidence | ask what line a flat-bottomed plan's angle is measured to. Flat mounted directly on the fuselage: the quoted angle is the chord to the flat and goes straight in as Incidence (negative for a stab hung flat side up); the tool's table has its chord 2.1° from its flat, so 2.1 / −2.1 puts the table's flat on the bar. Angle quoted for the flat itself: add 2.1° for the chord |
| Fibre volume | 45-50 % wet layup clamped in a matched mold, 55-60 % bagged or prepreg |
| Closing | *Closing* = Clamps (default) or Vacuum bag round the whole mold: the bag gives bag pressure x block plan area (5-15 kN), 1.5-4 bar on the laminate, uniform; with the bag set *Overcharge %* 3-5, keep *Groove vents* on and *Edge round* 4-6 mm; the notice's "holds X cm3 against Y cm3 of flash" must have X above Y or deepen *Groove depth* |
| Printed core | *Core* = Printed core: the mold feature generates the core as printable segments with two dowel holes at each joint, either side of the thickest point. Print with 2 walls and 10-15 % gyroid, standing on the joint face (mold settings with 5 walls gave a near-solid 510 g core: 1000 kg/m3). *Core kg/m^3* = slicer filament mass / core volume from the LAYUP line: the Silk V2 core at 2 walls and 15 % gyroid sliced at 297 g on 508 cm3 = 580 (5 walls gave 1000); *Core GPa* 0.5-1 |
| Core clear | with the wing's tube socket on and *Clear socket* ticked, a foam or printed core starts at the nacelle radius + *Core clear* (15 mm) each side; the root zone is solid laminate, counted as fill in LAYUP ("root zone solid"); do not set 0 unless the socket wall is meant to be the only solid material there |
| Core mold | a second Foil mold on the same part with *Mold of* = Its foam core: molds the foam itself (sections less the skins, cap grooves), open at the tips for a poured expanding foam |
| Core | Tow fill for a solid laminate; Foam core (Corecell M80 85 kg/m3, Core GPa 0.1) to match production weights, about 0.75 kg per 1000 cm2 of wing; Monolithic where stiffness matters more than weight |
| Mold material | PLA for wing and stab molds with a slow hardener and room-temperature cure (softens at 55-60 °C); PETG for the mast mold and anything post-cured (up to about 60 °C). Print each tile standing on its spanwise end so every layer contains the section profile and the steps run along the span, not across the cavity; 0.16-0.20 mm layers, 5 walls, seam at a back corner, 8-10 mm brim, 15-20 % adaptive cubic infill with 40 % only under flanges and keys (a stab mold with the default 25 mm flange and 20 mm base sliced at 1.29 kg / 19 h with 5 walls and light infill, 1.69 kg / 39 h with dense gyroid); for a stab, Flange width 18 and Base thickness 16; enter the printer height as Printer Y; seal with epoxy, sand to 800-1200, wax. Full settings in the user guide, section 6.4 |
