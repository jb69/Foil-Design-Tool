---
title: Foil Design Tool for Onshape
subtitle: User guide, design notes and parameter reference
build: 176
---

# Foil Design Tool for Onshape

**User guide, design notes and parameter reference. Build 176 (wing 1.035, stabiliser 4.018, performance 1.018, mast 2.009, fuselage 4.012, mold 2.099).**

By JB69. Licensed under Creative Commons Attribution-NonCommercial-ShareAlike 4.0 (CC BY-NC-SA 4.0): share and adapt it for non-commercial use, with credit, under the same licence.

**Two things before anything else.** First, this is a modelling exercise, not the advice of a foil builder. The tool started as a side quest to the B-series propeller blade generator: sizing a prop needs a drag curve, a drag curve needs a foil, and a nine-hour flight turned that into six features. Second, every number the tool produces is a steady-state, constant-value estimate: one speed, one weight, flat water, a rider who doesn't move. Real foils live in chop, pumping, turns and landings, and they break on peaks and repetition. Trust the trend from one variant to the next; treat absolute numbers, stall speed especially, as optimistic until you have calibrated them against something you have ridden (see 10.1).

This document accompanies the *Foil design* Feature Studio. It explains what the tool does, how the six features work together, what every parameter means and how to use it, and the hydrofoil design and construction knowledge that was worked out while building it. It is written for a rider who designs and builds their own foils: pump, SUP and surf, wing, windfoil, kite and eFoil are all first-class targets.

## Contents

1. What the tool is
2. Quick start
3. The six features
4. Reading the results
5. Design knowledge
6. Building knowledge: layup, structure, molds and printing
7. Worked example
8. Parameter reference
9. Console log reference
10. Model limits, versioning and the AI assistant

---

# 1. What the tool is

The tool is a single Onshape Feature Studio containing six custom features. Used in order in a Part Studio, they turn a handful of design decisions into a complete hydrofoil: front wing, stabiliser, mast with an optional motor pod, round tube fuselage, a full performance and stability analysis, and a set of 3D-printable molds with a layup schedule and fabric cutting templates.

| Feature | What it makes | Reads | Publishes |
|---|---|---|---|
| **Foil wing** | The front wing, optionally with a tube socket and nacelle for a round fuselage | nothing | area, span, MAC, incidence, zero-lift angle, the analysis model, the socket position |
| **Foil stabiliser** | The rear wing, placed by Arm and Height behind the wing, optionally linked to the wing, with the production-style mount pad, tail fairing and bolt holes | the wing (link ratios, the tube socket axis the seat Height is measured from) | area, position, the mount contour and bolt pattern |
| **Foil performance** | No geometry. A speed sweep of lift, drag, trim, stability, structure, propulsion and energy | wing, stab, mast, fuselage | the spanwise bending loads used by the mold's stiffness check |
| **Foil mast** | The mast: tapered, thickened at the top, with a root fillet into the board plate, optional motor pod with a placeholder cavity, plate with bolt holes | the wing pivot (position only) | the mast law and plate for the mold and the fuselage pocket |
| **Foil fuselage** | The round tube: spigot into the wing socket, seat cut to the stab's mount contour, tapped holes matching the stab's bolts, mast pocket | wing socket, stab mount, mast | the fuselage shape for performance |
| **Foil mold** | Two-part (mast: three-part) printable molds for the wing, stab or mast: parting curtain, locator keys, pinch-off groove, undersized bolt cones, plugs, printer tiling, plus the layup, material and resin estimate, stiffness check and cut-template plate | the part and every model above | nothing |

**Frame and conventions.** X points downstream (leading edge to trailing edge), Y along the span, Z up. The wing's root pivot, the quarter chord by default, sits at the world origin. Sections are streamwise. Incidence is positive leading edge up. *Decalage* is wing incidence minus stab incidence. Span is the projected tip-to-tip distance seen from above. Area is projected by default and always reported.

**Design philosophy, as decided during development.**

- Everything is parametric and mathematical: no sketches to draw, no freehand surfaces. Change a number, regenerate, read the notice.
- Foil area is a first-class input. You choose an area and an aspect ratio; the planform is solved to hit them exactly.
- The stab's arm and height are design decisions that belong with the wings. The mast and fuselage are structural parts that read those positions and never set them. The one deliberate exception is the stab's *Height*, which is measured from the wing's tube socket axis so its mount always lands on the fuselage.
- Discipline-neutral: nothing assumes an eFoil. Every tooltip gives typical values by discipline.
- Foils are carbon laid up in printed molds, not printed parts. Structural advice assumes carbon: woven skins, unidirectional caps and carbon tow.
- Every parameter has a short label so its value stays visible in the dialog, and a tooltip with limits, typical values and what the parameter does.
- Warnings tell you which field in which feature fixes the problem.

# 2. Quick start

1. In a Part Studio, open *Add custom features*, search for **Foil designer** and add it. The six features appear in the toolbar. This guide is the PDF in the same public document: right-click any of the features and choose *Open linked document* to find it again, and that document also has an example Part Studio with all six features placed.
2. Add **Foil wing**. Pick a discipline-appropriate area, aspect ratio and section; leave the rest at defaults. The notice shows the area achieved, span, MAC and root chord.
3. Add **Foil stabiliser**. Set Arm, and Height as the seat offset from the fuselage centreline (−4 mm with the pad on top). Leave *Link to wing* on to size the stab as a fraction of the wing; the decalage is then set by *Link decalage*. Turn on the *Mount pad* if the stab will bolt to a tube fuselage.
4. Add **Foil performance**. Enter rider plus board mass, water, ride depth and the speeds you care about. Read the notice: L/D and power at cruise, stall, take-off margin, trim CG, static margin, root bending and cap thickness. Turn on *Log inputs* and open the FeatureScript console for the full sweep as CSV.
5. Add **Foil mast** and **Foil fuselage** when you want the structure. The performance feature picks up their drag automatically, so *Other cm²* is only for fittings.
6. Iterate. Change one or two things at a time and compare notices. The console lines (`WING_INPUTS`, `STAB_INPUTS`, and so on) capture every input and are what you paste when asking for help, whether on a forum or to the AI assistant in section 10.3.
7. Add **Foil mold** for each part you will build, select the part, set your printer's bed size, and read the layup and stiffness lines. Turn on *Cut templates* to get a plate whose top face exports as one DXF of every fabric shape.
8. Keep any custom geometry that the mold must follow, such as a hand-modelled motor cavity in the pod or fillets and chamfers on the mast's plate, *above* the mold feature in the feature list. The mold cuts its cavity from the part as it stands, and sizes the mast's plate tray from the plate as modelled.

## 2.1 The download package

Everything outside Onshape comes as one zip, `foil-design.zip`, from the GitHub repository at https://github.com/jb69/Foil-Design-Tool (direct download: https://github.com/jb69/Foil-Design-Tool/raw/main/foil-design.zip). Unzip it anywhere; nothing installs. This guide's PDF is in the repository as well, so it can be read in the browser without downloading the zip.

| In the zip | What it is for |
|---|---|
| `foil_design.fs` | The Feature Studio source. Only needed if you want your own copy of the features rather than the published ones: in your Onshape document create a Feature Studio, select all its text and paste this file over it. The six features then appear under *Custom features* in that document's Part Studios. |
| `docs/` | This guide as PDF and as Markdown, its charts, and `parameters.md`, a table of every dialog field with its limits, default and tooltip |
| `assistant/` | The AI assistant of section 10.3: the Claude skill, the portable file for other assistants, its four scripts and a README with the setup for each |
| `examples/` | Two complete console logs and a speed sweep to try the assistant on before you have a design of your own, and `examples/afs/`, the AFS production range as parameter sets (section 5.8) |
| `tools/` | The scripts that rebuild `parameters.md`, the portable file and this PDF from the sources. Only for anyone changing the Feature Studio. |
| `LICENSE` | CC BY-NC-SA 4.0 |

Use the package like this: add the features in Onshape (step 1 above, or paste `foil_design.fs` for your own copy), design with the guide open, and when a run needs a second opinion, give the assistant in `assistant/` your console log. `examples/afs/` is the place to start when you want to model a foil you know: each document lists the dialog values, feature by feature.

# 3. The six features

## 3.1 Foil wing

The wing is built from an area-first planform solver: you give target area and aspect ratio (or span and root chord), the chord distribution shape (superellipse of exponent *n*, linear taper, or double taper), and the solver finds the root chord that hits the area exactly. On top of that: an alignment line (which chord fraction stays straight in plan), power-law sweep, tip drop with an anhedral exponent and optional root dihedral, washout, a thickness distribution from root to tip, incidence about a chosen pivot, a tapered or rounded tip cap, and a minimum tip thickness.

**Chord distribution.** *Superellipse* gives the rounded outline most wings have: exponent 2 is elliptic, 3 to 4 fuller with squarer tips, and the end ratio sets the small end face. *Linear taper* is a straight taper to a square tip. *Double taper* is two tapers: a steep one from the root to *Break %* of the half span, where the chord is *Mid ratio* of the root, then a gentle one to *Tip ratio*, with *Blend %* rounding the corner between them (0 for a sharp kink). That is the full-base shape of production stabs such as the AFS U Carve, whose outline the tool reproduces to about 1 % with Break 30, Mid 0.60, Tip 0.23 and Blend 10, and a high-aspect wing with a broad centre section. Linear and double tapers end square; *Tip cap* = Rounded + plan shrinks the chord along the cap's quarter-ellipse as well as the thickness, centred on the mid-chord whatever *Align line %* is, so both tip corners round and the area solver allows for it.

**Span line.** *Tip drop* is the anhedral, how far the tip sits below the root; *Drop shape* is how it is spread. *Power law* with *Drop exp* steepens all the way to the tip (2–3 gives a flat centre with the tips dropping late). *S-curve* is a smoothstep: flat at both ends and steepest in the middle, so the wing levels off again before its tips; that is the gull front view of a production surf wing, and the AFS Silk V2 measures as an S-curve from 3 % to 91 % of the half span with 45 mm of drop, to 0.3 mm. *Drop from %* and *Drop to %* set where the drop starts and finishes; beyond *Drop to %* the line runs level until a winglet bends it. *Gull dihedral* is the slope leaving the root for a true gull that rises before it falls.

**Winglets.** *Winglet* Up or Down bends the outer part of each half span through *Winglet angle* on an arc of *Bend radius*, then straight to the tip. Its size is *Winglet area*: the chord distribution continues along the bend, and the tool solves how much of the half span to bend so that area comes out. For a fin-like winglet use a small radius, 20 to 40 mm; for the smooth upturned tip of a downwind wing set *Bend radius* near the winglet's own length (150 to 250 mm), so the whole winglet is the arc and there is no straight leg to read as a kink. Every section beyond the bend is drawn square to the bent path, so a 90° winglet keeps its true section; the old route, *Tip drop* with a high *Drop exp*, keeps the sections vertical and only suits a gentle upturn. Area and aspect ratio stay the developed values of the whole half span, winglet included; the notice adds the winglet height, its projected area and the projected span. Foil performance credits a winglet as extra effective span for induced drag (0.9 × its height across the pair, the usual first estimate). Foil mold molds a winglet up to 75°: the parting follows the bent tip, and the mold block grows by the winglet's height; steeper winglets cannot release from a two-part mold pulled vertically.

**Leading-edge bumps.** *LE bumps* puts tubercles on the leading edge: it moves forward and back sinusoidally along the span by *Bump height* peak to trough, every *Bump pitch*, between *Bumps from %* and *Bumps to %*, fading in and out over half a pitch at each end. The trailing edge stays where it is, so the chord swells at each peak; the section is stretched there with its thickness in millimetres unchanged. Six stations per pitch are added so the loft draws each bump, which slows regeneration. Foil mold follows the bumps exactly.

The theory. Tubercles come from humpback whale flippers. Each bump sheds a pair of streamwise vortices that carry high-energy flow into the boundary layer behind the troughs, so the flow there stays attached to a higher angle of attack, and the wing's stall becomes gradual and partial instead of sudden: wind-tunnel tests (Miklosovic and others, 2004; Johari and others, 2007) show the stall angle rising by several degrees and lift retained well past it, with a small drag penalty below stall and, on some sections, a small loss of maximum lift. On a foil that is take-off, pumping and hard turns, which is where the makers put the claim; AFS measure about a 55 to 65 mm pitch and a 5 mm height on their wings, from about 15 to 85 % of the half span.

The caveat. *Foil performance ignores the bumps.* Its lift and drag come from lifting-line theory on the smooth chord distribution and from two-dimensional section polars, and neither can see a spanwise-periodic leading edge. The stall speed, the take-off margin and the drag it reports are those of the plain wing; if the bumps do what the tests suggest, the real stall is a little later and the real drag a little higher, and the tool will not tell you by how much. Treat them as a build feature you choose on the evidence above, and calibrate the stall against a ridden foil as section 5.3 describes.

**Sections.** NACA 4-digit is fully parametric (camber, camber position, thickness). Four published sections are built in as digitised coordinate tables: Eppler E817, Eppler E818, NACA 63-412 and Clark Y, the classic flat-bottomed section whose lower surface is straight from 30 % chord back. A tabulated profile fixes its own camber; Root and Tip thick % scale its thickness. *Tip profile* lets the section change along the span (give the Foil mold 22 or more *Split stations* when it is on; the parting needs them where the section changes): the root section runs out to *Blend from %* and then blends point by point into the tip section (any of the five, with its own *Tip camber %* and *Tip camb pos %* for NACA), reaching it at the tip, the way production wings run a cambered root out to a flatter, thinner-nosed tip that stalls later. The mold follows the blend, and so does the performance sweep (section 4.4). The trailing edge is held at a real thickness for moldability and thinned automatically near the tip so it never exceeds 3 % of the local chord.

**Section polar.** Analytic (thin-aerofoil theory) is the default. *Polar summary* takes thirteen numbers fitted from an XFoil or XFLR5 run at two Reynolds numbers; *Built-in* uses stored polars for the tabulated sections. With a polar, stall and profile drag come from the real section rather than from the Section CL max stand-in.

**Tube socket.** For a round fuselage the wing grows a nacelle with a socket for the tube: tube diameter and clearance, wall, blend and rear extension, depth, and cross pins. The socket's axis is what the fuselage spigots into and what the stab's Height is measured from.

**Notice.** Area achieved and definition, span, aspect ratio, MAC, root and tip chord, tip cap, thickness, incidence and washout, and the socket if on.

## 3.2 Foil stabiliser

The stab shares the wing's geometry core, so every planform, section, twist and tip control is the same. Two of those matter more on a stab: *Double taper* makes the full-base outline of current production stabs, a wide root that carries the mount and bolts flaring into a slim outer stab, and a *Root thick %* below *Tip thick %* keeps that wide root from becoming a bump (the U Carve is 5 mm on a 68 mm root chord, 7.4 %). What is specific to the stab:

**Root tail.** The stab's own outline can carry the tail: *Tail length* extends the trailing edge at the centreline and *Tail span %* fades it out, smoothly at both ends, so the root ends in a rounded point behind the trailing edge as on a production stab. The extension is all aft whatever *Align* is, the section keeps its thickness in millimetres and is stretched rather than fattened, and the area solver counts it, so the base chord shrinks a little to pay for it. With it on, the mount pad's *Tail* can be off and the fuselage ends at the stab's trailing edge.

**Position and link to wing.** Arm is the distance along X from the wing pivot to the stab pivot, the pitching moment arm. Height is the vertical offset. *Link to wing* derives area, aspect ratio, thickness and incidence from the wing's reported values through an area ratio, an AR offset, a thickness offset and a decalage, so the stab follows when the wing changes.

**Height is where the seat sits.** When the wing has a tube socket, *Height* is the offset of the stab's seat plane, the pad face or the bare root surface, from the fuselage centreline, positive up; 0 puts it on the centreline. The stab is built and then moved so its seat lands exactly there, so resizing or relinking it never moves the joint. With the pad on top, 0 cuts the fuselage flat to half the tube and −4 mm is typical; with the pad underneath (the stab sits on top of the fuselage), +4. A seat plane below the tube is also valid: the fuselage's block carries the stab and the tube stays round. Without a socket on the wing, Height is the pivot's offset from the wing pivot. The notice and the `pivotZ_mm` log field report where the pivot ended up.

**Mount pad: a fixed interface.** Modelled on the Axis rear wing after studying a real one: a flat pad face on the fuselage side, faired up from the leading edge, with a tail fairing behind it that forms the lower half of the fuselage's tail. The mount is pinned to the stab pivot, not to the root section: *Flat start* is where the seat flat begins, *Tail start* is where the fairing and the fuselage tip begin to taper, *Tail end* is where both finish, *Bolt 1 at* and *Bolt pitch* place the bolts; all in millimetres from the pivot. Only the ramp from the leading edge to Flat start adapts to the stab. The fairing stays full width from the trailing edge to Tail start, so a small stab simply has a longer tail. Every stab with the same Arm therefore presents the same seat plane, flat length, tapped-hole pattern and fuselage tip: any stab fits any fuselage built for that arm. The notice warns and holds the geometry when a section does not fit the interface.

**Mount bolts.** Through holes on the centreline, chosen by *Bolt* size (M4 to M10, or custom hole sizes). The stab owns the pattern: it cuts the close-fit clearance hole and, with *Countersink* on, a 90° countersink to the ISO 10642 head diameter on the face away from the pad; the fuselage taps blind holes at the same positions with the matching tapping drill, read from the stab so the two can't disagree; the mold puts undersized cones there to be drilled and countersunk after cure.

| Bolt | Clearance hole | Tapping drill | Countersunk head |
|---|---|---|---|
| M4 | 4.4 | 3.3 | 8.96 |
| M5 | 5.4 | 4.2 | 11.2 |
| M6 | 6.4 | 5.0 | 13.44 |
| M8 | 8.4 | 6.8 | 17.92 |
| M10 | 10.5 | 8.5 | 22.4 |

The mast plate and the wing socket's cross pin use the same dropdown, with the clearance 0.1 mm looser because several holes have to line up across two parts.

**Notice.** Planform summary, the mount description with the fixed-interface positions, the bolt holes, the seat report, and with a wing present: area as a percentage of the wing, tail volume, geometric and aerodynamic decalage.

## 3.3 Foil performance

Builds no geometry. It reads every model above and runs a speed sweep from take-off to max speed:

- **Lifting line** for the wing and the stab (span efficiency, lift slope, induced drag), the classic far-field downwash at the stab, and a trim solution at each speed: the body angle and the stab load that carry the mass in level flight.
- **Profile drag** from flat-plate skin friction with a thickness form factor on the real wetted area, plus a lift-dependent term, or the section polar's own drag bucket when one is given.
- **Mast, fuselage and pod drag** computed from the Foil mast and Foil fuselage features: submerged mast friction plus spray where it pierces the surface, pod friction on its wetted fraction, fuselage body friction. *Other cm²* is only for junctions, fittings and bolt heads.
- **Stall** where the first section inboard of 95 % span reaches the section's CL max; **take-off margin** as a percentage of CL max at the take-off speed.
- **Trim CG** (where the rider's mass must sit for level flight) and **static margin** (its distance ahead of the neutral point, as a percentage of MAC) at every speed.
- **Structure**: half-wing root bending at the load factor, the UD cap thickness needed for the chosen cap stress and width, and the spanwise moment distribution published for the mold's stiffness check.
- **Propulsion** (optional): Wageningen B-series open-water propeller, motor kV, cells, gearing, current limit and winding resistance, pack capacity. It solves thrust equals drag at every speed and reports rpm, throttle, current, battery watts, Wh/km, range and top speed, plus the powered trim: the thrust couple, the powered trim CG and the powered static margin.
- **Layout**: from Pod height it decides whether the foil is an eFoil (the pod can never clear the water at a rideable depth) or foil assist (the wing can ride with the pod out), and reports both modes.

**Notice.** One line: cruise L/D, drag and power, stall, take-off as a percentage of CL max, trim CG and static margin, root bending and caps; with propulsion, rpm, throttle, battery watts, Wh/km, range and top speed, and the powered trim. Warnings turn the notice yellow: stall at take-off, take-off within 15 % of stall, stab CL above 0.8, cavitation number below 1.5, depth under 2 MAC, propulsion out of limits, powered static margin under 5 %.

**Console.** The full report and a CSV with one row per speed. Its columns are listed in chapter 9.

## 3.4 Foil mast

The mast is a loft of symmetric NACA 00xx sections along a *mast law*: chord runs linearly from the base width to *Top chord*, with the taper on the leading edge, the trailing edge or both; thickness is constant to *Thicken from %* and then eases with a smoothstep to *Top thick* at the plate. A straight leading edge moves the plate aft relative to the wing, a straight trailing edge the reverse, so the taper side also moves the rider relative to the wing.

**Root fillet.** A fillet all round the section where it meets the plate's underside, held inside the plate with 2 mm to spare. Onshape will fillet the section's surface but not the 0.8 mm trailing edge line, so the fillet stops there and leaves a notch of trailing edge thickness; the console line `MAST_FILLET` reports the seam edges and the attempt that worked.

**Motor pod.** A streamlined pod on the mast for eFoils: diameter, height on the mast, where the nose starts, fairing length, blend height, aft extension, and *Pod tilt*, which rotates the pod about the span axis so the thrust vector can be aimed. The pod carries a placeholder cavity from its rear face (diameter and length parametric) that you are meant to replace or extend by hand with the real motor shape; the mold shapes its plug from whatever is there.

**Plate.** The board plate as a block with two rows of bolts on the track spacing, chosen by *Bolt* size (M8 by default), countersunk from below to the standard head diameter.

**Notice.** Height, chord and taper, thickness law, root fillet result, pod summary, plate.

## 3.5 Foil fuselage

A round tube with a spigot into the wing's socket, a body of the socket's tube diameter running aft, then a tail. With a stab mount present the tail is *seated*: the underside is cut to the stab's published mount contour (ramp then flat), the tip tapers from the stab's Tail start to its Tail end, blind tapped holes are cut at the stab's bolt positions to the chosen depth with the tapping drill for the stab's bolt, and a block under the flat fills the space when the seat is deeper than the tube. A pocket for the mast base and cross-pin holes matching the wing's socket pins are optional. The notice reports the seat, the holes made and any conflict, naming the field in the other feature that fixes it.

## 3.6 Foil mold

Select the finished part (wing, stab or mast). The mold feature:

- **Parts the mold** along a curtain built from the camber line's silhouette at up to 80 stations, with *Tip bias* packing stations toward the tip where the surface curls fastest. For the stab mount the parting steps onto the pad plane. The mast is molded flat in three parts: left and right halves plus a tray that forms the plate top, with straight locator pins. A stab with its pad underneath is molded upside down, as its mirror image, and turned over after cure; the notice says so.
- **Block and flange** of chosen size, **locator keys** (printed frustums or drilled pins), a **pinch-off groove** around the cavity in the lower half so the closing mold squeezes excess resin into a land, kept away from the pod. If a groove outline can't be built the mold finishes without it and warns, rather than failing.
- **Plugs** for the wing socket and the motor pod, extracted from the part's own cavities so that hand-customised pod interiors are reproduced.
- **Bolt cones** in the stab mount, undersized and tapered for release, on one face only, to be drilled to size after cure.
- **Tiles** the halves to your printer's bed, with staggered joints and keys between tiles, and a keep-out band so joints never fall on the pad, nacelle or pod.
- **Layup** from the part's own volume and surface: woven skins, UD caps sized as a percentage of the core inside the skins over a percentage of the chord, tow for the rest, the mast plate's woven fill, and the mast's cap run-out and tab plies into the plate. It prints the per-cap cut list and the material and resin to buy.
- **Stiffness** from that layup against the loads Foil performance published: tip deflection and root cap stress for wings; for the mast, the side-load case with deflection at the fuselage end, cap stress at the plate and at its worst point along the height, track bolt tension, the junction shear check and the plate's bending.
- **Cut templates**: a 1 mm plate beside the mold with every fabric outline cut through it and a row of tally holes under each shape for its cut count. Export the plate's top face as DXF.

# 4. Reading the results

## 4.1 The performance notice

`Cruise V km/h: L/D x · drag x N · x W | stall x km/h | take-off at x % of CL max | trim CG x mm · static margin x % MAC | root x Nm at n g, caps x mm`

- **L/D, drag, power** at cruise. Power is hydrodynamic, drag times speed. For an eFoil, battery power is roughly drag power divided by 0.45 to 0.6 overall efficiency; the Propulsion group computes it properly.
- **Stall** is the speed below which the foil cannot fly level with the whole foil trimmed.
- **Take-off at x % of CL max**: over 85 % is marginal, since gusts, pumping and turning all add load; 100 % means it cannot fly at that speed.
- **Trim CG** is where the combined centre of mass must be, in millimetres aft of the wing pivot, for level flight. The rider places it with their stance. It is an output.
- **Static margin** is the distance from the trim CG forward of the neutral point as a percentage of MAC. Positive is pitch-stable. It is lowest at low speed, so check the take-off row, not just cruise. With a motor pod, judge the powered static margin instead.
- **Root and caps**: half-wing root moment at the load factor and the UD cap thickness needed. "Impossible" means the root section is too thin for that load.

## 4.2 The CSV

`speed_kmh, alpha_deg, CL_wing, CL_stab, Re_wing_M, drag_N, drag_induced_N, drag_profile_N, L_D, power_W, trim_cg_mm, static_margin_pct, max_local_cl_pct, drag_mast_N, drag_body_N` and, with propulsion, `thrust_N, prop_rpm, J, eta_prop_pct, motor_A, throttle_pct, batt_A, batt_W, Wh_per_km, max_thrust_N, in_limits, thrust_couple_Nm, thrust_angle_deg, thrust_vert_N, trim_cg_powered_mm, static_margin_powered_pct`.

`alpha_deg` is the board attitude relative to the flow. The derived quantities that matter most:

- **Best-L/D speed and minimum-power speed.** If best L/D sits well below the cruise you care about, the wing is too big or too cambered for that speed; if above, too small.
- **Drag split.** Induced above profile means the wing is working hard: more span or AR helps. Profile above induced means excess wetted area or thickness: less area, thinner sections or a smaller stab. They are equal at best L/D.
- **Stance shift**, trim CG at take-off minus trim CG at max speed. Large means the rider must move a lot as speed changes, strong speed stability; small means a neutral foil that holds any speed but corrects less.

## 4.3 Quick scaling rules

- Stall speed goes with 1/√(area × CL max): 20 % more area gives about 10 % lower stall speed.
- Lift at a given speed and angle goes with area × speed².
- Induced drag at a given lift goes roughly with 1/span², so at fixed area with 1/AR. It dominates at low speed.
- Profile drag goes roughly with wetted area × speed², weakly reduced by Reynolds number. It dominates at high speed.
- Tail volume = stab area × arm / (wing area × wing MAC).
- Power = drag × speed, so at high speed it grows roughly with speed³.

# 5. Design knowledge


## 4.4 What the sweep sees, and what it doesn't

The geometry features and the performance model are not the same thing, and it pays to know which shapes reach the numbers.

**Fully in the figures:** area, aspect ratio and span; the chord distribution at every station of the lifting line (superellipse, linear, double taper with its blend, the root tail, plan-rounded tips), so the lift distribution and induced drag follow the outline; incidence, washout and its exponent; the section's zero-lift angle, moment and lift slope, and with a polar its CL max and drag bucket at two Reynolds numbers; a tip section, as a zero-lift angle that varies along the span (aerodynamic twist), a CL max checked station by station against the section that is actually there, and a drag bucket blended by area; the root thickness, through the profile-drag form factor; the wetted area, measured from the solid, so bumps, winglets, tail and nacelle all pay friction for their real surface; winglets as effective span for induced drag; and the mast, pod and fuselage through their own drag terms.

**Not in the figures beyond their surface area:** sweep (the lifting line is unswept); tip drop, the S-curve and gull dihedral (no anhedral effect on lift or stability); leading-edge bumps (their stall delay); the winglet's own side force; and the change of Reynolds number along the span (the MAC's is used). These are honest gaps: there is no formula at this level of model that would give them a number worth trusting.

## 5.1 Targets by discipline

| Discipline | Area cm² | Aspect ratio | Take-off km/h | Cruise km/h | Notes |
|---|---|---|---|---|---|
| Pump / downwind | 900–1500 | 9–14+ | 8–12 | 12–18 | Glide and low induced drag matter most; high AR, thin-ish sections |
| SUP / surf | 1200–2500 | 4–7 | 10–14 | 14–22 | Turning and low-speed lift; lower AR, more sweep and anhedral |
| Wing | 900–1800 | 6–10 | 12–16 | 18–28 | All-round compromise |
| Windfoil | 700–1200 | 6–10 | 12–18 | 25–35 | Higher speed; cavitation starts to matter |
| Kite race | 300–700 | 8–12 | 15–25 | 30–45+ | Small, thin, high speed; cavitation governs section choice |
| eFoil | 1000–2000 | 5–9 | 12–16 | 18–25 | Efficiency at cruise sets range; beginners want large area |

Scale area roughly with total mass for the same take-off speed. Section 5.8 checks these ranges against a measured production range.

| Section | Typical |
|---|---|
| Camber % | 3–4 pump/SUP/surf, 2–3 wing/eFoil/wind, 1.5–2.5 kite; stab 0, or −1 to −2 inverted |
| Root thick % | 11–14 front wing, 8–10 high speed, 8–11 stab |
| Section CL max (analytic) | 1.0–1.2 for 8–10 % thick low camber, 1.2–1.4 for 12 % with 2–3 % camber, 1.4–1.6 for 14 % with 4 %; lower on small stabs |

| Stabiliser and pitch | Target | Why |
|---|---|---|
| Stab area / wing area | 0.15–0.22 | Below: weak pitch damping; above: extra drag |
| Tail volume | about 0.5–0.8 | Higher is more stable and damped, slower to pitch |
| Arm | 550–800 mm; 450–550 surf, 700–900+ pump | Longer is more stable, less pitchy |
| Geometric decalage | 1.5–3° | Sets how much stance shifts with speed |
| Stab CL across the range | within about ±0.5; warning above 0.8 | A stab near its own stall is unpredictable |
| Static margin at take-off | positive; under about 5 % MAC feels twitchy | The lowest point of the range |
| Stance shift take-off to max | tens of mm normal; over 100 mm is a lot | Depends on decalage and camber |
| Board attitude at cruise | within a few degrees of level | Riders dislike nose-up or nose-down |

| Performance sanity | Guide |
|---|---|
| Take-off % of CL max | under 80–85 % |
| Stall vs take-off | stall 15–25 % below intended take-off |
| L/D wing + stab only | high teens to mid 20s at best L/D; expect 5–10 points less at cruise once a real mast and fuselage are added |
| Cavitation number at max speed | should exceed the section's −Cp min; below about 1.5 check with XFoil |
| Depth / MAC | above 2 to avoid free-surface effects |

## 5.2 Levers: what each change does

Measured with the tool's own maths on a 1200 cm² AR 7 wing with a 200 cm² stab at 650 mm, 100 kg:

- **Decalage is the stance-shift and speed-stability knob.** More decalage (stab incidence more negative, stab camber negative, or wing incidence up) makes the stab push down harder at speed: the trim CG moves forward as speed rises, a large stance shift, a foil that resists speeding up, higher static margin, a little more drag at speed. Less decalage gives a neutral foil that holds any speed with little stance change, but low-speed static margin falls toward zero. Going from decalage 1.5° to 3° roughly doubled the stance shift from 12 to 30 km/h (75 to 118 mm); decalage 0 cut it to 33 mm.
- **Wing incidence does not change stall speed.** It changes board attitude almost one for one and acts like extra decalage. Use it to level the board at cruise, not to fix take-off.
- **Wing camber** lowers the attitude needed and raises the real CL max, but adds nose-down moment: bigger stance shift and worse high-speed drag. Pair more camber with slightly less decalage.
- **Stab area and arm** raise tail volume and static margin and increase stance shift. Stab area adds drag at speed, about one L/D point at 30 km/h for 50 % more stab.
- **Aspect ratio at fixed area** is the big efficiency lever at low and medium speed: AR 7 to 10 gave +3.7 L/D at 12 km/h and +2.5 at 20 km/h, nearly neutral at 30. Costs: a longer, more flexible wing with a higher root moment, slower roll, less turning.
- **Area** trades low-speed for high-speed performance.
- **Powered foils** add the thrust line as a pitch lever: see 5.5.

| Symptom | First levers | Watch out for |
|---|---|---|
| Stalls at or near take-off | more area; more camber with a realistic CL max | top-end drag |
| Take-off fine but poor glide or pumping | more AR at the same area | root moment and cap thickness rise with span |
| Poor top speed, high power at speed | less area, thickness, camber; smaller stab | take-off speed rises |
| Best L/D well below cruise | wing too big or too cambered for that speed | |
| Best L/D well above cruise | wing too small: more area or AR | |
| Large stance shift | less decalage; less wing camber | low-speed static margin falls |
| Twitchy at low speed | more decalage, larger stab, longer arm | stance shift, drag |
| Nose-up or nose-down at cruise | wing incidence, and stab incidence by the same amount | |
| Stab CL near ±0.8 | larger stab, or stab incidence toward the unloading value | |
| Cavitation warning | thinner, less cambered sections; more depth | low-speed lift |
| Caps too thick or impossible | thicker root, wider caps, lower span, lower load factor | drag, weight |
| Twitchy under power | lower Pod height; longer Arm; motor only from a higher speed; then stab area | Pod height also sets eFoil versus foil assist |
| Stands much further back under power | thrust line far above the drag centroid: lower Pod height | |
| High Wh/km, short range | ride near the best-Wh/km speed; less drag; higher P/D if throttle is low at cruise | static thrust falls with P/D |
| Top speed too low | higher P/D, more cells, lower gear ratio if pitch-limited, more current if current-limited | |

## 5.3 Sections: where they came from, and what matters in water

The tool offers one parametric family and four published sections. Each was designed for a purpose and a flow regime, and none of them was designed for a 1 kg carbon wing under a board. Knowing what each was for makes its numbers easier to read.

**Two things separate water from air.** First, water is about 800 times denser than air, so a foil carries a rider at speeds where an aircraft wing would barely lift a hand: the section runs at modest lift coefficients most of the time, 0.2 to 0.5 at cruise, and only approaches its CL max at take-off. Where the section's low-drag range sits therefore matters more than how high its CL max is, except at the moment of take-off. Second, water boils at low pressure: where the local pressure on the suction side drops below the vapour pressure the flow cavitates, lift collapses and the surface pits. The cavitation number σ compares the static pressure margin at the foil's depth with the dynamic pressure, and cavitation starts where the section's −Cp min exceeds it. The tool reports σ at *V max* and *Depth*: about 2.0 at 36 km/h and 600 mm, about 1.1 at 50 km/h. A cambered 12 % section at CL 0.6 can reach −Cp min of 1.5 to 2, so above 45 km/h or so the section, not the planform, decides the top speed. That is why race sections are thin, lightly cambered and shaped for a flat pressure distribution. In between, the Reynolds numbers are those of a model aircraft rather than a full-size one: at a 150 mm chord and 6 m/s, Re is about 0.85 million (water's kinematic viscosity is 1.07 × 10⁻⁶ m²/s at 20 °C), where laminar flow is possible on a smooth surface and transition, and therefore drag and stall, are sensitive to finish. Structure is the other constraint: carbon stiffness goes with thickness cubed, so the 9 to 13 % sections of production foils are as much a structural choice as an aerodynamic one, which is what the stiffness check in chapter 6 is for.

**NACA 4-digit (1933).** Eastman Jacobs and his colleagues at NACA Langley tested 78 related sections in the variable-density wind tunnel and published them as Report 460. The family is defined by three numbers: maximum camber in percent of chord, its position in tenths, and thickness in percent, so a 2412 is 2 % camber at 40 % chord and 12 % thick. The camber line is two parabolic arcs and the thickness a single polynomial, which is why it is fully parametric here: *Camber %*, *Camber pos %*, *Root thick %* and *Tip thick %* give any member of the family, and the zero-lift angle and pitching moment come from the exact thin-aerofoil integral of that camber line. Designed for aircraft at Reynolds numbers of several million, the family is robust: tolerant of roughness, with a gentle stall at moderate thickness and a lift curve that XFoil and the wind tunnel agree on. Its drawback for a foil is that its pressure distribution has a sharp suction peak near the nose at high lift, so its −Cp min rises faster with CL than a section designed for water. For anything under 40 km/h it is a sound default and the easiest to reason about; the built-in polar for it is a fit across four real XFoil polars (0008, 0018, 2412, 4412), so it is coarse away from those anchors.

**NACA 6-series (1945).** The laminar-flow sections came from the same laboratory a decade later, designed inversely from a target pressure distribution to keep the boundary layer laminar over the front of the section, and summarised in Report 824 (Abbott, von Doenhoff and Stivers), the book most engineers still mean by "the NACA airfoil data". The P-51 Mustang was their famous application. The designation 63-412 reads: series 6; minimum pressure at 30 % chord on the basic thickness form at zero lift; design lift coefficient 0.4; thickness 12 %. Around the design CL the section has a drag bucket, a range of lift where friction drag drops by a third or more because the laminar run is long; outside it the drag rises to that of a conventional section. For a foil the attraction is that bucket, since the cruise CL of 0.3 to 0.5 sits inside it, and the aft-positioned minimum pressure gives a lower −Cp min at the same lift than a 4-digit. The catch is that the bucket exists only on a smooth surface with the transition where the design assumed: a pinch-off seam, a sanded repair or weed on the leading edge closes it, and the section then behaves like an ordinary 12 % section with a slightly earlier stall. XFoil at N crit 9 shows the bucket, which is why the built-in polar looks good; the tool's *Laminar run %* defaults to 0 because hand-laid parts rarely keep it.

**Eppler E817 and E818 (1979 to 1981).** These are the only sections in the list that were designed for hydrofoils. Richard Eppler at the University of Stuttgart, with Y. T. Shen of the David Taylor Naval Ship Research and Development Center, published "Wing sections for hydrofoils" in the Journal of Ship Research, symmetrical profiles first and cambered ones two years later, using Eppler's inverse design code. The design goal was not minimum drag but the widest cavitation-free range: a pressure distribution flat enough that −Cp min stays low across a band of lift coefficients, so a foil that changes speed and loading, as every ridden foil does, stays clear of cavitation over the whole band. The price is camber carried well aft, peaking near 67 to 69 % chord on both, which makes the zero-lift angle and the nose-down pitching moment larger than a 4-digit of similar camber, so the stab works harder and trim numbers move when you switch to them. They became the reference sections for small-craft and home-built foils because the coordinates were published and the purpose matched. E817 is the thicker of the two at 11.0 %, E818 at 9.4 % is the higher-speed choice; both have a slightly drooped nose that the tool handles by building each section from its own table rather than a camber line. The built-in polars for them come from XFoil at 0.2 and 1 million (E817) and 0.1 and 0.5 million (E818), which is the Reynolds range of a foil's tip rather than its root, so the *Section polar* group with your own run at the root Reynolds number is the better source for a large wing.

**Clark Y (1922).** Virginius Clark drew it for the U.S. Army Air Service: 11.7 % thick, with a lower surface that is straight from 30 % chord to the trailing edge, so a rib could be built on a flat board and checked with a straight edge. It carried the Spirit of St. Louis across the Atlantic and became the default section of model aircraft and propellers for fifty years, which means it has more test data at low Reynolds numbers than almost any other section. In water that history is the point: its CL max at 0.2 to 1 million is the highest of the four, so it is a good low-speed and take-off section, and its flat side is a build reference and a mating face. A stab built on it can sit flat side up against a fuselage, which is what the AFS U Carve's flat-sided section suggests and what *Invert section* is for. Two things to know. The flat is not the chord line: it is tilted 2.1° to it, so with the flat level the section is already at +2.1° chord incidence and about 5.5° above zero lift, making lift, and the tool's incidence is measured from the chord. And the tool scales the whole section vertically with *Root thick %*, so a thinner Clark Y keeps a straight flat but loses camber in proportion, and its zero-lift angle, moment and bucket centre scale with it, which is what the built-in polar does.

**The four sections by the numbers.** Geometry from the tool's own coordinate tables; thin-aerofoil values from their camber lines; the polar values from the built-in XFoil fits. The gap between the thin-aerofoil and polar columns is viscous decambering, largest on the aft-loaded Epplers.

| Section | t/c max, at | camber max, at | α₀ thin-aerofoil | α₀ polar | Cm₀ thin / polar | CL max at Re (polar) |
|---|---|---|---|---|---|---|
| NACA 4-digit | as set | as set | exact integral | 4-polar fit | exact / fit | fit |
| NACA 63-412 | 12.0 % at 35 % | 2.2 % at 50 % | −3.1° | −3.0° | −0.083 / −0.075 | 0.99 at 0.2 M, 1.31 at 0.5 M |
| Eppler E817 | 11.0 % at 33 % | 2.9 % at 69 % | −4.4° | −3.0° | −0.140 / −0.107 | 1.06 at 0.2 M, 1.15 at 1 M |
| Eppler E818 | 9.4 % at 33 % | 2.8 % at 67 % | −4.4° | −2.4° | −0.139 / −0.091 | 0.89 at 0.1 M, 1.03 at 0.5 M |
| Clark Y | 11.7 % at 28 % | 3.4 % at 42 % | −3.4° | −3.6° | −0.084 / −0.085 | 1.40 at 0.2 M, 1.52 at 1 M |

**Which to use.** Pump, surf and wing foils below 35 km/h: NACA 4-digit with 2 to 3 % camber, or Clark Y where take-off matters most and the flat side helps the build. Glide and downwind, where cruise sits in a narrow CL band and speed climbs toward 40 km/h: NACA 63-412 if the surface will be kept, E817 otherwise. Anything expected above 45 km/h: E818 or a thin, lightly cambered 4-digit, and check the cavitation number against an XFoil pressure distribution at the top speed and CL, since the tool reports only σ. Production wings run a cambered root section out to a flatter, thinner-nosed tip that stalls later; *Tip profile* does the same, and section 4.4 says how the sweep accounts for it.

**Polars and the model.** Analytic mode uses thin-aerofoil theory for the zero-lift angle and moment and a flat-plate friction estimate with a thickness form factor for drag, with *Section CL max* as the stall stand-in. The most accurate combination is a tabulated profile with a section polar: the shape from the table, the CL max and drag bucket from a real polar run at the actual Reynolds number. On a polar wing the Section CL max field is ignored; a better polar is the fix, not a bigger number. The stall margin is evaluated at the take-off Reynolds number, interpolated between the polar's two Reynolds numbers; the warning tells you when it is extrapolating. All the polars here are XFoil at N crit 9, a clean surface in steady flow, so every CL max is optimistic for a foil in chop; calibrate against a foil you have ridden (chapter 10).

## 5.4 Pitch stability and the linked stab

Static margin is lowest at the lowest speed, and under power it is lowest at the lowest powered speed, usually take-off. On the foil-assist example the pod's thrust line is what sets the lowest margin: see 5.5 and 7.1. The stab's height relative to the wing changes the trim only slightly; on a tube fuselage it is dictated by the fuselage anyway, which is why Height is measured from the fuselage centreline.

## 5.5 Powered foils: propulsion, thrust line and thrust angle

**Layout.** Pod height decides what the foil is. If the pod can only clear the water with the wing shallower than two MAC, it is an eFoil and the motor is always in. If the wing can still ride two MAC deep with the pod out, it is foil assist, and both modes are reported at their own depths. Riding with the pod partly submerged is the worst case, friction plus spray on its waterline.

**Method.** At steady speed thrust equals drag. The B-series polynomials turn the drag at each speed into prop rpm, torque, shaft power and prop efficiency; motor current follows from torque and kV, motor volts from rpm and winding resistance, throttle from pack volts, then battery watts, Wh/km and range. Top speed is where full-power thrust, falling with speed, meets drag rising with speed squared. Static thrust should be several times cruise drag because ploughing before lift-off is not modelled.

**Thrust couple.** Thrust and drag form a pure couple, so the CG height does not matter. A thrust line above the drag centroid, typical of a high pod, is a nose-down couple: the rider stands further back under power and the powered static margin falls. The couple barely changes with speed while the stab's correcting moment grows with speed squared, so the lowest powered margin is at the lowest powered speed. Lowering the pod is the direct fix; a longer arm and then stab area come next.

**Thrust angle.** The thrust vector is fixed to the body, so as the board pitches up at low speed the thrust points partly upward: on the foil-assist example it makes 7.3° to the flow at 15 km/h and gives about 9 N of vertical thrust. Pod tilt lets you aim the pod nose-down so the thrust is aligned at cruise and helps at take-off; the console reports the angle, the vertical component and the couple at every speed.

**Targets.** Powered static margin at least 5 % MAC from the lowest powered speed; cruise throttle 40 to 70 %; cruise motor current a third to a half of the limit; foil-assist pod-out depth at least two MAC or it is not a real mode.

## 5.6 Mast shaping

- **Taper side.** A straight leading edge moves the plate, and so the board and rider, aft relative to the wing; a straight trailing edge moves them forward. The trim CG in the performance output tells you where the rider needs to be; the taper side is one way to put the board there.
- **Thickness where it counts.** The side-load moment on the mast peaks at the plate, and the top of the mast is dry at ride depth. On the foil-assist example only 340 of 750 mm is submerged at 350 mm depth, so the waterline sits at about 45 % of the height: thickening from 50 to 60 % adds stiffness with no wetted thickness and no drag. Starting the thickening very high bunches all the build-up plies into the top few centimetres, where they do little.
- **The worst stress is where the thickening starts, not always at the plate.** The moment grows all the way up the mast but the section only thickens from *Thicken from %*, so the cap stress peaks just below that height. On the foil-assist example it is 243 MPa at about 500 mm against 198 MPa at the plate. The mold's stiffness line reports both; start the thickening lower or raise *Thickness* to flatten the peak.
- **Cap thickness barely matters once the caps are thick**: thicker caps sit closer to the neutral axis. Section thickness and where the thickening starts are the levers.

## 5.7 The stab-to-fuselage joint

Studied from a real Axis rear wing (STL) and a builder's video: the stab carries a flat mount pad on top, faired up from the leading edge over about 45 % of the chord, 22 mm wide, standing about 7 mm off the section; the tail of the mount continues behind the trailing edge as a fairing that becomes the lower half of the fuselage's tail; two M6 bolts at 35 mm pitch pass up through the stab into the fuselage. The fuselage sits over the stab on a flat seat that matches the pad contour exactly, so there is no gap and no step. Molded bolt holes are made undersized and tapered so the mold releases, then drilled to size after cure, and only from one face so the top and bottom cones never meet. The tool reproduces all of this, pins the interface to the stab pivot so any stab fits any fuselage built for the same arm, and places the seat by its offset from the fuselage centreline. The same joint works upside down, with the stab on top of the fuselage and the pad underneath, which suits a foil-assist fuselage.

# 6. Building knowledge: layup, structure, molds and printing

## 5.8 What a production range looks like: AFS, measured

The AFS range (afs-foiling.com, September 2026) is a useful yardstick because every part has published area, span, chord and thickness, and the plan-view renders are true to scale, so the outlines could be measured and expressed in this tool's own parameters. The per-family documents in `examples/afs/` carry the numbers; this section is what they teach. The sections, camber and twist are not published, so nothing here says what the profiles are.

**Front wings.**

| Family | Use | AR | Root thick % | Chord distribution | Align line % | Sweep aft, exp | Extras |
|---|---|---|---|---|---|---|---|
| Flyer | first flights | 6.3 | 10.7–11 | superellipse n 2.1, near elliptic | 69 | 43 mm, 3 | none |
| Evo | beginner to intermediate wing | 7.5–8.1 | 9 | superellipse n 1.7 | 38 | 70–85 mm, 3–4 | none |
| Pure | freerace, freestyle | 8.4–9.6 | 10.3–10.6 | superellipse n 1.8 | 73–80 | 18–58 mm, 3 | one-piece fuselage |
| Silk V2 | surf, downwind, carving | 9 | 11.9–12 | superellipse n 1.4, end 0.26 | 78 | 67 mm, 4 | S-curve drop, 45 mm from 3 % to 91 %, tips rising; bumps 59 / 5 mm |
| Enduro | all-terrain, dockstart | 11 | 10.8–11.9 | superellipse n 1.4, end 0.19 | 38 | 75 mm, 4 | bumps 53 / 5 mm; GLT 63 / 6.6 |
| Evo HA | high-aspect freeride | 12.1–13.3 | 11.9–12.2 | double taper, break 35, mid 0.83, tip 0.19, blend 12 | 17 | 61–72 mm, 2 | none |
| Ultra | downwind | 14–16 | 12.9–13.1 | superellipse n 1.5, end 0.17 | 87 | about 0 | S-curve drop, 21 mm from 15 % to 85 % on the 600, tips rising 12 mm; bumps 53 / 5 mm |

What the table says, read across:

- **Thickness ratio is constant across the range.** Every front wing is 11 to 13 % thick at the root, whatever its aspect ratio; only the Evo and Pure go to 9–10.6 %. So a high-aspect wing is thin in millimetres because its chord is short, not because its section is thinner: the Ultra 600 is 10.8 mm on an 84 mm chord, the Flyer 1800 is 22 mm on 205. Design the section ratio for the discipline and let the chord set the millimetres.
- **Aspect ratio tracks the discipline exactly as section 5.1 says.** 6 to 8 for learning and all-round, 9 for surf and carving, 11 for all-terrain, 12 to 16 for high-aspect glide. The 5.1 ranges hold; the AFS numbers sit inside them.
- **The outline changes with the discipline.** Low-aspect wings are rounded (superellipse exponents 1.7 to 2.1); mid-aspect surf and all-terrain wings are pointier in plan (1.4) with raked tips; the high-aspect Evo HA is a double taper with a broad centre and a blend at the break. That shape exists on front wings, not just stabs.
- **Where the straight edge is.** Surf, race and downwind wings keep the trailing edge nearly straight (Align line % 70 to 90) and put the curvature and the sweep on the leading edge; the high-aspect freeride wings do the opposite (17 %). The sweep is concentrated at the tips (exponent 3 to 4), 60 to 100 mm on an 850 to 1200 mm span, which is 7 to 8 % of span.
- **Bumps go with pumping, dockstart and surf,** on the Silk, Enduro and Ultra, never on the learning wings or the freerace Pure: pitch 53 to 63 mm, height 5 to 6.6 mm, from about 15 % to 85 % of the half span (see 3.1 for what they do and what the model cannot see).
- **The span line is an S, not a power curve.** The Silk V2's front view is level at the centre, steepest at mid-span, and levels off again by about 90 % before the tips rise: measured, it is a smoothstep from 3 % to 91 % of the half span with 45 mm of drop, to 0.3 mm, where the best power law misses by 1.8 mm. That is *Drop shape* S-curve, *Drop from %* 3, *Drop to %* 91, *Tip drop* 45, with a small upward winglet for the rise. AFS's own words are a more pronounced break near the centre and an ultra-progressive tip rise.
- **Winglets appear only on the high-aspect downwind wing,** as small upturned tips, and on the carving stab.
- **Weight:** 0.6 to 1.1 kg per wing, roughly 0.75 kg per 1000 cm², heavier for the one-piece Pure. The tool's layup estimate for the foil-assist example (1.6 kg for 1000 cm² with a tow core) is above this; AFS use Corecell cores or monolithic laminates and thinner skins.

**Stabilisers.**

| Family | Use | AR | Area cm² | Thick % (mm) | Outline | Extras |
|---|---|---|---|---|---|---|
| U-Cruise | all-round | 8 | 190–250 | 10 (7.2) | superellipse n 1.5, straight trailing edge | pronounced sweep, progressive anhedral |
| U Surf | surf | 9 | 120–150 | 9.4 (5) | superellipse n 1.4 on a mount base | bumps |
| U Carve | carving, glide | 10 | 130–160 | 6.3–7.4 (5) | double taper full base, break 30, mid 0.60, blend 10 | raised tips, flat-sided section |
| U Glide | downwind | 13.7–13.9 | 113–133 | 10.9 (4.5–5) | slim superellipse on a mount block | twist |

- **Stabs are 5 mm thick,** near enough regardless of chord: 4.5 to 7.4 mm across the range, so 6 to 11 % of chord. Set *Root thick %* from the millimetres you want, and on a full-base stab run the root thinner in percent than the tips (the U Carve is 7.4 % on its 68 mm root, 9 % outboard).
- **Stab area is 14 to 17 % of the wing** in AFS's own pairings: Silk 950 with the U Carve 130 to 160 (14 to 17 %), Silk with the U Surf 135 (14 %), Ultra 750 with the U Glide 41 (16 %), Evo 1450 with the U-Cruise 220 (15 %), Flyer 1800 with the U-Cruise 245 (14 %). That is the bottom of the 15 to 22 % band in 5.1, and it works because the arms are long (650 to 680 mm fuselages) and the stabs are high-aspect: tail volume 0.65 to 0.8.
- **Higher-aspect stabs go with higher-aspect wings.** AR 8 for learning, 9 to 10 for surf and carving, 14 for downwind.
- **Trim between pairings is small and stated:** AFS shim their stabs by half a degree to a degree, less stab angle for the carving and downwind stabs, more for the surf stab on older wings. In this tool that is a change of about 1° in *Decalage*, and the powered or gliding static margin at take-off is what to check after it.
- **The mount is part of the design.** Every AFS stab widens into a base at the centre, from a small block on the U Glide to the U Carve's full base; the wing hubs likewise run to 1.5 to 2 times the aerofoil root chord. In the tool the stab's *Root tail*, *Double taper* and *Mount pad* cover this; the wing has its tube socket nacelle instead.

**Masts and fuselages.**

- Masts run a constant section top to bottom: chord 105 to 135 mm, thickness 12.3 to 16 mm, so 10.3 to 12.7 % of chord, 13 % being the accessible sandwich mast and 10 to 12 % the stiff UHM ones. Lengths 65 to 95 cm; 1.3 to 2.3 kg. AFS quote UHM carbon at up to twice the stiffness of standard carbon and publish no deflection figures, so the tool's own mast stiffness check (6.2) is the only number you will have; set *Cap modulus* for the fibre you will actually use.
- Fuselages are 650 or 680 mm with a 32.5 mm section in carbon and 27 mm in titanium; AFS quote the slimmer titanium section as 23 % less drag and 30 % stiffer at twice the weight. In the tool that is *Tube dia* 27 to 33, and the fuselage drag term in the sweep will show the difference. Two stab positions are standard: a rear one for glide, a forward one for waves, which is *Arm* and *Bolt 1 at* here.

**What the range does not settle.** Sections, camber and twist. AFS describe thin, low-drag profiles for the high-aspect wings, a flat-sided section on the U Carve, and twist on the U Glide, and publish none of them. The suggestions in the AFS documents are starting points for calibration (5.3), not measurements.

## 6.1 The layup schedule

The mold sizes the layup from the part itself: its volume is the laminate volume, its surface carries the woven skins.

- **Skins**: *Skin plies* of *Skin gsm* woven on each face. On a two-ply skin turn the weave 45° on the outer ply for torsion.
- **UD caps**: *Cap thick %* of the *core inside the skins* (the local section less both skins), over *Cap width %* of the chord about the thickest point. The count is per cap; every UD template is cut twice, one per face. Ply k, outermost first, runs out to the last station where the stack is still k plies thick, so the caps taper along the span and the cut list gives every ply's length and its width at the root and at its end. On a mirrored wing a cap ply is one piece across the centre.
- **Tow**: whatever the skins and caps do not fill, given as a mass and a length at the chosen tex.
- **Cured ply thickness** = gsm / (1780 × fibre volume fraction); 300 gsm UD at 50 % is 0.34 mm. The one real-world check so far: a forged-carbon stab molded in a 3D-printed compression mold by Andrew W (YouTube) weighed 84 g for 60 ml of part, against 88 g from this formula at 50 % fibre volume. His build, with its printed matched mold, PVA release, wood-block clamping and molded bolt holes, is the method this feature automates.
- **Overcharge %** adds material above the exact fill so the closing mold packs the laminate and squeezes flash into the pinch-off. Cloth and resin waste percentages turn the in-part figures into what to buy and mix. Fibre volume 45 to 50 % for a wet layup clamped in a matched mold, 55 to 60 % vacuum bagged or prepreg.
- **Mast**: the cut list runs from the plate down, so the thickened top adds short plies at the plate end; the plate is a solid block of woven fill between its skins, with its own cut count; every cap ply runs out over the root fillet onto the plate; tab plies interleave with the caps, running down the mast and out over the plate, stitching the two surfaces together through the stack.

**The core.** *Core* chooses what fills the section between the skins and the caps. *Tow fill* is carbon roving laid along the span and wetted out, so the whole part is laminate: the heaviest and stiffest fill, and the tool's original assumption. *Foam core* is a shaped structural foam (Corecell M80, PVC H80, PET at 80 to 110 kg/m³) inside the skins and caps, which is how most production wings are built; the fill volume carries no fibre and no resin beyond a skim on its surface, so the part is a third to a half lighter, the caps and skins carry all the bending and the stiffness check drops accordingly, and the buy list adds the foam volume and the sheet thickness to cut it from. *Monolithic* fills the section with woven plies at the skin's ply thickness, as on high-modulus production wings: the same weight as tow, bought as cloth. *Printed core* is the foam core's shape 3D printed instead: the mold feature generates it as a part, split along the span to the longest axis of your printer, to be printed flat, glued end to end on a flat table and laid up in the part mold exactly as a foam core would be, with a dowel hole across each joint (along the span, 15 mm into each segment at the thickest point, sized at half the core's thickness there, 3 to 8 mm, for a carbon or hardwood rod; the notice lists them, and a joint too thin for one is said so); *Core kg/m³* is then the print's average density with its walls and infill (standard PLA at 10 to 15 % gyroid and two walls is about 600, PLA Aero about 320, ASA Aero about 230, read from the slicer's filament mass over the core volume) and *Core GPa* about 0.5 to 1 for solid PLA, 0.25 to 0.3 for a foamed filament. **A core keeps clear of the tube socket.** With the wing's socket on, a foam or printed core starts at the nacelle's radius plus *Core clear* (15 mm) on each side, as two mirrored halves, and the root zone between them is solid laminate: the socket wall and the laminate around it carry the fuselage's bending and the stab arm's moment into the wing, and the bore removes most of the root section anyway. The layup line counts that zone as fill and the printed core comes out as left and right sets of segments; the stiffness check does not see the bore and says so. It needs no core mold, and it is the quickest way to a core whose shape is exactly the tool's. On the Silk V2 example the tow fill weighs 1.33 kg and the M80 foam core 0.62, against AFS's published 0.9 kg for the wing with its mount hub, so the foam core is the honest comparison with a production part.

## 6.2 Stiffness and strength

Per station, bending stiffness EI = UD modulus × cap second moment + woven modulus × skin second moment (0.7 of the extreme fibre) + tow modulus × a lens-shaped core term. Curvature M/EI is integrated twice from the root to give the tip deflection; cap stress is E × M × y / EI at the root. Wings use the spanwise moment Foil performance publishes at the load factor. On the foil-assist example the wing at 4 g deflects 6.5 mm at the tip with 137 MPa in the caps, and the stab 1.9 mm with 100 MPa.

**Ply drops.** Plotting the stress with the real, whole-number ply count at each station instead of the smooth taper shows the drops change the local stress by about 1 % where it matters. The wing is limited by its taper, not by where the plies stop, so lay the drops where convenient and stagger their ends.

**Mast side load.** The mast is fixed at the plate by the board and rider, and a side force of *Mast side g* times the all-up weight is applied at the fuselage end, so the moment is force × height and peaks at the plate. The tool reports the deflection at the fuselage end, the cap stress at the plate, the track bolt tension (moment / track spacing / bolts per row), the plate's bending stress between the tracks, and the junction check below. One g of the whole all-up mass sideways is a severe case; a hard carve is nearer 0.3 to 0.5 g.

**The mast-to-plate junction is the weakest point.** In a 20 mm section the two caps are only about a centimetre and a half apart, so each carries tens of kilonewtons at the plate; on the foil-assist example about 38 kN. That force has to leave the UD by shear into the plate. With the caps folded 47 mm over the plate and nothing else, the shear would be about 19 MPa against an allowable of 15 (interlaminar shear strength 30 MPa with a factor of 2): the caps would peel off the corner. Four interleaved tab plies per face give nine bonded interfaces and bring it to about 2 MPa. The root fillet gives the plies a radius to turn through instead of a sharp fold. Tab plies take their thickness out of the tow core over the tab length; the layup line warns if there is not enough core.

## 6.3 Mold design

- **Printed PLA molds, carbon parts.** The molds are two halves parted along the camber line's silhouette so both halves release, with a 20 mm base and a 25 mm flange by default.
- **Stations and tip bias.** The parting curtain is lofted through up to 80 stations. Sections with a curled tip (a 6-series section with a strong tip drop) failed at 40 evenly spaced stations and worked at 50 with a tip bias of 4, which packs the stations toward the tip. If a mold fails to loft, raise the station count and the bias first.
- **Keys and pins.** Printed frustum keys with 12° draft, or drilled pin holes for dowels; pin fit clearance around 0.2 mm.
- **Pinch-off.** A land and a groove around the cavity in the lower half so the closing mold squeezes excess resin out and packs the laminate; kept off the motor pod so the pod's plug is undisturbed.
- **Plugs.** The wing socket and the motor pod need cores. The mold extracts them from the part's own cavities, so a hand-modelled motor interior, placed above the mold in the feature list, is reproduced in the plug.
- **Bolt cones.** Undersized, tapered, on one face only, drilled to size after cure. Molded holes become pins in the mold cavity; two opposing pins cannot meet.
- **The mast mold** is three parts: the mast laid flat, split at mid-thickness into left and right, plus a tray that forms the plate top with straight locator pins. Countersunk heads in the tray were tried and abandoned because they would not release. The tray is sized from the plate as it is in the part, not from the Foil mast's numbers: the mold splits a copy of the mast at the plate's underside and measures the plate side, so a plate you have edited by hand above the mold, with fillets, chamfers, a different outline or a different thickness, gets a pocket that matches. The bolt pins stay on the Foil mast's pattern, so move bolts in the mast's dialog rather than by editing holes. The console's `MAST_PLATE` line reports the measured plate against the nominal one and says when it found edits.
- **Closing.** *Closing* chooses what presses the halves together while the resin cures: clamps on the flanges against a rigid board, or the whole closed mold inside a vacuum bag. In a bag the atmosphere clamps the block uniformly with a force of the bag pressure times the block's plan area, about 5.7 kN on a stab mold and 14.5 kN on a 950 cm² wing mold at 85 kPa, and because the block is larger than the part the laminate sees more than the bag pressure, 1.5 to 4 bar. Choosing the bag rounds the block's outer edges (*Edge round*) so the bag is not cut, and vents the pinch-off groove to the block's outer face at each span end (*Groove vents*), since inside a bag the groove is otherwise a sealed pocket of air the flash cannot enter; the vents let the bag evacuate the groove and the laminate through it. Drop *Overcharge %* to 3 to 5 with a bag. The notice reports the closing force, the pressure on the laminate, and the groove's volume against the flash the overcharge makes, and warns when the groove is too small for either closing.
- **Tiling.** Halves larger than the printer bed are cut into tiles with staggered joints and keys, and joints are kept away from the stab pad, the wing nacelle and the mast pod.
- **Cut templates.** The template plate carries the woven skin outline developed along the tip droop, one tapered strip per UD ply, the mast's plate outline, the tab strips with fold notches, and a row of 3 mm tally holes under each shape for its cut count. Right-click the plate's top face in Onshape and export as DXF. A standalone script produces the same DXF from a pasted console log for a shop without Onshape.

**The core mold.** With *Core* = Foam core, a second Foil mold on the same part with *Mold of* = Its foam core (in the Part group, under *Source model*) molds the foam rather than the skin; the first Foil mold, with *Mold of* = The part, is still the mold for the skins. The feature first builds the core body itself: every section of the part offset inward along its normals by one face's skins, re-read and clipped where the two faces come within 0.6 mm of each other so the core ends in a blunt nose and tail, with a groove in each face where the UD caps run, as deep as the caps are thick at that station and ramped at its edges; the sections follow the part's bumps and winglet frame and are lofted through the same stations. That body is kept as a part, so the finished core, plus the caps in their grooves, plus the skins is the part. The mold pipeline then runs on it as it would on the part, without socket plug, bolt cones or mount pad, and with one difference at the tips: the outermost core section is carried straight out through the block's side, so the cavity is a channel open at both tips. That is for a poured two-part foam, which expands: it fills the cavity and the excess flows out of the tips instead of bursting the mold. Trim the flash at the tips, and the core is ready for its caps and skins in the part mold.

## 6.4 Printing the molds

These are starting points, not proven settings: the example molds have not been printed yet. Tune them on a test tile before committing a whole mold.

**Which material.** The deciding number is heat. Epoxy gives off heat as it cures, and a thick laminate with a fast hardener can reach 50 to 70 °C in the core. PLA starts to soften at about 55 to 60 °C, PETG at about 75 to 80 °C. So:

- **PLA** is fine for the wing and stab molds with a slow hardener, cured at room temperature, and demolded before any post-cure. It prints easily, holds dimensions well and sands cleanly.
- **PETG** is the safer choice for the mast mold, whose 20 mm root and tow core make the most heat, and for any mold you want to post-cure in, up to about 60 °C. It is tougher and less brittle when you clamp it, but harder to print accurately and harder to sand.

**Orientation: stand each tile on its end.** Print each tile standing on its spanwise end, the flat cut face where it meets the next tile, with the span vertical. Every layer is then a slice through the mold that contains the whole section profile, so the nozzle draws the cavity curve smoothly in one pass per layer, leading edge to trailing edge. The only layer steps run along the span, where the surface changes slowly, and the lines they leave run chordwise with the flow. Printed flat, base down, the same curve would be built from stacked layers and every one would leave a step across the chord in the cavity.

It also helps elsewhere. The end face that sits on the bed is the joint face, so it comes out flat and square. The tile-to-tile keys point straight up and print cleanly. Clamping force acts within each layer rather than trying to peel them apart.

The costs: a tall, narrow print needs a good brim and steady adhesion. The half keys on the flange face now point sideways and need a little support, or can be printed separately and glued in. Each tile's span length must fit your printer's height. The tool sizes tiles for a base-down print: *Printer X* limits the chord, *Printer Y* the span length of each tile, and *Printer Z* the block height. Standing on end, the span length goes up the printer's height and the block height lies across the bed, so enter your printer's height as *Printer Y* and the bed's second dimension as *Printer Z*. On a printer with the same size in all three directions, such as 250 × 250 × 250, nothing changes: the example's 225 mm tiles fit either way.

| Setting | PLA | PETG | Why |
|---|---|---|---|
| Nozzle | 205-215 °C | 235-245 °C | Good layer bonding; the mold is clamped and must not split |
| Bed | 55-60 °C | 75-85 °C | The end face on the bed is a joint face; it must stay flat |
| Cooling fan | 100 % after the first layers | 30-50 % | PETG bonds better and strings less with less cooling |
| Speed | 50-80 mm/s, outer walls 30-40 | 40-60 mm/s, outer walls 25-30 | The cavity is an outer wall in every layer; slow walls give a smoother surface to fair |
| Layer height | 0.16-0.20 mm | same | Steps now run along the span, where the surface is gentle; thinner layers only help at a strongly drooped tip |
| Walls | 5 perimeters (at least 2 mm) | same | The cavity is a wall now; there must be solid material under the sanding |
| Top and bottom | 4-5 layers | same | Only the tile's two end faces are top and bottom surfaces |
| Infill | 15-20 % adaptive cubic (or gyroid); 40 % only under the flanges and keys, with a modifier | same | The walls make the working surface; the core only carries clamp load to the base. Dense gyroid through the whole block more than doubled the print time on a test slice |
| Seam | aligned to a back corner of the base, never in the cavity | same | Every layer crosses the cavity, so a random seam would put a dot in it every layer |
| Brim | 8-10 mm, essential | 8-10 mm, essential | Tall, narrow tiles on a small end face |
| Supports | only under the flange half keys, if printed in place | same | Everything else is self-supporting |
| Elephant's foot compensation | 0.1-0.2 mm | 0.15-0.25 mm | The bed face is a joint face and must be square to seat the next tile |

**What it costs.** The stab mold for the foil-assist example is five tiles on one 250 mm bed, with the tool's default 25 mm flange and 20 mm base. It sliced as follows:

| Settings | Filament | Time |
|---|---|---|
| 4 walls, light infill | 1.17 kg | 16 h 38 m |
| 6 walls, dense gyroid infill | 1.69 kg | 39 h 14 m |
| 5 walls, light infill (recommended) | 1.29 kg | 19 h 21 m |

The dense infill more than doubled the time for almost no benefit; the fifth wall costs about an hour and a half and gives the cavity material to be sanded. For a stab, the tool's block can also shrink: *Flange width* 18 and *Base thickness* 16 still clear the key limits with 12 mm pins and 14 mm keys, and take about a quarter of the plastic off. Print a stab mold in two batches, upper tiles then lower, if one failure costing the whole bed would hurt.

**Fit.** The tool's *Pin fit* (0.2 mm by default) sets the clearance between each key and its socket. Print one key and socket pair first; if it binds, raise *Pin fit* by 0.05 mm and regenerate rather than sanding every key. Shrinkage over a 250 mm tile is well under half a millimetre, and the keys take it up; you don't need to scale the model.

**Bagging the mold.** With *Closing* = Vacuum bag: glue the tiles first and let the epoxy cure, since the bag pushes across the joints as well as along them. Wax the cavity, lay up, close on the keys, wrap the whole mold in breather cloth, bag it with a tacky-tape seal, and pull to 80 to 85 kPa. Check the flange gap with feeler gauges before the resin gels; if it will not close, the overcharge is too high, not the pump too weak. Leave it under vacuum for the full cure. Plugs and the mast's tray need no seal: the bag pushes them onto their seats. The mast mold, three pieces plus a plug, is a better bag candidate than a clamp candidate for that reason. Post-curing still happens out of the mold for PLA.

**Finishing before the first layup.**

1. Glue the tiles together on their keys with epoxy or CA, clamped on a flat surface.
2. Sand the cavity and parting faces, working from about 120 to 400 grit, until the layer lines are gone.
3. Seal the surface: two or three coats of laminating epoxy, or a high-build epoxy primer, sanded between coats. Raw PLA and PETG are porous and epoxy will bond to them.
4. Wet sand the sealed surface to 800-1200 grit. The mold finish is the part's finish.
5. Release: five or more coats of mold release wax, buffed between coats, then optionally a PVA film release. Re-wax before each layup.
6. Avoid solvents on the mold: acetone attacks PLA and softens PETG.

**Printing a core.** The mold settings above (five walls, dense infill under the flanges) are wrong for a core, which is thin and carries nothing. The first Silk V2 core sliced with mold settings came out at 510 g and 11 hours, 340 g of it inner walls: on a 16 mm section five walls a side is most of the volume, and the print was near solid PLA (about 1000 kg/m³). For a core use two walls, 10 to 15 % gyroid, 0.2 mm layers, no top or bottom solid layers beyond the walls, and stand each segment on its joint end face as the mold tiles stand on theirs, so the layers carry the section profile, the cap grooves print clean and nothing needs support; a brim holds it. Re-sliced that way the same core came to 297 g and 6 h 43 m, 190 g of it the two walls, which on a thin section stay the biggest share; 8 to 10 % infill would take another 40 g off. That is 580 kg/m³, and the wing with it weighs about 0.87 kg against AFS's 0.9 for the 950. Whatever the slicer reports, set *Core kg/m³* to its filament mass divided by the core volume the LAYUP line gives, so the weight and stiffness lines describe the core you actually printed.

# 7. Worked example

## 7.1 A prone wave foil assist, 95 kg all-up

A foil built to test the theory. More examples, built from published parameters of real foils, may follow. Rider 80 kg, board and kit 15 kg. Wing 1000 cm², AR 7.2, 850 mm span, NACA 4-digit with 3 % camber, 12/10 % thick, 100 mm tip sweep, 30 mm tip drop, 1° washout, 1.5° incidence, 1 mm minimum tip. Stab linked at 18 % (180 cm², AR 5.7, symmetric 10/8 %) at −1.5°, 660 mm behind the wing, its seat 4 mm below the fuselage centreline (*Height* −4), two M5 bolts at 35 mm. Mast 750 mm, 100 to 110 mm chord, 16 mm thick rising to 22 mm at the plate from 60 % height, 12 mm root fillet, 63 mm pod at 550 mm so it is out of the water once foiling. 24 mm tube fuselage. Drive: 160 mm three-blade prop, P/D 0.8, 140 kV direct on 10S, 120 A, 20 Ah.

Pod out, steady state:

| km/h | Board angle | CL wing | CL stab | Drag N (induced / profile / mast / fuselage) | L/D | W to hold speed |
|---|---|---|---|---|---|---|
| 15 | 7.4° | 1.04 | +0.05 | 63.1 (42.4 / 14.0 / 5.0 / 1.6) | 14.8 | 263 |
| 18 | 4.1° | 0.74 | −0.09 | 55.0 (31.5 / 14.3 / 7.0 / 2.3) | 16.9 | 275 |
| 20 | 2.7° | 0.62 | −0.15 | 53.7 (27.0 / 15.5 / 8.5 / 2.8) | 17.4 | 298 |
| 25 | 0.4° | 0.42 | −0.25 | 57.6 (21.0 / 19.8 / 12.7 / 4.1) | 16.2 | 400 |
| 30 | −0.8° | 0.32 | −0.30 | 67.0 (19.0 / 24.5 / 17.8 / 5.8) | 13.9 | 558 |

![Drag split against speed](charts/drag_split.png)

The model's stall is 13.8 km/h, with take-off at 15 at 86 % of the section's CL max. An experienced builder's estimate for a real foil like this is nearer 18 km/h, which corresponds to an effective CL max of about 0.75 against the section's 1.27: see 10.1 before trusting a stall speed. Best L/D 17.4 at 20 km/h. With the pod in the water, drag rises about 7 N and L/D falls to 14.7.

Motor on, pod in:

| km/h | Thrust N | rpm | Prop eff. | Motor A | Throttle | Battery W | Wh/km |
|---|---|---|---|---|---|---|---|
| 15 | 68.5 | 2160 | 69 % | 31 | 46 % | 539 | 36 |
| 20 | 63.2 | 2600 | 64 % | 34 | 55 % | 718 | 36 |
| 25 | 72.0 | 3140 | 59 % | 44 | 67 % | 1116 | 45 |
| 30 | 87.1 | 3710 | 55 % | 57 | 79 % | 1730 | 58 |

![Thrust available against thrust needed](charts/thrust.png)

![Battery watts and Wh per km](charts/energy.png)

Static thrust 41 kgf, top speed 37 km/h, 18.5 km or about 56 minutes of continuous powered cruising.

**Pitch.** Gliding, the static margin is 30 % of MAC at take-off and 53 % at cruise. Under power the thrust line is 560 mm above the wing and 450 mm above the drag centroid, a 34 Nm nose-down couple at take-off, and the powered margin at 15 km/h is −0.6 %, rising to +5.5 % at 16: neutral at take-off. The first version, with the pod 50 mm higher, a 150 cm² stab at 620 mm and 2° decalage, read −16 %. Foil assist trades powered stability for a dry pod, and pod height is the lever.

![Static margin gliding and under power](charts/pitch.png)

**Structure**, from the layup the mold feature wrote:

| Part | Load case | Layup | Deflection | Cap stress |
|---|---|---|---|---|
| Wing | 4 g, 354 Nm at the root | 2 × 200 g woven each face, 15 UD plies per cap tapering to 4, tow core | 6.5 mm at the tip | 137 MPa |
| Stab | 4 g | same skins, 5 UD per cap | 1.9 mm | 100 MPa |
| Mast | 1 g sideways at the fuselage, 932 N | 20 UD per cap at the plate, 15 at the foot, 4 tabs per face into the plate | 53 mm at the fuselage end | 198 MPa at the plate, 243 MPa at 488 mm |

Mast junction: 38 kN cap force, 2.1 MPa shear against 15 allowed, 3.9 kN per track bolt, 96 MPa in the plate.

![Bending moment, cap stress and ply count along the wing and the mast](charts/loads.png)

**Materials** at 50 % fibre volume: wing 1.6 kg cured (0.43 m² woven, 1 m² UD, 600 g tow, 830 g resin mixed), stab 0.13 kg, mast with plate 1.9 kg; about 3.7 kg of carbon and epoxy for the three molded parts. Wing mold 225 × 899 × 91 mm in nine tiles for a 250 mm bed, stab mold in two halves with the bolt cones, mast mold in three.

# 8. Parameter reference

Every dialog field of every feature, with its limits, default and the tooltip text, generated from the Feature Studio itself. Fields marked as appearing only when a checkbox or dropdown enables them are hidden otherwise.

PARAMETERS_PLACEHOLDER

# 9. Console log reference

Turn on *Log inputs* on a feature to print its inputs to the FeatureScript console. The keys are stable so a log can be pasted back to an assistant or into the scripts.

| Key | Feature | Content |
|---|---|---|
| `WING_INPUTS`, `STAB_INPUTS`, `MAST_INPUTS`, `FUSELAGE_INPUTS`, `PERFORMANCE_INPUTS`, `MOLD_INPUTS` | each | every input of the feature, with its version as the first field |
| `FUSELAGE_SEAT` | fuselage | the seat and the tapped holes made, or the conflict and the fix |
| `MAST_FILLET` | mast | the seam edges found at the plate and the fillet attempt that worked |
| `===== FOIL PERFORMANCE =====` block | performance | the full report, the propulsion block and the CSV |
| `UD_CAP_PLIES` | mold | per-cap cut list: ply, length, width at root, width at end |
| `UD_TABS` | mold (mast) | tab plies per face, size, fold position, interleave |
| `LAYUP` | mold | volumes, masses, plies, tow, resin, what to buy |
| `STIFFNESS` | mold | deflection, EI, cap stress; mast: stress at the plate and at its worst point, bolt tension, junction, plate |
| `STAB_CONES` | mold (stab) | the bolt cones made and their positions |
| `MAST_PLUG` | mold (mast) | the pod plug's cores and depth |
| `TEMPLATES` | mold | the order of shapes on the template plate and their cut counts |

Each feature's version is printed as the first field of its log line; the file's build number is in the Feature Studio header. If a pasted log shows a version older than the file you have, the Feature Studio was not pasted over.

# 10. Model limits, versioning and the AI assistant

## 10.1 Model limits

- Leading-edge bumps and winglets are geometry only, apart from the winglet's effective-span credit: the performance sweep neither credits nor charges the bumps.
- Results are best for comparing variants. Profile drag is about ±20–30 % absolute; induced drag within 5–10 % for modest sweep.
- With the analytic section model, stall comes entirely from the Section CL max input; use a polar for real behaviour.
- **Stall speed is optimistic.** It is the speed at which the most loaded section of a perfect, clean section reaches its 2D CL max in dead steady flight. Hand finish, the fuselage junction, wake, free surface and the margin a rider needs all lower the usable CL max. Stall speed goes with 1/√CL max, so calibrate: take one foil you know, find the Section CL max (or polar CL max) that reproduces its real take-off speed, and use that value for new designs.
- **One section family per surface.** Thickness ratio varies root to tip and Min tip holds an absolute floor, but camber and profile are the same along the span. Blending a cambered root to a flatter tip is not modelled yet.
- Lifting line ignores sweep and anhedral except for moving the aerodynamic centre; strongly swept or drooped wings will differ.
- Downwash at the stab is the classic far-field estimate.
- Not modelled: free-surface effects beyond the two MAC warning, ventilation, cavitation onset (only the cavitation number is reported), pumping and unsteady motion, board and rider aerodynamics, ploughing before lift-off, acceleration, junction drag between mast and fuselage, pod base drag.
- Propulsion is the B-series open-water estimate, about ±20 %, with fixed motor losses; no wake, no prop cavitation, no thermal limits.
- Structure: a spar-cap estimate with a simple EI model; no shear, torsion, buckling, fatigue, core or insert design; the junction check ignores peel at the fillet and the tabs' own anchoring.

## 10.2 Versioning

The Feature Studio header carries the build number and every feature's version. The build number goes up on every delivery; a feature's version goes up only when that feature changes, by 0.001 for an ordinary change and to the next whole number for a redesign. A changelog comment above the version constants records every change and why. The `toolVersion` field in each console log line tells you which version produced it.

## 10.3 The AI assistant and its scripts

**The foil design assistant** is a skill for AI assistants that reads what the features print and helps you decide what to change next. Its files are in the `assistant/` folder of the download package (section 2.1). Paste your console log and it explains the results, checks them against the targets in chapter 5, and recommends a few changes in the dialog's own labels, with the expected effect and the cost. Then it compares the next run with the last.

| Assistant | Setup |
|---|---|
| Claude (desktop app, claude.ai, Claude Code) | Add `foil-design-assistant.skill`. It loads when you paste foil output and runs the scripts itself. |
| ChatGPT | Use `foil-design-assistant-portable.md` as a custom GPT's instructions, with `parameters.md` and the scripts as knowledge, and Code Interpreter on. Or attach both files to a chat. |
| Other assistants | Give them `foil-design-assistant-portable.md` and `parameters.md` at the start of the chat. Without code execution they follow the manual method in the file. |

**What to paste.** Turn on *Log inputs* on every feature, regenerate, and copy the whole FeatureScript console, plus the notice of any feature showing a warning. One paste then carries every input and output, so every recommendation can be checked.

**The scripts.** Four Python 3 scripts come with the assistant, standard library only. An assistant that can run code runs them for you. To run them yourself, save the console to a text file and use a terminal:

```
python3 analyse_sweep.py run.txt [previous_run.txt]
python3 pitch_sweep.py run.txt --vmin 15
python3 polar_summary.py polar_re1.txt polar_re2.txt
python3 cut_templates.py run.txt templates.dxf
```

- `analyse_sweep.py` summarises a run: best L/D, minimum power, take-off loading, stance shift, static margin, drag split and, with propulsion, the lowest Wh/km, throttle range, top speed and lowest powered margin. Given two runs, it compares them.
- `pitch_sweep.py` rebuilds the design's trim from the log, checks it against the tool's own numbers, and finds the smallest stab, arm and decalage that reach a target static margin, including the effect of moving a motor pod.
- `polar_summary.py` turns one or two XFoil or XFLR5 polar files into the thirteen numbers the Section polar group takes.
- `cut_templates.py` writes the skin and UD ply outlines as a DXF from the log, for cutting without Onshape.
