# AFS designs as parameter sets

One document per AFS family from afs-foiling.com's foil range, with AFS's published numbers, what the outline measures as, and a parameter set for the tool in the dialog's own labels. They exist to check the tool against real, published parts, and as starting points: the sections, camber and twist are AFS's secrets, so those rows are suggestions and the guide's calibration section applies.

AFS's leading-edge bumps are modelled from build 153 (*LE bumps*), measured from the renders where they are large enough to see; Foil performance ignores them. How the outlines were measured: AFS's plan-view render, masked by transparency, scaled by the published span, chord fitted outside the centre mount hub with both of the tool's chord laws (superellipse; double taper with blend), and the leading edge fitted for the alignment line and a power-law sweep. Fit errors are 0.3 to 2 % of root chord. The fitted root chord lands within 3 to 8 % of AFS's published max chord on every wing, which is the check that the renders are true to scale.

| Family | Type | Sizes | Outline | Document |
|---|---|---|---|---|
| Silk V2 | surf, downwind, carving wing | 650 to 1150 cm², AR 9 | superellipse n 1.4, tips raked, progressive anhedral | [silk-v2.md](silk-v2.md) |
| Ultra and Ultra Fuselink | downwind | 600 to 900 cm², AR 14 to 16 | superellipse, straight trailing edge, mini winglets | [ultra.md](ultra.md) |
| Enduro and Enduro GLT | all-terrain, dockstart | 600 to 1600 cm², AR 11 | superellipse n 1.4 with swept tips | [enduro.md](enduro.md) |
| Evo HA | high-aspect freeride | 750, 1000 cm², AR 12 to 13 | double taper, break 35 %, mid 0.83 | [evo-ha.md](evo-ha.md) |
| Evo | beginner to intermediate wing | 950 to 1640 cm², AR 7.5 to 8 | superellipse n 1.7 | [evo.md](evo.md) |
| Flyer | first flights | 1430, 1735 cm², AR 6.3 | near-elliptic, n 2.1 | [flyer.md](flyer.md) |
| Pure Fuselink | freerace, freestyle | 600 to 880 cm², AR 8 to 10 | superellipse n 1.8, straight trailing edge | [pure.md](pure.md) |
| U Surf | surf stab | 120 to 150 cm², AR 9 | superellipse n 1.4 on a mount base | [u-surf.md](u-surf.md) |
| U Carve | carving stab | 130 to 160 cm², AR 10 | double taper, full base, Clark Y flat side | [u-carve.md](u-carve.md) |
| U Glide | downwind stab | 113 to 133 cm², AR 14 | slim superellipse on a mount block | [u-glide.md](u-glide.md) |
| U-Cruise | all-round stab | 190 to 250 cm², AR 8 | superellipse n 1.5, straight trailing edge | [u-cruise.md](u-cruise.md) |
| Ultra 900 + U Glide 43 | a complete downwind set, all six features | 85 kg | ready to type in | [ultra-uglide-downwind.md](ultra-uglide-downwind.md) |
| Masts | HR, HM, UHM, Skinny, Infinity | 65 to 95 cm | constant chord and thickness | [masts.md](masts.md) |
| Fuselages | Fuselink, Advanced, Titanium, Aluminium, Switch | 650, 680 mm | 27 to 33.5 mm section | [fuselages.md](fuselages.md) |

What none of them can reproduce: the Corecell cores, the centre mount hubs and the one-piece Fuselink fuselages. Every AFS number is theirs; the measurements and suggestions are this project's and carry its licence.
