# AFS Enduro and Enduro GLT front wings

Numbers in the *Published* tables are AFS's own, copied from afs-foiling.com on 24 September 2026. The outline was measured from AFS's plan-view product render, scaled by the published span; that gives the chord distribution, the alignment line and the sweep, but not the section, the camber or the twist, which AFS does not publish. Where a setting is a suggestion rather than a measurement the table says so. Bumps on the leading edge (AFS's tubercles) and the centre mount hub are not modelled; the fit is made outside the hub.


Source: https://afs-foiling.com/product/enduro-front-wing

Render measured: Enduro1300_0001-4.png (GLT: glt_0002-1-scaled.png)

## What AFS says

All-terrain AR 11 range: the big sizes for ultra light wind, downwind, dockstart and parawing, the 800 and 900 for downwind carving and small-wave surf, the 600 and 700 for downwind glide. The GLT is a single 1600 cm² dockstart and flat-water pump wing developed with Gwen Le Tutour.

Leading-edge bumps on both; the GLT adds tapered swept-back tips to clear the mast, bumps concentrated at the centre, and a double-curvature anhedral for turning. Monolithic HR carbon (Enduro), Corecell (GLT), M8 mount.

## Published sizes

| Size | Area cm² | Span mm | AR | Max chord mm | Max thick mm | Root thick % | Weight g |
|---|---|---|---|---|---|---|---|
| 600 | 600 | 813 | 11 | 100 | 10.8 | 10.8 | 600 |
| 700 | 700 | 877 | 11 | 108 | 12.9 | 11.9 | 500 |
| 800 | 800 | 940 | 11 | 116 | 13.9 | 12.0 | 600 |
| 900 | 900 | 994 | 11 | 122 | 14.6 | 12.0 | 800 |
| 1000 | 1000 | 1050 | 11 | 129.5 | 15.5 | 12.0 | 850 |
| 1100 | 1100 | 1100 | 11 | 136 | 16.2 | 11.9 | 900 |
| 1300 | 1300 | 1190 | 11 | 149 | 17.8 | 11.9 | 1000 |
| GLT 1600 | 1600 | 1323 | 11 | 162 | 19 | 11.7 | 1400 |

## Measured from the render (1300)

Outline: superellipse, exponent 1.4, end ratio 0.19 (1.3 % RMS of root chord). Root chord from the fit 158 mm against AFS's 149 mm max chord. The centre hub is 188 mm long. Alignment line 38 % of chord, sweep 75 mm at the tip, exponent 4.0.

## Foil wing parameters, 1300

| Dialog field | Value | Basis |
|---|---|---|
| Area cm^2 | 1300 | published |
| Aspect ratio | 11 | published |
| Area definition | Projected area | the render is a plan view |
| Profile | NACA 4-digit | suggestion: AFS does not publish the section |
| Camber % | 3 | suggestion for the discipline |
| Camber pos % | 40 | suggestion |
| Section data | Built-in | fitted NACA polars |
| Root thick % | 11.9 | published max thickness over max chord |
| Tip thick % | 9.9 | suggestion: 2 points thinner than the root |
| Thickness exp | 1.5 | default |
| Chord distribution | Superellipse | measured |
| Exponent n | 1.4 | measured |
| End ratio | 0.19 | measured; a rounded tip needs Tip cap = Rounded + plan or a smaller end ratio |
| Align line % | 38 | measured: the chord line that stays straight |
| Sweep aft | 75 mm | measured at this size; scale with span for the others |
| Sweep exp | 4.0 | measured |
| Tip drop | 35 mm | suggestion |
| Drop exp | 2.5 | suggestion; for the GLT's double curvature add Gull dihedral 6 deg with Drop exp 3 |
| Tip cap | Rounded + plan; Cap length 24 mm; Cap end % 25 | suggestion, rounds the tip as the render shows |
| Stations | 13 | suggestion |
| LE bumps | on; Bump height 5 mm; Bump pitch 53 mm; Bumps from % 15; Bumps to % 85 | measured from the 1300 render; the GLT measured 63 mm pitch, 6 mm height, 14 to 85 % |


## Every size

Change these; keep the rest.

| Size | Area cm² | Aspect ratio | Root thick % | Sweep aft mm |
|---|---|---|---|---|
| 600 | 600 | 11 | 10.8 | 51 |
| 700 | 700 | 11 | 11.9 | 55 |
| 800 | 800 | 11 | 12.0 | 59 |
| 900 | 900 | 11 | 12.0 | 63 |
| 1000 | 1000 | 11 | 12.0 | 66 |
| 1100 | 1100 | 11 | 11.9 | 69 |
| 1300 | 1300 | 11 | 11.9 | 75 |
| GLT 1600 | 1600 | 11 | 11.7 | 83 |

## Not modelled

The hub. The GLT render measured on its own: superellipse n 1.4, end 0.26, alignment 31 %, sweep 102 mm exponent 4, root chord 170 against AFS's 162.

Bumps are geometry only: Foil performance uses the smooth outline (guide, section 3.1).
