# AFS Evo HA front wing

Numbers in the *Published* tables are AFS's own, copied from afs-foiling.com on 24 September 2026. The outline was measured from AFS's plan-view product render, scaled by the published span; that gives the chord distribution, the alignment line and the sweep, but not the section, the camber or the twist, which AFS does not publish. Where a setting is a suggestion rather than a measurement the table says so. Bumps on the leading edge (AFS's tubercles) and the centre mount hub are not modelled; the fit is made outside the hub.


Source: https://afs-foiling.com/product/evo-ha-front-wing

Render measured: HA750_0001.png

## What AFS says

Removable high-aspect wings derived from the Pure HA: the HA1000 for wing freeride and downwind at 10 to 25 knots, the HA750 for dynamic freeride at 14 to 30 knots. AFS pairs them with the U-Cruise S or M by rider weight.

A slender section, a tighter outline on the 750, HM reinforcement on the 750 for torsion. Monolithic HR and HM carbon, M8 mount.

## Published sizes

| Size | Area cm² | Span mm | AR | Max chord mm | Max thick mm | Root thick % | Weight g |
|---|---|---|---|---|---|---|---|
| HA750 | 750 | 1000 | 13.3 | 113 | 13.8 | 12.2 | 700 |
| HA1000 | 1000 | 1100 | 12.1 | 135 | 16 | 11.9 | 1100 |

## Measured from the render (HA750)

Outline: double taper, break 34 %, mid ratio 0.84, tip ratio 0.19, blend 12 % (0.4 % RMS of root chord). Root chord from the fit 118 mm against AFS's 113 mm max chord. The centre hub is 172 mm long. Alignment line 17 % of chord, sweep 61 mm at the tip, exponent 2.0.

## Foil wing parameters, HA750

| Dialog field | Value | Basis |
|---|---|---|
| Area cm^2 | 750 | published |
| Aspect ratio | 13.3 | published |
| Area definition | Projected area | the render is a plan view |
| Profile | NACA 4-digit | suggestion: AFS does not publish the section |
| Camber % | 2.5 | suggestion for the discipline |
| Camber pos % | 40 | suggestion |
| Section data | Built-in | fitted NACA polars |
| Root thick % | 12.2 | published max thickness over max chord |
| Tip thick % | 10.2 | suggestion: 2 points thinner than the root |
| Thickness exp | 1.5 | default |
| Chord distribution | Double taper | measured |
| Break % | 34 | measured |
| Mid ratio | 0.84 | measured |
| Blend % | 12 | measured |
| Tip ratio | 0.19 | measured |
| Align line % | 17 | measured: the chord line that stays straight |
| Sweep aft | 61 mm | measured at this size; scale with span for the others |
| Sweep exp | 2.0 | measured |
| Tip drop | 20 mm | suggestion |
| Drop exp | 2 | suggestion |
| Tip cap | Rounded + plan; Cap length 20 mm; Cap end % 25 | suggestion, rounds the tip as the render shows |
| Stations | 13 | suggestion |


## Every size

Change these; keep the rest.

| Size | Area cm² | Aspect ratio | Root thick % | Sweep aft mm |
|---|---|---|---|---|
| HA750 | 750 | 13.3 | 12.2 | 61 |
| HA1000 | 1000 | 12.1 | 11.9 | 67 |

## Not modelled

The hub (centre chord about 170 mm against a 118 mm wing root: a mount block). Both sizes measured almost identically: the HA1000 gave break 36 %, mid 0.82, tip 0.19, alignment 17 %, sweep 72 mm.
