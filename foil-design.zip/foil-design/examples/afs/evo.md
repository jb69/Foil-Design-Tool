# AFS Evo front wing

Numbers in the *Published* tables are AFS's own, copied from afs-foiling.com on 24 September 2026. The outline was measured from AFS's plan-view product render, scaled by the published span; that gives the chord distribution, the alignment line and the sweep, but not the section, the camber or the twist, which AFS does not publish. Where a setting is a suggestion rather than a measurement the table says so. Bumps on the leading edge (AFS's tubercles) and the centre mount hub are not modelled; the fit is made outside the hub.


Source: https://afs-foiling.com/product/evo-front-wing

Render measured: EVO_Top_1650.png

## What AFS says

Beginner and intermediate wing foil, plus surf, SUP and downwind, at a medium aspect ratio of 7.5 to 8.1: flat water, jumps, surf. AFS sizes it by rider weight and wind, with a U-Cruise stab.

Corecell sandwich, EVO quick-release mount. No section or anhedral wording published.

## Published sizes

| Size | Area cm² | Span mm | AR | Max chord mm | Max thick mm | Root thick % | Weight g |
|---|---|---|---|---|---|---|---|
| 950 | 950 | 880 | 8.1 | 150 | 13.5 | 9.0 | 700 |
| 1250 | 1240 | 970 | 7.6 | 185 | 16.5 | 8.9 | 800 |
| 1450 | 1440 | 1040 | 7.6 | 195 | 17.5 | 9.0 | 1000 |
| 1650 | 1640 | 1110 | 7.5 | 195 | 17.5 | 9.0 | 1100 |

## Measured from the render (1650)

Outline: superellipse, exponent 1.7, end ratio 0.12 (0.8 % RMS of root chord). Root chord from the fit 201 mm against AFS's 195 mm max chord. Alignment line 38 % of chord, sweep 70 mm at the tip, exponent 4.0.

## Foil wing parameters, 1650

| Dialog field | Value | Basis |
|---|---|---|
| Area cm^2 | 1640 | published |
| Aspect ratio | 7.5 | published |
| Area definition | Projected area | the render is a plan view |
| Profile | NACA 4-digit | suggestion: AFS does not publish the section |
| Camber % | 3 | suggestion for the discipline |
| Camber pos % | 40 | suggestion |
| Section data | Built-in | fitted NACA polars |
| Root thick % | 9.0 | published max thickness over max chord |
| Tip thick % | 7.0 | suggestion: 2 points thinner than the root |
| Thickness exp | 1.5 | default |
| Chord distribution | Superellipse | measured |
| Exponent n | 1.7 | measured |
| End ratio | 0.12 | measured; a rounded tip needs Tip cap = Rounded + plan or a smaller end ratio |
| Align line % | 38 | measured: the chord line that stays straight |
| Sweep aft | 70 mm | measured at this size; scale with span for the others |
| Sweep exp | 4.0 | measured |
| Tip drop | 25 mm | suggestion |
| Drop exp | 2 | suggestion |
| Tip cap | Rounded + plan; Cap length 22 mm; Cap end % 25 | suggestion, rounds the tip as the render shows |
| Stations | 13 | suggestion |


## Every size

Change these; keep the rest.

| Size | Area cm² | Aspect ratio | Root thick % | Sweep aft mm |
|---|---|---|---|---|
| 950 | 950 | 8.1 | 9.0 | 55 |
| 1250 | 1240 | 7.6 | 8.9 | 61 |
| 1450 | 1440 | 7.6 | 9.0 | 66 |
| 1650 | 1640 | 7.5 | 9.0 | 70 |

## Not modelled

The 950 measured as a double taper (break 68 %, mid 0.62, tip 0.21, alignment 6 %, sweep 85 mm), the 1650 as a superellipse; the two outlines differ, so use each size's own row above. The Corecell core.
