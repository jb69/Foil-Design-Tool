# AFS Flyer front wing

Numbers in the *Published* tables are AFS's own, copied from afs-foiling.com on 24 September 2026. The outline was measured from AFS's plan-view product render, scaled by the published span; that gives the chord distribution, the alignment line and the sweep, but not the section, the camber or the twist, which AFS does not publish. Where a setting is a suggestion rather than a measurement the table says so. Bumps on the leading edge (AFS's tubercles) and the centre mount hub are not modelled; the fit is made outside the hub.


Source: https://afs-foiling.com/product/flyer-front-wing

Render measured: Flyer-front-wing.png

## What AFS says

Wing foil initiation and progression: first flights, upwind, first manoeuvres, small waves. 1500 for riders under 75 kg, 1800 above. Early take-off, stability, predictability.

Carbon sandwich with a Corecell core; the outline is the closest to a plain ellipse in the range.

## Published sizes

| Size | Area cm² | Span mm | AR | Max chord mm | Max thick mm | Root thick % | Weight g |
|---|---|---|---|---|---|---|---|
| 1500 | 1430 | 955 | 6.3 | 185 | 20 | 10.8 | 900 |
| 1800 | 1735 | 1050 | 6.3 | 205 | 22 | 10.7 | 1000 |

## Measured from the render (1800)

Outline: superellipse, exponent 2.1, end ratio 0.02 (0.5 % RMS of root chord). Root chord from the fit 208 mm against AFS's 205 mm max chord. Alignment line 69 % of chord, sweep 43 mm at the tip, exponent 3.0.

## Foil wing parameters, 1800

| Dialog field | Value | Basis |
|---|---|---|
| Area cm^2 | 1735 | published |
| Aspect ratio | 6.3 | published |
| Area definition | Projected area | the render is a plan view |
| Profile | NACA 4-digit | suggestion: AFS does not publish the section |
| Camber % | 3.5 | suggestion for the discipline |
| Camber pos % | 40 | suggestion |
| Section data | Built-in | fitted NACA polars |
| Root thick % | 10.7 | published max thickness over max chord |
| Tip thick % | 8.7 | suggestion: 2 points thinner than the root |
| Thickness exp | 1.5 | default |
| Chord distribution | Superellipse | measured |
| Exponent n | 2.1 | measured |
| End ratio | 0.02 | measured; a rounded tip needs Tip cap = Rounded + plan or a smaller end ratio |
| Align line % | 69 | measured: the chord line that stays straight |
| Sweep aft | 43 mm | measured at this size; scale with span for the others |
| Sweep exp | 3.0 | measured |
| Tip drop | 20 mm | suggestion |
| Drop exp | 2 | suggestion |
| Tip cap | Rounded + plan; Cap length 21 mm; Cap end % 25 | suggestion, rounds the tip as the render shows |
| Stations | 13 | suggestion |


## Every size

Change these; keep the rest.

| Size | Area cm² | Aspect ratio | Root thick % | Sweep aft mm |
|---|---|---|---|---|
| 1500 | 1430 | 6.3 | 10.8 | 39 |
| 1800 | 1735 | 6.3 | 10.7 | 43 |

## Not modelled

Nothing structural: the Flyer is the simplest shape here and the best first check of the tool against a production wing (superellipse n 2.1, root chord 208 against AFS's 205).
