# AFS fuselages

Published numbers from afs-foiling.com, 24 September 2026. AFS publishes length, section thickness, material and weight, and that there are two stab positions; not the stab-position spacing, the wing bolt positions or the section shape beyond a thickness.

## Published

| Fuselage | Length mm | Section mm | Material | Weight kg | Stab positions | Wing screws | Notes |
|---|---|---|---|---|---|---|---|
| Fuselink Standard | 680 | 32.5 | HR carbon, monolithic | 0.56 | 2 | M8 | stability and high-speed control |
| Fuselink Short | 650 | 32.5 | HR carbon, monolithic | 0.50 | 2 | M8 | manoeuvrability, pumping frequency |
| Fuselink Advanced HM | 650 | 32.5 | HM carbon | 0.50 | 2 (back for glide, advanced for surf and waves) | 3 × M8 × 20 Torx 40 | Ultra, Silk V2, Enduro |
| Advanced Titanium | 650 | 27 | grade 5 titanium | 1.08 | 2 | | 30 % stiffer than carbon at twice the density; 23 % less drag from the slimmer section |
| EVO Aluminium | 680 | 32.5 | T6 aluminium | 0.96 | | | entry level |
| Switch | 680 | 33.5 | HR carbon, monolithic | 0.6 | | | adapts the older Performer mast to Fuselink wings |

## Foil fuselage parameters

The tool's fuselage is a round tube that plugs into the wing's socket and seats on the stab's mount; AFS's Fuselink is a tapered socket on the mast with the wing bolted below. The numbers that carry across are the section and the arm.

| Dialog field | Fuselink Standard | Advanced Titanium | Basis |
|---|---|---|---|
| Tube dia (Foil wing, Tube socket) | 32.5 mm | 27 mm | published section |
| Arm (Foil stabiliser) | about 560 mm | about 530 mm | AFS's length minus the wing's root chord ahead of the pivot and the stab's mount; not published, estimate from the render |
| Tail dia | 12 mm | 10 mm | suggestion |
| Parallel aft | to the stab seat | | tool geometry |

The Advanced fuselage's two stab positions are AFS's version of the tool's *Arm* and *Bolt 1 at*: the back position for glide, the forward one for waves. With the U Carve or U Glide on a tube of this size, set the stab's *Height* so its seat plane sits 4 mm above the centreline as the guide describes.
