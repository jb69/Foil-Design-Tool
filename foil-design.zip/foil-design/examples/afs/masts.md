# AFS masts

Published numbers from afs-foiling.com, 24 September 2026. AFS publishes length, chord, thickness, weight and construction; not the plate size, the bolt pattern, the taper from base to top, or any deflection figure. Where the tool needs one of those, the table says it is the tool's default.

## Published

| Mast | Length cm | Chord mm | Thickness mm | Thick % of chord | Weight g | Construction | Use |
|---|---|---|---|---|---|---|---|
| HR 65 / 80 / 85 | 65, 80, 85 | 135 | 16 | 11.9 | 1300, 1600, 1700 | HR carbon, Corecell sandwich, 0° and ±45° plies | all disciplines, beginners; shorter for shallow water |
| HM 80 / 85 | 80, 85 | 120 | 15 | 12.5 | 1900, 1600 (as published) | HM carbon, Corecell | 85 for mostly wing, 80 for half surf |
| UHM 80 / 85 | 80, 85 | 115 | 13.8, 13.5 | 12.0, 11.7 | 2000 | multi-layer UHM carbon, Corecell, integrated plate | wing, parawing, downwind, kite |
| UHM 95 Freeride | 95 | 115 | 14 | 12.2 | 2100 | as above, rake 0.5° | |
| UHM 95 Race | 95 | 120 | 12.3 | 10.3 | 2300 | as above, rake 2.5° | |
| UHM Skinny 75 / 80 / 85 | 75, 80, 85 | 105 (75: 100 or 105, the page disagrees) | 13.2 (75: 12.8 or 13.2) | 12.6 | 1600, 1900, 1900 | monolithic UHM, no foam core | experienced riders; 75 for surf and shallow spots |
| Infinity 80 (Manta Foils, Foil Drive) | 80 | 110 | 14 | 12.7 | 2100, 2000 | hybrid UHM and HM, Corecell; pod 15 cm below the plate | foil assist |

AFS's claim for UHM carbon is up to twice the stiffness of standard carbon. No deflection numbers are published, so the tool's own stiffness check (Foil mold, mast) is the only figure you will have.

## Foil mast parameters

Every AFS mast has one chord and one thickness for its whole height, so *Top chord* equals *Width* and *Top thick* equals *Thickness*. The tool thickens toward the plate if you ask it to; AFS does not say it does.

| Dialog field | HR 85 | UHM 85 | UHM Skinny 80 | Infinity 80 | Basis |
|---|---|---|---|---|---|
| Height | 850 mm | 850 mm | 800 mm | 800 mm | published |
| Width | 135 mm | 115 mm | 105 mm | 110 mm | published chord |
| Thickness | 16 mm | 13.5 mm | 13.2 mm | 14 mm | published |
| Top chord | 135 mm | 115 mm | 105 mm | 110 mm | no taper published |
| Top thick | 16 mm | 13.5 mm | 13.2 mm | 14 mm | no taper published |
| Thicken from % | 100 | 100 | 100 | 100 | constant section |
| Root fillet | 15 mm | 15 mm | 15 mm | 15 mm | tool default; AFS does not show the junction |
| Plate length, Plate width, Track spacing, Bolt | tool defaults (double US box, M8) | | | | not published |
| Motor pod | off | off | off | on; Pod height 150 mm below the plate | Infinity only, published |

The tool's stiffness check for a 135 × 16 HR mast at 850 mm will report far more deflection than for a 115 × 13.5 UHM one only if you raise *Cap modulus* for UHM; the layup fields default to standard carbon. AFS's Skinny at 105 × 13.2 is the thinnest and is monolithic, so set the tow core to nothing in the layup if you want its material estimate to match.
