# AFS Pure Fuselink front wings

Numbers in the *Published* tables are AFS's own, copied from afs-foiling.com on 24 September 2026. The outline was measured from AFS's plan-view product render, scaled by the published span; that gives the chord distribution, the alignment line and the sweep, but not the section, the camber or the twist, which AFS does not publish. Where a setting is a suggestion rather than a measurement the table says so. Bumps on the leading edge (AFS's tubercles) and the centre mount hub are not modelled; the fit is made outside the hub.


Source: https://afs-foiling.com/product/pure-fuselink-foil

Render measured: F_PureV2700_0001-2-1-1.png (600: afs-pure-600.png)

## What AFS says

High-performance wing foil, freerace and freestyle, molded in one piece with the fuselage. The 600 is a freestyle pro model that takes off around 17 to 18 knots for 40 to 60 kg riders; the 700 and 900 split by rider weight at 10 to 20 knots.

An ultra-thin section for drag, a moderate aspect ratio for stability, adjustable stab positions. Monolithic HM and HR carbon.

## Published sizes

| Size | Area cm² | Span mm | AR | Max chord mm | Max thick mm | Root thick % | Weight g |
|---|---|---|---|---|---|---|---|
| 600 | 600 | 708 | 8.4 | 108 | 11.4 | 10.6 | 1100 |
| 700 | 700 | 820 | 9.6 | 112 | 11.5 | 10.3 | 1200 |
| 900 | 880 | 900 | 9.2 | 137 | 14.1 | 10.3 | 1700 |

## Measured from the render (700)

Outline: superellipse, exponent 1.8, end ratio 0.13 (0.3 % RMS of root chord). Root chord from the fit 114 mm against AFS's 112 mm max chord. Alignment line 73 % of chord, sweep 18 mm at the tip, exponent 3.0.

## Foil wing parameters, 700

| Dialog field | Value | Basis |
|---|---|---|
| Area cm^2 | 700 | published |
| Aspect ratio | 9.6 | published |
| Area definition | Projected area | the render is a plan view |
| Profile | NACA 4-digit | suggestion: AFS does not publish the section |
| Camber % | 2.5 | suggestion for the discipline |
| Camber pos % | 40 | suggestion |
| Section data | Built-in | fitted NACA polars |
| Root thick % | 10.3 | published max thickness over max chord |
| Tip thick % | 8.3 | suggestion: 2 points thinner than the root |
| Thickness exp | 1.5 | default |
| Chord distribution | Superellipse | measured |
| Exponent n | 1.8 | measured |
| End ratio | 0.13 | measured; a rounded tip needs Tip cap = Rounded + plan or a smaller end ratio |
| Align line % | 73 | measured: the chord line that stays straight |
| Sweep aft | 18 mm | measured at this size; scale with span for the others |
| Sweep exp | 3.0 | measured |
| Tip drop | 15 mm | suggestion |
| Drop exp | 2 | suggestion |
| Tip cap | Rounded + plan; Cap length 16 mm; Cap end % 25 | suggestion, rounds the tip as the render shows |
| Stations | 13 | suggestion |


## Every size

Change these; keep the rest.

| Size | Area cm² | Aspect ratio | Root thick % | Sweep aft mm |
|---|---|---|---|---|
| 600 | 600 | 8.4 | 10.6 | 16 |
| 700 | 700 | 9.6 | 10.3 | 18 |
| 900 | 880 | 9.2 | 10.3 | 20 |

## Not modelled

The one-piece fuselage (the tool's wing takes a round tube in a socket instead; the render's fuselage was masked before fitting). The 600 measured as a double taper: break 60 %, mid 0.78, tip 0.21, alignment 12 %, sweep 58 mm.
