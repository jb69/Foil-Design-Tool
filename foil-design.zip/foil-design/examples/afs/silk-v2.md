# AFS Silk V2 front wing

Numbers in the *Published* tables are AFS's own, copied from afs-foiling.com on 24 September 2026. The outline was measured from AFS's plan-view product render, scaled by the published span; that gives the chord distribution, the alignment line and the sweep, but not the section, the camber or the twist, which AFS does not publish. Where a setting is a suggestion rather than a measurement the table says so. Bumps on the leading edge (AFS's tubercles) and the centre mount hub are not modelled; the fit is made outside the hub.


Source: https://afs-foiling.com/product/silk-v2-front-wing

Render measured: SILK_v2_950_0001.png

## What AFS says

Surf foil, downwind and carving wing foil for riders past the basics. AFS sizes it by wave and wind: 1150 for micro conditions and light wind, 950 as the small-to-medium wave sweet spot, 650 for big waves, tow-in and strong wind.

AFS describes a progressive anhedral (they call it dihedral) with a more pronounced bend near the centre so the tips rise steadily, redesigned tips that tolerate one tip leaving the water, leading-edge bumps, and a higher aspect ratio than the V1 for pumping and glide. Corecell sandwich, M8 mount.

## Published sizes

| Size | Area cm² | Span mm | AR | Max chord mm | Max thick mm | Root thick % | Weight g |
|---|---|---|---|---|---|---|---|
| 650 | 650 | 765 | 9 | 113.1 | 13.6 | 12.0 | 700 |
| 750 | 750 | 821 | 9 | 122.5 | 14.7 | 12.0 | 700 |
| 850 | 850 | 875 | 9 | 131.5 | 15.7 | 11.9 | 800 |
| 950 | 950 | 925 | 9 | 139.8 | 16.7 | 11.9 | 900 |
| 1050 | 1050 | 972 | 9 | 147.8 | 17.7 | 12.0 | 1000 |
| 1150 | 1150 | 1017 | 9 | 155.5 | 18.7 | 12.0 | 1100 |

## Measured from the render (950)

Front view: an S-curve, level at the centre, steepest at mid-span, level again by 91 % with 45 mm of drop, then the tips rise (measured from AFS's V1-V2 comparison render, span-scaled: 0, −1.4, −4.8, −10.3, −17.2, −24.7, −32.3, −39.2, −44.0, −45.4 mm at 0 to 90 %). Outline: superellipse, exponent 1.4, end ratio 0.26 (1.5 % RMS of root chord). Root chord from the fit 144 mm against AFS's 140 mm max chord. The centre hub is 191 mm long. Alignment line 78 % of chord, sweep 67 mm at the tip, exponent 4.0.

## Foil wing parameters, 950

| Dialog field | Value | Basis |
|---|---|---|
| Area cm^2 | 950 | published |
| Aspect ratio | 9 | published |
| Area definition | Projected area | the render is a plan view |
| Profile | NACA 4-digit | suggestion: AFS does not publish the section |
| Camber % | 3 | suggestion for the discipline |
| Camber pos % | 40 | suggestion |
| Section data | Built-in | fitted NACA polars |
| Root thick % | 11.9 | published max thickness over max chord |
| Tip thick % | 9.9 | suggestion: 2 points thinner than the root |
| Thickness exp | 1.5 | default |
| Chord distribution | Superellipse | measured |
| Exponent n | 1.4 | measured |
| End ratio | 0.26 | measured; a rounded tip needs Tip cap = Rounded + plan or a smaller end ratio |
| Align line % | 78 | measured: the chord line that stays straight |
| Sweep aft | 67 mm | measured at this size; scale with span for the others |
| Sweep exp | 4.0 | measured |
| Tip drop | 45 mm | measured from AFS's front-view render |
| Drop shape | S-curve | measured: level centre, steepest mid-span, level again before the tips (0.3 mm RMS; a power law misses by 1.8 mm) |
| Drop from % | 3 | measured |
| Drop to % | 91 | measured |
| Winglet | Up; Winglet area 15; Winglet angle 25; Bend radius 60 | suggestion for the tip rise over the last 10-15 % |
| Tip profile | NACA 4-digit; Tip camber % 1.5; Tip camb pos % 50; Blend from % 40 (Foil mold: Split stations 22) | suggestion: washes the tips out (take-off loading 74 % against 75 with one section, stall 15.2 against 15.3, root bending down 4 %); E817 at the tip does the opposite |
| Tip cap | Rounded + plan; Cap length 18 mm; Cap end % 25 | suggestion, rounds the tip as the render shows |
| Stations | 13 | suggestion |
| LE bumps | on; Bump height 5 mm; Bump pitch 59 mm; Bumps from % 18; Bumps to % 82 | measured from the render |


## Every size

Change these; keep the rest.

| Size | Area cm² | Aspect ratio | Root thick % | Sweep aft mm |
|---|---|---|---|---|
| 650 | 650 | 9 | 12.0 | 55 |
| 750 | 750 | 9 | 12.0 | 59 |
| 850 | 850 | 9 | 11.9 | 63 |
| 950 | 950 | 9 | 11.9 | 67 |
| 1050 | 1050 | 9 | 12.0 | 70 |
| 1150 | 1150 | 9 | 12.0 | 74 |

## Not modelled

The Corecell core (the layup estimate assumes a tow core), the mount hub. The section and camber are guesses: calibrate against a known take-off speed as the guide describes.

Bumps are geometry only: Foil performance uses the smooth outline (guide, section 3.1).
