# AFS U Carve stabilizer

Numbers in the *Published* tables are AFS's own, copied from afs-foiling.com on 24 September 2026. The outline was measured from AFS's plan-view product render, scaled by the published span; that gives the chord distribution, the alignment line and the sweep, but not the section, the camber or the twist, which AFS does not publish. Where a setting is a suggestion rather than a measurement the table says so. Bumps on the leading edge (AFS's tubercles) and the centre mount hub are not modelled; the fit is made outside the hub.


Source: https://afs-foiling.com/product/u-carve-stabilizer

Render measured: ucrave160_0001-2.png (130: ucrave130_0001-1.png)

## What AFS says

For carving wingers, surf foilers and downwinders who draw clean lines: glide, precision and a surf feel. The 160 has a straighter outline for tight turns in small conditions; the smaller sizes carry more sweep for drive in faster lines.

A full-base concept with a wide mounting footprint for stiffness, a reduced span with refined tips, a section tuned for low drag, raised tips acting as winglets. Jan12 on foil.zone describes the section as flat on one side. HR and HM monolithic carbon, 12 mm Torx 30 screws.

## Published sizes

| Size | Area cm² | Span mm | AR | Max chord mm | Max thick mm | Root thick % | Weight g |
|---|---|---|---|---|---|---|---|
| 130 | 130 | 360 | 10 | 68 | 5 | 7.4 | 100 |
| 140 | 140 | 375 | 10 | 72 | 5 | 6.9 | 100 |
| 150 | 150 | 390 | 10 | 76 | 5 | 6.6 | 100 |
| 160 | 160 | 400 | 10 | 80 | 5 | 6.2 | 100 |

## Measured from the render (160)

Outline: double taper, break 30 %, mid ratio 0.54, tip ratio 0.17, blend 12 % (0.7 % RMS of root chord). Root chord from the fit 82 mm against AFS's 80 mm max chord. Alignment line 2 % of chord, sweep 14 mm at the tip, exponent 3.0.

## Foil stabiliser parameters, 160

| Dialog field | Value | Basis |
|---|---|---|
| Link to wing | Independent |  |
| Area cm^2 | 160 | published |
| Aspect ratio | 10 | published |
| Area definition | Projected area | the render is a plan view |
| Profile | Clark Y | flat on one side, as described on foil.zone; from build 168 the section is scaled whole with its thickness, so at 7.4 % it carries about 0.63 of the table's camber and the stab's download is less than builds 143-168 reported |
| Invert section | on | camber down, flat face up to the fuselage |
| Section data | Built-in | Clark Y polar at Re 0.2 M and 1 M |
| Root thick % | 6.2 | published max thickness over max chord |
| Tip thick % | 4.2 | suggestion: 2 points thinner than the root |
| Thickness exp | 1.5 | default |
| Chord distribution | Double taper | measured |
| Break % | 30 | measured |
| Mid ratio | 0.54 | measured |
| Blend % | 12 | measured |
| Tip ratio | 0.17 | measured |
| Align line % | 2 | measured: the chord line that stays straight (straight leading edge) |
| Sweep aft | 14 mm | measured at this size; scale with span for the others |
| Sweep exp | 3.0 | measured |
| Tip drop | −10 mm | AFS's raised tips |
| Drop exp | 6 | late upturn; or Winglet = Up, area 4, angle 45, radius 20 the mold handles it up to 75° |
| Root tail | on; Tail length 40 mm; Tail span % 30 | the V behind the root is part of the stab; turn the mount pad's Tail fairing off |
| Mount pad | on; Pad width 22; Pad height 6 | suggestion for the tool's fuselage seat; AFS mounts on a flat with two 12 mm Torx 30 screws |
| Bolt | M6; Bolt pitch 35 mm | AFS's screws are M6-size Torx 30; pitch estimated from the render |
| Tip cap | Rounded + plan; Cap length 8 mm; Cap end % 25 | suggestion, rounds the tip as the render shows |
| Stations | 13 | suggestion |


## Every size

Change these; keep the rest.

| Size | Area cm² | Aspect ratio | Root thick % | Sweep aft mm |
|---|---|---|---|---|
| 130 | 130 | 10 | 7.4 | 13 |
| 140 | 140 | 10 | 6.9 | 13 |
| 150 | 150 | 10 | 6.6 | 14 |
| 160 | 160 | 10 | 6.2 | 14 |

## Not modelled

The 130 measured on its own render fits break 30 %, mid 0.60, tip 0.23, blend 10 %, and the solver returns AFS's 360 mm span and 68 mm root chord; the 160 is straighter, as AFS says. Tip thick % 9 rather than root minus 2, so the tips stay buildable.
