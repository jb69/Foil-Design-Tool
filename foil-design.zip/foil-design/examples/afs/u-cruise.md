# AFS U-Cruise stabilizer

Numbers in the *Published* tables are AFS's own, copied from afs-foiling.com on 24 September 2026. The outline was measured from AFS's plan-view product render, scaled by the published span; that gives the chord distribution, the alignment line and the sweep, but not the section, the camber or the twist, which AFS does not publish. Where a setting is a suggestion rather than a measurement the table says so. Bumps on the leading edge (AFS's tubercles) and the centre mount hub are not modelled; the fit is made outside the hub.


Source: https://afs-foiling.com/product/cruiser-stabilizer

Render measured: UCRUISE_220_0001.png

## What AFS says

The all-round stab AFS pairs with the Evo, Evo HA and Flyer as Cruiser S, M and L.

A slim section for glide, pronounced sweep and a progressive anhedral for intuitive turning. Monolithic HR carbon, 12 mm Torx 30 screws.

## Published sizes

| Size | Area cm² | Span mm | AR | Max chord mm | Max thick mm | Root thick % | Weight g |
|---|---|---|---|---|---|---|---|
| 190 | 190 | 390 | 8 | 69 | 7.15 | 10.4 | 120 |
| 220 | 220 | 420 | 8 | 71 | 7.2 | 10.1 | 150 |
| 245 | 250 | 450 | 8 | 75 | 7.35 | 9.8 | 200 |

## Measured from the render (220)

Outline: superellipse, exponent 1.5, end ratio 0.24 (0.5 % RMS of root chord). Root chord from the fit 71 mm against AFS's 71 mm max chord. Alignment line 71 % of chord, sweep 16 mm at the tip, exponent 4.0.

## Foil stabiliser parameters, 220

| Dialog field | Value | Basis |
|---|---|---|
| Link to wing | Independent |  |
| Area cm^2 | 220 | published |
| Aspect ratio | 8 | published |
| Area definition | Projected area | the render is a plan view |
| Profile | NACA 4-digit | suggestion: AFS does not publish the section |
| Camber % | 0 | suggestion: symmetric stab |
| Section data | Built-in |  |
| Root thick % | 10.1 | published max thickness over max chord |
| Tip thick % | 8.1 | suggestion: 2 points thinner than the root |
| Thickness exp | 1.5 | default |
| Chord distribution | Superellipse | measured |
| Exponent n | 1.5 | measured |
| End ratio | 0.24 | measured; a rounded tip needs Tip cap = Rounded + plan or a smaller end ratio |
| Align line % | 71 | measured: the chord line that stays straight |
| Sweep aft | 16 mm | measured at this size; scale with span for the others |
| Sweep exp | 4.0 | measured |
| Tip drop | 10 mm | AFS's progressive anhedral |
| Drop exp | 2.5 | suggestion |
| Mount pad | on; Pad width 22; Pad height 6 | suggestion for the tool's fuselage seat; AFS mounts on a flat with two 12 mm Torx 30 screws |
| Bolt | M6; Bolt pitch 35 mm | AFS's screws are M6-size Torx 30; pitch estimated from the render |
| Tip cap | Rounded + plan; Cap length 8 mm; Cap end % 25 | suggestion, rounds the tip as the render shows |
| Stations | 13 | suggestion |


## Every size

Change these; keep the rest.

| Size | Area cm² | Aspect ratio | Root thick % | Sweep aft mm |
|---|---|---|---|---|
| 190 | 190 | 8 | 10.4 | 15 |
| 220 | 220 | 8 | 10.1 | 16 |
| 245 | 250 | 8 | 9.8 | 17 |

## Not modelled

Nothing beyond the section: the outline is a clean superellipse (n 1.5, end 0.24) with a straight-ish trailing edge (alignment 71 %), and the root chord measured 71 against AFS's 71.
