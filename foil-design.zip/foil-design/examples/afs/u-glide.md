# AFS U Glide stabilizer

Numbers in the *Published* tables are AFS's own, copied from afs-foiling.com on 24 September 2026. The outline was measured from AFS's plan-view product render, scaled by the published span; that gives the chord distribution, the alignment line and the sweep, but not the section, the camber or the twist, which AFS does not publish. Where a setting is a suggestion rather than a measurement the table says so. Bumps on the leading edge (AFS's tubercles) and the centre mount hub are not modelled; the fit is made outside the hub.


Source: https://afs-foiling.com/product/ultra-glide-stabilizer

Render measured: UGlide_0002-1.png

## What AFS says

Downwind and freefly wing for experts and competitors: long-distance glide, also carving. Paired with the Ultra as AFS's downwind signature; compatible with the Silk and Enduro.

A high-aspect stab with an extended span and a very narrow chord for induced drag, sections 4.5 to 5 mm thin, and twist. HM carbon throughout.

## Published sizes

| Size | Area cm² | Span mm | AR | Max chord mm | Max thick mm | Root thick % | Weight g |
|---|---|---|---|---|---|---|---|
| 39 | 113 | 390 | 13.9 | 44 | 4.5 | 10.2 | 100 |
| 41 | 123 | 410 | 13.8 | 46 | 5 | 10.9 | 100 |
| 43 | 133 | 430 | 13.7 | 48.3 | 5 | 10.4 | 100 |

## Measured from the render (41)

Outline: double taper, break 20 %, mid ratio 0.64, tip ratio 0.21, blend 6 % (2.1 % RMS of root chord). Root chord from the fit 60 mm against AFS's 46 mm max chord. The centre hub is 70 mm long. Alignment line 5 % of chord, sweep 16 mm at the tip, exponent 3.0.

## Foil stabiliser parameters, 41

| Dialog field | Value | Basis |
|---|---|---|
| Link to wing | Independent |  |
| Area cm^2 | 123 | published |
| Aspect ratio | 13.8 | published |
| Area definition | Projected area | the render is a plan view |
| Profile | NACA 4-digit | suggestion: AFS does not publish the section |
| Camber % | 0 | suggestion: symmetric stab |
| Section data | Built-in |  |
| Root thick % | 10.9 | published max thickness over max chord |
| Tip thick % | 8.9 | suggestion: 2 points thinner than the root |
| Thickness exp | 1.5 | default |
| Chord distribution | Double taper | measured |
| Break % | 20 | measured |
| Mid ratio | 0.64 | measured |
| Blend % | 6 | measured |
| Tip ratio | 0.21 | measured |
| Align line % | 5 | measured: the chord line that stays straight (straight leading edge) |
| Sweep aft | 16 mm | measured at this size; scale with span for the others |
| Sweep exp | 3.0 | measured |
| Tip drop | 0 | flat |
| Washout | 1 deg | suggestion for AFS's twist; sign positive washes the tips out |
| Mount pad | on; Pad width 22; Pad height 6 | suggestion for the tool's fuselage seat; AFS mounts on a flat with two 12 mm Torx 30 screws |
| Bolt | M6; Bolt pitch 35 mm | AFS's screws are M6-size Torx 30; pitch estimated from the render |
| Tip cap | Rounded + plan; Cap length 8 mm; Cap end % 25 | suggestion, rounds the tip as the render shows |
| Stations | 13 | suggestion |


## Every size

Change these; keep the rest.

| Size | Area cm² | Aspect ratio | Root thick % | Sweep aft mm |
|---|---|---|---|---|
| 39 | 113 | 13.9 | 10.2 | 15 |
| 41 | 123 | 13.8 | 10.9 | 16 |
| 43 | 133 | 13.7 | 10.4 | 17 |

## Not modelled

The base: the centre chord is 70 mm against a 46 mm chord, a mounting block about 15 % of the half span wide. The double-taper fit (break 20 %, mid 0.64) is that block; for the wing alone use superellipse n 1.3, end 0.26 and let the Root tail or the mount pad make the base. Min tip on at 1 mm: the tips are under 10 mm of chord.
