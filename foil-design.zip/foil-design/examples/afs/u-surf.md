# AFS U Surf stabilizer

Numbers in the *Published* tables are AFS's own, copied from afs-foiling.com on 24 September 2026. The outline was measured from AFS's plan-view product render, scaled by the published span; that gives the chord distribution, the alignment line and the sweep, but not the section, the camber or the twist, which AFS does not publish. Where a setting is a suggestion rather than a measurement the table says so. Bumps on the leading edge (AFS's tubercles) and the centre mount hub are not modelled; the fit is made outside the hub.


Source: https://afs-foiling.com/product/u-surf-stabilizer

Render measured: USURF_135_0001.png

## What AFS says

The surf-foil reference stab, made to extend the Silk V2: grip and support under the back foot, tolerance in tight turns and rough water. AFS trims the Silk V2 and U Surf together with reduced stab angle; with the Enduro, Evo HA or Silk V1 they suggest a half or one degree shim under it.

Leading-edge bumps to soften the stall, a section reworked for support and lateral grip. HR and HM monolithic carbon, 12 mm Torx 30 screws.

## Published sizes

| Size | Area cm² | Span mm | AR | Max chord mm | Max thick mm | Root thick % | Weight g |
|---|---|---|---|---|---|---|---|
| 120 | 120 | 328 | 9 | 50 | 5 | 10.0 | 100 |
| 135 | 135 | 348 | 9 | 53 | 5 | 9.4 | 100 |
| 150 | 150 | 368 | 9 | 56 | 5 | 8.9 | 100 |

## Measured from the render (135)

Outline: superellipse, exponent 1.4, end ratio 0.20 (1.5 % RMS of root chord). Root chord from the fit 56 mm against AFS's 53 mm max chord. The centre hub is 70 mm long. Alignment line 19 % of chord, sweep 15 mm at the tip, exponent 4.0.

## Foil stabiliser parameters, 135

| Dialog field | Value | Basis |
|---|---|---|
| Link to wing | Independent |  |
| Area cm^2 | 135 | published |
| Aspect ratio | 9 | published |
| Area definition | Projected area | the render is a plan view |
| Profile | NACA 4-digit | suggestion: AFS does not publish the section |
| Camber % | 0 | suggestion: symmetric stab |
| Section data | Built-in |  |
| Root thick % | 9.4 | published max thickness over max chord |
| Tip thick % | 7.4 | suggestion: 2 points thinner than the root |
| Thickness exp | 1.5 | default |
| Chord distribution | Superellipse | measured |
| Exponent n | 1.4 | measured |
| End ratio | 0.20 | measured; a rounded tip needs Tip cap = Rounded + plan or a smaller end ratio |
| Align line % | 19 | measured: the chord line that stays straight |
| Sweep aft | 15 mm | measured at this size; scale with span for the others |
| Sweep exp | 4.0 | measured |
| Tip drop | 0 | the render is flat |
| Mount pad | on; Pad width 22; Pad height 6 | suggestion for the tool's fuselage seat; AFS mounts on a flat with two 12 mm Torx 30 screws |
| Bolt | M6; Bolt pitch 35 mm | AFS's screws are M6-size Torx 30; pitch estimated from the render |
| Tip cap | Rounded + plan; Cap length 8 mm; Cap end % 25 | suggestion, rounds the tip as the render shows |
| Stations | 13 | suggestion |
| LE bumps | on; Bump height 1.5 mm; Bump pitch 30 mm; Bumps from % 15; Bumps to % 85 | suggestion: AFS describe bumps; the render is too small to measure them |


## Every size

Change these; keep the rest.

| Size | Area cm² | Aspect ratio | Root thick % | Sweep aft mm |
|---|---|---|---|---|
| 120 | 120 | 9 | 10.0 | 14 |
| 135 | 135 | 9 | 9.4 | 15 |
| 150 | 150 | 9 | 8.9 | 16 |

## Not modelled

The centre chord of 70 mm against a 56 mm wing root is the mount base; Root tail 15 mm over 12 % of the span reproduces it.

Bumps are geometry only: Foil performance uses the smooth outline (guide, section 3.1).
