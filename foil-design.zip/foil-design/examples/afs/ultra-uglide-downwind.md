# AFS Ultra 900 with the U Glide 43: a downwind set

AFS's own pairing ("the downwind signature"), sized for 85 kg all-up. The Ultra is their AR 14 to 16 downwind wing with tubercles and mini winglets; the U Glide is the AR 14 stab with 4.5 to 5 mm sections and twist. Every number below is either AFS's published figure, measured from their render (the Ultra 600 plan render and the U Glide render, scaled by the published span) or a guess, and the table says which. Sections, camber and twist are guesses; calibrate as the guide's section 5.3 describes.

Why the 900 and not the 750 at this weight: with the tool's default Section CL max of 1.0 the 750 stalls at 16.8 km/h and the 900 at 15.3, and a real section at these Reynolds numbers is closer to 0.75, which puts them at 19.4 and 17.7. Downwind paddle-ups happen with bump help the model does not have, so treat those as the flat-water, no-pump numbers. Lighter riders, or those with strong bumps, take the 750: same shape, Area 750, Aspect ratio 15.

Front view, measured from AFS's render of the 600 (span line relative to the root, mm at 0 to 100 % of the half span): 0, 0, −1.6, −4.3, −8.1, −12.0, −15.5, −18.5, −20.6 at 80 %, −20.9 at 85 %, then rising to −8.7 at the tip. The mount hub is a pedestal about 12 mm deep under the centre, not modelled.

Build 165 or later. Confirmed on 164 (wing, stab, both molds, sweep): stall 13.7 km/h with the built-in polar, best L/D 29.6 at 20 km/h, static margin 17 % at take-off, stance shift 56 mm, monolithic layup 1.11 kg against AFS's 1000 g, 21 mm tip deflection at 3 g. Expected notice values: wing span 1122 mm, root about 113 mm (AFS publish 106 as max chord), MAC 89; stab span 427, root about 45 plus the tail; stab 14.8 % of the wing, tail volume 0.95 at a 570 mm arm.

## Foil wing: Ultra 900

| Dialog field | Value | Basis |
|---|---|---|
| Area cm^2 | 900 | published |
| Aspect ratio | 14 | published |
| Area definition | Projected area | plan render |
| Profile | NACA 4-digit | guess; Eppler E817 with Built-in data is the alternative for a thin downwind section with a real polar |
| Camber % | 2.5 | guess for a high-aspect glide wing |
| Camber pos % | 40 | guess |
| Section data | Built-in | fitted NACA polars |
| Root thick % | 13.1 | published 13.9 mm on 106 |
| Tip thick % | 11 | guess |
| Chord distribution | Superellipse | measured on the 600 render |
| Exponent n | 1.5 | measured |
| End ratio | 0.17 | measured |
| Align line % | 87 | measured: near-straight trailing edge |
| Sweep aft | 0 | measured within a few mm of none |
| Drop shape | S-curve; Tip drop 24 mm; Drop from % 15; Drop to % 85 | measured from AFS's front-view render of the 600 (21 mm at 980 span, scaled to 1120): flat to 15 %, steepest at mid-span, level again by 85 % |
| Winglet | Up; Winglet area 25; Winglet angle 25; Bend radius 200 | measured: the tips rise 12 mm over the last 15 % of the half span as a smooth curl; the large radius puts the whole winglet on the arc (at 62 it turned up on a short arc and ran straight, a visible kink) |
| LE bumps | on; Bump height 5 mm; Bump pitch 53 mm; Bumps from % 12 (not 0: the mold fails); Bumps to % 88 | pitch and height measured on the plan render; the 3D render shows them running from just outside the hub to near the tip, further than the plan render resolved |
| Tip cap | Rounded + plan; Cap length 20 mm; Cap end % 25 | suggestion |
| Min tip | on; Min tip mm 1 | the tip chord is small at AR 14 |
| Stations | 13 | suggestion; the bumps add their own |
| Tube socket | on; Tube dia 27 | AFS's titanium fuselage section; 32.5 for their carbon ones |
| Incidence | 0 | |

## Foil stabiliser: U Glide 43

| Dialog field | Value | Basis |
|---|---|---|
| Link to wing | Independent | |
| Area cm^2 | 133 | published |
| Aspect ratio | 13.7 | published |
| Profile | NACA 4-digit; Camber % 0 | guess: AFS describe thin sections and twist, not a flat side |
| Section data | Built-in | |
| Root thick % | 10.9 | published 5 mm on 48.3 |
| Tip thick % | 11 | 4.5 mm sections outboard; Min tip guards the tip |
| Chord distribution | Superellipse; Exponent n 1.3; End ratio 0.26 | measured outside the mount block |
| Align line % | 17 | measured |
| Sweep aft | 13 mm; Sweep exp 4 | measured |
| Root tail | on; Tail length 20 mm; Tail span % 15 | the mount block: centre chord 70 mm against a 46 mm wing root |
| Washout | 1 deg | AFS's twist, size a guess |
| Tip cap | Rounded + plan; Cap length 10 mm; Cap end % 25 | suggestion |
| Min tip | on; Min tip mm 1 | tips are under 10 mm of chord |
| Stations | 11 | |
| Arm | 570 mm | AFS's rear (glide) stab position on their 650 mm fuselages, estimated |
| Incidence | −1 | start here; tune to a static margin of 10 to 20 % at take-off |
| Height | −4 | seat plane 4 mm above the centreline, pad on top |
| Mount pad | on; Pad width 22; Pad height 6 | |
| Bolt | M6; Bolt pitch 35 mm | AFS's 12 mm Torx 30 screws |

## Foil performance

| Dialog field | Value |
|---|---|
| Rider + board mass | 85 kg |
| Take-off / Cruise / Max | 13 / 17 / 28 km/h |
| Section CL max | 1.0 to start; expect 0.75 after calibration |
| Load factor | 3 g (downwind loads are gentler than surf) |

## Foil mast and Foil fuselage, AFS-like

| Dialog field | Value | Basis |
|---|---|---|
| Mast Height / Width / Thickness | 850 / 115 / 13.5 mm | UHM 85, published |
| Top chord / Top thick | 115 / 13.5 | constant section |
| Fuselage Tube dia | 27 mm | Advanced Titanium |
| Fuselage length | to the stab seat: Arm 570 plus the stab's tail | |

## Foil mold

As the Silk V2 set: 2 × 200 g skins, 300 g UD, Cap width % 40, Cap thick % 60, Vf 50 %. Core = Foam core at 85 kg/m³ (AFS build the Ultra in UHM and HM carbon, most likely monolithic; Monolithic is the honest comparison for their weight), or Printed core at 580 with two walls and 15 % gyroid.

What the tool cannot reproduce: the tubercles' effect on stall (geometry only), the mount hub, and the section itself.
