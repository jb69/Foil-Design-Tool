# AFS Ultra (HA Ultra) front wing and Ultra Fuselink

Numbers in the *Published* tables are AFS's own, copied from afs-foiling.com on 24 September 2026. The outline was measured from AFS's plan-view product render, scaled by the published span; that gives the chord distribution, the alignment line and the sweep, but not the section, the camber or the twist, which AFS does not publish. Where a setting is a suggestion rather than a measurement the table says so. Bumps on the leading edge (AFS's tubercles) and the centre mount hub are not modelled; the fit is made outside the hub.


Source: https://afs-foiling.com/product/ultra-front-wing

Render measured: ULTRA600_3D_04.png

## What AFS says

Downwind. AFS pitches the Ultra on glide, precision and a high average speed, with a profile tuned so pumping costs little energy. The Ultra Fuselink 750 is the same family molded in one piece with its fuselage, AR 14, aimed at downwind competitors.

Leading-edge tubercles for a progressive stall, mini winglets at the tips to settle the flow, ultra-high aspect ratio, UHM and HM carbon.

## Published sizes

| Size | Area cm² | Span mm | AR | Max chord mm | Max thick mm | Root thick % | Weight g |
|---|---|---|---|---|---|---|---|
| 600 | 600 | 980 | 16 | 84 | 10.8 | 12.9 | 600 |
| 750 | 750 | 1060 | 15 | 95 | 12.3 | 12.9 | 700 |
| 900 | 900 | 1120 | 14 | 106 | 13.9 | 13.1 | 1000 |
| Fuselink 750 | 750 | 1024 | 14 | 95 | 12.3 | 12.9 | 1200 |

## Measured from the render (600)

Outline: superellipse, exponent 1.5, end ratio 0.17 (1.9 % RMS of root chord). Root chord from the fit 87 mm against AFS's 84 mm max chord. The centre hub is 162 mm long. Alignment line 87 % of chord, sweep -22 mm at the tip, exponent 1.5.

## Foil wing parameters, 600

| Dialog field | Value | Basis |
|---|---|---|
| Area cm^2 | 600 | published |
| Aspect ratio | 16 | published |
| Area definition | Projected area | the render is a plan view |
| Profile | Eppler E817 | suggestion: AFS does not publish the section; E817 is a thin, well-documented hydrofoil section with a real polar |
| Section data | Built-in | E817 polar |
| Root thick % | 12.9 | published max thickness over max chord |
| Tip thick % | 10.9 | suggestion: 2 points thinner than the root |
| Thickness exp | 1.5 | default |
| Chord distribution | Superellipse | measured |
| Exponent n | 1.5 | measured |
| End ratio | 0.17 | measured; a rounded tip needs Tip cap = Rounded + plan or a smaller end ratio |
| Align line % | 87 | measured: the chord line that stays straight |
| Sweep aft | -22 mm | measured at this size; scale with span for the others |
| Sweep exp | 1.5 | measured |
| Tip drop | 10 mm | suggestion: the render is nearly flat |
| Winglet | Up; Winglet area 4; Winglet angle 45; Bend radius 20 | suggestion for AFS's mini winglets; Foil mold molds them up to 75° |
| Tip cap | Rounded + plan; Cap length 20 mm; Cap end % 25 | suggestion, rounds the tip as the render shows |
| Stations | 13 | suggestion |
| LE bumps | on; Bump height 5 mm; Bump pitch 53 mm; Bumps from % 17; Bumps to % 72 | measured from the 600 render |


## Every size

Change these; keep the rest.

| Size | Area cm² | Aspect ratio | Root thick % | Sweep aft mm |
|---|---|---|---|---|
| 600 | 600 | 16 | 12.9 | -22 |
| 750 | 750 | 15 | 12.9 | -24 |
| 900 | 900 | 14 | 13.1 | -25 |
| Fuselink 750 | 750 | 14 | 12.9 | -23 |

## Not modelled

The one-piece fuselage of the Fuselink version, the mount hub (AFS's centre chord is about twice the wing's root chord here, a mounting block rather than aerofoil). The Fuselink 750 render includes the fuselage, so its outline was fitted outside the centre; measured separately it gave superellipse n 1.6, end 0.13, alignment 100 % (straight trailing edge).

Bumps are geometry only: Foil performance uses the smooth outline (guide, section 3.1).
