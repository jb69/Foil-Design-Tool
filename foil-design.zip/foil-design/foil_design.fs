FeatureScript 3083;
import(path : "onshape/std/common.fs", version : "3083.0");

// ---------------------------------------------------------------------------
// FOIL DESIGN TOOL
// Version: build 175 (2026-09-25)
//   wing 1.035 | stab 4.018 | performance 1.018 | mast 2.009 | fuselage 4.012 | mold 2.098
//
// Features: Foil wing, Foil stabiliser, Foil performance, Foil mast, Foil fuselage, Foil mold.
// Shared geometry core used by the wing and stabiliser: area-first planform solver,
// superellipse / linear chord, alignment line, power-law sweep, anhedral + gull,
// washout, thickness distribution, tip cap, tabulated profiles, section polars.
//
// Frame: X = downstream (LE -> TE), Y = span, Z = up.
// Wing root pivot (default quarter chord) sits at the world origin.
// Sections are streamwise (planes normal to Y). Span is the projected,
// tip-to-tip distance seen from above.
//
// The build number goes up on every delivery, the per-feature versions when that
// feature changes; both must match FOIL_FILE_BUILD and the FOIL_*_VERSION constants.
// Full change history: see the changelog above those constants.
// ---------------------------------------------------------------------------

export enum BoltSize
{
    annotation { "Name" : "M4" }
    M4,
    annotation { "Name" : "M5" }
    M5,
    annotation { "Name" : "M6" }
    M6,
    annotation { "Name" : "M8" }
    M8,
    annotation { "Name" : "M10" }
    M10,
    annotation { "Name" : "Custom hole sizes" }
    CUSTOM
}

/**
 * Metric bolt dimensions, mm: close-fit clearance hole, tapping drill, and the 90 deg countersunk
 * head (ISO 10642 / DIN 7991 theoretical head diameter dk and head height k). CUSTOM returns zeros;
 * callers then take the typed hole and a head of twice the hole.
 */
function boltDims(size is BoltSize) returns map
{
    if (size == BoltSize.M4) return { "name" : "M4", "clear" : 4.4, "tap" : 3.3, "head" : 8.96, "k" : 2.48 };
    if (size == BoltSize.M5) return { "name" : "M5", "clear" : 5.4, "tap" : 4.2, "head" : 11.2, "k" : 3.1 };
    if (size == BoltSize.M6) return { "name" : "M6", "clear" : 6.4, "tap" : 5.0, "head" : 13.44, "k" : 3.72 };
    if (size == BoltSize.M8) return { "name" : "M8", "clear" : 8.4, "tap" : 6.8, "head" : 17.92, "k" : 4.96 };
    if (size == BoltSize.M10) return { "name" : "M10", "clear" : 10.5, "tap" : 8.5, "head" : 22.4, "k" : 6.2 };
    return { "name" : "custom", "clear" : 0, "tap" : 0, "head" : 0, "k" : 0 };
}

/** Countersunk head diameter for a bolt choice, given the hole it goes through (Custom: twice the hole). */
function boltHead(size is BoltSize, hole is ValueWithUnits) returns ValueWithUnits
{
    return size == BoltSize.CUSTOM ? 2 * hole : boltDims(size).head * millimeter;
}

export enum PartsGroup
{
    annotation { "Name" : "Closed: one entry in the parts list" }
    CLOSED,
    annotation { "Name" : "Open: parts stay listed, group under Composite parts" }
    OPEN,
    annotation { "Name" : "Off: loose parts" }
    OFF
}

export enum FoilProfile
{
    annotation { "Name" : "NACA 4-digit" }
    NACA4,
    annotation { "Name" : "Eppler E817" }
    E817,
    annotation { "Name" : "Eppler E818" }
    E818,
    annotation { "Name" : "NACA 63-412" }
    NACA63412,
    annotation { "Name" : "Clark Y" }
    CLARKY
}

export enum FoilPivot
{
    annotation { "Name" : "Quarter chord" }
    QUARTER_CHORD,
    annotation { "Name" : "Leading edge" }
    LEADING_EDGE,
    annotation { "Name" : "Trailing edge" }
    TRAILING_EDGE
}

export enum PlanformMode
{
    annotation { "Name" : "Area + aspect ratio" }
    AREA_AR,
    annotation { "Name" : "Span + root chord" }
    SPAN_CHORD
}

export enum AreaDefinition
{
    annotation { "Name" : "Projected area" }
    PROJECTED,
    annotation { "Name" : "Developed area" }
    DEVELOPED
}

export enum ChordShape
{
    annotation { "Name" : "Superellipse" }
    SUPERELLIPSE,
    annotation { "Name" : "Linear taper" }
    LINEAR,
    annotation { "Name" : "Double taper" }
    DOUBLE
}

export enum StabLink
{
    annotation { "Name" : "Independent" }
    INDEPENDENT,
    annotation { "Name" : "Linked to wing" }
    LINKED
}

export enum PadSide
{
    annotation { "Name" : "Top (fuselage above)" }
    TOP,
    annotation { "Name" : "Bottom (fuselage below)" }
    BOTTOM
}

export enum PolarSource
{
    annotation { "Name" : "Analytic" }
    ANALYTIC,
    annotation { "Name" : "Polar summary" }
    POLAR,
    annotation { "Name" : "Built-in" }
    BUILTIN
}

export enum TipProfile
{
    annotation { "Name" : "Same as root" }
    SAME,
    annotation { "Name" : "NACA 4-digit" }
    NACA4,
    annotation { "Name" : "Eppler E817" }
    E817,
    annotation { "Name" : "Eppler E818" }
    E818,
    annotation { "Name" : "NACA 63-412" }
    NACA63412,
    annotation { "Name" : "Clark Y" }
    CLARKY
}

export enum DropLaw
{
    annotation { "Name" : "Power law" }
    POWER,
    annotation { "Name" : "S-curve" }
    SCURVE
}

export enum CoreType
{
    annotation { "Name" : "Tow fill" }
    TOW,
    annotation { "Name" : "Foam core" }
    FOAM,
    annotation { "Name" : "Monolithic" }
    SOLID,
    annotation { "Name" : "Printed core" }
    PRINTED
}

export enum Winglet
{
    annotation { "Name" : "Off" }
    OFF,
    annotation { "Name" : "Up" }
    UP,
    annotation { "Name" : "Down" }
    DOWN
}

export enum TipCap
{
    annotation { "Name" : "Rounded tip" }
    TAPERED,
    annotation { "Name" : "Rounded + plan" }
    ROUND_PLAN,
    annotation { "Name" : "Flat tip" }
    FLAT
}

// One version number per feature: MAJOR.mmm, three-digit decimal (e.g. "1.000", "1.001").
// Bump only the one(s) whose precondition or body actually changed in a delivered edit -
// +0.001 for an ordinary change, +1.000 (decimals back to 000) for a major redesign of that
// feature - so a pasted console log shows exactly what changed and what didn't, with no
// ceiling on how many edits a day (unlike a single letter suffix).
//
// Changelog (append one line per bump; keep it here, not only in chat history):
//   1.000  wing/stab/perf/mold  baseline reset when per-feature versioning was introduced
//   1.001  wing/stab/perf        fixed corrupted tooltips - a find/replace regex had spliced
//                                text into the middle of decimal bounds (e.g. "Limits 1.2-8"
//                                became "Limits 1. <text> 2-8")
//   1.001  mold                 ply schedule: Root/Mid/Tip plies (absolute counts) ->
//                                Root/Mid/Tip fill % (targets); the absolute defaults, tuned
//                                for the wing, overfilled the much thinner stab past 100%
//   1.002  mold                 ply rounding floor -> ceil, plus a Compression % allowance:
//                                a matched-die mold is normally deliberately overcharged and
//                                closed under pressure, squeezing the excess out as flash -
//                                floor could only ever undershoot, which was the wrong model
//   1.003  mold                 added the required Filter to the Part query parameter
//                                (Onshape rejects a Query param with no Filter/ALWAYS_HIDDEN);
//                                removed the unused plyCounts variable
//   1.004  mold                 removed a duplicate chordFactor(...) that had been copied into
//                                the mold code without checking the shared library already had
//                                one - caused "multiple visible overloads" errors at every call
//                                site in the wing, stab and performance features too
//   1.005  mold                 parting curve was built with skFitSpline (a 2D sketch op) fed
//                                full 3D points; failed is2dPointVector, since the curve genuinely
//                                varies in span, chord AND height (sweep + droop) at once. Switched
//                                to opFitSpline, a 3D space-curve op, for both LE and TE curves
//   1.002  wing/stab/perf        added an optional "Section polar" group (Foil wing/Foil
//                                stabiliser): Analytic (unchanged default) or Polar summary -
//                                13 numbers (zero-lift, lift slope, Cm, and CLmax/Cdmin/CL@Cdmin/k
//                                at two Reynolds numbers) fitted from a real XFoil/XFLR5 run via
//                                scripts/polar_summary.py. When set, replaces the thin-aerofoil
//                                lift slope/alpha0/Cm, the flat-plate profile-drag build-up (now
//                                a log-Re-interpolated drag-bucket parabola), and the wing's
//                                Section CL max (now interpolated at the take-off Re) - the
//                                lifting line, trim, static margin and structure are unchanged.
//                                Verified: polar OFF reproduces the exact analytic baseline
//                                (regression suite unaffected, 16/16); polar ON checked against
//                                a Python twin and against a synthetic XFoil-format polar fit
//                                with known ground truth (see polar_summary.py test in pitfalls)
//   1.003  wing/stab             Profile gained three digitised sections (Eppler E817, E818,
//                                NACA 63-412 - real coordinates from the UIUC Airfoil
//                                Coordinates Database, checked against each one's published
//                                max thickness/camber). Camber %/Camber pos % are hidden for
//                                these (the table sets its own camber); Root/Tip thick % scale
//                                the table's own thickness distribution instead. Analytic
//                                alpha0/Cm for a tabulated profile now come from numerically
//                                differentiating its digitised camber line (same thin-aerofoil
//                                integral as NACA4, not a new approximation) rather than a
//                                fixed table value - Section polar still overrides this if set.
//                                NACA4 stays the default profile; nothing changes unless Profile
//                                is switched. Custom pasted .dat import is still a later phase.
//   1.004  wing/stab             Section polar's 13 fields now prefill from the real fitted
//                                E817/E818/NACA 63-412 polars (fetched and fit this session)
//                                when that Profile is selected and Section data is switched to
//                                Polar summary - selecting a tabulated profile's real aero data
//                                no longer needs copy-pasting 13 numbers in by hand. Falls back
//                                to the previous generic defaults for NACA4 or no selection
//   1.005  wing/stab             1.004 failed: "Duplicate feature parameter" - Onshape rejects a
//                                parameter declared in more than one branch, even mutually
//                                exclusive if/else ones. Replaced with Section data = Built-in,
//                                which reads the fitted E817/E818/NACA 63-412 polars from a table
//                                in code (resolvePolar/builtinPolar); Polar summary is back to one
//                                plain declaration per field with generic defaults
//   1.000  mast                  new Foil mast feature: symmetric NACA 00xx mast lofted between two
//                                sections, bolted board plate (twin tracks, optional countersink),
//                                optional lofted motor pod; publishes foilMastModel. Geometry only -
//                                mast drag in Foil performance is a separate next step
//   1.001  mast                  motor pod redesigned: nose tip on the mast chord (Nose start %),
//                                elliptical fairing to full diameter (Fairing length), cylinder to a
//                                flat rear face Aft extension behind the mast TE for a hand-modelled
//                                motor mount. No protrusion ahead of the mast, no tail fairing.
//                                Replaces Pod length, Pod X %, Nose % and Tail %
//   1.002  mast                  pod nose is now a loft of ellipses from the mast's own local
//                                thickness (x motor height, Blend height %) to the motor circle,
//                                eased with zero slope at both ends so the pod swells out of the
//                                mast faces instead of sitting on them as an appendage. Fairing
//                                length default 100 -> 150 mm (about 2 x motor dia)
//   1.003  mast                  countersinks moved to the plate underside (mast side) - bolts go in
//                                from below into the board's track nuts; added a check that the
//                                bolt heads clear the mast sides
//   1.000  fuselage              new Foil fuselage feature: streamlined body (elliptical nose/tail
//                                taper, reusing ellipseSplines) between the wing root pivot and the
//                                stab's own Arm/Height (read via foilStabArm; foilStabHeight falls
//                                back to 0 if not published), with bolted wing/stab mounts and an
//                                optional bolted mast box sized and positioned from foilMastModel -
//                                geometry only, drag comes later in Foil performance
//   1.006  stab                  publishes foilStabHeight (the Height parameter was never
//                                published before - Foil fuselage needs it to place its
//                                centreline; without this it would have silently assumed the
//                                stab sits level with the wing even when Height is nonzero)
//   1.001  fuselage              fixed CANNOT_RESOLVE_ENTITIES: the hole cut targeted the union's id,
//                                which creates no body - now targets this feature's solids minus the
//                                hole tools. Box base sunk to the centreline (it was touching the
//                                curved top only along a line); box bolt holes now run from the
//                                fuselage underside with the countersink there (it was buried inside
//                                the body at the box's own underside)
//   1.006  wing                  optional Mount pad (on by default): flat-topped boss on the upper
//                                root surface, fitted to the actual root section, with a row of
//                                vertical bolt holes and underside countersinks; publishes
//                                foilWingPad (top Z etc.) for Foil fuselage to sit on
//   1.007  wing                  Mount pad removed (not streamlined) and replaced by an optional
//                                Tube socket: streamlined nacelle on the root, axis through the
//                                root's mid-thickness at its thickest point, bore open at the rear
//                                for a round fuselage tube, optional vertical pins; publishes
//                                foilWingSocket for the tube fuselage to use
//   build 21                     version moved into the file's top comment header (was a separate
//                                line above the import); header text brought up to date
//   1.008  wing (build 22)       tube socket reshaped for low drag: no nose ahead of the wing - it
//                                starts hidden inside the wing at the root's thickest point and
//                                blends out of both surfaces (Blend length), extends behind the TE
//                                by Rear extension, eases onto the tube (Rear fairing). Replaces
//                                Rear face X, Nacelle length and Nose length
//   build 23                     fuselage 2.000: rewritten as a round tube - starts at the bottom of
//                                the wing socket bore, parallel past the mast, eased taper to Tail
//                                dia at the stab, rounded tail cap, flat stab seat cut at the stab's
//                                lowest root point, stab bolts, pin holes matching the wing socket.
//                                Placement conflicts are warnings naming the fix, never changed here.
//                                wing 1.009: socket publishes its pin pattern. stab 1.007: publishes
//                                foilStabRoot (LE/TE X, lowest root Z). buildFoil returns rootPts
//   build 24                     fuselage 2.001: body now at the socket's outside diameter, flush at
//                                the rear face, with a spigot of Tube dia plugging into the bore
//                                (two solids joined - a loft cannot step). Warns if the wing's Rear
//                                fairing would spoil the flush joint. wing 1.010: Rear fairing
//                                default 0; socket publishes rearFair
//   build 25                     1.010/2.001 made the whole fuselage as fat as the nacelle's PEAK
//                                diameter - wrong direction, high drag. Fixed: Rear fairing default
//                                restored to 25 mm (0 refused) so the socket actually tapers down
//                                near the tube; wing publishes rearDia (the diameter that taper
//                                reaches at the rear face); fuselage body matches rearDia, not
//                                nacelleDia - flush at the join, slender everywhere aft of it
//   build 26                     fuselage 2.003: new Tail overhang toggle (default off) - the tail
//                                (seat margin + Tail cap) is shortened/clamped to stay within the
//                                stab's own trailing edge, so it never pokes out as a visible nub;
//                                turn it on to always build Tail cap at full length. wing 1.012:
//                                Socket depth can no longer reach past the wing's own leading edge
//                                (was previously only checked against the blend, not the true LE)
//   build 27                     fuselage 2.004: fixed "Cannot assign to constant xSeat1" - it is
//                                reassigned when Tail overhang clamps it to the stab TE, so it must
//                                be var, not const
//   build 28                     fuselage 2.005: Tail cap + Tail overhang (boolean) replaced by one
//                                Overhang parameter (0-200 mm). The tail cap always tapers smoothly
//                                to a rounded point over Overhang, unconditionally - no toggle, no
//                                clamping to the stab TE, no flat/abrupt end at any setting. Seat
//                                margin running past the stab TE is still an independent warning
//   build 29                     fuselage 2.006: fixed the seat cut running all the way across the
//                                tail cap instead of stopping at xSeat1 - it was flattening the
//                                taper the loft had already built, producing a chopped-off end
//                                instead of the smooth rounded point Overhang was supposed to give
//   build 30                     fuselage 2.007: Overhang redefined entirely - it is now the X of
//                                the fuselage's tapered tip measured from the stab's own Arm, not a
//                                trim added on top of Seat margin. Can be negative (tip ends before
//                                the stab, even short of the seat). Removed a dead, always-true
//                                check ("Seat margin runs past stab TE") that silently clamped away
//                                any positive Seat margin on every regen - Seat margin extending past
//                                the stab's own TE is correct by design, not a conflict
//   build 31                     fuselage 2.008: fixed "Variable xTaperEnd not found" - the 2.007
//                                rename to xTailDia missed one leftover use in the notice string.
//                                Caught by grepping the WHOLE file for the old name after this fix,
//                                not just the section that was edited
//   build 32                     fuselage 2.009: tail tip's minimum radius floor was 10% of Tail
//                                dia (1.6 mm across at the default) - reads as a visible flat/
//                                squared end on shorter tapers, not a point. Dropped to 2% (0.3 mm)
//   build 33                     fuselage 2.010: the tail tip was never actually elliptical - radius
//                                was sqrt(1 - eased_x^2), nesting two different easings, which stays
//                                near full radius for most of the taper then collapses sharply right
//                                at the end (a squared cylinder with a cap, not a curve). Rewritten
//                                so X and radius share one angle (sin/cos of the same phi) - a true
//                                quarter-ellipse, narrowing the whole way, reaching zero on its own.
//                                No more arbitrary minimum-radius floor (was 10%, then 2%) - just a
//                                0.1% hair's-width value so the final sketch circle isn't exactly 0
//   build 34                     fuselage 2.011: the real cause of "still squared off" when Overhang
//                                is shorter than the stab - the seat cut (x1 = xSeat1, fixed) and the
//                                stab bolt holes (full tail radius, centred on Arm) never accounted
//                                for the tip already being at xEnd < xSeat1. A full-size bolt hole or
//                                a seat box reaching past the actual tapered material rounds the
//                                point off. Both now clip to the tube's real extent: the seat cut
//                                stops at xEnd - 1mm, and any bolt that would fall in already-too-
//                                thin material is skipped with a warning naming how many and why
//   build 35                     Foil fuselage deleted entirely per the user's instruction, after
//                                repeated fixes each addressed the specific defect shown without the
//                                finished part being right. See the note above the version header.
//                                Nothing else referenced foilFuselageModel, so nothing else changes.
//                                foilStabRoot stays published by the stab (harmless, useful again
//                                whenever the fuselage is rebuilt)
//   build 36                     fuselage 3.000: rebuilt from a clean sheet (not the 2.x code).
//                                Spigot into the wing socket bore, flush body at the socket's rear
//                                diameter, parallel past the mast, eased taper to Tail dia, a true
//                                quarter-ellipse tip (Tip length) ending at Overhang from the stab root
//                                TE - the two are independent, so the tip is never squashed. Flat seat
//                                confined to the stab footprint and the tube's own length; blind stab
//                                bolt holes down from the seat, centred on the stab root mid-chord,
//                                each checked against the local profile radius (skipped with a
//                                warning if it would leave < 1 mm of wall). Mirrors a Python
//                                reference model checked at Overhang 60/20/0/-20 before writing
//   build 37                     fuselage 3.001: Mast pocket - a pocket in the top of the body shaped
//                                to the mast's own NACA section plus Clearance, Pocket depth deep;
//                                the mast sits on its floor (warning gives the matching mast Base
//                                height). mast 1.004: publishes te and points so the pocket matches
//   build 38                     mast 1.005: Base height limits -150..150 mm (was 0..150) - the
//                                fuselage pocket floor can sit below the wing pivot, so the value the
//                                fuselage warning asked for could not be entered. fuselage 3.002: the
//                                stab bolt warning now says whether the hole would break through and
//                                by how much, and gives the Overhang and Bolt depth that would fix it
//   build 39                     fuselage 3.003: Pocket depth removed - the pocket floor is the mast's
//                                own Base height, so moving the mast reshapes the pocket (depth and
//                                position). Mast base above the fuselage: no pocket, warning with a
//                                Base height to use. Too low (< 2 mm floor): pocket stops at the
//                                limit, warning with the lowest Base height that fits
//   build 40                     stab 1.008: Mount pad - a wedge under the stab root, flat horizontal
//                                bottom, top following the root's own lower surface (so it fixes the
//                                incidence against the fuselage seat and recuts when Incidence
//                                changes). foilStabRoot.bottomZ is now the pad bottom, so the Foil
//                                fuselage seat moves to it with no fuselage change
//   build 41                     stab 1.009: removed the made-up "stab thinner than 1.5 mm" pad length
//                                limit. It only guarded a fixed 0.5 mm overlap that would poke through
//                                near the TE; the overlap now scales with local thickness (padLift),
//                                so any Pad length works. Beyond the root chord the pad runs LE to TE
//   build 42                     performance 1.003: mast, motor pod and fuselage drag in every speed
//                                point (partsDrag). Mast: only the part between its base and the
//                                surface (Wing depth - Base height) is wetted, 2D friction x thickness
//                                form factor, plus Hoerner spray 0.24 q t^2. Pod/fuselage: friction x
//                                body form factor on external wetted area. New CSV columns
//                                drag_mast_N, drag_body_N; notice splits them out. Not in trim.
//                                fuselage 3.004: publishes len and wettedExt from its own profile
//   build 43                     performance 1.004: motor pod can be partly or fully out of the water.
//                                Friction scales with its wetted fraction (from where the surface cuts
//                                its round section), plus spray on its waterline width when it breaks
//                                the surface; zero when fully out. Warnings for both cases (prop would
//                                ventilate / not drive the foil). Previously anything not fully under
//                                water counted as zero drag
//   build 44                     performance 1.005: console mislabelled the pod's spray as the mast's
//                                ("mast ... incl. spray 8.72 N" was 0.74 N mast + 7.97 N pod). Spray is
//                                now reported separately; totals were already right
//   build 45                     performance 1.006: foil assist - a high pod in or out of the water is
//                                the rider's choice of mode, not a fault. Depth-dependent part data moved
//                                into rideDepth(); cruise is also solved at the pod-out depth (surface
//                                10 mm below the pod) and pod-in depth (10 mm above it), reported in
//                                the notice and console. The pod state at Wing depth is information;
//                                warnings only when a mode is physically impossible
//   build 46                     wing/stab 1.013/1.010: Built-in polar now covers NACA 4-digit, not
//                                just E817/E818/N63412. alpha0/cm0 are the EXACT thin-aerofoil
//                                integral (zeroLiftAngle/momentCoefficient - same as Analytic, not a
//                                fit). Lift slope, CLmax, drag bucket are a linear fit in (thickness,
//                                camber) against 4 real XFoil polars (NACA 0008/0018/2412/4412),
//                                clamped to the Polar summary fields' own limits. CLcd is anchored
//                                through zero at zero camber by symmetry, not fit - the raw fit gave
//                                a physically impossible negative value from one data point (0008)
//   build 47                     wing/stab 1.014/1.011: fixed "precondition analysis failed" - the
//                                Section data tooltip (extended for NACA4 Built-in) was 1042 chars,
//                                over Onshape's 900 char limit on parameter descriptions. That single
//                                failure cascaded into "Only previously defined parameters allowed in
//                                comparisons" on every later use of polarSource, since the compiler
//                                never registered the parameter as declared. Shortened to 756 chars
//   build 48                     performance 1.007: optional Propulsion group (off by default). Thrust =
//                                drag at each speed -> prop rpm from Wageningen B-series KT/KQ (same
//                                tables as the B-series blade feature; reproduces its 4249 rpm / 58.6 kgf
//                                static and 4906 rpm / 20.9 kgf at 30 km/h with 12 mOhm), then motor A
//                                (8.27/kV), throttle, battery A/W, Wh/km, range, and top speed where
//                                full-power thrust meets drag. Solved at Wing depth if the prop is under
//                                water there, else at the pod-in depth; with Propulsion on, the foil
//                                assist in/out depths include the prop disc. New CSV columns, variables
//                                foilCruiseBatteryPower/foilCruiseWhPerKm/foilRangeKm/foilTopSpeed
//   build 49                     performance 1.008: thrust couple in trim when Propulsion is on and the
//                                mast has a pod. Thrust = drag, so thrust on the pod axis against each
//                                drag force at its own height (stab baseZ, fuselage axisZ, mast mid-wetted
//                                span, spray at the surface, pod axis) is a pure couple - no CG height
//                                input needed. Powered trim CG / static margin in the notice, console and
//                                CSV; warning if the powered static margin drops under 5 % (or below 0)
//                                anywhere from take-off to max. Unpowered columns unchanged
//   build 50                     performance 1.009: Pod height now sets the layout. Low pod = eFoil (motor
//                                in the water at every rideable depth); high pod = foil assist, with a
//                                motor mode (deep) and a pump/wave mode (shallow, pod out). Pod out only
//                                counts if the wing can ride there (>= 2 MAC, the Wing depth free-surface
//                                limit) - it used to accept any depth > 0 (80 mm with a 150 mm pod). The
//                                "pod too low to clear the water" warning is gone: a low pod is an eFoil,
//                                not a fault; the console gives the Pod height raise that makes it assist
//   build 51                     mold 2.000 (Foil mold -> Foil mold, never run in Onshape before, so
//                                rebuilt): block = part bounding box + Flange width + Base thickness,
//                                split by a parting sheet lofted through every station's CAMBER LINE
//                                (chord-line parting leaves a tongue of mold under a cambered TE),
//                                extended straight through the flange and, at the wing socket, aimed
//                                through the nacelle axis; part subtracted from both halves (keepTools).
//                                Printer X/Y/Z + Tile margin: reports tiles per half (cuts, dowels and
//                                registration keys are the next build). Ply schedule and gull check
//                                kept. wing 1.015 / stab 1.012: model publishes profileName, camber,
//                                camberPos, mirror for the mold's section rebuild
//   build 52                     mold 2.001: did not parse - `box` is a reserved word in FeatureScript
//                                (boxed values), used as a local name for the part's bounding box.
//                                Renamed pbox (and all -> rows). lint_fs.py now knows `box`
//   build 53                     mold 2.002: removed an unused splitNote variable (compiler warning only)
//   build 54                     mold 2.003: parting loft failed LOFT_PROFILE_SOLID - opLoft builds a
//                                SOLID unless told otherwise, and open curves cannot bound one. Added
//                                bodyType SURFACE. (The block loft, two closed rectangles, was fine)
//   build 55                     mold 2.004: surface loft refused (LOFT_INVALID). Parting rebuilt as a
//                                SOLID curtain under the camber surface from closed planar sketch
//                                profiles (spline + 3 lines, the foil's own loft pattern); lower half =
//                                block INTERSECTION curtain, upper = block minus lower (keepTools);
//                                no opSplitPart, no surface loft, no qContainsPoint
//   build 56                     mold 2.005: stab molded, wing still LOFT_INVALID - one fit-spline ran
//                                through the camber points AND the long chord-direction extensions,
//                                with an 8 deg corner at the LE/TE; at a 6 mm tip chord that spline
//                                wiggles into a self-intersection. Now: spline through the camber
//                                line only, extensions as straight lines tangent to it (no corner)
//   build 57                     mold 2.006: 56 broke the stab too (LOFT_PROFILE_FAILED: extension line
//                                collinear with its straight mean line) and the wing was never the
//                                profile (Python check: no self-intersection) but the LOFT - 32
//                                profiles of wildly different proportions fold. Now: horizontal
//                                extensions (LE/TE stay vertices), one two-profile ruled loft per
//                                station pair, all subtracted from the block -> upper; second block
//                                minus upper -> lower. Socket ramp is one straight line to the axis
//   build 58                     mold 2.007: 57 got through every loft and the half booleans on the wing;
//                                the cavity subtraction failed BOOLEAN_INVALID. Now cut per half with a
//                                regenError naming the half and the tip thickness (wing default tip is
//                                0.06 mm: 4 % of a 6 mm end chord x Cap end 25 %); warning under 1 mm
//   build 59                     mold 2.008: wing LOWER cavity still invalid with socket off, tip drop 0
//                                and a 0.14 mm tip - none of those. Parting stations sat exactly on
//                                the part's seams (y = 0 mirror join, y = +/-h tip end face plane);
//                                moved 0.4 mm off them so no sheet seam lies in a part face or edge
//   build 60                     mold 2.009: WING MOLD CONFIRMED with tip drop 0 (59). With droop the
//                                cavity cuts pass but evBox3d found no LOWER body: a lazy qSubtraction
//                                query lost it after the cut. Lower is now frozen with evaluateQuery
//                                right after it is made (like upper); the report counts bodies and
//                                warns instead of failing if a half is split or missing
//   build 61                     mold 2.010: BOTH MOLDS CONFIRMED (60, wing with droop). Tiling: each
//                                half cut along the span into printer-sized tiles (and across the chord
//                                if still too wide), Stagger joints offsets the upper cuts half a tile;
//                                dowel holes (Pin dia/length/fit) drilled in the base layer centred on
//                                every cut before cutting - two per span joint in the flanges, one per
//                                tile across a chord joint. Cuts: construction plane split, with a
//                                lofted-sheet fallback. Base thickness default 12 -> 15 (pins live in it)
//   build 62                     mold 2.011: STAB MOLD TILED AND DRILLED on 61 (plane split works). Wing:
//                                drilling could not resolve its target - the frozen lower half again went
//                                stale after the cavity cut. Halves and tiles are now re-found by
//                                geometry (touching the block top = upper, bottom = lower) before every
//                                drill, cut and the report; no body identity is carried across a boolean
//   build 63                     mold 2.012: TILING AND DOWELS CONFIRMED on wing and stab (62). Tiles are
//                                now named "<Wing|Stab> mold <upper|lower> k of n [fwd/aft]" (setProperty
//                                NAME), ordered from the -Y end, so the parts list and exports read
//   build 64                     mold 2.013: NAMES AND SOCKET-ON CONFIRMED (63). Half keys: vertical
//                                registration dowel holes through the parting in both flanges, one pair
//                                per span tile a quarter tile in from the joint (clear of all cuts and
//                                tile pins in both halves), Key dia/length, drilled into both halves
//                                before the cuts. Key length capped so it cannot break the thinner half
//   build 65                     mold 2.014: Key style = Printed keys (default) or Dowel holes. Printed:
//                                tapered boss (Pin/Key dia, Key height, Key draft) on one side of every
//                                joint, socket (+Pin fit, +0.3 mm) on the other; bosses point +Y, +X and
//                                up from the lower half (print unsupported cavity-up); added after the
//                                cuts, base sunk 1 mm, tiles found by footprint (moldTileAt). User's
//                                choice: printed keys on every joint instead of dowels
//   build 66                     mold 2.015: keys were too small (user). Defaults Pin dia 8 -> 12, Key dia
//                                8 -> 14, Key height 5 -> 8, Base thickness 15 -> 20; limits to 30/25 mm
//                                with checks against Base thickness - 4 and Flange width - 4
//   build 67                     stab 1.013: Link profile (default on) - a linked stab now takes the
//                                wing's section family (read from foilWingModel.profileName) as well as
//                                area/AR/thickness/incidence; it kept NACA4 when the wing went to E818.
//                                Own Camber % still applies for NACA4. Notice shows the profile used
//   build 68                     mold 2.016: Surface allow. (signed cavity offset via an offset copy of
//                                the part, opOffsetFace; 0 = off) and Pinch-off groove in the lower
//                                half: planform outline (LE/TE per station, nacelle faired in) offset by
//                                Land width and Land + Groove width (moldOffsetLoop: bevel convex, mitre
//                                reflex), prisms lofted from polygon sketches, ring = outer - inner, floor
//                                = ring minus the curtain lowered by Groove depth (opPattern copy), cut
//                                from the lower half before the tiles
//                                stab 1.014: Invert section (default on) for a linked tabulated profile -
//                                67 showed an E818 stab the right way up LIFTS (CL0 +0.24, static margin
//                                -39 %). Section mirrored in z, alpha0/Cm0 negated, polar alpha0/Cm/CLcd
//                                negated; model publishes inverted, the mold follows it
//   build 69                     mold 2.017: (1) the groove cut could not resolve the lower half - the
//                                transient queries evaluateQuery returns are only valid until the next
//                                operation changes the context; no body is now held across ANY
//                                operation (moldHalves right before every boolean, tool bodies never
//                                touch the block faces, printed keys look their tiles up after the tool
//                                exists). (2) E818 wing: upper cavity invalid - the mean line through the
//                                table's (0,0) leaves a drooped nose. Parting is now the true silhouette:
//                                nose-most to tail-most point of the placed section along the midline
//                                of its vertical extent, 30 samples per station (12 were too few for
//                                E818's aft-loaded, sub-millimetre TE region). wing 1.016 / stab 1.015
//                                publish teThick for it. Surface allow. CONFIRMED (stab, -0.2, in 68)
//   build 70                     stab 1.016: Link profile default on -> off (user: the stab keeps its own,
//                                symmetric, profile). Option and Invert section kept for a matched
//                                cambered stab. No other change
//   build 71                     stab 1.017: Link profile removed - the stab always uses its own Profile,
//                                linked or not (user). Invert section kept as a stab-only field, shown
//                                for a tabulated own profile, default on (cambered stab = camber down)
//   build 72                     mold 2.018: Surface allow. removed (user: a 0.2 mm coat is within layup
//                                tolerance; the offset refused thin tips). The cavity is cut with the
//                                part itself again. opOffsetFace itself worked where the tip allowed it
//   build 73                     fuselage 3.005: Stab block (default on) - a rectangular block from the
//                                body axis up to the stab pad's underside, the pad's width, the seat's
//                                length, joined before the seat cut and bolts: a block-on-block joint
//                                with real bolt depth instead of a flat shaved off the tube (user: the
//                                fuselage is high-stress and solid; M8). Tail dia default 16 -> 24 and
//                                clamped to the body instead of erroring; Stab bolt dia 5 -> 6.8 (M8
//                                tapping), Bolt depth 10 -> 16. stab 1.018: foilStabRoot publishes
//                                padOn/padWidth/padLength; Pad width default 16 -> 24
//   build 74                     fuselage 3.006: with the stab pad below the body top the block cannot
//                                help and the seat still shaves the body (user screenshot: "worse").
//                                Now warns with the exact Height to set so the pad sits on the block
//                                above a full round body (stab Height 8 mm put the pad on the axis)
//   build 75                     mold 2.019: wing with the tube socket on failed both tile-cut attempts
//                                (SPLIT_FAILED) at the chordwise cut, which ran through the nacelle.
//                                With the socket on and two tiles across the chord, the cut now goes
//                                just ahead of the nacelle start (socket axisX - 5 mm) when both tiles
//                                still fit, so the bore core stays in one tile. Cause not confirmed
//   build 76                     mold 2.020: Socket plug (user: the socket bore needs a separate plug).
//                                Cavity cut with a copy of the wing whose bore and pin holes are filled;
//                                a half-round channel (bore dia + Pin fit) behind the rear face in both
//                                halves; a separate "Wing socket plug" body, bore dia x (depth + Plug
//                                extension). Chordwise cuts now target the halves only, not every solid
//   build 77                     mold 2.021: Source model = Mast. The user molded the mast as a wing and
//                                the first loft failed (span is Z, thickness Y). Mast mode works on a copy
//                                laid flat (rotationAround X 90 deg + drop to Z -400: span -> -Y,
//                                thickness -> Z), flat parting on the mid-plane (one box curtain), outline
//                                = mast rectangle + plate for the groove, single-zone ply count, names
//                                "Mast mold". Pod must be off (regenError). mast 1.006 publishes the
//                                plate dimensions for the outline
//   build 78                     wing 1.017, stab 1.019, mast 1.007, fuselage 3.007: every feature names
//                                the part it makes (user: "each tool should name the parts appropriately")
//                                - "Wing" / "Wing (half)", "Stabiliser" / "Stabiliser (half)", "Mast",
//                                "Fuselage" - via nameSolids(), the same setProperty NAME the mold uses
//   build 79                     mold 2.022: Ply schedule -> Layup. The fill-% schedule described a 30-60 %
//                                empty cavity and its compression check could never fire. Now three
//                                materials sized from the part: woven skins (Skin plies x Skin gsm on the
//                                part's surface area), UD caps (Cap width % x Cap thick % of the section,
//                                ply count from gsm / (1780 x Vf), cut list on the console), tow for the
//                                rest of evVolume(part), resin from Fibre vol %, Overcharge %, cloth and
//                                resin waste. Removed Ply thickness, Root/Mid/Tip fill %, Zone break 1/2
//   build 80                     mold 2.023: cap ply counts round to the nearest ply and ply k runs to
//                                where the stack is k - 0.5 plies thick (ceil left a 0 mm innermost ply
//                                in the build 79 cut list: stab ply 19, wing ply 53)
//   build 81                     wing 1.018, stab 1.020: Min tip (boolean, off) + Min tip mm (1): the
//                                planform solve (now solvePlanform) raises End/Tip ratio until the section
//                                at the cap start is at least Min tip mm; notice reports the ratio used.
//                                User: the linked stab's 7.5 mm tip chord gave a 0.7 mm section - the
//                                chord, not t/c, is the lever. mold 2.024: the tip warning checks the cap
//                                start (not the cap end, which always runs out) and names End ratio first
//   build 82                     fuselage 3.008 publishes stabBoltX (world X of each bolt hole made) and
//                                stabBoltDia. mold 2.025: Bolt cones group (stab molds): a drafted frustum
//                                per bolt from the pad face to Cone web under the root section's top,
//                                unioned into the lower half - undersized, drilled to clearance after cure
//                                (user, after reviewing a forged-carbon stab build video)
//   build 83                     mold 2.026: moldTileAt picks the nearest body (evDistance) instead of the
//                                first loose bounding box containing the point - on the drooped wing tips
//                                that matched a neighbouring tile and left the half-key bosses floating as
//                                un-named parts (user screenshot). Warning if any body is neither an upper
//                                nor a lower tile after the keys. STAB_CONES console line and per-reason
//                                "no bolt cones" notice for the stab cones that did not appear
//   build 84                     fuselage 3.009: FUSELAGE_SEAT console line (seat note, bolt X list, warnings).
//                                mold 2.027: STAB_CONES "off - reason" console line. Both so a pasted
//                                console explains missing cones without the notice text
//   build 85                     stab 2.000, fuselage 4.000, mold 2.028: stab-fuselage joint redesigned on
//                                the Axis rear wing (user measured Andrew W's STL: pad on the fuselage side,
//                                22 wide, full chord, 45 % ramp, 7.4 proud; 40 mm tail fairing to 4 x 6;
//                                two bolts 22 mm from the LE at 35 pitch). Stab: Mount pad group (Pad side
//                                Top/Bottom, Pad width/height, Pad ramp %, Tail fairing: length, End
//                                width, End thick) built as side-prism x plan-prism intersection
//                                (buildStabMount); Mount bolts group (Stab bolts, Bolt from LE, Bolt
//                                pitch, Bolt dia) as through holes; foilStabRoot publishes padSide, padZ,
//                                topZ, tailOn, tailEndX, boltX, boltDia. Fuselage passes OVER the stab
//                                with Pad side Top: flat seat at the pad plane (wants it ~4 mm under the
//                                axis, warning gives the Height), block hangs under the body, tip ends at
//                                the stab's tail end, tapped holes UP on the stab's pattern; Stab bolts /
//                                Stab pitch removed; Bolt depth default 14. Mold cones from the stab's
//                                pattern on either side (no fuselage needed)
//   build 86                     stab 2.001: tail fairing is a loft of superellipse sections (exponent 12
//                                at the TE -> 2 at the end, flat at the pad plane) instead of a box prism
//                                - user: "the tail is square edged rather than a smooth profile". Pairwise
//                                ruled lofts over 9 stations, unioned. Pad body unchanged (rectangle)
//   build 87                     Build 86 confirmed: stab mount, tail, holes and mold cones (STAB_CONES made=2).
//                                mold 2.029: over the pad's plan the parting is the pad-side skin (nose,
//                                ramp, pad plane out to the block edge) instead of the camber line, with
//                                stations 0.4 mm inside/outside the pad edge - the camber parting left the
//                                tail fairing trapped in the upper half (its far face above the parting)
//                                and the groove ran under it; the groove outline now follows the tail
//                                plan. stab 2.002 publishes padRampPct, padX0, tailLength, tailEndWidth,
//                                tailExp. fuselage 4.001: with a stab tail the tip's radius follows the
//                                stab's plan law (scaled rT/hW) and the circles drop to stay tangent to
//                                the pad plane - user: the fuselage tip "is a different shape"
//   build 88                     Build 87 mold confirmed to regenerate (raised T at the pad plane, cones).
//                                mold 2.030: pad-edge stations both inside the pad (hp - 0.5 / hp - 0.1)
//                                so the step face is inside the part - the straddling pair left a 0.4 mm
//                                lip over the skin beside the pad (user: "unattached surfaces").
//                                stab 2.003: tail as one smooth loft (try), pairwise ruled as fallback -
//                                the ruled segments read as terraces in the mold cavity
//   build 89                     mold 2.031: the pad-plane parting is a prism (pad-side skin profile lofted
//                                between y = +/-(hp - 0.05)) added to the curtain, instead of pad-edge
//                                stations - their sloped step showed as slivers along the T (user, twice).
//                                Spanwise tile cuts keep 5 mm clear of the stab pad / wing nacelle (moved
//                                to the keep-out edge when both tiles still fit): the lower half's centre
//                                cut ran along the tail and through the bolt cones (user: "pins interfere")
//   build 90                     mold 2.032: pad prism walls 0.2 mm inside the pad wall (0.05 gave
//                                BOOLEAN_INVALID on the lower cavity cut - near-coincident faces)
//   build 91                     mold 2.033: still BOOLEAN_INVALID at 0.2 mm - so the prism top is now
//                                0.15 mm under the pad skin (no face coincident with the pad face or
//                                the ramp); the upper half forms the top 0.15 mm of the pad
//   build 92                     Build 91 confirmed: stab mold regenerates with the prism T, smooth tail
//                                and cones. mold 2.034: the stab's own through holes had left full-size
//                                pins of mold in the lower cavity, into which the cones descended (user:
//                                "top and bottom pins interfere"). Each pin is now cut away (cylinder
//                                hole dia + 0.2, from the skin nearest the pad through the parting) before
//                                the cones go in; the stub under it lies inside the drilled hole
//   build 93                     mold 2.035: the pin cut targets only the half away from the pad - cutting
//                                both took the cones' seat out of the pad-side half and left them floating
//                                (user: Parts 28 and 29)
//   build 94                     mast 1.008: Pod wall (4) + Cavity length (80): a blind motor cavity from
//                                the pod's rear face, a placeholder to tune to the motor; publishes
//                                podRearX, podNoseX, cavDia, cavLength. mold 2.036: the pod is molded with
//                                the mast (user: "if a pod is included it should be in the mold ... the
//                                motor pod should always have a plug"): cavity filled in the laid-flat copy,
//                                pod bar in the groove outline, half-round channel behind the rear face,
//                                "Mast pod plug" body (cavity + Plug extension). Pod regenError removed
//   build 95                     mast 1.009: Pod wall replaced by Cavity dia (default 20, at most Motor dia
//                                - 4); Cavity length default 10 - user: a small placeholder pocket to open
//                                out to the motor by hand
//   build 96                     mold 2.037: the pod cavity volume is subtracted from both halves after the
//                                cavity cut (belt and braces for the fill in the copy) - user: "any cavity
//                                in the pod should be part of the plug not the mast outer pieces"
//   build 97                     mold 2.038: the pod plug is extracted from the part, not rebuilt from the
//                                placeholder (user: custom inside geometry - tabs, hollow shell - modelled
//                                before the mold must shape the plug). No fill in the copy; after the
//                                cavity cut a channel of radius podDia/2 - 1 severs the void's cores from
//                                the halves; the bodies touching neither block face are the cores; they
//                                are unioned with a handle of that radius in the channel = "Mast pod plug",
//                                whose shoulder forms the rear face. Plug Extension = handle length
//   build 98                     mold 2.039: the plug is found by geometry (moldFloating) after the union -
//                                the merged body kept a core's identity and the handle's query was empty
//                                (CANNOT_RESOLVE_ENTITIES at the evBox3d)
//   build 99                     mold 2.040: the plug existed after its join (build 98) but was gone at
//                                naming (CANNOT_RESOLVE_ENTITIES on setProperty). Keep-out generalised to
//                                a centre + half-width so the mast's pod band (y' = -podZ +/- podDia/2 +
//                                5) also repels spanwise seams and the half keys (a half key at the aft
//                                flange sat inside the plug channel); MAST_PLUG console lines count the
//                                floating bodies after the plug, the groove and the tiles/keys; naming
//                                the plug warns instead of throwing when it is missing
//   build 100                    fuselage 4.002: tail-matched tip circles dip 0.3 mm below the pad plane
//                                instead of tangent to it - the seat cut was BOOLEAN_INVALID the first
//                                time it ran with Height -6.6 (tangent tool face on cylinders)
//   build 101                    mold 2.041: moldFloating uses tight boxes; MAST_PLUG prints the cores count
//                                and the plug's box against the block (user: no plug part, no error)
//   build 102                    mold 2.042: build 101 trace - plug whole after its stage (1 floating,
//                                3 cores), gone after the groove stage. The plug now carries an attribute
//                                (foilPodPlug) and moldTrace prints solids / floating / the tagged plug's
//                                box after every groove operation; naming uses the attribute first
//   build 103                    mold 2.043: trace showed gFloor consumed the plug as a tool - the lowered
//                                curtain touches the block bottom, was classed as a lower body, got the
//                                cavity and channel cuts, and its severed pocket core was joined into the
//                                plug, which then answered to the curtain's identity. `solids` now excludes
//                                the lowered curtain. Groove cleared from the pod's band (user: keep the
//                                pinch-off away from the pod)
//   build 104                    Build 103 confirmed: plug survives every stage (6 cores from the user's
//                                custom inside), fuselage seats on the pad. mold 2.044: stage traces
//                                removed, one MAST_PLUG summary line kept
//   build 105                    stab 2.004 publishes the mount contour (ramp + pad plane, world x/z) in
//                                foilStabRoot.contour. fuselage 4.003: the seat is a prism cut to that
//                                contour (spline top) instead of a flat plane, the block reaches the
//                                contour's lowest point, and the tapped holes start at the local contour
//                                height - user: "the fuselage should have the same contour as the stab
//                                mounting block" (a wedge gap over the ramp)
//   build 106                    fuselage 4.004: the block is confined to the flat of the pad (ramp end to
//                                the tip start) at the pad plane - build 105's block hung below the tube
//                                ahead of the nose and past the tip (user: "patchwork")
//   build 107                    mold 2.045: mast mold in three parts (user): the left/right halves stop
//                                0.5 mm into the plate's underside; a "Mast plate mold" tray (plate
//                                outline + flange, block height, Base thickness beyond the board face)
//                                is cut by the mast copy and keyed to the halves' end faces with two
//                                printed keys; plate holes molded by the tray's pins; groove outline no
//                                longer includes the plate band; mast halves named left / right
//   build 108                    Build 107 confirmed: three-part mast mold regenerates. mast 1.010 publishes
//                                the plate bolt layout. mold 2.046: the tray's pins were the copied holes
//                                with the countersink at the free end (mushroom heads, user: would not
//                                release) - pocket cleared and straight pins (bolt dia - 0.5) stood on the
//                                mast's pattern; drill and countersink after cure
//   build 109                    mast 1.011: Pod tilt (nose-down positive, rotates the pod and its cavity
//                                about the pod centre), published as podTilt. performance 1.010: the thrust
//                                vector is fixed to the body - angle to the flow = body angle - tilt; its
//                                vertical component unloads the foil and, at the pod's X, pitches nose-down
//                                (three trim passes); thrust along the axis (D / cos) feeds the prop; CSV
//                                thrust_angle_deg, thrust_vert_N; console line. mold 2.047: pod channel and
//                                handle along the tilted axis, keep-outs widened by the tilt spread
//   build 110                    mast 2.000: Taper and top group - Top chord, Taper side (symmetric /
//                                straight LE / straight TE), Top thick, Thicken from % (smoothstep to the
//                                top); the blade is a loft through 13 sections by mastLaw(); the pod and
//                                the plate use the local chord / LE; publishes chordTop, thickTop,
//                                thickenFrom, taperSide, leXTop, plateXc (user: taper parameters and a
//                                thicker top near the plate). performance 1.011: mast drag section at half
//                                the submerged height. mold 2.048: trapezoid outline, plate centre from
//                                plateXc, mean section for the UD cap volume
//   build 111                    Build 110 confirmed (tapered, thickened mast and its mold). Wing mold
//                                upper cavity BOOLEAN_INVALID on NACA 63-412 with Sweep exp / Drop exp 4,
//                                still at 40 stations. mold 2.049: Split stations limit 80; Tip bias
//                                (eta = 1 - (1 - u)^bias, default 2 ~ the old cosine packing) so
//                                stations can crowd into the outer third
//   build 112                    Build 111 confirmed (63-412 wing mold cuts at 50 stations, Tip bias 4).
//                                mold 2.050: Cut templates group - a 1 mm plate beside the block with the
//                                woven skin outline (planform developed along the droop, both halves) and
//                                one tapered strip per UD ply (30 % chord line, Cap width %, to the ply's
//                                end station) cut through it, + Trim margin; export the top face as DXF.
//                                Mast: rectangles. Console TEMPLATES key (user: templates for cutting)
//   build 113                    Build 112 confirmed (stab template plate, 12 shapes). mold 2.051: LAYUP
//                                console line (the resin and material totals were notice-only); the skin
//                                template key explains the single outline and the 45 deg outer ply
//   build 114                    mold 2.052: tally holes (3 mm, one per cut) under each template outline, so
//                                the count survives into the DXF (user: how many cuts of a template)
//   build 115                    Build 114 confirmed (template plate, LAYUP line). mold 2.053: Cap thick %
//                                is of the core inside the skins (section - 2 x skin plies x ply
//                                thickness), so the skin count moves the UD count and skins + caps never
//                                exceed a station (user: halving the skins changed nothing in the fill)
//   build 116                    performance 1.012 publishes foilWingLoads / foilStabLoads: the spanwise
//                                bending moment at the load factor (lltMoments, 21 stations; stab load =
//                                max(cruise lift, 15 % W)). mold 2.054: Stiffness group (UD / woven / tow
//                                moduli, Mast side load g) - EI per station from caps, skins and the tow
//                                core, curvature integrated twice: tip deflection at n g and 1 g and root
//                                cap stress for wing / stab; top deflection and base stress for the mast
//                                under a side load at the plate (user: strength / flex)
//   build 117                    Build 116 confirmed (wing 3.2 mm / 67 MPa, stab 0.6 mm / 35 MPa at 3 g).
//                                mold 2.055: mast load case turned round - plate fixed, side force at the
//                                fuselage end, moment F z peaking at the plate; reports the deflection at
//                                the fuselage end and the cap stress at the plate (was base-fixed)
//   build 118                    Build 117 confirmed (mast 111 mm / 323 MPa = the Python estimate).
//                                mold 2.056: UD cap ply count is PER CAP and every UD template is cut
//                                twice (one per face) - build 117 printed both caps' plies as one stack
//                                cut once, which cannot be laid up as written (mast 25 x 0.34 mm in a
//                                14 mm section). Mast cut list follows the taper / thickening law from
//                                the plate down (was a constant section from the base thickness, while
//                                the stiffness check credited the thicker top); mast templates are
//                                trapezoids with the plate end at the bottom of the strip. Plate (user:
//                                did you consider the plate): woven fill plies between its skins counted
//                                in the layup and on its template (cut N: skins + fill, tally holes wrap
//                                10 to a row), and the track bolt tension M / track spacing / bolts per
//                                row on the STIFFNESS line
//   build 119                    Mast-plate junction (user: high flex load there, no fillet, tab the two
//                                surfaces with alternating UD). mast 2.001: Root fillet (opFillet on the
//                                edges the mast/plate union made, in the plate underside plane; limited to
//                                the room on the plate; notice says if Onshape refuses it), published as
//                                rootFillet. mold 2.057: Cap run-out (0 = to the plate edge), Tab plies,
//                                Tab length - cap plies run out over the fillet onto the plate, UD tabs
//                                interleaved with them run Tab length down the mast; both in the cut list,
//                                the templates (fold line notched) and the material totals. Shear allow:
//                                STIFFNESS adds the junction check - cap force at the plate, shear over
//                                the bonded run-out (1 + 2 x tabs interfaces) against Shear allow / 2,
//                                the run-out needed, and the plate's bending stress between the tracks
//   build 120                    mast 2.002: root fillet FILLET_FAILED on build 119 although the user could
//                                fillet the seam by hand at 15 mm - the qCreatedBy(join, EDGE) selection
//                                was wrong; the seam is now picked explicitly: edges of the joined solid
//                                flat in the plate underside plane and inside the top section's footprint
//                                (evBox3d per edge). Notice counts the seam edges
//   build 121                    mast 2.003: FILLET_FAILED again on the explicit seam (2 edges: the fit
//                                spline and the 0.8 mm TE line), and a plain try still shows the error, so
//                                the fillet is now a ladder of try-silent attempts (all edges / no tangent
//                                propagation / long edges only / half radius); console MAST_FILLET lists
//                                the seam edges and the attempt that worked or every one that failed; on
//                                total failure the notice says to add a manual Fillet feature before
//                                Foil mold, which follows the part
//   build 122                    Build 121 confirmed: MAST_FILLET "OK: long edges only, no propagation at
//                                10 mm" (the 0.8 mm TE line edge is what fails); per-cap counts wing 22 /
//                                stab 10 / mast 22 -> 15; junction 52 kN, 2.6 MPa with 4 tabs. mast 2.004:
//                                that attempt is now first, the others stay as fallbacks; tooltip says the
//                                fillet stops at the TE line
//   build 123                    Build 122 confirmed (mast 17 / 25 from 60 %, fillet 15: 48.5 mm / 207 MPa;
//                                template plate screenshot). mold 2.058: the template plate is sized from
//                                the shapes' real V extent (vMin..vMax), not +/- the largest |v| - the
//                                mast's one-sided strips left the top half of the plate empty
//   build 124                    User: "this join has to be more stable than this" - relinking the stab at
//                                20 % thickened its root and lifted the pad plane above the fuselage axis,
//                                so the seat vanished at the Height that had worked. stab 2.005: Seat on
//                                tube (default on) + Seat drop: after the build the whole stab is shifted
//                                in Z so its seat plane (pad face, or the bare root surface) sits Seat drop
//                                below the wing socket's tube axis (above it with the pad underneath);
//                                Height is then reported, not typed; falls back to Height with no socket.
//                                The published root / pad / contour values and foilStabHeight carry the
//                                shifted position. fuselage 4.005: the no-seat warning names Seat on tube
//   build 125                    User: "the mount for the stab on the fuselage should always be the same
//                                size and position, not moving around". stab 3.000: the mount is a fixed
//                                interface pinned to the stab pivot, not to the root section - Flat start
//                                (ramp end), Tail start (where the tail fairing and the fuselage tip begin
//                                to taper), Tail end, Bolt 1 at + Bolt pitch, all mm from the pivot;
//                                replaces Pad ramp %, Tail length and Bolt from LE. The ramp runs from the
//                                LE to Flat start, the pad flat to the TE, the fairing full-width from the
//                                TE to Tail start then tapering to Tail end, so the seat plane, its length,
//                                the tapped-hole pattern and the fuselage's tip are the same for every stab
//                                with the same Arm. Warnings when the section does not fit the interface.
//                                foilStabRoot still publishes padRampPct / tailLength (derived) for the
//                                mold, plus tailStartX. fuselage 4.006: the tip tapers from tailStartX
//   build 126                    Build 125 confirmed on the foil-assist document (Seat on tube, fixed
//                                interface, 2 of 2 tapped holes). fuselage 4.007: stab-on-top seat accepts
//                                a flat into the top of the body down to min(4 mm, 0.35 R) above the axis,
//                                the mirror of the seat under it (it warned for any flat, so Seat on tube
//                                with the pad underneath always drew a warning); warns when the stab's
//                                clearance hole is not bigger than the tapping drill (user had 5 / 6.8)
//   build 127                    mold 2.059: Parts group (default on) - every body the feature made goes
//                                into one open composite part named "<Source> mold" (user: make the mold
//                                parts a parts group); try-silent so a composite failure never fails the
//                                mold. Source model tooltip no longer says the pod must be off
//   build 128                    Build 127: the open composite left the parts listed (Onshape lists an
//                                open composite's constituents; only a closed one nests them) and 4 keys
//                                floated where a spanwise seam crossed the socket plug channel. mold
//                                2.060: Parts group is a dropdown Closed (default) / Open / Off;
//                                moldPrintedKey returns false and makes nothing when a key point is more
//                                than 1 mm from any tile (the notice counts the skipped keys)
//   build 129                    Build 128: the closed composite hid every mold piece and was itself hidden
//                                in the parts list (user: "I have lost all my mold parts"). mold 2.061:
//                                Parts group defaults to Off - loose, named parts as before; Open / Closed
//                                remain as options
//   build 130                    Stab mold LOFT_FAILED with Pad side Bottom (foil-assist stab on top of
//                                the fuselage): the parting, pad prism and cones only handle a pad on
//                                top. mold 2.062: a pad-under stab is molded on a Z-mirrored copy about
//                                its pivot, with the model (incidence, washout, drop, dihedral, camber,
//                                inverted) and the mount map (padSide, padZ, top/bottom, contour)
//                                mirrored; the copy is deleted after the cavity cuts; the notice says to
//                                turn the finished part over (a Y-symmetric part molded upside down)
//   build 131                    User: "is it easier for the input to be the bolt size ... or make that
//                                an option". BoltSize enum M4-M10 + Custom, boltDims() (close-fit
//                                clearance / tapping drill). stab 3.001: Bolt dropdown (default M6),
//                                Bolt dia only when Custom; publishes tapDia and boltName. fuselage
//                                4.008: taps from the stab's named bolt, Stab bolt dia only for Custom;
//                                FUSELAGE_SEAT names the drill and bolt. mast 2.005: plate Bolt dropdown
//                                (default M8, clearance +0.1 mm looser), Bolt dia only when Custom
//   build 132                    User: bolts everywhere, and the countersink from the standard. boltDims
//                                carries ISO 10642 / DIN 7991 head dia and height; boltHead(). wing 1.019:
//                                socket Pin bolt dropdown (M6 default, +0.1 mm clearance), Pin dia only
//                                when Custom, publishes pinBolt. stab 3.002: Countersink (default on) on
//                                the face away from the pad to the head diameter, publishes headDia.
//                                mast 2.006: plate countersink to the standard head, not 2 x d. mold
//                                2.063: cone note says drill AND countersink after cure
//   build 133                    Stab mold CANNOT_RESOLVE_ENTITIES on the lower cavity cut (build 130,
//                                seated pad-under stab): since build 124 Seat on tube shifts the stab
//                                AFTER buildFoil, but foilStabModel kept the typed Height as baseZ, so
//                                the mold's parting and cavity were built dz away from the part. stab
//                                3.003 publishes the model at the shifted height; mold 2.064 also takes
//                                the stab's baseZ from foilStabHeight (the value the shift produced)
//   build 134                    User: "isn't it easier to make a 0 mm offset on the stab height always
//                                have the mount interface sit on the centreline of the fuselage". stab
//                                4.000: Height IS the seat plane's offset from the fuselage centreline
//                                (0 = on it, -4 typical with the pad on top, +4 underneath); Seat on
//                                tube and Seat drop removed; the stab is always shifted to it when the
//                                wing has a socket, else Height is the pivot offset as before. Log:
//                                height_mm (typed) + pivotZ_mm (effective). fuselage 4.009: accepts a
//                                flat to the centreline both ways, warns only past it, names Height.
//                                mold 2.065: build 133's stab mold reached the pinch-off and LOFT_FAILED
//                                in its offset outline (the fixed-interface tail meets the root at a
//                                shallow angle): moldOffsetLoop bevels near-parallel / far intersections
//                                (miter limit 3 x offset), and a groove that still cannot be built is
//                                skipped with a warning instead of failing the mold
//   build 135                    Build 134 confirmed on the foil-assist document: all three molds
//                                regenerate (stab mold complete on the mirrored pad-under stab, cones and
//                                templates made). fuselage 4.010: unused stabHeight removed (Onshape
//                                warned "set but not used")
//   build 136                    fuselage 4.011: seat cut LOFT_FAILED with the pad plane just under a 19 mm
//                                tail (Height -10): the cut region's floor was above the contour's nose end.
//                                Floor now 2 mm under the lowest contour point. Stab mold confirmed on the
//                                pad-top stab too (cones, templates)
//   build 137                    mold 2.066: the build 134 miter limit in moldOffsetLoop took the pinch-off
//                                groove off every mold (user: "where have my pinch-off grooves gone");
//                                reverted to the build 51-133 offset. The try-silent skip with its
//                                warning stays, so a groove that cannot be built no longer fails the mold
//   build 138                    mold 2.067: the mast check reports the WORST cap stress along the height
//                                and where it is, not only the plate's - plotting the foil-assist mast
//                                showed 243 MPa at 494 mm (where the thickening begins) against 198 at
//                                the plate; the notice says to start the thickening lower or thicken
//   build 139                    Error texts that named removed fields: stab 4.001 "Mount pad reaches
//                                outside..." now names Flat start / Bolt 1 at / Bolt pitch (was Pad X /
//                                Pad length); mast 2.007 bolt-head and countersink errors name Bolt (the
//                                dropdown), not Bolt dia
//   build 140                    First public release. mold 2.068: Parts group tooltip no longer quotes a
//                                build number (development history out of a published dialog)
//   build 141                    All six Feature Type Descriptions rewritten for publishing (Onshape shows
//                                them in the custom feature search): current scope, user terms, no internal
//                                variable names or brand names
//   build 142                    wing 1.021 / stab 4.003: Chord distribution gained Double taper (Break %,
//                                Mid ratio, Tip ratio): a steep root taper then a gentle outer one, the
//                                full-base stab shape (AFS U Carve 130 measured: break 28 %, mid 0.62, tip
//                                0.21, and the solver then returns AFS's own 360 mm span / 68 mm root for
//                                130 cm2 AR 10). chordFactor/shapeIntegral take brk, mid; the model maps
//                                publish them; chordFactor(m, eta) is the guarded accessor for consumers
//                                (performance 1.014, mold 2.070 use it). Profile gained Clark Y (UIUC table,
//                                flat lower surface from 30 %c, the section Jan described on foil.zone)
//                                with a built-in polar fit from airfoiltools XFoil runs at Re 0.2 M / 1 M.
//   build 143                    stab 4.004: LOFT_FAILED in buildStabMount with an inverted Clark Y and
//                                the pad on top. An inverted table keeps its point order, so the mount's
//                                index-based "upper" was the geometric lower surface: pad plane 6 mm
//                                above the underside, zero overlap lift, a self-overlapping side profile.
//                                The mount now swaps the halves by mid-chord Z (also fixes the far-face
//                                countersink for any inverted stab). wing 1.022 / stab 4.004: Clark Y is
//                                thickness-scaled about its flat lower surface, so the flat stays flat.
//   build 144                    USER: the double taper "has the approximate shape but sharp transitions;
//                                we need an option to use curves, including the tips". wing 1.023 / stab
//                                4.005: Blend % rounds the break with a quadratic Bezier tangent to both
//                                tapers (five stations across it); Tip cap gained Rounded + plan, which
//                                shrinks the chord along the cap's quarter-ellipse as well as the
//                                thickness, so linear and double tapers get rounded tips in plan. The
//                                chord law is now one map (chordFactor(pl, eta); model maps carry blend,
//                                capEta, planRound) and the area solver includes the plan rounding.
//                                performance 1.015 / mold 2.071 use the map; the template plate no
//                                longer adds its own linear cap taper when the law already rounds.
//   build 145                    USER: "need to be able to build the tail into the profile rather than
//                                depend on the mount pad". stab 4.006: Root tail (Tail length, Tail span %)
//                                extends the trailing edge at the centreline with a smoothstep fade, all
//                                aft whatever Align is, thickness held in mm (the section is stretched, not
//                                fattened); law map keys tail/tailEta, tailFactor(pl, eta); the solve loop
//                                re-derives the fraction as c0 settles; the notice's root chord includes it.
//                                mold 2.072 places sections and the template plate the same way.
//   build 146                    USER: "the wingtip leading edge corners are still sharp" (Rounded + plan
//                                with Align line 0: the shrink was applied about the alignment line, so
//                                the straight leading edge ran to a square corner). wing 1.024 / stab
//                                4.007 / mold 2.073: the plan rounding's shrink is centred on the
//                                mid-chord whatever Align line % is (capPlanFactor split out of
//                                chordFactor; xOff gains (0.5 - pivotFrac) x shrink), so both corners
//                                round. Align line % tooltips reworded for the double taper.
//   build 147                    wing 1.025 / stab 4.008: Min tip shrank a double taper's Tip ratio from
//                                0.21 to 0.128 ("raised to 0.128" in the notice). The 145 solve loop kept
//                                iterating while the root tail settled and the raise line ran even when
//                                the tip was already thick enough, scaling the ratio DOWN to the minimum.
//                                Now the ratio only changes when the tip is too thin.
//   build 148                    USER: "winglets, up/down or angle and area". wing 1.026 / stab 4.009:
//                                Winglet (Off/Up/Down), Winglet area, Winglet angle, Bend radius. The
//                                outer part of the developed half span bends on an arc then runs
//                                straight; the bend start is solved so the chord law's area outboard of
//                                it equals Winglet area; sections beyond it sit in planes square to the
//                                bent path (plane normal (0, -cos phi, -sin phi)), so a 90 deg winglet
//                                keeps its true section. Model maps carry wingletOn/Sign/Eta/Angle/R/
//                                Height and spanProj. performance 1.016: lifting-line span = projected
//                                span + 0.9 x winglet height when a winglet is on. mold 2.074: refuses a
//                                winglet foil with a clear message (parting and tiling of a bent tip
//                                are a later build).
//   build 149                    mold 2.075: molds a foil with a winglet up to 75 deg. The parting curve
//                                at a bent station is the section's midline in its own tilted plane
//                                (the pull direction projects onto that plane's up axis, so the
//                                silhouette points are unchanged), carried onto a VERTICAL curtain
//                                station at the path's y as zMid / cos(phi) (tilted sketch planes
//                                fold the ruled curtain: their floors fan inboard). Stations: bend
//                                start, four along the
//                                arc, just inside the tip, and one beyond the tip continued straight
//                                along the winglet past the block. Keys map y to eta through the path
//                                (wingletEtaFromY). Tiles still cut by Y planes; the block is the
//                                part's box, so the winglet's height adds to every tile.
//   build 150                    wing 1.027 / stab 4.010 / mold 2.076: with Tip cap = Rounded + plan the
//                                thickness cap law multiplied the plan shrink (Cap end % squared: a
//                                0.06 mm end face, BOOLEAN_INVALID cutting the cavity). The thickness
//                                law now divides the plan factor out, so the end face is Cap end % of
//                                the cap-start thickness as the tooltip says; the mold's tip advice
//                                reports it that way.
//   build 151                    mold 2.077: USER: "the mold works with the winglets off" (150 still
//                                BOOLEAN_INVALID with them on). 149's parting over the winglet lifted
//                                the midline by 1/cos(phi) on a vertical station: first order only,
//                                and at the LE/TE the error (twist x chord x tan phi) left slivers.
//                                Now the mid-surface over the bent tip is tabulated on 48 sub-stations
//                                in their true tilted planes (moldWingletTable) and each curtain
//                                station is that table cut by its vertical plane
//                                (moldPartingPointsWinglet), so the parting is on the surface to the
//                                table's spacing. Stations past the bend are chosen by y, not eta.
//   build 152                    mold 2.078: the UPPER cavity now cuts; the LOWER failed with
//                                CANNOT_RESOLVE_ENTITIES because the parting continued up the
//                                winglet's line beyond the tip and met the block's top at the edge, so
//                                the lower half touched both faces and was not a half. Beyond the tip
//                                the parting now runs flat at the tip's height.
//   build 153                    USER: "LE bumps as geometry despite the performance model ignoring
//                                them". wing 1.028 / stab 4.011: LE bumps (Bump height, Bump pitch,
//                                Bumps from %, Bumps to %): the leading edge moves +/- height/2
//                                sinusoidally along the span, TE fixed, thickness in mm kept, fading
//                                over half a pitch at each end; six stations per pitch. bumpOffset(pl,
//                                eta, h); model maps carry bumpOn/Amp/Pitch/From/To. mold 2.079 places
//                                its parting sections the same way (both parting functions) and adds
//                                the same stations. Performance and the template plate use the smooth
//                                outline. The winglet mold was confirmed on 152 (stab, 2 cm2, 45 deg).
//   build 154                    USER: "the Silk V2 also has a complex gull wing we cannot shape" (front
//                                view: flat centre to ~20 %, a distinct break, a near-straight drop to
//                                ~85 %, then the tips rise). wing 1.029 / stab 4.012: Drop from % - the
//                                drop law becomes ((eta - b)/(1 - b))^e beyond b, 0 before; dropShape /
//                                dropSlope replace eta^e and powerSlope everywhere the span line is
//                                built (sections, winglet frame, developed area, template plate, mold
//                                parting, stiffness slope); model maps carry dropFrom. The tip rise is
//                                the winglet. mold 2.080 for the shared helpers. LE bumps confirmed on
//                                153 (Silk V2 wing and its mold, first time).
//   build 155                    removed powerSlope (Onshape: "Unused declaration" is an error in a
//                                Feature Studio); dropSlope replaced its last caller in 154.
//   build 156                    USER: "you missed the gull wing in the top foil in the picture, the
//                                winglets are extra". The Silk V2's front view is an S: flat centre,
//                                steepest mid-span, levelling off again before the tips (measured
//                                mid-line: 0, -1.4, -4.8, -10.3, -17.2, -24.7, -32.3, -39.2, -44.0,
//                                -45.4 mm at eta 0..0.9) - a power law cannot level off (best 1.75 mm
//                                RMS); a smoothstep between Drop from 3 % and Drop to 91 % with Tip
//                                drop 45 fits to 0.3 mm. wing 1.030 / stab 4.013: Drop shape (Power
//                                law / S-curve) and Drop to %; the drop law is one map (dropExp,
//                                dropFrom, dropTo, dropSmooth) read by dropShape(d, eta) /
//                                dropSlope(d, eta) from the planform map, the model maps or the
//                                buildFoil literal; shapeIntegral lost its e argument. mold 2.081.
//   build 157                    USER: "do we add a core option in the layup" (the Silk V2 layup came out
//                                at 1.33 kg with 489 g of tow against AFS's published 0.9 kg). mold 2.082:
//                                Core = Tow fill / Foam core (Core kg/m^3, Core GPa) / Monolithic. Foam:
//                                the fill volume is foam at its density with no fibre or resin inside
//                                (5 % of its volume in resin to wet it), the stiffness uses Core GPa, the
//                                buy list adds the foam volume and the sheet thickness. Monolithic: the
//                                fill is woven at the skin's ply thickness, bought as cloth, Woven GPa.
//                                Tow tex and Tow GPa show only for the tow fill. The Silk V2 with M80
//                                foam should come out near 0.95 kg. Bumps, S-curve drop, winglets and
//                                both molds were confirmed on 156 (Silk V2 950 and U Carve 130).
//   build 158                    USER: "do a core mold now". mold 2.083: Mold of = The part / Its foam
//                                core. Core: moldCoreBody lofts the part's sections offset inward
//                                along their normals by one face's skins (coreOutline: offset loop,
//                                re-read as x-monotonic faces, clipped where they close within
//                                0.6 mm, cap groove of capF x (t - skins)/2 over Cap width % ramped at
//                                its edges), through the part's stations, bumps and winglet frame;
//                                mirrored; kept as a named part. The mold pipeline then runs on that
//                                body with socket plug, cones, pad prism and the pad-under flip off.
//                                USER: "leave the tips open to allow foam to expand out": the outermost
//                                core section is carried straight out past the block side as a vent
//                                body, cut with the cavity and deleted, so each tip is an open channel.
//                                The foam core layup was confirmed on 157 (Silk V2: 0.62 kg).
//   build 159                    USER: "a 4th option for the core is a 3d printed plastic core, if this
//                                option is selected generate the model". mold 2.084: Core = Printed
//                                core: the part-mold run also builds the core body (moldCoreBody
//                                without a vent), splits it along the span to the longest printer axis
//                                less margins (moldCut on Y planes), names the segments, and the layup
//                                counts it at Core kg/m^3 (walls + infill) like a foam core. Mold of =
//                                Its foam core with a printed core is refused (it needs no mold).
//   build 160                    mold 2.085: the core mold CONFIRMED on 159 (9 tiles, keys, open tips)
//                                but warned "11 bodies, 2 key bodies floating": the core's stations
//                                started at eta 0.002, so the mirrored halves never touched and the
//                                union left two core bodies, which the tile count then took for
//                                stray keys. Core stations now start at the root plane, and the
//                                mold's solids query excludes any foilCoreBody.
//   build 161                    mold 2.086: Core = Printed core threw "First operand of logical or
//                                conditional operator must be boolean, value is string": FeatureScript's
//                                ?: is LEFT-associative, so a ? b : c ? d : e is (a ? b : c) ? d : e.
//                                The layup message's nested ternary is now parenthesised.
//   build 162                    mold 2.087: Core = Printed core: setAttribute CANNOT_RESOLVE_ENTITIES in
//                                moldCoreBody - the printed core has no vent and setAttribute on the
//                                empty vent query throws. Attribute and return only when there is one.
//   build 163                    performance 1.017: the stab mold's STIFFNESS line read 0 mm / 0 MPa.
//                                lltMoments clipped the circulation at zero before scaling it to the
//                                published half lift, and a stab's circulation is negative all along
//                                the span (download), so the whole distribution vanished. It now takes
//                                the distribution's own sign; the load's magnitude was always right.
//   build 164                    USER: "the printed core also needs some way to key the parts together,
//                                either dowel holes or a frustum again". mold 2.088: dowel holes across
//                                each printed-core joint, along the span, 15 mm into each segment at
//                                the section's thickest point, diameter half the core thickness under
//                                the cap groove (3-8 mm), skipped where that is under 4 mm or in the
//                                winglet; the notice lists them. Dowels over frustums because a
//                                printed peg on a 5-15 mm thick end would snap.
//   build 165                    wing 1.031 / stab 4.014: Bumps from % now 3-90 (was 0-90). The Ultra
//                                wing mold failed BOOLEAN_INVALID on the upper cavity with the bumps
//                                starting at 0 and passed at 5 with nothing else changed (Split
//                                stations 33 -> 15 had not helped). Mechanism not pinned down: the
//                                first bump station coincides with the root seam station, or the
//                                mirrored LE at the centreline; either way a wing has its mount there.
//   build 166                    USER: tip section profiles, in the performance figures too. wing 1.032 /
//                                stab 4.015: Tip profile (Same as root / NACA 4-digit / E817 / E818 /
//                                NACA 63-412 / Clark Y), Tip camber %, Tip camber pos %, Blend from %.
//                                Sections blend point by point (same cosine sampling) with a smoothstep
//                                from Blend from % to the tip: buildSectionAt / sectionWeightAt on a
//                                section map (sectionDefFromDefinition / sectionDefFromModel). Model maps
//                                carry tipOn, tipProfileName, tipCamber/Pos, blendFrom, alpha0Tip, cm0Tip,
//                                tipAreaFrac, polarClmax1/2Tip; cm0 and the drag-bucket fields are
//                                published area-blended. performance 1.018: alpha0At(m, eta) in the
//                                lifting line (aerodynamic twist), clMaxAt per station in stallAlpha and
//                                maxLocalClRatio (the take-off margin and max_local_cl_pct are now
//                                against each station's own CL max). mold 2.089: all four section
//                                builders blend the same way.
//   build 167                    The Silk wing mold with a tip section failed the upper cavity at 15
//                                split stations and passed at 22: with the camber changing along the
//                                span, the parting and the loft interpolated differently between
//                                distant stations. wing 1.033 / stab 4.016: six stations across the
//                                blend in the foil's loft; mold 2.090: twelve parting stations across
//                                it, whatever Split stations says (as the bumps already had).
//   build 168                    A Clark Y TIP still failed the cavity cut on 167. Cause: the Clark Y's
//                                flat-side scaling (143) shrank only the upper surface, so as the tip
//                                cap thinned the section it converged on the table's dipped underside
//                                - a 2.5 % thick sliver with 3 % of reflexed camber, and the loft and
//                                the parting no longer agreed. wing 1.034 / stab 4.017 / mold 2.091:
//                                the whole Clark Y section is scaled vertically (the flat stays a
//                                straight line, camber scales with thickness, the section tends to the
//                                chord line as it thins). A Clark Y stab at 7.4 % now sits 1.9 % below
//                                its chord line at 15 % chord instead of 3 %: slightly less camber.
//   build 169                    The Clark Y tip STILL failed the cavity cut on 168. wing 1.035 / stab
//                                4.018 / mold 2.092: one station list for both. foilStationEtas(m)
//                                builds the foil's loft stations from the model-map keys (stations is
//                                now published); buildFoil lofts through exactly that list and the
//                                mold adds it to its parting stations, so the parting is ruled between
//                                the stations the loft interpolates. Also: a Clark Y's zero-lift angle,
//                                moment and drag-bucket centre now scale with its thickness, as its
//                                section does since 168 (a 7.4 % U Carve stab carries about 0.63 of
//                                the table's camber, so less download than 143-168 reported).
//   build 170                    mold 2.093: 169 made the Ultra mold fail that had passed on 165-167.
//                                Adding the loft's stations to the parting put stations 0.1-0.3 mm
//                                apart (the mold's tip-biased set against the loft's cap and winglet
//                                stations); the mold deduped at 0.06 mm and lofted slivers. Stations
//                                closer than 0.5 mm are now merged.
//   build 171                    USER: revert to the last working mold. 169 and 170 both broke molds
//                                that had passed (Ultra at 33 stations, Silk with a NACA tip). mold
//                                2.094 = 167's parting stations again: the mold's own list, bumps,
//                                twelve across a section blend, deduped at 1e-4 (the 0.5 mm merge of
//                                170 would also have swallowed the stab pad's two 0.4 mm stations).
//                                Kept from 168-169: the Clark Y scaled whole with its aero scaled to
//                                match, foilStationEtas as the loft's station builder (same list as
//                                167), and the published stations count. A Clark Y TIP section remains
//                                unsupported by the mold: unexplained, and the user has dropped it.
//   build 172                    mold 2.095: Split stations tooltip says a wing with a Tip profile needs
//                                22 or more (171 CONFIRMED: Silk with a NACA tip passes at 22, not 15).
//                                Release build.
//   build 173                    mold 2.096: the mast plate tray is sized from the mast PART as it
//                                stands (a copy split at the plate underside, bounding box of the plate
//                                side), not from the Foil mast's plate numbers, so direct edits to the
//                                plate - fillets, chamfers, another outline, a thicker plate - reach the
//                                mold (user). The pocket-cleaning box (which squared off any edited
//                                outline) is replaced by one clearing cylinder per bolt hole, head
//                                diameter + 0.3 mm. Layup plate fill/area and the plate template use the
//                                measured plate. MAST_PLATE console line reports measured vs nominal.
//                                mast 2.009: publishes plateHeadDia and countersink for that clearing.
//   build 174                    mold 2.097: Closing group - Clamps (as before) or Vacuum bag round the
//                                whole closed mold (user). Bag: the block's outer edges are rounded so the
//                                bag survives, the pinch-off groove is vented to the block's outer face at
//                                each span end (in the bag the groove is a sealed pocket of air and the
//                                flash has nowhere to go; the vents let the bag evacuate the groove and
//                                the laminate through it), and the notice reports the closing force (bag
//                                pressure x block plan area), the pressure on the laminate, and the groove
//                                volume against the overcharge's flash volume (warning when the groove is
//                                too small, either closing). Overcharge tooltip: 3-5 % under a bag.
//   build 175                    mold 2.098: 174 did not compile - "Variable loop not found": the groove
//                                outline `loop` was declared inside the first groove block and the new
//                                perimeter code in the second. Declared at feature scope (pitfalls: block
//                                scope, again).
export const FOIL_FILE_BUILD = "175";
export const FOIL_WING_VERSION = "1.035";
export const FOIL_STAB_VERSION = "4.018";
export const FOIL_PERF_VERSION = "1.018";
export const FOIL_MAST_VERSION = "2.009";
export const FOIL_FUSELAGE_VERSION = "4.012";
export const FOIL_MOLD_VERSION = "2.098";

annotation { "Feature Type Name" : "Foil wing",
             "Feature Type Description" : "Parametric hydrofoil front wing from area and aspect ratio: NACA 4-digit or tabulated sections (E817, E818, NACA 63-412, Clark Y) with optional polars, superellipse, linear or double-taper chord, sweep, tip drop, washout, tip cap, minimum tip thickness, and an optional tube socket for a round fuselage. The first of six Foil design features; see the linked guide." }
export const foilWing = defineFeature(function(context is Context, id is Id, definition is map)
    precondition
    {
        annotation { "Group Name" : "Section", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Profile",
                         "Description" : "Section family. NACA 4-digit is fully parametric (camber, camber position, thickness) - use it for anything except matching a known published section. The Eppler and NACA 63-412 options are real digitised coordinate tables (UIUC Airfoil Coordinates Database), thickness-scaled to your Root/Tip thick % (Camber % is fixed by the table and hidden). Custom .dat paste is a later phase." }
            definition.profile is FoilProfile;

            if (definition.profile == FoilProfile.NACA4)
            {
                annotation { "Name" : "Camber %",
                             "Description" : "Maximum camber as % of chord. Limits 0-9 %. 0 = symmetric. Typical front wing: 3-4 % pump/SUP/surf (early lift), 2-3 % wind/eFoil, 1.5-2.5 % kite/high speed. More camber = more lift at low speed but more drag and a bigger nose-down pitching moment. Only shown for NACA 4-digit - the tabulated profiles carry their own fixed camber." }
                isReal(definition.camber, { (unitless) : [0, 3, 9] } as RealBoundSpec);

                annotation { "Name" : "Camber pos %",
                             "Description" : "Position of maximum camber as % of chord from the leading edge. Limits 10-90 %. Typical 30-50 %, 40 % is the classic NACA choice. Further forward = gentler stall; further aft = more aft loading and a stronger nose-down moment. Ignored when camber is 0. Only shown for NACA 4-digit." }
                isReal(definition.camberPos, { (unitless) : [10, 40, 90] } as RealBoundSpec);
            }

            annotation { "Name" : "Root thick %",
                         "Description" : "Root section thickness as % of chord. Limits 4-25 %. Typical front wing 11-14 %, high-speed/kite 8-10 %. Thicker = stiffer, more room for spar caps and a more forgiving stall; thinner = less drag and later cavitation." }
            isReal(definition.rootThickness, { (unitless) : [4, 12, 25] } as RealBoundSpec);

            annotation { "Name" : "Tip thick %",
                         "Description" : "Tip section thickness as % of chord. Limits 4-25 %. Typical 8-11 %, usually 1-3 points thinner than the root. Blend between root and tip is set by the thickness exponent." }
            isReal(definition.tipThickness, { (unitless) : [4, 10, 25] } as RealBoundSpec);

            annotation { "Name" : "Tip profile",
                         "Description" : "Section at the tip. Same as root: one section along the whole span, as before. Any other: the root section changes into this one from Blend from % outward, point by point along the section, so a cambered root can run out to a flatter, thinner-nosed tip the way production wings do. Foil performance uses it: the zero-lift angle varies along the span (aerodynamic twist, so the lift distribution and trim move), the stall check compares each station against ITS section's CL max, and the drag bucket is blended by area. Foil mold follows the blend. With Section data = Built-in the tip gets its own fitted polar; with Polar summary the root's numbers are used for both (one set of 13)." }
            definition.tipProfile is TipProfile;

            if (definition.tipProfile != TipProfile.SAME)
            {
                if (definition.tipProfile == TipProfile.NACA4)
                {
                    annotation { "Name" : "Tip camber %",
                                 "Description" : "Maximum camber of the tip section as % of chord. Limits -6 to 8. Negative = inverted. Typical 1-2.5 on a front wing whose root has 3-4, so the tip stalls later and flies flatter; 0 for a symmetric tip." }
                    isReal(definition.tipCamber, { (unitless) : [-6, 2, 8] } as RealBoundSpec);

                    annotation { "Name" : "Tip camb pos %",
                                 "Description" : "Position of the tip section's maximum camber, % of chord from the leading edge. Limits 10-90. Typical 35-45." }
                    isReal(definition.tipCamberPos, { (unitless) : [10, 40, 90] } as RealBoundSpec);
                }

                annotation { "Name" : "Blend from %",
                             "Description" : "Limits 0-95, per half span. Out to here the section is the root's; from here it blends smoothly into the tip section, reaching it at the tip. 0 = a straight blend across the whole span. Typical 30-60: keep the root section where the chord and the bending are, change it over the outer half." }
                isReal(definition.blendFrom, { (unitless) : [0, 40, 95] } as RealBoundSpec);
            }

            annotation { "Name" : "TE thickness",
                         "Description" : "Limits 0.1-5 mm, and at most 3 % of the root chord. Held constant along the span, then thinned automatically near the tip so it never exceeds 3 % of the local chord. Typical 0.6-1.0 mm for wet-laid carbon in printed molds (room for 2-3 plies to wrap the edge), 0.3-0.5 mm for prepreg in machined molds. Thicker = tougher edge but more base drag and a risk of humming (vortex shedding)." }
            isLength(definition.teThickness, { (millimeter) : [0.1, 0.8, 5] } as LengthBoundSpec);

            annotation { "Name" : "Points/surface",
                         "Description" : "Limits 10-120. Typical 30-50. Cosine-spaced, so the leading edge is well resolved even at low counts. Above about 60 slows regeneration for no visible gain." }
            isInteger(definition.pointsPerSurface, { (unitless) : [10, 40, 120] } as IntegerBoundSpec);
        }

        annotation { "Group Name" : "Planform", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Planform input",
                         "Description" : "Area + aspect ratio (recommended): enter the area everyone quotes and the shape; span and root chord are solved. Span + root chord: enter the geometry directly (e.g. to copy an existing foil); area becomes an output." }
            definition.planformMode is PlanformMode;

            if (definition.planformMode == PlanformMode.AREA_AR)
            {
                annotation { "Name" : "Area cm^2",
                             "Description" : "Target wing area in cm^2. Limits 100-5000 cm^2. Typical front wing: 1500-2500 SUP/surf/beginner eFoil, 1000-1600 intermediate eFoil/wind, 900-1500 pump/downwind (high aspect), 300-700 kite race." }
                isReal(definition.targetArea, { (unitless) : [100, 1100, 5000] } as RealBoundSpec);

                annotation { "Name" : "Aspect ratio",
                             "Description" : "Limits 2-20, projected span^2 / projected area. Typical front wing: 4-6 surf/beginner, 6-9 all-round/eFoil/wind, 9-14+ pump/downwind, 8-12 kite race. Higher = less induced drag and better glide, but less roll agility and more root bending." }
                isReal(definition.aspectRatio, { (unitless) : [2, 9, 20] } as RealBoundSpec);

                annotation { "Name" : "Area definition",
                             "Description" : "Which area the target refers to. Projected (top view) is what sets lift and what most brands quote. Developed is measured along the curved span line and is larger with anhedral or gull. Both are reported." }
                definition.areaDefinition is AreaDefinition;
            }
            else
            {
                annotation { "Name" : "Span",
                             "Description" : "Limits 100-3000 mm, projected tip to tip (top view). Typical front wing: 700-950 mm SUP/surf/eFoil, 900-1300 mm pump/downwind, 700-1000 mm wind, 600-900 mm kite race." }
                isLength(definition.span, { (millimeter) : [100, 800, 3000] } as LengthBoundSpec);

                annotation { "Name" : "Root chord",
                             "Description" : "Limits 20-600 mm. Typical front wing 140-250 mm (low/medium aspect) or 90-140 mm (high aspect, kite)." }
                isLength(definition.rootChord, { (millimeter) : [20, 180, 600] } as LengthBoundSpec);
            }

            annotation { "Name" : "Chord distribution",
                         "Description" : "Superellipse: c = c0 (1 - (s 2y/b)^n)^(1/n), cut off at the end chord ratio, giving a rounded tip. Linear: straight taper to a square tip. Double taper: a steep taper from the root to Break %, then a gentler one to the tip - a wide root flaring into a slim outer wing (the full-base stab, or a high-aspect wing with a broad centre); Blend % rounds the corner between the two. Linear and double taper end in a square tip: Tip cap = Rounded + plan rounds it in plan view too." }
            definition.chordShape is ChordShape;

            if (definition.chordShape == ChordShape.SUPERELLIPSE)
            {
                annotation { "Name" : "Exponent n",
                             "Description" : "Limits 1.2-8. 2 = elliptic (lowest induced drag for an untwisted wing). 2.5-4 = fuller, squarer tips as on many surf/eFoil wings. Below 2 = pointier, glider-like tips. Above 5 approaches a rectangle with rounded corners. Typical 2-3 for most wings, 3-4 for surf/eFoil." }
                isReal(definition.superN, { (unitless) : [1.2, 3, 8] } as RealBoundSpec);

                annotation { "Name" : "End ratio",
                             "Description" : "Limits 0.02-0.6. Chord of the small end face where the superellipse is cut off, as a fraction of root chord. The leading and trailing edges follow the curve all the way to this chord, so the tip is rounded in plan view. Typical 0.04-0.08 for a fully rounded tip; 0.15-0.3 gives a curved but blunt tip. The trailing edge is thinned automatically near the tip." }
                isReal(definition.endRatio, { (unitless) : [0.02, 0.05, 0.6] } as RealBoundSpec);
            }
            else
            {
                if (definition.chordShape == ChordShape.DOUBLE)
                {
                    annotation { "Name" : "Break %",
                                 "Description" : "Limits 5-60, per half span. Where the steep root taper ends and the gentle outer taper begins, as a percentage of the half span. Typical 20-30 for a full-base stab (the AFS U Carve measures about 28), 30-50 for a high-aspect wing with a broad centre section." }
                    isReal(definition.breakPct, { (unitless) : [5, 28, 60] } as RealBoundSpec);

                    annotation { "Name" : "Mid ratio",
                                 "Description" : "Limits 0.2-1.0. Chord at the break as a fraction of root chord. The root taper runs from 1 to this over Break %; the outer taper from this to Tip ratio over the rest. Must be at least Tip ratio. Typical 0.55-0.7 for a full-base stab (U Carve about 0.62), 0.7-0.9 for a wing." }
                    isReal(definition.midRatio, { (unitless) : [0.2, 0.62, 1] } as RealBoundSpec);

                    annotation { "Name" : "Blend %",
                                 "Description" : "Limits 0-30, per half span. Rounds the corner where the two tapers meet: the outline follows a smooth curve from Blend % before the break to Blend % after it, tangent to both tapers, instead of a sharp kink. 0 = sharp. Typical 8-15 (the AFS U Carve fits best at 10). Clamped so the blend never reaches the root or the tip." }
                    isReal(definition.blendPct, { (unitless) : [0, 10, 30] } as RealBoundSpec);
                }

                annotation { "Name" : "Tip ratio",
                             "Description" : "Limits 0.1-1.0. Tip chord as a fraction of root chord; the tip is square in plan view. Typical 0.3-0.6 for linear taper (about 0.4 gives near-elliptic loading for an untwisted wing; below 0.3 the tips load up and stall first), 0.15-0.3 for double taper (U Carve about 0.21), where it is the chord at the end of the outer taper and must not exceed Mid ratio." }
                isReal(definition.tipRatio, { (unitless) : [0.1, 0.4, 1] } as RealBoundSpec);
            }

            annotation { "Name" : "Min tip", "Default" : false,
                         "Description" : "On = the tip chord is widened automatically until the section at the tip cap start is at least Min tip mm thick, by raising End ratio (or Tip ratio) above the value entered. The notice reports the ratio used. Guards a thin, small-chord tip that cannot be laid up; especially useful on a stab linked to a wing, where the link sets area, aspect ratio and thickness but the tip chord is still this feature's own." }
            definition.minTipOn is boolean;

            if (definition.minTipOn)
            {
                annotation { "Name" : "Min tip mm",
                             "Description" : "Minimum section thickness at the tip cap start (the last full section before the cap tapers out). Limits 0.2-5 mm. Typical 1-1.5 mm for a carbon layup: two skin plies plus a little UD; the cap beyond it is tow and resin. Only the tip chord is changed, never the thickness %." }
                isLength(definition.minTip, { (millimeter) : [0.2, 1, 5] } as LengthBoundSpec);
            }

            annotation { "Name" : "Stations",
                         "Description" : "Limits 3-30, per half span. Typical 11-15 for a rounded superellipse tip, 5-9 for linear or double taper. Superellipse stations are spaced evenly around the tip curve; the tapers use sine spacing, and double taper adds stations through the break (five across the blend) so the corner is followed. Tip-cap stations are added on top. More = slower regeneration." }
            isInteger(definition.stations, { (unitless) : [3, 9, 30] } as IntegerBoundSpec);

            annotation { "Name" : "Mirror to full span", "Default" : true,
                         "Description" : "On = complete foil. Off = right half only, for faster edits and section inspection. Reported metrics are always full-span values." }
            definition.mirror is boolean;
        }

        annotation { "Group Name" : "Sweep, alignment and anhedral", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Align line %",
                         "Description" : "Limits 0-100 %. The chord line that stays straight (apart from Sweep aft); chord is added around it. Typical 25 for a classic elliptical superellipse (both edges curve), 60-100 for modern pump/downwind and many surf wings (100 = straight trailing edge, leading edge curves back), 0 for a double taper that should keep a straight leading edge with the root flare all on the trailing edge (the full-base stab look). Independent of the incidence pivot. Moving it aft sweeps the quarter-chord line back at the tips, moving the lift centre aft. Plan-view tip rounding (Tip cap = Rounded + plan) is centred on the mid-chord regardless, so both tip corners round." }
            isReal(definition.planformAlign, { (unitless) : [0, 25, 100] } as RealBoundSpec);

            annotation { "Name" : "Sweep aft",
                         "Description" : "Limits -100 to +400 mm, positive = aft. How far the alignment line sits aft at the tip, relative to the root. 0 = alignment line straight across. Typical 20-80 mm for all-round wings, 80-200 mm for surf/carving wings with a curved leading edge. More sweep = more yaw/pitch stability and forgiveness, less efficiency." }
            isLength(definition.sweepTip, { (millimeter) : [-100, 100, 400] } as LengthBoundSpec);

            annotation { "Name" : "Sweep exp",
                         "Description" : "Limits 0.5-4. Shape of the sweep line x = offset (2y/b)^m. 1 = straight swept line (kinked at the root), 2-3 = curved 'banana' leading edge that is tangent at the root, below 1 = sweep concentrated near the root, 3-4 = raked tips. Typical 2-3." }
            isReal(definition.sweepExp, { (unitless) : [0.5, 2, 4] } as RealBoundSpec);

            annotation { "Name" : "Tip drop",
                         "Description" : "Limits -100 to +200 mm, positive = down (anhedral). Vertical drop of the tip pivot below the root pivot (net, including any gull dihedral); negative = tips up. Typical 0-40 mm for all-round wings, 30-80 mm for surf wings. Anhedral loosens roll and helps carving; too much reduces effective span and can create mold undercuts." }
            isLength(definition.tipDrop, { (millimeter) : [-100, 50, 200] } as LengthBoundSpec);

            annotation { "Name" : "Drop shape",
                         "Description" : "How the drop is spread between Drop from % and Drop to %. Power law: z = -drop u^e with Drop exp, steepening all the way to the tip (2-3 = flat centre, tips dropping late). S-curve: a smoothstep, flat at both ends and steepest in the middle, so the wing levels off again before the tip - the gull front view of the AFS Silk V2 (Drop from 3, Drop to 91, Tip drop 45 measures it to 0.3 mm)." }
            definition.dropLaw is DropLaw;

            if (definition.dropLaw == DropLaw.POWER)
            {
            annotation { "Name" : "Drop exp",
                         "Description" : "Limits 1-6. Typical 2-3. Shape of the drop z = -drop (2y/b)^e. 1 = straight anhedral from the root, 2-3 = flat centre with tips falling away, higher = droop only near the tips." }
            isReal(definition.dropExp, { (unitless) : [1, 2, 6] } as RealBoundSpec);
            }

            annotation { "Name" : "Drop from %",
                         "Description" : "Limits 0-70, per half span. Where the drop begins: the span line is flat (or on the gull dihedral line) out to here, then drops by Tip drop over the rest with the Drop exp shape. 0 = the drop starts at the root, the plain law. Typical 0, or 15-30 for a flat centre with a break. A flat centre with a distinct break and a near-straight drop, as on the AFS Silk V2 (about 20 with Drop exp 1.3), needs this; the winglet gives the tip rise on top of it." }
            isReal(definition.dropFrom, { (unitless) : [0, 0, 70] } as RealBoundSpec);

            annotation { "Name" : "Drop to %",
                         "Description" : "Limits 30-100, per half span. Where the drop is complete: beyond it the span line runs level at the full Tip drop (until a winglet bends it). Typical 100, or 85-95 for a wing that levels off before its tips, as the Silk V2 does (91)." }
            isReal(definition.dropTo, { (unitless) : [30, 100, 100] } as RealBoundSpec);

            annotation { "Name" : "Gull dihedral",
                         "Description" : "Limits -10 to +20 deg, positive = up. Slope of the span line leaving the root, for gull wings: the wing rises inboard, then the drop term pulls the tips down to the tip drop. Needs a drop exponent above 1 (no effect at 1). Typical 0 (plain anhedral) or 3-8 deg with tip drop 20-60 mm and exponent 2.5-4 for a gull. Creates a V at the root; large values can cause mold undercuts." }
            isAngle(definition.rootDihedral, { (degree) : [-10, 0, 20] } as AngleBoundSpec);

            annotation { "Name" : "Winglet",
                         "Description" : "Off: the tip follows Tip drop and Gull dihedral only. Up / Down: the outer part of each half span bends through Winglet angle on an arc of Bend radius and then runs straight, with every section drawn square to the bent path, so the winglet keeps its true section at any angle up to 90 deg. Its size is Winglet area: the chord distribution continues along the bend, and the tool solves how much of the half span to bend so that area comes out. Area and aspect ratio stay the developed values of the whole half span, winglet included; the notice adds the winglet height and the projected span. Foil performance credits a winglet as extra effective span for induced drag (0.9 x its height across the pair). Foil mold molds it up to 75 deg; steeper cannot release from a vertical pull." }
            definition.winglet is Winglet;

            if (definition.winglet != Winglet.OFF)
            {
                annotation { "Name" : "Winglet area",
                             "Description" : "Area of each winglet, cm^2, measured along the bend. Limits 1-500. Typical 20-60 for a front wing. The bend starts where the outer chord distribution has this much area left to the tip, so it must fit: the winglet cannot start inside 30 % of the half span." }
                isReal(definition.wingletArea, { (unitless) : [1, 30, 500] } as RealBoundSpec);

                annotation { "Name" : "Winglet angle",
                             "Description" : "Limits 10-90 deg from the span plane. 90 = vertical. Typical 45-70 for a foil winglet; small angles are just a stronger tip drop and Tip drop does that with a smooth curve." }
                isAngle(definition.wingletAngle, { (degree) : [10, 60, 90] } as AngleBoundSpec);

                annotation { "Name" : "Bend radius",
                             "Description" : "Limits 5-300 mm, on the span line. The bend is an arc of this radius through Winglet angle, then straight to the tip. Typical 20-40 mm. If the arc would be longer than the winglet, the radius is reduced so the whole winglet is the bend, and the notice says so." }
                isLength(definition.wingletRadius, { (millimeter) : [5, 30, 300] } as LengthBoundSpec);
            }

            annotation { "Name" : "LE bumps", "Default" : false,
                         "Description" : "Leading-edge bumps (tubercles, as on humpback flippers and on AFS, Lift and other production wings): the leading edge moves forward and back sinusoidally along the span while the trailing edge stays put, so the chord swells at each peak. Published tests (Miklosovic 2004, Johari 2007) show a softer stall and lift kept beyond it, for a little drag and sometimes a little maximum lift before stall; for a foil that is take-off, pumping and hard turns. GEOMETRY ONLY: Foil performance uses the smooth chord distribution and does not credit or charge them. Foil mold follows them exactly. Adds six stations per bump pitch, so regeneration slows." }
            definition.bumpOn is boolean;

            if (definition.bumpOn)
            {
                annotation { "Name" : "Bump height",
                             "Description" : "Limits 0.5-15 mm. Peak-to-trough travel of the leading edge. Typical 3-6 on a front wing (about 3-4 % of the local chord). The section is stretched at a peak and compressed at a trough with its thickness in mm unchanged." }
                isLength(definition.bumpAmp, { (millimeter) : [0.5, 4, 15] } as LengthBoundSpec);

                annotation { "Name" : "Bump pitch",
                             "Description" : "Limits 20-300 mm. Spanwise distance from one peak to the next. Typical 50-90 on a front wing, five to eight bumps per half span. The bumps fade in and out over half a pitch at each end of their range." }
                isLength(definition.bumpPitch, { (millimeter) : [20, 70, 300] } as LengthBoundSpec);

                annotation { "Name" : "Bumps from %",
                             "Description" : "Limits 3-90, per half span. Where the bumps start, from the centreline. AFS centre them on the GLT dockstart wing (from 5) and run them outboard on the Silk and Ultra (from 12-20). Typical 10-20. Not 0: a bump starting on the centreline broke the mold's cavity cut (build 164), and a real wing has its mount there anyway." }
                isReal(definition.bumpFrom, { (unitless) : [3, 15, 90] } as RealBoundSpec);

                annotation { "Name" : "Bumps to %",
                             "Description" : "Limits 10-100, per half span. Where the bumps end; must be beyond Bumps from by at least one pitch. Typical 90-95, leaving the tip cap clean." }
                isReal(definition.bumpTo, { (unitless) : [10, 92, 100] } as RealBoundSpec);
            }
        }

        annotation { "Group Name" : "Twist and thickness distribution", "Collapsed By Default" : true }
        {
            annotation { "Name" : "Washout",
                         "Description" : "Limits -5 to +8 deg, relative to the root incidence; positive = tip leading edge down. Typical 0-3 deg. Washout unloads the tips so the root stalls first (gentler stall, better tip-breach behaviour) at a small cost in induced drag. Negative = wash-in (rarely useful)." }
            isAngle(definition.washout, { (degree) : [-5, 0, 8] } as AngleBoundSpec);

            annotation { "Name" : "Washout exp",
                         "Description" : "Limits 0.5-4. Twist follows washout (2y/b)^w. 1 = linear, 2-3 = twist concentrated towards the tips, below 1 = twist concentrated near the root. Typical 1-2." }
            isReal(definition.washoutExp, { (unitless) : [0.5, 1, 4] } as RealBoundSpec);

            annotation { "Name" : "Thickness exp",
                         "Description" : "Limits 0.5-4. Thickness % follows root + (tip - root)(2y/b)^p. 1 = linear, 2-3 = keeps the root thickness (and stiffness) further out before thinning, below 1 = thins quickly away from the root. Typical 1-2." }
            isReal(definition.thicknessExp, { (unitless) : [0.5, 1.5, 4] } as RealBoundSpec);
        }

        annotation { "Group Name" : "Incidence", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Incidence",
                         "Description" : "Limits -10 to +10 deg, measured from the fuselage axis (X), positive = leading edge up. Typical front wing +0.5 to +2.5 deg. Aim for a wing-minus-stab difference (decalage) of 1.5-3 deg; the stabiliser feature reports it." }
            isAngle(definition.incidence, { (degree) : [-10, 0, 10] } as AngleBoundSpec);

            annotation { "Name" : "Pivot",
                         "Description" : "Point each section rotates about for incidence and washout, and the line that follows the drop curve. The root pivot sits at the world origin. Quarter chord (recommended) keeps the lift centre fixed as angles change. Plan-view shape is set by the alignment line, not the pivot." }
            definition.pivot is FoilPivot;
        }

        annotation { "Group Name" : "Tip", "Collapsed By Default" : true }
        {
            annotation { "Name" : "Tip cap",
                         "Description" : "Rounded tip: section thickness falls along a quarter-ellipse over the cap length, rounding the tip in front view; plan-view rounding then comes only from the superellipse end ratio. Rounded + plan: the chord also shrinks along the same quarter-ellipse over the cap length, to Cap end % of the chord at the cap start, so a linear or double taper gets a rounded tip in plan view as well (the area solver allows for it). Flat tip: thickness is unchanged to the end face." }
            definition.tipCap is TipCap;

            if (definition.tipCap != TipCap.FLAT)
            {
                annotation { "Name" : "Cap length",
                             "Description" : "Limits 2-80 mm, and at most 30 % of the half span. Typical 10-25 mm. Longer looks smoother but thins more of the working span." }
                isLength(definition.capLength, { (millimeter) : [2, 15, 80] } as LengthBoundSpec);

                annotation { "Name" : "Cap end %",
                             "Description" : "End-face thickness as % of the tip section thickness. Limits 5-80 %. Typical 15-30 %. Lower = rounder, thinner tip; very low values with a thick trailing edge give a wafer-thin end that is hard to lay up." }
                isReal(definition.capEnd, { (unitless) : [5, 25, 80] } as RealBoundSpec);
            }
        }


        annotation { "Group Name" : "Section polar", "Collapsed By Default" : true }
        {
            annotation { "Name" : "Section data",
                         "Description" : "Built-in: fitted XFoil data, nothing to type in. E817/E818/NACA 63-412/Clark Y use one real polar each. NACA 4-digit uses the exact zero-lift angle/moment for your Camber %/Camber pos %, plus lift slope, CLmax and drag bucket fitted from real NACA polars at your thickness/camber - coarser than the fixed profiles (a fit across a family, not one measured shape); use Polar summary for higher accuracy at your exact section. Analytic (default): thin-aerofoil model - camber-line angle/moment, fixed lift slope, skin-friction drag, Section CL max from Foil performance. Polar summary: your own XFoil/XFLR5 numbers at your own Reynolds numbers, via the fields below. Run scripts/polar_summary.py (developer skill) on your polar - the tool never invents section data." }
            definition.polarSource is PolarSource;

            if (definition.polarSource == PolarSource.POLAR)
            {
                annotation { "Name" : "Zero-lift",
                             "Description" : "Zero-lift angle of attack from the polar, deg (usually negative for a cambered section). Limits -8 to 4 deg. Replaces the thin-aerofoil estimate. Typical -1 to -3 deg for a few % camber. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isAngle(definition.polarAlpha0, { (degree) : [-8, -2, 4] } as AngleBoundSpec);

                annotation { "Name" : "Lift slope",
                             "Description" : "Section lift-curve slope from the polar, per radian. Limits 4-7.5. Thin-aerofoil theory gives 2*pi = 6.28. Replaces the fixed analytic value. Typical 5.5-6.5 depending on thickness and Reynolds number. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarCla, { (unitless) : [4, 6, 7.5] } as RealBoundSpec);

                annotation { "Name" : "Cm c/4",
                             "Description" : "Section pitching moment about the quarter chord from the polar (usually fairly constant with CL below stall). Limits -0.15 to 0.05. Replaces the thin-aerofoil Cm0. Typical -0.03 to -0.11 for a cambered section, near 0 for symmetric. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarCm0, { (unitless) : [-0.15, -0.05, 0.05] } as RealBoundSpec);

                annotation { "Name" : "Re 1 (M)",
                             "Description" : "First Reynolds number the polar data below is from, in millions. Limits 0.1-5. Values are interpolated (log Re) between Re 1 and Re 2, and held flat outside that range. Typical: near your take-off Reynolds number (about 0.2-0.5 M for a wing, lower for a stab). For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarRe1, { (unitless) : [0.1, 0.35, 5] } as RealBoundSpec);

                annotation { "Name" : "CLmax @Re1",
                             "Description" : "Maximum section lift coefficient at Re 1. Limits 0.6-1.8. Real CLmax usually drops noticeably below the higher-Re value, which is why a single fixed CL max (the analytic fallback) can be optimistic at take-off. Typical 0.85-1.1 at low Re. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarClmax1, { (unitless) : [0.6, 1, 1.8] } as RealBoundSpec);

                annotation { "Name" : "Cdmin @Re1",
                             "Description" : "Minimum section drag coefficient at Re 1 (the bottom of the drag bucket). Limits 0.004-0.03. Friction drag rises as Re falls. Typical 0.008-0.018 at low Re. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarCdmin1, { (unitless) : [0.004, 0.01, 0.03] } as RealBoundSpec);

                annotation { "Name" : "CL@Cdmin 1",
                             "Description" : "The lift coefficient at which Cdmin occurs at Re 1 - the centre of the drag bucket. Limits -0.3 to 1.0. Typical 0.3-0.7. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarClcd1, { (unitless) : [-0.3, 0.3, 1] } as RealBoundSpec);

                annotation { "Name" : "k @Re1",
                             "Description" : "Drag-rise rate at Re 1: Cd = Cdmin + k (CL - CL@Cdmin)^2. Limits 0.005-0.05. For your own polar, read it off two points on the drag bucket away from Cdmin and solve for k, or use polar_summary.py to fit it automatically. Typical 0.005-0.04. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarK1, { (unitless) : [0.005, 0.013, 0.05] } as RealBoundSpec);

                annotation { "Name" : "Re 2 (M)",
                             "Description" : "Second Reynolds number, in millions. Limits 0.1-5. Must differ from Re 1 for interpolation to do anything. Typical: near your cruise or max-speed Reynolds number. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarRe2, { (unitless) : [0.1, 0.9, 5] } as RealBoundSpec);

                annotation { "Name" : "CLmax @Re2",
                             "Description" : "Maximum section lift coefficient at Re 2. Limits 0.6-1.8. Typical 1.0-1.3 at higher Re. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarClmax2, { (unitless) : [0.6, 1.2, 1.8] } as RealBoundSpec);

                annotation { "Name" : "Cdmin @Re2",
                             "Description" : "Minimum section drag coefficient at Re 2. Limits 0.004-0.03. Typical 0.004-0.008 at higher Re. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarCdmin2, { (unitless) : [0.004, 0.007, 0.03] } as RealBoundSpec);

                annotation { "Name" : "CL@Cdmin 2",
                             "Description" : "The lift coefficient at which Cdmin occurs at Re 2. Limits -0.3 to 1.0. Typically close to CL@Cdmin 1, since the drag bucket centre moves less with Re than CLmax does. Typical 0.3-0.4. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarClcd2, { (unitless) : [-0.3, 0.3, 1] } as RealBoundSpec);

                annotation { "Name" : "k @Re2",
                             "Description" : "Drag-rise rate at Re 2. Limits 0.005-0.05. Typical 0.01-0.035. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarK2, { (unitless) : [0.005, 0.01, 0.05] } as RealBoundSpec);
            }
        }

        annotation { "Group Name" : "Tube socket", "Collapsed By Default" : true }
        {
            annotation { "Name" : "Tube socket", "Default" : true,
                         "Description" : "Adds a low-drag tube socket to the wing root. It starts hidden inside the wing at the root's thickest point, blends smoothly out of the upper and lower surfaces to a round nacelle, and continues behind the trailing edge to a rear face where the round fuselage tube enters. The tube axis runs through the middle of the root thickness. Turn off for a clean wing (molding, analysis, or a different mount)." }
            definition.socketOn is boolean;

            if (definition.socketOn)
            {
                annotation { "Name" : "Tube dia",
                             "Description" : "Outside diameter of the round fuselage tube. Limits 10-60 mm. Typical 20-30 mm for carbon or aluminium tube." }
                isLength(definition.tubeDia, { (millimeter) : [10, 24, 60] } as LengthBoundSpec);

                annotation { "Name" : "Clearance",
                             "Description" : "Diametral clearance between bore and tube. Limits 0-2 mm. Typical 0.1-0.3 mm for a firm slip fit that is then pinned or bonded." }
                isLength(definition.tubeClearance, { (millimeter) : [0, 0.2, 2] } as LengthBoundSpec);

                annotation { "Name" : "Wall",
                             "Description" : "Nacelle wall thickness around the bore, which sets the nacelle diameter (Tube dia + 2 x Wall). Limits 2-15 mm. Typical 4-6 mm for carbon. Thicker is stronger but adds frontal area and drag." }
                isLength(definition.socketWall, { (millimeter) : [2, 5, 15] } as LengthBoundSpec);

                annotation { "Name" : "Blend length",
                             "Description" : "Length over which the socket grows out of the wing, from the root's thickest point (where it starts hidden inside the wing) to the full nacelle diameter. Limits 10-300 mm. Typical 50-90 mm - longer is a gentler, lower-drag blend. Should reach full diameter before or just after the trailing edge." }
                isLength(definition.socketBlend, { (millimeter) : [10, 70, 300] } as LengthBoundSpec);

                annotation { "Name" : "Rear extension",
                             "Description" : "How far the socket extends behind the root trailing edge to its rear face, where the tube enters. Limits 0-400 mm. Typical 60-120 mm; with Socket depth this sets how much tube is held and how far the joint sits behind the wing." }
                isLength(definition.socketRearExt, { (millimeter) : [0, 90, 400] } as LengthBoundSpec);

                annotation { "Name" : "Rear fairing",
                             "Description" : "Taper at the back of the socket, from the full nacelle diameter down to just over the tube (Tube dia + Wall) at the rear face - this is what keeps the fuselage slender: Foil fuselage matches the diameter this taper actually produces, not the nacelle's peak diameter. Limits 5-150 mm. Typical 20-40 mm; longer is gentler and lower drag. 0 is refused, since it would force the whole fuselage to the wide nacelle diameter." }
                isLength(definition.nacelleRearFair, { (millimeter) : [5, 25, 150] } as LengthBoundSpec);

                annotation { "Name" : "Socket depth",
                             "Description" : "How far the bore runs forward from the rear face - the length of tube inside the wing. Limits 20-300 mm. Typical 3-4 x Tube dia; longer carries bending better." }
                isLength(definition.socketDepth, { (millimeter) : [20, 80, 300] } as LengthBoundSpec);

                annotation { "Name" : "Pins",
                             "Description" : "Vertical pin or bolt holes through the nacelle and tube, spread along the socket. Limits 0-3. Typical 1-2. 0 = no holes (bonded tube)." }
                isInteger(definition.socketPins, { (unitless) : [0, 2, 3] } as IntegerBoundSpec);

                annotation { "Name" : "Pin bolt", "Default" : "M6",
                             "Description" : "The cross bolt (or pin) through the nacelle and the tube: sets the clearance hole here and in the Foil fuselage's matching holes (M5 5.5, M6 6.5, M8 8.5 mm, 0.1 mm looser than a close fit so the two parts line up). Typical M6 for a 24 mm tube; keep it well under half the tube diameter. Custom hole sizes: type the hole below (a plain dowel, for instance)." }
                definition.socketPinBolt is BoltSize;

                if (definition.socketPinBolt == BoltSize.CUSTOM)
                {
                    annotation { "Name" : "Pin dia",
                                 "Description" : "Pin or bolt clearance hole diameter (Custom only). Limits 3-12 mm. Typical 6.5 mm (M6) for a 24 mm tube; keep well under half the tube diameter." }
                    isLength(definition.socketPinDia, { (millimeter) : [3, 6.5, 12] } as LengthBoundSpec);
                }

                annotation { "Name" : "Pin pitch",
                             "Description" : "Spacing between pins along X, centred on the socket. Limits 10-150 mm. Typical 30-40 mm. Ignored with one pin." }
                isLength(definition.socketPinPitch, { (millimeter) : [10, 35, 150] } as LengthBoundSpec);
            }
        }

        annotation { "Name" : "Log inputs", "Default" : true,
                     "Description" : "Prints every parameter on this feature to the FeatureScript console as one line, so the whole set can be pasted elsewhere (e.g. back to an AI assistant) along with the notice or CSV." }
        definition.logInputs is boolean;
    }
    {
        const m = buildFoil(context, id, definition, vector(0, 0, 0) * meter);
        if (definition.logInputs)
            println(wingInputLog(definition));
        const socketInfo = buildWingSocket(context, id, definition, m);
        setVariable(context, "foilWingSocket", socketInfo.model);
        nameSolids(context, id, definition.mirror ? "Wing" : "Wing (half)");

        setVariable(context, "foilWingArea", m.areaProj);
        setVariable(context, "foilWingAreaDeveloped", m.areaDev);
        setVariable(context, "foilWingSpan", m.span);
        setVariable(context, "foilWingRootChord", m.rootChord);
        setVariable(context, "foilWingTipChord", m.tipChord);
        setVariable(context, "foilWingMAC", m.mac);
        setVariable(context, "foilWingAR", m.aspect);
        setVariable(context, "foilWingIncidence", definition.incidence);
        setVariable(context, "foilWingRootThickness", definition.rootThickness);
        setVariable(context, "foilWingTipThickness", definition.tipThickness);
        setVariable(context, "foilWingZeroLift", m.alpha0);
        setVariable(context, "foilWingModel", m.model);

        reportFeatureInfo(context, id, planformSummary(definition, m) ~ socketInfo.note);
    });

annotation { "Feature Type Name" : "Foil stabiliser",
             "Feature Type Description" : "Parametric hydrofoil stabiliser with the wing's geometry, placed by arm behind the wing and optionally linked to it as a fraction of its area. Carries a mount pad, tail fairing and bolt pattern pinned to its pivot, seated on the fuselage by Height; reports tail volume and decalage." }
export const foilStabiliser = defineFeature(function(context is Context, id is Id, definition is map)
    precondition
    {
        annotation { "Group Name" : "Section", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Profile",
                         "Description" : "Section family. NACA 4-digit is fully parametric (camber, camber position, thickness) - use it for anything except matching a known published section. The Eppler and NACA 63-412 options are real digitised coordinate tables (UIUC Airfoil Coordinates Database), thickness-scaled to your Root/Tip thick % (Camber % is fixed by the table and hidden). Custom .dat paste is a later phase." }
            definition.profile is FoilProfile;

            if (definition.profile == FoilProfile.NACA4)
            {
                annotation { "Name" : "Camber %",
                             "Description" : "Maximum camber as % of chord. Limits -6 to +6 %. Typical 0 for stabs. 0 = symmetric (most common stab section). Negative = inverted camber that lifts downward, trimming with less negative incidence; typical -1 to -2 % if used. Positive only for lifting stabs (rare). Only shown for NACA 4-digit - the tabulated profiles carry their own fixed camber." }
                isReal(definition.camber, { (unitless) : [-6, 0, 6] } as RealBoundSpec);

                annotation { "Name" : "Camber pos %",
                             "Description" : "Position of maximum camber as % of chord from the leading edge. Limits 10-90 %. Typical 30-50 %. Ignored when camber is 0. Only shown for NACA 4-digit." }
                isReal(definition.camberPos, { (unitless) : [10, 40, 90] } as RealBoundSpec);
            }

            annotation { "Name" : "Root thick %",
                         "Description" : "Root section thickness as % of chord. Limits 4-20 %. Typical 8-11 %. Thinner = less drag; below about 8 % stabs get flexible and stall abruptly." }
            isReal(definition.rootThickness, { (unitless) : [4, 10, 20] } as RealBoundSpec);

            annotation { "Name" : "Tip thick %",
                         "Description" : "Tip section thickness as % of chord. Limits 4-20 %. Typical 7-10 %. Blend between root and tip is set by the thickness exponent." }
            isReal(definition.tipThickness, { (unitless) : [4, 8, 20] } as RealBoundSpec);

            annotation { "Name" : "Tip profile",
                         "Description" : "Section at the tip. Same as root: one section along the whole span, as before. Any other: the root section changes into this one from Blend from % outward, point by point along the section, so a cambered root can run out to a flatter, thinner-nosed tip the way production wings do. Foil performance uses it: the zero-lift angle varies along the span (aerodynamic twist, so the lift distribution and trim move), the stall check compares each station against ITS section's CL max, and the drag bucket is blended by area. Foil mold follows the blend. With Section data = Built-in the tip gets its own fitted polar; with Polar summary the root's numbers are used for both (one set of 13)." }
            definition.tipProfile is TipProfile;

            if (definition.tipProfile != TipProfile.SAME)
            {
                if (definition.tipProfile == TipProfile.NACA4)
                {
                    annotation { "Name" : "Tip camber %",
                                 "Description" : "Maximum camber of the tip section as % of chord. Limits -6 to 8. Negative = inverted. Typical 0 on a stab, or the root's own value with a flatter shape." }
                    isReal(definition.tipCamber, { (unitless) : [-6, 2, 8] } as RealBoundSpec);

                    annotation { "Name" : "Tip camb pos %",
                                 "Description" : "Position of the tip section's maximum camber, % of chord from the leading edge. Limits 10-90. Typical 35-45." }
                    isReal(definition.tipCamberPos, { (unitless) : [10, 40, 90] } as RealBoundSpec);
                }

                annotation { "Name" : "Blend from %",
                             "Description" : "Limits 0-95, per half span. Out to here the section is the root's; from here it blends smoothly into the tip section, reaching it at the tip. 0 = a straight blend across the whole span. Typical 30-60: keep the root section where the chord and the bending are, change it over the outer half." }
                isReal(definition.blendFrom, { (unitless) : [0, 40, 95] } as RealBoundSpec);
            }

            annotation { "Name" : "TE thickness",
                         "Description" : "Limits 0.1-3 mm, and at most 3 % of the root chord. Thinned automatically near the tip. Typical 0.5-0.8 mm for wet-laid carbon in printed molds, 0.3-0.5 mm for prepreg. Thicker = tougher edge but more base drag and a risk of humming." }
            isLength(definition.teThickness, { (millimeter) : [0.1, 0.6, 3] } as LengthBoundSpec);

            annotation { "Name" : "Points/surface",
                         "Description" : "Limits 10-120. Typical 30-40. Cosine-spaced towards the leading edge. Above about 60 slows regeneration for no visible gain." }
            isInteger(definition.pointsPerSurface, { (unitless) : [10, 36, 120] } as IntegerBoundSpec);
        }

        annotation { "Group Name" : "Planform", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Planform input",
                         "Description" : "Area + aspect ratio (recommended): enter the area everyone quotes and the shape; span and root chord are solved. Span + root chord: enter the geometry directly (e.g. to copy an existing foil); area becomes an output." }
            definition.planformMode is PlanformMode;

            if (definition.planformMode == PlanformMode.AREA_AR)
            {
                annotation { "Name" : "Area cm^2",
                             "Description" : "Target stab area in cm^2. Limits 30-1000 cm^2. Typical 15-22 % of the front wing: 150-350 cm^2 for surf/eFoil/pump, 80-150 for kite race. Larger = more pitch stability and damping, more drag. The notice reports the ratio to the wing." }
                isReal(definition.targetArea, { (unitless) : [30, 165, 1000] } as RealBoundSpec);

                annotation { "Name" : "Aspect ratio",
                             "Description" : "Limits 2-14, projected span^2 / projected area. Typical 4-6 surf/eFoil, 6-9 pump/downwind/race. Higher = more efficient stab and more pitch damping per area, but more tip-breach risk and flex." }
                isReal(definition.aspectRatio, { (unitless) : [2, 7.5, 14] } as RealBoundSpec);

                annotation { "Name" : "Area definition",
                             "Description" : "Which area the target refers to. Projected (top view) is what sets lift and what most brands quote. Developed is measured along the curved span line and is larger with anhedral or gull. Both are reported." }
                definition.areaDefinition is AreaDefinition;
            }
            else
            {
                annotation { "Name" : "Span",
                             "Description" : "Limits 80-1200 mm, projected tip to tip (top view). Typical 250-450 mm." }
                isLength(definition.span, { (millimeter) : [80, 330, 1200] } as LengthBoundSpec);

                annotation { "Name" : "Root chord",
                             "Description" : "Limits 20-300 mm. Typical 60-110 mm." }
                isLength(definition.rootChord, { (millimeter) : [20, 75, 300] } as LengthBoundSpec);
            }

            annotation { "Name" : "Chord distribution",
                         "Description" : "Superellipse: c = c0 (1 - (s 2y/b)^n)^(1/n), cut off at the end chord ratio, giving a rounded tip. Linear: straight taper to a square tip. Double taper: a steep taper from the root to Break %, then a gentler one to the tip - a wide root flaring into a slim outer wing (the full-base stab, or a high-aspect wing with a broad centre); Blend % rounds the corner between the two. Linear and double taper end in a square tip: Tip cap = Rounded + plan rounds it in plan view too." }
            definition.chordShape is ChordShape;

            if (definition.chordShape == ChordShape.SUPERELLIPSE)
            {
                annotation { "Name" : "Exponent n",
                             "Description" : "Limits 1.2-8. 2 = elliptic. 2.5-4 = fuller tips (common on stabs, keeps area outboard for damping). Above 5 approaches a rectangle with rounded corners. Typical 2.5-4." }
                isReal(definition.superN, { (unitless) : [1.2, 2.5, 8] } as RealBoundSpec);

                annotation { "Name" : "End ratio",
                             "Description" : "Limits 0.02-0.6. Chord of the small end face as a fraction of root chord. Typical 0.06-0.12 for a rounded tip (stab chords are small, so keep the end face above about 5 mm); 0.15-0.3 for a blunt tip." }
                isReal(definition.endRatio, { (unitless) : [0.02, 0.08, 0.6] } as RealBoundSpec);
            }
            else
            {
                if (definition.chordShape == ChordShape.DOUBLE)
                {
                    annotation { "Name" : "Break %",
                                 "Description" : "Limits 5-60, per half span. Where the steep root taper ends and the gentle outer taper begins, as a percentage of the half span. Typical 20-30 for a full-base stab: the wide root carries the mount and the bolts, so the mount pad can be shorter and the root thinner in percent without a bump. The AFS U Carve measures about 28." }
                    isReal(definition.breakPct, { (unitless) : [5, 28, 60] } as RealBoundSpec);

                    annotation { "Name" : "Mid ratio",
                                 "Description" : "Limits 0.2-1.0. Chord at the break as a fraction of root chord. Must be at least Tip ratio. Typical 0.55-0.7 for a full-base stab (U Carve about 0.62)." }
                    isReal(definition.midRatio, { (unitless) : [0.2, 0.62, 1] } as RealBoundSpec);

                    annotation { "Name" : "Blend %",
                                 "Description" : "Limits 0-30, per half span. Rounds the corner where the two tapers meet: the outline follows a smooth curve from Blend % before the break to Blend % after it, tangent to both tapers, instead of a sharp kink. 0 = sharp. Typical 8-15 (the AFS U Carve fits best at 10). Clamped so the blend never reaches the root or the tip." }
                    isReal(definition.blendPct, { (unitless) : [0, 10, 30] } as RealBoundSpec);
                }

                annotation { "Name" : "Tip ratio",
                             "Description" : "Limits 0.1-1.0. Tip chord as a fraction of root chord; the tip is square in plan view. Typical 0.4-0.7 for linear taper, 0.15-0.3 for double taper (U Carve about 0.21), where it is the chord at the end of the outer taper and must not exceed Mid ratio." }
                isReal(definition.tipRatio, { (unitless) : [0.1, 0.5, 1] } as RealBoundSpec);
            }

            annotation { "Name" : "Min tip", "Default" : false,
                         "Description" : "On = the tip chord is widened automatically until the section at the tip cap start is at least Min tip mm thick, by raising End ratio (or Tip ratio) above the value entered. The notice reports the ratio used. Guards a thin, small-chord tip that cannot be laid up; especially useful on a stab linked to a wing, where the link sets area, aspect ratio and thickness but the tip chord is still this feature's own." }
            definition.minTipOn is boolean;

            if (definition.minTipOn)
            {
                annotation { "Name" : "Min tip mm",
                             "Description" : "Minimum section thickness at the tip cap start (the last full section before the cap tapers out). Limits 0.2-5 mm. Typical 1-1.5 mm for a carbon layup: two skin plies plus a little UD; the cap beyond it is tow and resin. Only the tip chord is changed, never the thickness %." }
                isLength(definition.minTip, { (millimeter) : [0.2, 1, 5] } as LengthBoundSpec);
            }

            annotation { "Name" : "Stations",
                         "Description" : "Limits 3-30, per half span. Typical 9-13 for a rounded superellipse tip, 5-7 for linear taper. Tip-cap stations are added on top." }
            isInteger(definition.stations, { (unitless) : [3, 11, 30] } as IntegerBoundSpec);

            annotation { "Name" : "Root tail", "Default" : false,
                         "Description" : "On = the stab's own outline carries a tail: the trailing edge is extended aft at the centreline by Tail length, fading to nothing over Tail span %, so the root ends in a rounded point behind the trailing edge like a production stab's, and the fuselage tip can be the stab itself. The extension is all behind the trailing edge whatever Align is; the section keeps its thickness in mm and is stretched aft, so the tail is thin. The area solver includes it. With it on you can turn the mount pad's Tail off; the fuselage then ends at the stab's trailing edge." }
            definition.rootTailOn is boolean;

            if (definition.rootTailOn)
            {
                annotation { "Name" : "Tail length",
                             "Description" : "How far the trailing edge extends behind the root trailing edge at the centreline. Limits 5-200 mm. Typical 30-60 mm for a stab; about half the root chord gives the V of a full-base stab." }
                isLength(definition.rootTailLen, { (millimeter) : [5, 40, 200] } as LengthBoundSpec);

                annotation { "Name" : "Tail span %",
                             "Description" : "Over what part of the half span the tail fades to nothing, from the centreline. Limits 5-60 %. The fade is smooth at both ends: flat across the centreline (a rounded tail nose) and tangent to the outline where it ends. Typical 20-35." }
                isReal(definition.rootTailSpan, { (unitless) : [5, 25, 60] } as RealBoundSpec);
            }

            annotation { "Name" : "Mirror to full span", "Default" : true,
                         "Description" : "On = complete foil. Off = right half only, for faster edits and section inspection. Reported metrics are always full-span values." }
            definition.mirror is boolean;
        }

        annotation { "Group Name" : "Sweep, alignment and anhedral", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Align line %",
                         "Description" : "Limits 0-100 %. The chord line that stays straight (apart from Sweep aft). Typical 100 for a superellipse stab with a straight trailing edge, 25-50 for both edges curving, 0 for a double-taper full-base stab: straight leading edge, the flare and the root tail all on the trailing edge. Independent of the incidence pivot. Plan-view tip rounding is centred on the mid-chord regardless, so both tip corners round." }
            isReal(definition.planformAlign, { (unitless) : [0, 50, 100] } as RealBoundSpec);

            annotation { "Name" : "Sweep aft",
                         "Description" : "Limits -50 to +200 mm, positive = aft. How far the alignment line sits aft at the tip. Typical 10-50 mm. More sweep = more yaw stability and a longer effective tail arm." }
            isLength(definition.sweepTip, { (millimeter) : [-50, 30, 200] } as LengthBoundSpec);

            annotation { "Name" : "Sweep exp",
                         "Description" : "Limits 0.5-4. Shape of the sweep line x = offset (2y/b)^m. 1 = straight (kinked at the root), 2-3 = curved and tangent at the root, 3-4 = raked tips. Typical 2." }
            isReal(definition.sweepExp, { (unitless) : [0.5, 2, 4] } as RealBoundSpec);

            annotation { "Name" : "Tip drop",
                         "Description" : "Limits -50 to +100 mm, positive = down (anhedral). Typical 0-15 mm; negative (tips up) is used on some stabs for yaw stability. Large values can create mold undercuts." }
            isLength(definition.tipDrop, { (millimeter) : [-50, 20, 100] } as LengthBoundSpec);

            annotation { "Name" : "Drop shape",
                         "Description" : "How the drop is spread between Drop from % and Drop to %. Power law: z = -drop u^e with Drop exp, steepening all the way to the tip (2-3 = flat centre, tips dropping late). S-curve: a smoothstep, flat at both ends and steepest in the middle, so the wing levels off again before the tip - the gull front view of the AFS Silk V2 (Drop from 3, Drop to 91, Tip drop 45 measures it to 0.3 mm)." }
            definition.dropLaw is DropLaw;

            if (definition.dropLaw == DropLaw.POWER)
            {
            annotation { "Name" : "Drop exp",
                         "Description" : "Limits 1-6. Typical 2-3. Shape of the drop z = -drop (2y/b)^e. 1 = straight from the root, 2-3 = flat centre with tips falling away." }
            isReal(definition.dropExp, { (unitless) : [1, 2, 6] } as RealBoundSpec);
            }

            annotation { "Name" : "Drop from %",
                         "Description" : "Limits 0-70, per half span. Where the drop begins: the span line is flat (or on the gull dihedral line) out to here, then drops by Tip drop over the rest with the Drop exp shape. 0 = the drop starts at the root, the plain law. Typical 0, or 15-30 for a flat centre with a break. A flat centre with a distinct break and a near-straight drop, as on the AFS Silk V2 (about 20 with Drop exp 1.3), needs this; the winglet gives the tip rise on top of it." }
            isReal(definition.dropFrom, { (unitless) : [0, 0, 70] } as RealBoundSpec);

            annotation { "Name" : "Drop to %",
                         "Description" : "Limits 30-100, per half span. Where the drop is complete: beyond it the span line runs level at the full Tip drop (until a winglet bends it). Typical 100, or 85-95 for a wing that levels off before its tips, as the Silk V2 does (91)." }
            isReal(definition.dropTo, { (unitless) : [30, 100, 100] } as RealBoundSpec);

            annotation { "Name" : "Gull dihedral",
                         "Description" : "Limits -10 to +20 deg, positive = up. Gull term as on the wing; rarely used on stabs. Typical 0. Needs a drop exponent above 1." }
            isAngle(definition.rootDihedral, { (degree) : [-10, 0, 20] } as AngleBoundSpec);

            annotation { "Name" : "Winglet",
                         "Description" : "Off: the tip follows Tip drop and Gull dihedral only. Up / Down: the outer part of each half span bends through Winglet angle on an arc of Bend radius and then runs straight, with every section drawn square to the bent path, so the winglet keeps its true section at any angle up to 90 deg. Its size is Winglet area: the chord distribution continues along the bend, and the tool solves how much of the half span to bend so that area comes out. Area and aspect ratio stay the developed values of the whole half span, winglet included; the notice adds the winglet height and the projected span. Foil performance credits a winglet as extra effective span for induced drag (0.9 x its height across the pair). Foil mold molds it up to 75 deg; steeper cannot release from a vertical pull." }
            definition.winglet is Winglet;

            if (definition.winglet != Winglet.OFF)
            {
                annotation { "Name" : "Winglet area",
                             "Description" : "Area of each winglet, cm^2, measured along the bend. Limits 0.5-200. Typical 4-15 for a stab. The bend starts where the outer chord distribution has this much area left to the tip, so it must fit: the winglet cannot start inside 30 % of the half span." }
                isReal(definition.wingletArea, { (unitless) : [0.5, 8, 200] } as RealBoundSpec);

                annotation { "Name" : "Winglet angle",
                             "Description" : "Limits 10-90 deg from the span plane. 90 = vertical. Typical 45-70 for a foil winglet; small angles are just a stronger tip drop and Tip drop does that with a smooth curve." }
                isAngle(definition.wingletAngle, { (degree) : [10, 60, 90] } as AngleBoundSpec);

                annotation { "Name" : "Bend radius",
                             "Description" : "Limits 5-300 mm, on the span line. The bend is an arc of this radius through Winglet angle, then straight to the tip. Typical 20-40 mm. If the arc would be longer than the winglet, the radius is reduced so the whole winglet is the bend, and the notice says so." }
                isLength(definition.wingletRadius, { (millimeter) : [5, 30, 300] } as LengthBoundSpec);
            }

            annotation { "Name" : "LE bumps", "Default" : false,
                         "Description" : "Leading-edge bumps (tubercles, as on humpback flippers and on AFS, Lift and other production wings): the leading edge moves forward and back sinusoidally along the span while the trailing edge stays put, so the chord swells at each peak. Published tests (Miklosovic 2004, Johari 2007) show a softer stall and lift kept beyond it, for a little drag and sometimes a little maximum lift before stall; for a foil that is take-off, pumping and hard turns. GEOMETRY ONLY: Foil performance uses the smooth chord distribution and does not credit or charge them. Foil mold follows them exactly. Adds six stations per bump pitch, so regeneration slows." }
            definition.bumpOn is boolean;

            if (definition.bumpOn)
            {
                annotation { "Name" : "Bump height",
                             "Description" : "Limits 0.3-8 mm. Peak-to-trough travel of the leading edge. Typical 1.5-3 on a stab. The section is stretched at a peak and compressed at a trough with its thickness in mm unchanged." }
                isLength(definition.bumpAmp, { (millimeter) : [0.3, 2, 8] } as LengthBoundSpec);

                annotation { "Name" : "Bump pitch",
                             "Description" : "Limits 10-150 mm. Spanwise distance from one peak to the next. Typical 25-50 on a stab. The bumps fade in and out over half a pitch at each end of their range." }
                isLength(definition.bumpPitch, { (millimeter) : [10, 35, 150] } as LengthBoundSpec);

                annotation { "Name" : "Bumps from %",
                             "Description" : "Limits 3-90, per half span. Where the bumps start, from the centreline. AFS centre them on the GLT dockstart wing (from 5) and run them outboard on the Silk and Ultra (from 12-20). Typical 10-20. Not 0: a bump starting on the centreline broke the mold's cavity cut (build 164), and a real wing has its mount there anyway." }
                isReal(definition.bumpFrom, { (unitless) : [3, 15, 90] } as RealBoundSpec);

                annotation { "Name" : "Bumps to %",
                             "Description" : "Limits 10-100, per half span. Where the bumps end; must be beyond Bumps from by at least one pitch. Typical 90-95, leaving the tip cap clean." }
                isReal(definition.bumpTo, { (unitless) : [10, 92, 100] } as RealBoundSpec);
            }
        }

        annotation { "Group Name" : "Twist and thickness distribution", "Collapsed By Default" : true }
        {
            annotation { "Name" : "Washout",
                         "Description" : "Limits -5 to +8 deg, relative to the root incidence; positive = tip leading edge down. Typical 0 deg; stabs are normally untwisted." }
            isAngle(definition.washout, { (degree) : [-5, 0, 8] } as AngleBoundSpec);

            annotation { "Name" : "Washout exp",
                         "Description" : "Limits 0.5-4. Twist follows washout (2y/b)^w. 1 = linear, 2-3 = twist concentrated towards the tips. Typical 1." }
            isReal(definition.washoutExp, { (unitless) : [0.5, 1, 4] } as RealBoundSpec);

            annotation { "Name" : "Thickness exp",
                         "Description" : "Limits 0.5-4. Thickness % follows root + (tip - root)(2y/b)^p. 1 = linear, 2-3 = keeps root thickness further out. Typical 1-2." }
            isReal(definition.thicknessExp, { (unitless) : [0.5, 1.5, 4] } as RealBoundSpec);
        }

        annotation { "Group Name" : "Incidence", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Incidence",
                         "Description" : "Limits -10 to +5 deg, measured from the fuselage axis (X), positive = leading edge up. Typical -1 to -3 deg. Aim for a wing-minus-stab difference (decalage) of 1.5-3 deg; the notice reports geometric and aerodynamic decalage." }
            isAngle(definition.incidence, { (degree) : [-10, -1.5, 5] } as AngleBoundSpec);

            annotation { "Name" : "Pivot",
                         "Description" : "Point each section rotates about for incidence and washout, and the line that follows the drop curve. The root pivot sits at the stab position. Quarter chord (recommended) keeps the lift centre fixed as angles change. Plan-view shape is set by the alignment line, not the pivot." }
            definition.pivot is FoilPivot;
        }

        annotation { "Group Name" : "Position and link to wing", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Arm",
                         "Description" : "Limits 200-1500 mm, positive = aft. Distance along the fuselage axis from the wing root pivot (world origin) to the stab root pivot. This sets the pitching moment arm and, with stab area, the tail volume - it is a design decision, not a fuselage detail. Typical 550-800 mm; short (450-550) for surf/carving, long (700-900+) for pump/downwind. Longer = more pitch stability and damping, slower pitch response. A fuselage, if you add one later, is built to match this arm rather than the other way round." }
            isLength(definition.arm, { (millimeter) : [200, 650, 1500] } as LengthBoundSpec);

            annotation { "Name" : "Height",
                         "Description" : "Where the stab's seat plane sits relative to the fuselage centreline (the wing's tube socket axis), positive = up; 0 = on the centreline. The seat plane is the pad face, or the bare root surface without a pad. Pad on top (fuselage over the stab): 0 cuts the fuselage flat to half the tube under the seat, -4 leaves a flat 2 x sqrt(R^2 - 16) wide and more tube (typical -3 to -5); below the axis only. Pad underneath (stab on top): +4 does the same the other way; above the axis only. The stab is placed to this after it is built, so resizing or relinking it never moves the seat. Without a tube socket on the wing this is the offset of the stab pivot from the wing pivot instead. Limits -100 to +100 mm. Typical -4 (pad on top), +4 (pad underneath), 0 to +20 with no socket." }
            isLength(definition.height, { (millimeter) : [-100, 0, 100] } as LengthBoundSpec);

            annotation { "Name" : "Link to wing",
                         "Description" : "Independent: every stab parameter below is typed in directly. Linked to wing: area, aspect ratio, thickness and incidence are derived from the wing's reported values instead, using the ratios and offsets below. Camber, planform shape, sweep, anhedral, twist and tip stay independent either way." }
            definition.stabLink is StabLink;

            if (definition.stabLink == StabLink.LINKED)
            {
                annotation { "Name" : "Area ratio",
                             "Description" : "Limits 0.05-0.4. Stab projected area as a fraction of the wing's projected area. Typical 0.15-0.22. Replaces the direct area input; aspect ratio still sets the span/chord split." }
                isReal(definition.linkAreaRatio, { (unitless) : [0.05, 0.15, 0.4] } as RealBoundSpec);

                annotation { "Name" : "AR offset",
                             "Description" : "Limits -8 to +4. Added to the wing's aspect ratio to get the stab's. Typical -2 to 0: a lower-AR stab is common for extra pitch damping and robustness." }
                isReal(definition.linkAROffset, { (unitless) : [-8, -1.5, 4] } as RealBoundSpec);

                annotation { "Name" : "Thick offset",
                             "Description" : "Limits -6 to +2 %. Added to the wing's root and tip thickness % to get the stab's, so the stab reliably stays thinner (or thicker) than the wing. Typical -3 to -1." }
                isReal(definition.linkThicknessOffset, { (unitless) : [-6, -2, 2] } as RealBoundSpec);

                annotation { "Name" : "Decalage",
                             "Description" : "Limits 0-6 deg. Stab incidence is set to the wing's incidence minus this value, so you tune the one number that actually sets trim instead of two absolute angles. Typical 1.5-3 deg geometric. The notice still reports the resulting geometric and aerodynamic decalage." }
                isAngle(definition.linkDecalage, { (degree) : [0, 1.5, 6] } as AngleBoundSpec);
            }
        }

        annotation { "Group Name" : "Tip", "Collapsed By Default" : true }
        {
            annotation { "Name" : "Tip cap",
                         "Description" : "Rounded tip: section thickness falls along a quarter-ellipse over the cap length, rounding the tip in front view; plan-view rounding then comes only from the superellipse end ratio. Rounded + plan: the chord also shrinks along the same quarter-ellipse over the cap length, to Cap end % of the chord at the cap start, so a linear or double taper gets a rounded tip in plan view as well (the area solver allows for it). Flat tip: thickness is unchanged to the end face." }
            definition.tipCap is TipCap;

            if (definition.tipCap != TipCap.FLAT)
            {
                annotation { "Name" : "Cap length",
                             "Description" : "Limits 2-40 mm, and at most 30 % of the half span. Typical 5-12 mm." }
                isLength(definition.capLength, { (millimeter) : [2, 8, 40] } as LengthBoundSpec);

                annotation { "Name" : "Cap end %",
                             "Description" : "End-face thickness as % of the tip section thickness. Limits 5-80 %. Typical 20-35 % (stab tips are small; keep the end face layable)." }
                isReal(definition.capEnd, { (unitless) : [5, 30, 80] } as RealBoundSpec);
            }
        }


        annotation { "Group Name" : "Section polar", "Collapsed By Default" : true }
        {
            annotation { "Name" : "Section data",
                         "Description" : "Built-in: fitted XFoil data, nothing to type in. E817/E818/NACA 63-412/Clark Y use one real polar each. NACA 4-digit uses the exact zero-lift angle/moment for your Camber %/Camber pos %, plus lift slope, CLmax and drag bucket fitted from real NACA polars at your thickness/camber - coarser than the fixed profiles (a fit across a family, not one measured shape); use Polar summary for higher accuracy at your exact section. Analytic (default): thin-aerofoil model - camber-line angle/moment, fixed lift slope, skin-friction drag, Section CL max from Foil performance. Polar summary: your own XFoil/XFLR5 numbers at your own Reynolds numbers, via the fields below. Run scripts/polar_summary.py (developer skill) on your polar - the tool never invents section data." }
            definition.polarSource is PolarSource;

            if (definition.polarSource == PolarSource.POLAR)
            {
                annotation { "Name" : "Zero-lift",
                             "Description" : "Zero-lift angle of attack from the polar, deg (usually negative for a cambered section). Limits -8 to 4 deg. Replaces the thin-aerofoil estimate. Typical -1 to -3 deg for a few % camber. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isAngle(definition.polarAlpha0, { (degree) : [-8, -2, 4] } as AngleBoundSpec);

                annotation { "Name" : "Lift slope",
                             "Description" : "Section lift-curve slope from the polar, per radian. Limits 4-7.5. Thin-aerofoil theory gives 2*pi = 6.28. Replaces the fixed analytic value. Typical 5.5-6.5 depending on thickness and Reynolds number. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarCla, { (unitless) : [4, 6, 7.5] } as RealBoundSpec);

                annotation { "Name" : "Cm c/4",
                             "Description" : "Section pitching moment about the quarter chord from the polar (usually fairly constant with CL below stall). Limits -0.15 to 0.05. Replaces the thin-aerofoil Cm0. Typical -0.03 to -0.11 for a cambered section, near 0 for symmetric. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarCm0, { (unitless) : [-0.15, -0.05, 0.05] } as RealBoundSpec);

                annotation { "Name" : "Re 1 (M)",
                             "Description" : "First Reynolds number the polar data below is from, in millions. Limits 0.1-5. Values are interpolated (log Re) between Re 1 and Re 2, and held flat outside that range. Typical: near your take-off Reynolds number (about 0.2-0.5 M for a wing, lower for a stab). For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarRe1, { (unitless) : [0.1, 0.2, 5] } as RealBoundSpec);

                annotation { "Name" : "CLmax @Re1",
                             "Description" : "Maximum section lift coefficient at Re 1. Limits 0.6-1.8. Real CLmax usually drops noticeably below the higher-Re value, which is why a single fixed CL max (the analytic fallback) can be optimistic at take-off. Typical 0.85-1.1 at low Re. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarClmax1, { (unitless) : [0.6, 0.85, 1.8] } as RealBoundSpec);

                annotation { "Name" : "Cdmin @Re1",
                             "Description" : "Minimum section drag coefficient at Re 1 (the bottom of the drag bucket). Limits 0.004-0.03. Friction drag rises as Re falls. Typical 0.008-0.018 at low Re. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarCdmin1, { (unitless) : [0.004, 0.01, 0.03] } as RealBoundSpec);

                annotation { "Name" : "CL@Cdmin 1",
                             "Description" : "The lift coefficient at which Cdmin occurs at Re 1 - the centre of the drag bucket. Limits -0.3 to 1.0. Typical 0.3-0.7. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarClcd1, { (unitless) : [-0.3, 0.3, 1] } as RealBoundSpec);

                annotation { "Name" : "k @Re1",
                             "Description" : "Drag-rise rate at Re 1: Cd = Cdmin + k (CL - CL@Cdmin)^2. Limits 0.005-0.05. For your own polar, read it off two points on the drag bucket away from Cdmin and solve for k, or use polar_summary.py to fit it automatically. Typical 0.005-0.04. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarK1, { (unitless) : [0.005, 0.013, 0.05] } as RealBoundSpec);

                annotation { "Name" : "Re 2 (M)",
                             "Description" : "Second Reynolds number, in millions. Limits 0.1-5. Must differ from Re 1 for interpolation to do anything. Typical: near your cruise or max-speed Reynolds number. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarRe2, { (unitless) : [0.1, 0.5, 5] } as RealBoundSpec);

                annotation { "Name" : "CLmax @Re2",
                             "Description" : "Maximum section lift coefficient at Re 2. Limits 0.6-1.8. Typical 1.0-1.3 at higher Re. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarClmax2, { (unitless) : [0.6, 1, 1.8] } as RealBoundSpec);

                annotation { "Name" : "Cdmin @Re2",
                             "Description" : "Minimum section drag coefficient at Re 2. Limits 0.004-0.03. Typical 0.004-0.008 at higher Re. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarCdmin2, { (unitless) : [0.004, 0.007, 0.03] } as RealBoundSpec);

                annotation { "Name" : "CL@Cdmin 2",
                             "Description" : "The lift coefficient at which Cdmin occurs at Re 2. Limits -0.3 to 1.0. Typically close to CL@Cdmin 1, since the drag bucket centre moves less with Re than CLmax does. Typical 0.3-0.4. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarClcd2, { (unitless) : [-0.3, 0.3, 1] } as RealBoundSpec);

                annotation { "Name" : "k @Re2",
                             "Description" : "Drag-rise rate at Re 2. Limits 0.005-0.05. Typical 0.01-0.035. For the built-in profiles (E817, E818, NACA 63-412, Clark Y) use Section data = Built-in instead of typing these in." }
                isReal(definition.polarK2, { (unitless) : [0.005, 0.01, 0.05] } as RealBoundSpec);
            }
        }

        if (definition.profile != FoilProfile.NACA4)
        {
            annotation { "Name" : "Invert section", "Default" : true,
                         "Description" : "Mount the stab's tabulated profile (E817, E818, NACA 63-412, Clark Y) upside down, camber down, so it makes the downforce a stab is there for - the convention for a cambered stab section. The right way up it LIFTS at cruise and throws the trim CG far aft. No effect on NACA 4-digit, where the sign of Camber % does this (negative = inverted)." }
            definition.invertSection is boolean;
        }

        annotation { "Group Name" : "Mount pad", "Collapsed By Default" : true }
        {
            annotation { "Name" : "Mount pad", "Default" : true,
                         "Description" : "Adds the production-style mount to the stab root, modelled on the Axis rear wing: a flat pad face on the fuselage side, faired in from the leading edge, the full root chord long, with an optional tail fairing running aft of the trailing edge to close the fuselage's end. The Foil fuselage seats on this face and the Foil mold puts bolt cones in it. Off = bare root, the fuselage seats on the curved skin." }
            definition.padOn is boolean;

            if (definition.padOn)
            {
                annotation { "Name" : "Pad side",
                             "Description" : "Top: the fuselage passes over the stab and bolts up through it into the fuselage (Axis, Lift, Armstrong layout). Bottom: the stab sits on top of the fuselage tail and bolts down into it. Top is the norm: the bolt heads sit in the stab's underside, the fuselage tail fairs into the stab's tail, and the stab's convex side faces down." }
                definition.padSide is PadSide;

                annotation { "Name" : "Pad width",
                             "Description" : "Width of the pad face across the span, centred on the root. Limits 5-80 mm. Typical 20-24 mm (Axis 22); match or slightly under the fuselage Tail dia so the seat is full width. Also the width of the tail fairing where it leaves the trailing edge." }
                isLength(definition.padWidth, { (millimeter) : [5, 22, 80] } as LengthBoundSpec);

                annotation { "Name" : "Pad height",
                             "Description" : "How far the flat pad face stands above the section's highest point at the root (on the pad side). Limits 1-20 mm. Typical 5-8 mm (Axis 7.4): room for the fuselage seat to be full width and the bolt heads or threads to bite. Sets the pad plane the fuselage seats on." }
                isLength(definition.padHeight, { (millimeter) : [1, 6, 20] } as LengthBoundSpec);

                annotation { "Name" : "Flat start",
                             "Description" : "Where the flat pad face begins, in mm from the stab pivot along X (negative = ahead of it). Limits -100 to 100 mm. Typical -10 to 0 (just ahead of the quarter-chord pivot). The ramp fairs up from the leading edge to here, so it adapts to the stab; everything aft of here is the fixed interface the fuselage seats on. Must be at least 5 mm behind the leading edge - the notice warns and holds it there if not." }
                isLength(definition.flatStart, { (millimeter) : [-100, -5, 100] } as LengthBoundSpec);

                annotation { "Name" : "Tail fairing", "Default" : true,
                             "Description" : "Continues the pad aft of the trailing edge as a tail: full Pad width from the trailing edge to Tail start, then tapering to End width x End thick at Tail end, flat on the pad side. Its top is the same seat plane, so the fuselage's flat runs from Flat start to Tail end and its tip tapers from Tail start, whatever the stab's chord. Off = the pad ends at the trailing edge and the interface is no longer fixed." }
                definition.tailOn is boolean;

                if (definition.tailOn)
                {
                    annotation { "Name" : "Tail start",
                                 "Description" : "Where the tail fairing and the fuselage tip begin to taper, in mm aft of the stab pivot. Limits 0-300 mm. Typical 80-100: at or a little behind the trailing edge of your biggest stab (root chord x 0.75 from a quarter-chord pivot). A stab whose trailing edge is behind this is warned and the taper starts at its trailing edge instead." }
                    isLength(definition.tailStart, { (millimeter) : [0, 85, 300] } as LengthBoundSpec);

                    annotation { "Name" : "Tail end",
                                 "Description" : "Where the tail fairing and the fuselage end, in mm aft of the stab pivot. Limits 10-400 mm. Typical Tail start + 35-50 (Axis tail 40 mm). Must be at least 5 mm behind Tail start and the trailing edge." }
                    isLength(definition.tailEnd, { (millimeter) : [10, 125, 400] } as LengthBoundSpec);

                    annotation { "Name" : "End width",
                                 "Description" : "Plan width of the tail at its end. Limits 1-30 mm. Typical 3-6 mm (Axis 4). The taper from Pad width is concave - fast at first, then easing - like a fuselage tail." }
                    isLength(definition.tailEndWidth, { (millimeter) : [1, 4, 30] } as LengthBoundSpec);

                    annotation { "Name" : "End thick",
                                 "Description" : "Thickness of the tail at its end, from the pad plane to the far surface. Limits 1-20 mm. Typical 5-7 mm (Axis 6): the far surface slopes from the trailing edge up to here." }
                    isLength(definition.tailEndThick, { (millimeter) : [1, 6, 20] } as LengthBoundSpec);
                }
            }
        }

        annotation { "Group Name" : "Mount bolts", "Collapsed By Default" : true }
        {
            annotation { "Name" : "Stab bolts",
                         "Description" : "Through holes on the centreline for the bolts that hold the stab to the fuselage. Limits 0-6. Typical 2 (Axis: two at 35 mm). The stab owns this pattern: the Foil fuselage taps its blind holes to match and the Foil mold puts undersized cones at the same positions. 0 = no holes." }
            isInteger(definition.stabBolts, { (unitless) : [0, 2, 6] } as IntegerBoundSpec);

            {
                annotation { "Name" : "Bolt 1 at",
                             "Description" : "First bolt's position in mm from the stab pivot along X (negative = ahead). Limits -100 to 200 mm. Typical 0 (Axis: 22 mm behind the LE on an 89 mm chord, i.e. at the quarter chord, where the section is thickest). Fixed to the pivot, so the fuselage's tapped holes are the same for every stab. Keep it on the flat (at or behind Flat start) for a seat of constant depth." }
                isLength(definition.bolt1At, { (millimeter) : [-100, 0, 200] } as LengthBoundSpec);

                annotation { "Name" : "Bolt pitch",
                             "Description" : "Spacing between bolts along X. Limits 5-200 mm. Typical 30-40 mm (Axis 35). Every bolt must sit inside the root or the tail; the notice warns if one does not." }
                isLength(definition.boltPitch, { (millimeter) : [5, 35, 200] } as LengthBoundSpec);

                annotation { "Name" : "Bolt", "Default" : "M6",
                             "Description" : "The bolt that holds the stab to the fuselage. Sets the stab's clearance hole (close fit: M4 4.4, M5 5.4, M6 6.4, M8 8.4, M10 10.5 mm) and, through the published pattern, the Foil fuselage's tapping drill (3.3 / 4.2 / 5.0 / 6.8 / 8.5 mm), so the two can never disagree. Typical M6 (Axis), M8 for a big stab. Custom hole sizes: type the clearance hole here and the tapping drill in the fuselage yourself." }
                definition.boltSize is BoltSize;

                if (definition.boltSize == BoltSize.CUSTOM)
                {
                    annotation { "Name" : "Bolt dia",
                                 "Description" : "Clearance hole diameter in the stab (Custom only). Limits 2-14 mm. Typical 8.4 (M8) or 6.4 (M6). This is the finished hole: the mold makes an undersized cone and it is drilled to this after cure. Set the matching tapping drill in Foil fuselage's Stab bolt dia." }
                    isLength(definition.boltDia, { (millimeter) : [2, 8.4, 14] } as LengthBoundSpec);
                }

                annotation { "Name" : "Countersink", "Default" : true,
                             "Description" : "90 deg countersink on the face away from the pad, where the bolt heads sit (the underside with the pad on top), to the ISO 10642 head diameter of the chosen Bolt (M6 13.4, M8 17.9 mm; Custom: twice the hole). Cut in the model for fit; on the molded part it is drilled and countersunk after cure like the hole itself. Skipped for a bolt behind the trailing edge." }
                definition.boltCsk is boolean;
            }
        }

        annotation { "Name" : "Log inputs", "Default" : true,
                     "Description" : "Prints every parameter on this feature to the FeatureScript console as one line, so the whole set can be pasted elsewhere (e.g. back to an AI assistant) along with the notice or CSV." }
        definition.logInputs is boolean;
    }
    {
        const m = buildFoil(context, id, definition, vector(definition.arm, 0 * meter, definition.height));
        var height = definition.height;            // effective pivot height: set by the seat shift below
        var seatNote = "";

        setVariable(context, "foilStabArea", m.areaProj);
        setVariable(context, "foilStabAreaDeveloped", m.areaDev);
        setVariable(context, "foilStabSpan", m.span);
        setVariable(context, "foilStabRootChord", m.rootChord);
        setVariable(context, "foilStabMAC", m.mac);
        setVariable(context, "foilStabAR", m.aspect);
        setVariable(context, "foilStabIncidence", m.incidence);
        setVariable(context, "foilStabZeroLift", m.alpha0);
        setVariable(context, "foilStabArm", definition.arm);
        var sxMin = 1 * meter;
        var sxMax = -1 * meter;
        var szMin = 1 * meter;
        for (var p in m.rootPts)
        {
            sxMin = min(sxMin, p[0]);
            sxMax = max(sxMax, p[0]);
            szMin = min(szMin, p[1]);
        }
        var szMax = -1 * meter;
        for (var p in m.rootPts)
            szMax = max(szMax, p[1]);
        const pad = buildStabMount(context, id, definition, m);
        if (pad.on && pad.side == -1)
            szMin = pad.padRel;             // pad underneath: its face is the lowest point of the root
        if (pad.on && pad.side == 1)
            szMax = pad.padRel;             // pad on top: its face is the highest point
        // Height is where the seat plane sits relative to the fuselage centreline (build 134, user:
        // "0 mm offset always has the mount interface on the centreline"). The stab is built at a
        // provisional height and then shifted so its seat plane - the pad face, or the bare root
        // surface - lands at axis + Height. Everything published below uses the shifted height
        // (build 124: relinking the stab lifted the pad into the fuselage and the seat vanished)
        var contour = pad.contour;
        {
            var sockS;
            try silent { sockS = getVariable(context, "foilWingSocket"); }
            if (sockS == undefined || sockS.on != 1)
                seatNote = " | no tube socket on the wing: Height is the pivot's offset from the wing pivot";
            else
            {
                const over = !(pad.on && pad.side == -1);            // fuselage over the stab
                const seatRel = over ? szMax : szMin;                 // seat plane relative to the root pivot
                const target = sockS.axisZ * meter + definition.height;
                const dz = target - (definition.height + seatRel);
                if (abs(dz) > 0.005 * millimeter)
                {
                    opTransform(context, id + "seatShift", {
                                "bodies" : qBodyType(qCreatedBy(id, EntityType.BODY), BodyType.SOLID),
                                "transform" : transform(vector(0 * meter, 0 * meter, dz))
                            });
                    height = definition.height + dz;
                    contour = [];
                    for (var cp in pad.contour)
                        contour = append(contour, [cp[0], cp[1] + dz / meter]);
                }
                seatNote = " | seat plane " ~ (definition.height == 0 * meter ? "on" : fmt(abs(definition.height) / millimeter, 1) ~ " mm " ~ (definition.height > 0 * meter ? "above" : "below")) ~
                    " the fuselage centreline (Z " ~ fmt(sockS.axisZ * 1000, 1) ~ "), pivot at Z " ~ fmt(height / millimeter, 1) ~ " mm" ~
                    (over && definition.height > 0 * meter ? " - WARNING: with the pad on top the seat must be at or below the centreline; set Height to 0 or negative" : "") ~
                    (!over && definition.height < 0 * meter ? " - WARNING: with the pad underneath the seat must be at or above the centreline; set Height to 0 or positive" : "");
            }
        }
        if (definition.logInputs)
            println(stabInputLog(definition, height));
        setVariable(context, "foilStabHeight", height);
        nameSolids(context, id, definition.mirror ? "Stabiliser" : "Stabiliser (half)");
        var boltWorld = [];
        for (var bx in pad.boltX)
            boltWorld = append(boltWorld, (definition.arm + bx) / meter);
        setVariable(context, "foilStabRoot", {
                    "leX" : (definition.arm + sxMin) / meter, "teX" : (definition.arm + sxMax) / meter,
                    "bottomZ" : (height + szMin) / meter, "topZ" : (height + szMax) / meter,
                    "pivotX" : definition.arm / meter,
                    "padOn" : pad.on ? 1 : 0, "padSide" : pad.side,
                    "padZ" : (height + pad.padRel) / meter,
                    "padWidth" : (pad.on ? definition.padWidth : 0 * meter) / meter,
                    "tailOn" : pad.tailOn ? 1 : 0, "tailEndX" : (definition.arm + pad.endRel) / meter,
                    "padRampPct" : pad.on ? pad.rampPct : 0, "padX0" : (definition.arm + sxMin + 1 * millimeter) / meter,
                    "tailStartX" : (definition.arm + pad.tailStartRel) / meter,
                    "contour" : contour,
                    "tailLength" : (pad.tailOn ? pad.tailLen : 0 * meter) / meter,
                    "tailEndWidth" : (pad.tailOn ? definition.tailEndWidth : 0 * meter) / meter, "tailExp" : 1.6,
                    "boltX" : boltWorld, "boltDia" : (definition.stabBolts > 0 ? stabBoltClear(definition) : 0 * meter) / meter,
                    "tapDia" : definition.stabBolts > 0 && definition.boltSize != BoltSize.CUSTOM ? boltDims(definition.boltSize).tap / 1000 : 0,
                    "boltName" : boltDims(definition.boltSize).name, "headDia" : (definition.boltCsk ? boltHead(definition.boltSize, stabBoltClear(definition)) : 0 * meter) / meter
                });
        // the model at the height the stab actually ended up at (Seat on tube shifts it after
        // buildFoil; build 124-132 published the typed Height, so every mold of a seated stab
        // parted at the wrong height)
        var stabModel = m.model;
        stabModel.baseZ = height / meter;
        setVariable(context, "foilStabModel", stabModel);

        var msg = planformSummary(definition, m) ~ pad.note ~ seatNote;
        if (definition.stabLink == StabLink.LINKED)
            msg = msg ~ " (linked)";
        if (m.model.inverted == 1)
            msg = msg ~ " (" ~ m.model.profileName ~ " inverted)";

        // wing reference, if a Foil wing feature precedes this one
        var wingArea;
        var wingMac;
        var wingInc;
        var wingA0;
        try silent
        {
            wingArea = getVariable(context, "foilWingArea");
            wingMac = getVariable(context, "foilWingMAC");
            wingInc = getVariable(context, "foilWingIncidence");
            wingA0 = getVariable(context, "foilWingZeroLift");
        }
        if (wingArea == undefined || wingMac == undefined || wingInc == undefined || wingA0 == undefined)
        {
            msg = msg ~ " | add a Foil wing feature above this one for tail volume and decalage";
        }
        else
        {
            const areaPct = m.areaProj / wingArea * 100;
            const tailVolume = m.areaProj * definition.arm / (wingArea * wingMac);
            const decGeo = wingInc - m.incidence;
            const decAero = (wingInc - wingA0) - (m.incidence - m.alpha0);
            setVariable(context, "foilTailVolume", tailVolume);
            msg = msg ~ " | " ~ toString(round(areaPct)) ~ "% of wing" ~
                " · tail volume " ~ toString(round(tailVolume * 100) / 100) ~
                " · decalage " ~ toString(round(decGeo / degree * 10) / 10) ~ " deg geometric, " ~
                toString(round(decAero / degree * 10) / 10) ~ " deg aerodynamic";
        }
        reportFeatureInfo(context, id, msg);
    });

annotation { "Feature Type Name" : "Foil performance",
             "Feature Type Description" : "No geometry: a speed sweep of the Foil wing, stabiliser, mast and fuselage above it. Lifting-line lift and induced drag, profile, mast, pod and fuselage drag, trim, static margin, stall, cavitation and root bending, with optional propulsion for eFoil and foil assist: prop rpm, battery power, Wh/km, range, top speed and powered trim. Results in the notice and as a CSV in the console." }
export const foilPerformance = defineFeature(function(context is Context, id is Id, definition is map)
    precondition
    {
        annotation { "Group Name" : "Load and water", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Total mass kg",
                         "Description" : "Rider + board + foil (+ battery for eFoil), in kg. Limits 20-250. Typical 75-110 kg for an adult rider with board and foil; add 10-20 kg of battery for eFoil. The weight the foil must lift at every speed." }
            isReal(definition.mass, { (unitless) : [20, 75, 250] } as RealBoundSpec);

            annotation { "Name" : "Pitch Nm",
                         "Description" : "External pitching moment about the centre of mass, N m, positive = nose up. Limits -500 to +500. Typical 0 unless modelling propulsion or sail forces. 0 for pump/SUP/surf (rider weight only). eFoil: with Propulsion on and a motor pod, the thrust/drag couple is added automatically, so leave this 0 unless something else acts. Wind/kite: sail or harness force times its height above the CG. Shifts the trim CG position; does not change drag." }
            isReal(definition.extMoment, { (unitless) : [-500, 0, 500] } as RealBoundSpec);

            annotation { "Name" : "Density kg/m^3",
                         "Description" : "Water density. Limits 990-1040. Typical 1025 (sea) or 998 (fresh). 1025 seawater, 998 fresh water. Fresh water needs about 1.3 % more speed for the same lift." }
            isReal(definition.density, { (unitless) : [990, 1025, 1040] } as RealBoundSpec);

            annotation { "Name" : "Water temp C",
                         "Description" : "Water temperature in deg C. Limits 0-35. Typical 15-25 C. Sets viscosity (Reynolds number, skin friction) and vapour pressure (cavitation). Cold water raises friction drag slightly." }
            isReal(definition.waterTemp, { (unitless) : [0, 20, 35] } as RealBoundSpec);

            annotation { "Name" : "Wing depth",
                         "Description" : "Depth of the front wing below the surface. Limits 100-3000 mm. Typical 400-800 mm when riding. Used for the cavitation number and a free-surface warning: below about 2 MAC the surface causes lift loss and wave drag that are not modelled." }
            isLength(definition.depth, { (millimeter) : [100, 600, 3000] } as LengthBoundSpec);
        }

        annotation { "Group Name" : "Speeds", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Take-off km/h",
                         "Description" : "Speed at which you want to be foiling. Limits 3-60 km/h. Typical 8-12 pump/SUP, 12-16 eFoil/surf, 12-18 wind, 15-25 kite race. The notice shows how close to stall the wing is here." }
            isReal(definition.vTakeoff, { (unitless) : [3, 15, 60] } as RealBoundSpec);

            annotation { "Name" : "Cruise km/h",
                         "Description" : "Main operating speed; headline L/D, drag, power, trim and structure are reported here. Limits 4-80 km/h. Typical 12-18 pump/downwind, 18-25 eFoil/wind, 30-45 kite race." }
            isReal(definition.vCruise, { (unitless) : [4, 20, 80] } as RealBoundSpec);

            annotation { "Name" : "Max km/h",
                         "Description" : "Top of the analysed range, used for the cavitation check. Limits 5-100 km/h. Typical 25-35 eFoil/wind, 45-70 kite race." }
            isReal(definition.vMax, { (unitless) : [5, 30, 100] } as RealBoundSpec);

            annotation { "Name" : "Step km/h",
                         "Description" : "Speed step for the CSV sweep printed to the FeatureScript console, from take-off to max speed. Limits 0.5-5 km/h. Typical 1 km/h." }
            isReal(definition.vStep, { (unitless) : [0.5, 1, 5] } as RealBoundSpec);
        }

        annotation { "Group Name" : "Section and drag model", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Section CL max",
                         "Description" : "Maximum lift coefficient of the section. Used only when the wing's Section polar (in Foil wing) is set to Analytic - if it is set to Polar summary, the polar's own CLmax (interpolated at the take-off Reynolds number) is used instead and this field is ignored. Limits 0.6-1.8. Typical 1.0-1.2 for 8-10 % thick low-camber sections, 1.2-1.4 for 12 % with 2-3 % camber, 1.4-1.6 for 14 % with 4 % camber. Real values drop at low Reynolds number. Local lift in the outer 5 % of span is ignored." }
            isReal(definition.clMax, { (unitless) : [0.6, 1, 1.8] } as RealBoundSpec);

            annotation { "Name" : "Laminar run %",
                         "Description" : "Portion of the chord in laminar flow before transition. Limits 0-60 %. Typical 0-20 % for molded carbon parts. 0 = fully turbulent (conservative; realistic for a hand-finished or scratched surface). 20-40 % for a smooth, fair finish on a NACA 4-digit; 50-60 % only for laminar sections with a polished finish." }
            isReal(definition.laminar, { (unitless) : [0, 0, 60] } as RealBoundSpec);

            annotation { "Name" : "Other cm^2",
                         "Description" : "Extra drag area (Cd x area) in cm^2 for anything NOT modelled. Limits 0-200. Typical 1-4 cm^2. The mast (submerged part + spray), motor pod and fuselage are now computed from the Foil mast and Foil fuselage features, so do not include them here; use this for junctions, the wing socket nacelle, fittings and bolt heads." }
            isReal(definition.otherDrag, { (unitless) : [0, 0, 200] } as RealBoundSpec);
        }

        annotation { "Group Name" : "Structure", "Collapsed By Default" : true }
        {
            annotation { "Name" : "Load factor g",
                         "Description" : "Multiple of the cruise wing lift used for the root bending check. Limits 1-8. Typical 3 for general riding, 4-5 for pumping, jumps and hard landings, 6+ for kite freestyle." }
            isReal(definition.loadFactor, { (unitless) : [1, 3, 8] } as RealBoundSpec);

            annotation { "Name" : "Cap stress MPa",
                         "Description" : "Allowable stress in the unidirectional carbon spar caps, MPa. Limits 100-1500. Typical 300-500 for wet-laid UD carbon with a safety factor (compression governs, roughly half the tensile strength), 600-900 for prepreg. Lower = more conservative." }
            isReal(definition.capStress, { (unitless) : [100, 450, 1500] } as RealBoundSpec);

            annotation { "Name" : "Cap width %",
                         "Description" : "Width of each spar cap as % of root chord. Limits 10-70 %. Typical 25-40 %. Wider caps can be thinner for the same strength." }
            isReal(definition.capWidth, { (unitless) : [10, 35, 70] } as RealBoundSpec);
        }

        annotation { "Group Name" : "Propulsion", "Collapsed By Default" : true }
        {
            annotation { "Name" : "Propulsion", "Default" : false,
                         "Description" : "eFoil / foil-assist drivetrain. At steady speed prop thrust equals foil drag, so from the drag at each speed this finds the prop rpm (Wageningen B-series open-water KT/KQ, the same polynomials as the B-series blade feature), then motor current, throttle, battery power, Wh/km, range, top speed, and the thrust/drag couple in trim (thrust on the pod axis). Off for pump, SUP, surf, wing, wind and kite. Open-water estimate, about +/- 20 %: no pod or mast wake, no free surface, no cavitation or ventilation." }
            definition.propOn is boolean;

            if (definition.propOn)
            {
                annotation { "Name" : "Prop dia",
                             "Description" : "Propeller diameter. Limits 60-400 mm. Typical 120-160 mm for eFoil, 100-140 mm for foil assist. The prop axis is taken as the motor pod axis for the immersion check. Bigger turns slower and more efficiently but needs more depth to stay submerged." }
                isLength(definition.propDia, { (millimeter) : [60, 140, 400] } as LengthBoundSpec);

                annotation { "Name" : "Prop P/D",
                             "Description" : "Pitch / diameter at 0.7R. Limits 0.5-1.4 (the B-series fitted range). Typical 0.8-1.0 for eFoil. Higher pitch raises top speed and cruise efficiency, lower pitch gives more static thrust. Top speed is roughly pitch x no-load rpm less slip." }
                isReal(definition.propPD, { (unitless) : [0.5, 0.8, 1.4] } as RealBoundSpec);

                annotation { "Name" : "Prop EAR",
                             "Description" : "Expanded blade area ratio. Limits 0.3-1.05 (the B-series fitted range). Typical 0.3-0.55 for eFoil. More area spreads the load (less cavitation) but adds blade friction." }
                isReal(definition.propEAR, { (unitless) : [0.3, 0.3, 1.05] } as RealBoundSpec);

                annotation { "Name" : "Blades",
                             "Description" : "Number of blades. Limits 2-7 (the B-series fitted range). Typical 2-3 for eFoil." }
                isInteger(definition.propBlades, { (unitless) : [2, 3, 7] } as IntegerBoundSpec);

                annotation { "Name" : "Motor kV",
                             "Description" : "Motor speed constant, rpm per volt at no load. Limits 50-1000. Typical 150-500 for eFoil outrunners, geared or direct. Torque per amp is taken as 8.27 / kV N m (same as the blade feature)." }
                isReal(definition.motorKv, { (unitless) : [50, 450, 1000] } as RealBoundSpec);

                annotation { "Name" : "Cells (S)",
                             "Description" : "Lithium cells in series; pack voltage = cells x 3.7 V nominal. Limits 1-30. Typical 10-14 S for eFoil (12 S = 44.4 V)." }
                isInteger(definition.cells, { (unitless) : [1, 12, 30] } as IntegerBoundSpec);

                annotation { "Name" : "Gear ratio",
                             "Description" : "Motor turns per prop turn. Limits 1-10. Typical 1 (direct drive) or 3-5 for a geared outrunner. Higher gives more prop torque, less prop rpm." }
                isReal(definition.gearRatio, { (unitless) : [1, 4, 10] } as RealBoundSpec);

                annotation { "Name" : "Current lim A",
                             "Description" : "Motor current limit set in the ESC, A. Limits 1-600. Typical 80-150 A for eFoil. Sets the full-power torque, so the static thrust and the top speed." }
                isReal(definition.currentLimit, { (unitless) : [1, 120, 600] } as RealBoundSpec);

                annotation { "Name" : "Winding mOhm",
                             "Description" : "Motor winding (phase) resistance, milliohm. Limits 0-500. Typical 5-40 for eFoil motors; 12 matches the B-series blade feature's check of a 450 kV 12 S drive. Near no-load rpm it caps the current the pack voltage can push. 0 = ignore (optimistic top speed)." }
                isReal(definition.windingR, { (unitless) : [0, 12, 500] } as RealBoundSpec);

                annotation { "Name" : "Gearbox eff %",
                             "Description" : "Gearbox efficiency, %. Limits 80-100. Typical 95 for one planetary stage, 100 for direct drive. The blade feature ignores gear loss, so set 100 to compare with its numbers." }
                isReal(definition.gearEff, { (unitless) : [80, 95, 100] } as RealBoundSpec);

                annotation { "Name" : "ESC eff %",
                             "Description" : "ESC efficiency, %. Limits 80-100. Typical 95-98. Motor losses are already in the 8.27 / kV torque constant and the winding resistance." }
                isReal(definition.escEff, { (unitless) : [80, 97, 100] } as RealBoundSpec);

                annotation { "Name" : "Pack Ah",
                             "Description" : "Battery pack capacity, amp hours. Limits 1-100. Typical 12-30 Ah for eFoil. With Cells (S) x 3.7 V and Usable % this sets the range." }
                isReal(definition.packAh, { (unitless) : [1, 20, 100] } as RealBoundSpec);

                annotation { "Name" : "Usable %",
                             "Description" : "Share of the nameplate pack energy you actually use before cut-off or voltage sag ends the ride, %. Limits 50-100. Typical 80-90." }
                isReal(definition.usable, { (unitless) : [50, 90, 100] } as RealBoundSpec);
            }
        }

        annotation { "Name" : "Print report", "Default" : true,
                     "Description" : "Prints the full report and a CSV speed sweep to the FeatureScript console, ready to paste into a spreadsheet." }
        definition.printReport is boolean;
    }
    {
        // ---------------- inputs ----------------
        var wing;
        var stab;
        try silent { wing = getVariable(context, "foilWingModel"); }
        try silent { stab = getVariable(context, "foilStabModel"); }
        var mastM;
        var fusM;
        try silent { mastM = getVariable(context, "foilMastModel"); }
        try silent { fusM = getVariable(context, "foilFuselageModel"); }
        if (wing == undefined)
            throw regenError("Add a Foil wing feature above this one");
        if (!(definition.vTakeoff < definition.vCruise && definition.vCruise < definition.vMax))
            throw regenError("Speeds must increase: take-off < cruise < max", ["vTakeoff", "vCruise", "vMax"]);

        const g = 9.80665;
        const rho = definition.density;
        const T = definition.waterTemp;
        const nu = waterViscosity(T, rho);
        const W = definition.mass * g;

        // ---------------- aerodynamic model ----------------
        // each surface's own lift-curve slope: the polar value if it has one, else the shared
        // thin-aerofoil default (2 pi with a viscous allowance) - previously both surfaces were
        // forced to share one fixed slope regardless of section
        const Lw = liftingLine(wing, wing.claSection, 20);
        var ctx = {
                "rho" : rho, "nu" : nu, "W" : W, "lam" : definition.laminar / 100,
                "cdA" : definition.otherDrag / 10000, "Mext" : definition.extMoment,
                "wing" : wing, "Lw" : Lw, "xw" : acX(wing), "cd0Shape_w" : formFactor(meanThickness(wing)) * wing.wetted / wing.area,
                "ke" : 2 / (PI * Lw.AR), "hasStab" : stab != undefined,
                "powered" : false, "thrustZ" : 0, "stabZ" : stab != undefined ? stab.baseZ : 0, "fusZ" : 0,
                "podX" : 0, "podTilt" : 0
            };
        if (ctx.hasStab)
        {
            const Ls = liftingLine(stab, stab.claSection, 20);
            ctx.stab = stab;
            ctx.Ls = Ls;
            ctx.xs = acX(stab);
            ctx.cd0Shape_s = formFactor(meanThickness(stab)) * stab.wetted / stab.area;
            ctx.C1 = Ls.CL0 - Ls.CLa * ctx.ke * Lw.CL0;
            ctx.C2 = Ls.CLa * (1 - ctx.ke * Lw.CLa);
        }
        else
        {
            ctx.C1 = 0;
            ctx.C2 = 0;
            ctx.xs = 0;
        }
        // mast, motor pod and fuselage drag. The wing is Wing depth below the surface (surface at
        // Z = +depth in the wing-pivot frame), so only the mast between its base and the surface is
        // wetted; spray drag where it pierces the surface. Drag only - their pitching moments are
        // not added to trim (the balancing thrust/pull line depends on the discipline).
        const depthM = definition.depth / meter;
        ctx.mastOn = mastM != undefined;
        if (ctx.mastOn)
        {
            // the section where the mast is wetted: at half the submerged height (taper / thickening)
            const sMid = mastM.chordTop != undefined ? min(max((depthM / 2) / mastM.height, 0), 1) : 0;
            ctx.mastC = mastM.chordTop != undefined ? mastM.chord + (mastM.chordTop - mastM.chord) * sMid : mastM.chord;
            const uT = mastM.chordTop != undefined && mastM.thickenFrom < 1 ? min(max((sMid - mastM.thickenFrom) / (1 - mastM.thickenFrom), 0), 1) : 0;
            ctx.mastT = mastM.chordTop != undefined ? mastM.thick + (mastM.thickTop - mastM.thick) * uT * uT * (3 - 2 * uT) : mastM.thick;
            ctx.mastFF = formFactor(ctx.mastT / ctx.mastC);
            ctx.mastBase = mastM.baseZ;
            ctx.mastH = mastM.height;
            ctx.podOn = mastM.podOn == 1;
            if (ctx.podOn)
            {
                ctx.podL = mastM.podLength;
                ctx.podD = mastM.podDia;
                ctx.podZ = mastM.podZ;
                ctx.podX = mastM.podX;
                ctx.podTilt = mastM.podTilt != undefined ? mastM.podTilt : 0;      // rad, nose-down positive
                ctx.podSwet = PI * mastM.podDia * (mastM.podLength - 0.5 * mastM.podFairLength);
            }
        }
        else
            ctx.podOn = false;
        ctx = rideDepth(ctx, depthM);
        ctx.fusOn = fusM != undefined && fusM.len != undefined;
        if (ctx.fusOn)
        {
            ctx.fusL = fusM.len;
            ctx.fusD = fusM.dia;
            ctx.fusSwet = fusM.wettedExt;
            ctx.fusZ = fusM.axisZ != undefined ? fusM.axisZ : 0;
        }

        const Sw = wing.area;
        const Ss = ctx.hasStab ? stab.area : 0;
        const xnp = (Sw * Lw.CLa * ctx.xw + Ss * ctx.C2 * ctx.xs) / (Sw * Lw.CLa + Ss * ctx.C2);

        // ---------------- operating points ----------------
        const pTo = trimPoint(ctx, definition.vTakeoff / 3.6);
        const pCr = trimPoint(ctx, definition.vCruise / 3.6);
        const pMx = trimPoint(ctx, definition.vMax / 3.6);

        // motor pod layout, set by Pod height. Low pod = eFoil: the motor is in the water at every depth
        // the wing can ride. High pod = foil assist: the rider picks the mode by ride depth - deep, the
        // motor is in the water and drives; shallow, the pod is out and the foil is ridden on pumping
        // or wave energy. Pod out = surface 10 mm below the pod's bottom; pod in = 10 mm above its top.
        // Pod out only counts as a real mode if the wing can still ride there: at least 2 MAC deep,
        // the same free-surface limit as the Wing depth check. Each mode is solved at its own depth.
        // with Propulsion on, "in" and "out" also cover the prop disc (its axis on the pod axis)
        const propOn = definition.propOn;
        const pr = propOn ? propModel(definition, rho) : undefined;
        var assist = undefined;
        if (ctx.podOn)
        {
            const rP = propOn ? max(ctx.podD, pr.D) / 2 : ctx.podD / 2;
            const dOut = ctx.podZ - rP - 0.01;
            const dIn = ctx.podZ + rP + 0.01;
            const minOut = 2 * wing.mac;
            assist = { "dOut" : dOut, "dIn" : dIn, "minOut" : minOut,
                       "outOk" : dOut >= minOut, "inOk" : dIn - ctx.mastBase < ctx.mastH };
            if (assist.outOk)
                assist.pOut = trimPoint(rideDepth(ctx, dOut), definition.vCruise / 3.6);
            if (assist.inOk)
                assist.pIn = trimPoint(rideDepth(ctx, dIn), definition.vCruise / 3.6);
        }

        // propulsion: solved at the powered ride depth - Wing depth if the prop is fully under
        // water there, else the pod-in depth (foil assist), else not at all
        var pctx = undefined;
        var pDepth = depthM;
        var propCr = undefined;
        var vTop = -1;
        var fullStatic = undefined;
        var pPw = undefined;            // powered cruise point (thrust couple in trim)
        var smPwMin = 1e9;              // lowest powered static margin over take-off..max, % MAC
        var smPwMinV = 0;
        if (propOn)
        {
            if (!ctx.podOn)
                pctx = ctx;
            else if (depthM >= ctx.podZ + max(ctx.podD, pr.D) / 2)
                pctx = ctx;
            else if (assist.inOk)
            {
                pDepth = assist.dIn;
                pctx = rideDepth(ctx, pDepth);
            }
            if (pctx != undefined)
            {
                // the thrust line is the pod axis; with no pod its height is unknown, so no couple
                if (ctx.podOn)
                {
                    pctx.powered = true;
                    pctx.thrustZ = ctx.podZ;
                }
                const Vc = definition.vCruise / 3.6;
                pPw = trimPoint(pctx, Vc);
                const Tc = pPw.T;
                propCr = propOperate(pr, Vc, Tc);
                propCr.T = Tc;
                vTop = propTopSpeed(pr, pctx, definition.vTakeoff);
                fullStatic = propFullPower(pr, 0);
                if (ctx.hasStab && pctx.powered)
                {
                    var vs = definition.vTakeoff;
                    while (vs <= definition.vMax + 1e-9)
                    {
                        const sm = (xnp - trimPoint(pctx, vs / 3.6).xcg) / wing.mac * 100;
                        if (sm < smPwMin)
                        {
                            smPwMin = sm;
                            smPwMinV = vs;
                        }
                        vs += definition.vStep;
                    }
                }
            }
        }

        // wing section CL max: the polar value interpolated at the take-off Reynolds number if
        // the wing has a polar (stall genuinely happens near take-off, so that Re is the one
        // that matters most), else the flat analytic input
        const clMaxWing = wing.polarOn == 1
            ? polarInterp(wing.polarRe1, wing.polarClmax1, wing.polarRe2, wing.polarClmax2, pTo.Re)
            : definition.clMax;
        // the tip section's own CL max at the same Re (build 166); the root's when there is no tip section
        const clMaxTip = wing.polarOn == 1 && wing.tipOn == 1
            ? polarInterp(wing.polarRe1, wing.polarClmax1Tip, wing.polarRe2, wing.polarClmax2Tip, pTo.Re)
            : clMaxWing;

        // stall: first section to reach ITS CL max, then the speed that needs that alpha
        const aStall = stallAlpha(wing, Lw, clMaxWing, clMaxTip);
        const liftCoefAtStall = Sw * (Lw.CL0 + Lw.CLa * aStall) + Ss * (ctx.C1 + ctx.C2 * aStall);
        const vStall = (aStall < 1e8 && liftCoefAtStall > 0) ? sqrt(2 * W / (rho * liftCoefAtStall)) : -1;
        const toMargin = maxLocalClRatio(wing, Lw, pTo.alpha, clMaxWing, clMaxTip);

        // cavitation number at max speed
        const pv = 610.94 * exp(17.625 * T / (T + 243.04));
        const depth = definition.depth / meter;
        const sigma = (101325 + rho * g * depth - pv) / (0.5 * rho * (definition.vMax / 3.6) ^ 2);

        // root bending at cruise lift x load factor
        const halfLift = 0.5 * rho * (definition.vCruise / 3.6) ^ 2 * Sw * pCr.CLw / 2;
        const yBar = lltCentroid(Lw, pCr.alpha) * wing.span / 2;
        const Mroot = definition.loadFactor * halfLift * yBar;
        const hRoot = wing.rootT * wing.c0;
        const capW = definition.capWidth / 100 * wing.c0;
        const disc = hRoot ^ 2 - 4 * Mroot / (definition.capStress * 1e6 * capW);
        const tCap = disc > 0 ? (hRoot - sqrt(disc)) / 2 : -1;
        // bending moment along the half span at the load factor, for the Foil mold's stiffness check
        // (it has the layup; this has the loads). Stab: its cruise lift, or 15 % of the weight if
        // that is larger (a pump or a gust loads it far beyond level trim), same load factor
        setVariable(context, "foilWingLoads", { "n" : definition.loadFactor, "W" : W, "span" : wing.span,
                    "M" : lltMoments(Lw, pCr.alpha, wing.span, definition.loadFactor * halfLift) });
        if (ctx.hasStab)
        {
            const halfLiftS = max(abs(0.5 * rho * (definition.vCruise / 3.6) ^ 2 * Ss * pCr.CLs), 0.15 * W) / 2;
            setVariable(context, "foilStabLoads", { "n" : definition.loadFactor, "W" : W, "span" : stab.span,
                        "M" : lltMoments(ctx.Ls, pCr.alpha, stab.span, definition.loadFactor * halfLiftS) });
        }

        // ---------------- notice ----------------
        const macW = wing.mac;
        var msg = "Cruise " ~ fmt(definition.vCruise, 0) ~ " km/h: L/D " ~ fmt(pCr.LD, 1) ~
            " · drag " ~ fmt(pCr.D, 0) ~ " N (mast " ~ fmt(pCr.Dmast, 1) ~ ", fuselage/pod " ~ fmt(pCr.Dbody, 1) ~ ") · " ~ fmt(pCr.P, 0) ~ " W" ~
            " | stall " ~ (vStall > 0 ? fmt(vStall * 3.6, 1) ~ " km/h" : "n/a") ~ (wing.polarOn == 1 ? " (polar)" : "") ~
            " | take-off at " ~ fmt(toMargin * 100, 0) ~ "% of CL max" ~
            (ctx.hasStab ? " | trim CG " ~ fmt(pCr.xcg * 1000, 0) ~ " mm · static margin " ~ fmt((xnp - pCr.xcg) / macW * 100, 0) ~ "% MAC" : " | no stabiliser: trim not solved") ~
            " | root " ~ fmt(Mroot, 0) ~ " Nm at " ~ fmt(definition.loadFactor, 1) ~ "g, caps " ~ (tCap > 0 ? fmt(tCap * 1000, 1) ~ " mm" : "impossible (section too thin)");
        var warnings = [];
        if (toMargin >= 1)
            warnings = append(warnings, "wing stalls at take-off speed");
        else if (toMargin > 0.85)
            warnings = append(warnings, "take-off within 15% of stall");
        if (ctx.hasStab && (abs(pTo.CLs) > 0.8 || abs(pMx.CLs) > 0.8))
            warnings = append(warnings, "stab CL above 0.8 in range");
        if (sigma < 1.5)
            warnings = append(warnings, "cavitation number " ~ fmt(sigma, 2) ~ " at max speed - check section Cp min");
        if (depth / macW < 2)
            warnings = append(warnings, "depth under 2 MAC - free-surface effects not modelled");
        if (!ctx.mastOn)
            warnings = append(warnings, "no Foil mast above this feature - mast drag not included (move Foil performance below the mast, or use Other cm^2)");
        else if (!ctx.mastPierces)
            warnings = append(warnings, "the whole mast is under water at this Wing depth - the board would be submerged; check Wing depth");
        if (assist != undefined && !assist.inOk)
            warnings = append(warnings, "the motor pod cannot be fully submerged without the board going under, so the motor can never drive - lower Pod height (Foil mast)");
        if (assist != undefined)
        {
            const podState = ctx.podFrac >= 1 ? "in the water" : (ctx.podFrac <= 0 ? "out of the water" : fmt(ctx.podFrac * 100, 0) ~ "% in the water (transition)");
            if (assist.outOk)
            {
                msg = msg ~ " | foil assist: pod " ~ podState ~ " at this depth";
                if (assist.inOk)
                    msg = msg ~ "; motor mode at >= " ~ fmt(assist.dIn * 1000, 0) ~ " mm: L/D " ~ fmt(assist.pIn.LD, 1) ~ ", drag (= thrust) " ~ fmt(assist.pIn.D, 0) ~ " N";
                msg = msg ~ "; pump/wave mode at <= " ~ fmt(assist.dOut * 1000, 0) ~ " mm: L/D " ~ fmt(assist.pOut.LD, 1) ~ ", drag " ~ fmt(assist.pOut.D, 0) ~ " N, " ~
                    fmt(assist.pOut.P, 0) ~ " W to sustain";
            }
            else
                msg = msg ~ " | eFoil layout: pod " ~ podState ~ " at this depth" ~ (assist.inOk ? ", fully in at >= " ~ fmt(assist.dIn * 1000, 0) ~ " mm" : "");
        }
        if (propOn)
        {
            if (pctx == undefined)
                warnings = append(warnings, "Propulsion: the prop cannot be fully submerged without the board going under - lower Pod height (Foil mast) or use a smaller Prop dia");
            else
            {
                msg = msg ~ " | prop at " ~ fmt(definition.vCruise, 0) ~ " km/h" ~ (pDepth != depthM ? " (pod in, " ~ fmt(pDepth * 1000, 0) ~ " mm)" : "") ~ ": " ~
                    fmt(propCr.rpm, 0) ~ " rpm, " ~ fmt(propCr.throttle * 100, 0) ~ "% throttle, " ~ fmt(propCr.pBatt, 0) ~ " W battery, " ~
                    fmt(propCr.whKm, 1) ~ " Wh/km, range " ~ fmt(propCr.range, 0) ~ " km · top speed " ~
                    (vTop < 0 ? "over 100 km/h" : (vTop == 0 ? "below take-off" : fmt(vTop, 1) ~ " km/h"));
                if (pctx.powered && ctx.hasStab)
                    msg = msg ~ " · under power: thrust couple " ~ fmt(pPw.Mthrust, 1) ~ " Nm, trim CG " ~ fmt(pPw.xcg * 1000, 0) ~ " mm (" ~
                        (pPw.xcg >= pCr.xcg ? "+" : "") ~ fmt((pPw.xcg - pCr.xcg) * 1000, 0) ~ "), static margin " ~ fmt((xnp - pPw.xcg) / macW * 100, 0) ~ "% MAC";
                if (smPwMin < 0)
                    warnings = append(warnings, "Propulsion: pitch-unstable under power at " ~ fmt(smPwMinV, 1) ~ " km/h (static margin " ~ fmt(smPwMin, 0) ~
                        "% MAC - the thrust couple puts the trim CG behind the neutral point). Lower Pod height (Foil mast) to bring the thrust line down, or add stab area / Arm");
                else if (smPwMin < 5)
                    warnings = append(warnings, "Propulsion: static margin under power only " ~ fmt(smPwMin, 0) ~ "% MAC at " ~ fmt(smPwMinV, 1) ~ " km/h - lower Pod height or add stab area / Arm");
                if (vTop == 0)
                    warnings = append(warnings, "Propulsion: full power cannot hold take-off speed - raise Current lim A, Gear ratio or Prop dia");
                if (propCr.iMotor > pr.iLim)
                    warnings = append(warnings, "Propulsion: cruise needs " ~ fmt(propCr.iMotor, 0) ~ " A, over the " ~ fmt(pr.iLim, 0) ~ " A limit - raise Current lim A or Gear ratio, or lower Prop P/D");
                if (propCr.throttle > 1)
                    warnings = append(warnings, "Propulsion: cruise needs " ~ fmt(propCr.throttle * 100, 0) ~ "% throttle (the motor cannot spin the prop fast enough) - raise Prop P/D or Cells (S), or lower Gear ratio");
            }
        }
        if (!ctx.fusOn)
            warnings = append(warnings, "no Foil fuselage above this feature - fuselage drag not included (move Foil performance below the fuselage, or use Other cm^2)");
        if (wing.polarOn == 1 && polarOutOfRange(wing, [pTo.Re, pCr.Re, pMx.Re]))
            warnings = append(warnings, "wing polar used outside its own Re 1-Re 2 range at some speed - CLmax/Cd there are extrapolated flat, not interpolated");
        if (ctx.hasStab && stab.polarOn == 1 && polarOutOfRange(stab, [pTo.Re * stab.mac / wing.mac, pCr.Re * stab.mac / wing.mac, pMx.Re * stab.mac / wing.mac]))
            warnings = append(warnings, "stab polar used outside its own Re 1-Re 2 range at some speed - CLmax/Cd there are extrapolated flat, not interpolated");
        if (size(warnings) > 0)
        {
            var w = "";
            for (var s in warnings)
                w = w ~ (w == "" ? "" : "; ") ~ s;
            reportFeatureWarning(context, id, msg ~ " | WARNING: " ~ w);
        }
        else
            reportFeatureInfo(context, id, msg);

        setVariable(context, "foilCruiseLD", pCr.LD);
        setVariable(context, "foilCruiseDrag", pCr.D);
        setVariable(context, "foilCruisePower", pCr.P);
        setVariable(context, "foilStallSpeed", vStall * 3.6);
        setVariable(context, "foilRootMoment", Mroot);
        if (propCr != undefined)
        {
            setVariable(context, "foilCruiseBatteryPower", propCr.pBatt);
            setVariable(context, "foilCruiseWhPerKm", propCr.whKm);
            setVariable(context, "foilRangeKm", propCr.range);
            setVariable(context, "foilTopSpeed", vTop);
            if (pctx.powered)
                setVariable(context, "foilPoweredTrimCG", pPw.xcg * 1000);   // mm aft of the wing root pivot
        }

        // ---------------- console report ----------------
        if (definition.printReport)
        {
            println("===== FOIL PERFORMANCE =====");
            println(perfInputLog(definition));
            println("Water: rho " ~ fmt(rho, 0) ~ " kg/m3, nu " ~ fmt(nu * 1e6, 3) ~ "e-6 m2/s, mass " ~ fmt(definition.mass, 0) ~ " kg");
            println("Wing: S " ~ fmt(Sw * 1e4, 0) ~ " cm2, AR " ~ fmt(Lw.AR, 2) ~ ", CLa " ~ fmt(Lw.CLa, 3) ~ "/rad, CL0 " ~ fmt(Lw.CL0, 3) ~
                ", span efficiency e " ~ fmt(spanEfficiency(Lw), 3) ~ ", Cm0 " ~ fmt(wing.cm0, 4) ~ ", ac " ~ fmt(ctx.xw * 1000, 1) ~ " mm");
            if (ctx.hasStab)
            {
                println("Stab: S " ~ fmt(Ss * 1e4, 0) ~ " cm2, AR " ~ fmt(ctx.Ls.AR, 2) ~ ", CLa " ~ fmt(ctx.Ls.CLa, 3) ~ "/rad, CL0 " ~ fmt(ctx.Ls.CL0, 3) ~
                    ", ac " ~ fmt(ctx.xs * 1000, 1) ~ " mm, downwash de/da " ~ fmt(ctx.ke * Lw.CLa, 3));
                println("Neutral point " ~ fmt(xnp * 1000, 1) ~ " mm aft of wing root pivot");
            }
            println("Stall " ~ (vStall > 0 ? fmt(vStall * 3.6, 1) ~ " km/h" : "n/a") ~ " (section CL max " ~ fmt(clMaxWing, 2) ~ (wing.tipOn == 1 ? " root, " ~ fmt(clMaxTip, 2) ~ " tip" : "") ~
                (wing.polarOn == 1 ? " from polar at Re " ~ fmt(pTo.Re / 1e6, 2) ~ "M" : " analytic") ~ ")");
            println("Cavitation number at " ~ fmt(definition.vMax, 0) ~ " km/h, depth " ~ fmt(depth * 1000, 0) ~ " mm: " ~ fmt(sigma, 2) ~ " (cavitation starts where -Cp min exceeds this)");
            if (ctx.mastOn)
                println("Mast: " ~ fmt(ctx.mastSub * 1000, 0) ~ " mm of " ~ fmt(mastM.height * 1000, 0) ~ " mm submerged at this depth, chord " ~ fmt(ctx.mastC * 1000, 0) ~
                    " mm, t/c " ~ fmt(mastM.tc * 100, 1) ~ "%, at cruise " ~ fmt(pCr.Dmast, 1) ~ " N incl. spray " ~ fmt(pCr.Dspray, 2) ~ " N" ~
                    (ctx.podOn ? "; motor pod " ~ fmt(ctx.podD * 1000, 0) ~ " x " ~ fmt(ctx.podL * 1000, 0) ~ " mm, " ~ fmt(ctx.podFrac * 100, 0) ~ "% under water" ~
                        (pCr.DpodSpray > 0 ? ", pod spray " ~ fmt(pCr.DpodSpray, 2) ~ " N (in fuselage/pod drag)" : "") : ""));
            if (assist != undefined)
            {
                if (assist.outOk)
                {
                    println("Layout: foil assist - motor mode when ridden deep, pump/wave mode when ridden shallow with the pod out");
                    println("  pump/wave mode (pod OUT, wing depth <= " ~ fmt(assist.dOut * 1000, 0) ~ " mm): cruise drag " ~ fmt(assist.pOut.D, 1) ~ " N, L/D " ~ fmt(assist.pOut.LD, 2) ~
                        ", " ~ fmt(assist.pOut.P, 0) ~ " W to sustain from pumping or the wave, mast " ~ fmt(assist.pOut.Dmast, 1) ~ " N");
                }
                else
                    println("Layout: eFoil - the pod would only clear the water with the wing at " ~ fmt(assist.dOut * 1000, 0) ~ " mm, under the " ~ fmt(assist.minOut * 1000, 0) ~
                        " mm (2 MAC) it needs to ride; raise Pod height by at least " ~ fmt((assist.minOut - assist.dOut) * 1000, 0) ~ " mm for a foil-assist layout");
                if (assist.inOk)
                    println("  " ~ (assist.outOk ? "motor mode" : "motor") ~ " (pod IN, wing depth >= " ~ fmt(assist.dIn * 1000, 0) ~ " mm): cruise drag = thrust needed " ~ fmt(assist.pIn.D, 1) ~ " N, L/D " ~ fmt(assist.pIn.LD, 2) ~
                        ", power at the prop " ~ fmt(assist.pIn.P, 0) ~ " W, mast " ~ fmt(assist.pIn.Dmast, 1) ~ " N, fuselage/pod " ~ fmt(assist.pIn.Dbody, 1) ~ " N");
            }
            if (ctx.fusOn)
                println("Fuselage: " ~ fmt(ctx.fusL * 1000, 0) ~ " mm long, " ~ fmt(ctx.fusD * 1000, 1) ~ " mm dia, wetted " ~ fmt(ctx.fusSwet * 1e4, 0) ~
                    " cm2, fuselage + pod at cruise " ~ fmt(pCr.Dbody, 1) ~ " N");
            println("Root bending at " ~ fmt(definition.loadFactor, 1) ~ "g: " ~ fmt(Mroot, 0) ~ " Nm, lift centroid " ~ fmt(yBar * 1000, 0) ~ " mm from centreline, section depth " ~
                fmt(hRoot * 1000, 1) ~ " mm, cap width " ~ fmt(capW * 1000, 0) ~ " mm -> cap thickness " ~ (tCap > 0 ? fmt(tCap * 1000, 2) ~ " mm each" : "not achievable"));
            if (propCr != undefined)
            {
                println("Propulsion (B-series open water, +/- 20 %): prop " ~ fmt(pr.D * 1000, 0) ~ " mm, P/D " ~ fmt(pr.pd, 2) ~ ", EAR " ~ fmt(pr.ear, 2) ~ ", " ~ pr.z ~
                    " blades; " ~ fmt(pr.kv, 0) ~ " kV, " ~ definition.cells ~ "S (" ~ fmt(pr.vPack, 1) ~ " V), gear " ~ fmt(pr.gear, 2) ~ ":1, limit " ~ fmt(pr.iLim, 0) ~
                    " A, winding " ~ fmt(pr.R * 1000, 1) ~ " mOhm; pack " ~ fmt(pr.packWh, 0) ~ " Wh usable");
                println("  solved at ride depth " ~ fmt(pDepth * 1000, 0) ~ " mm" ~ (pDepth != depthM ? " (pod-in depth: the prop is not fully under water at Wing depth)" : "") ~
                    (ctx.podOn ? "" : " - no motor pod on Foil mast, so prop immersion is not checked"));
                println("  static, full power: " ~ fmt(fullStatic.n * 60, 0) ~ " prop rpm, " ~ fmt(fullStatic.T, 0) ~ " N (" ~ fmt(fullStatic.T / g, 1) ~ " kgf) thrust; no-load prop speed " ~
                    fmt(pr.nNoLoad * 60, 0) ~ " rpm, pitch speed " ~ fmt(pr.pd * pr.D * pr.nNoLoad * 3.6, 1) ~ " km/h");
                println("  cruise " ~ fmt(definition.vCruise, 1) ~ " km/h: thrust = drag " ~ fmt(propCr.T, 1) ~ " N (" ~ fmt(propCr.T / g, 2) ~ " kgf), " ~ fmt(propCr.rpm, 0) ~
                    " prop rpm, J " ~ fmt(propCr.J, 2) ~ ", prop efficiency " ~ fmt(propCr.eta0 * 100, 0) ~ "%, shaft " ~ fmt(propCr.Pshaft, 0) ~ " W, motor " ~ fmt(propCr.iMotor, 1) ~
                    " A, throttle " ~ fmt(propCr.throttle * 100, 0) ~ "%, battery " ~ fmt(propCr.iBatt, 1) ~ " A / " ~ fmt(propCr.pBatt, 0) ~ " W, overall " ~
                    fmt(propCr.T * definition.vCruise / 3.6 / propCr.pBatt * 100, 0) ~ "%");
                println("  " ~ fmt(propCr.whKm, 1) ~ " Wh/km, range " ~ fmt(propCr.range, 1) ~ " km / " ~ fmt(propCr.range / definition.vCruise * 60, 0) ~ " min powered at cruise" ~
                    (assist != undefined && assist.outOk ? " (pump/wave riding with the pod out draws nothing, so a mixed session goes further)" : "") ~ "; top speed " ~
                    (vTop < 0 ? "over 100 km/h" : (vTop == 0 ? "below take-off (full power cannot hold it)" : fmt(vTop, 1) ~ " km/h (full-power thrust = drag)")));
                if (pctx.powered)
                {
                    println("  thrust vector: pod tilt " ~ fmt(ctx.podTilt * 180 / PI, 1) ~ " deg nose-down, so at cruise it points " ~ fmt(pPw.thrustAngle, 1) ~
                        " deg to the flow (" ~ fmt(pPw.Tz, 1) ~ " N vertical at the pod, " ~ fmt(-pPw.Tz * ctx.podX, 1) ~ " Nm about the pivot); at take-off " ~
                        fmt(trimPoint(pctx, definition.vTakeoff / 3.6).thrustAngle, 1) ~ " deg, " ~ fmt(trimPoint(pctx, definition.vTakeoff / 3.6).Tz, 1) ~ " N");
                    println("  thrust line at the pod axis, Z " ~ fmt(ctx.podZ * 1000, 0) ~ " mm; drag centroid at cruise Z " ~ fmt((pPw.Mthrust + pPw.D * ctx.podZ) / pPw.D * 1000, 0) ~
                        " mm -> couple " ~ fmt(pPw.Mthrust, 1) ~ " Nm (" ~ (pPw.Mthrust < 0 ? "nose down" : "nose up") ~ "), a pure couple so the CG height does not matter; trim CG " ~
                        fmt(pCr.xcg * 1000, 1) ~ " -> " ~ fmt(pPw.xcg * 1000, 1) ~ " mm" ~ (ctx.hasStab ? ", static margin " ~ fmt((xnp - pCr.xcg) / macW * 100, 1) ~ " -> " ~
                        fmt((xnp - pPw.xcg) / macW * 100, 1) ~ "% MAC" ~ (smPwMin < 1e8 ? "; lowest under power " ~ fmt(smPwMin, 1) ~ "% at " ~ fmt(smPwMinV, 1) ~ " km/h" : "") : ""));
                }
                else
                    println("  no motor pod on Foil mast, so the thrust line height is unknown - thrust couple not in trim (enter it in Pitch Nm)");
                if (propCr.tip > 25)
                    println("  NOTE: tip speed " ~ fmt(propCr.tip, 1) ~ " m/s at cruise - expect ventilation and noise near the surface");
                println("  not modelled: ploughing before lift-off, cavitation/ventilation of the prop, pod and mast wake, acceleration (thrust above drag), and the prop's efficiency loss in oblique inflow (its axis is off the flow by thrust_angle_deg)");
            }
            println("");
            println("speed_kmh,alpha_deg,CL_wing,CL_stab,Re_wing_M,drag_N,drag_induced_N,drag_profile_N,L_D,power_W,trim_cg_mm,static_margin_pct,max_local_cl_pct,drag_mast_N,drag_body_N" ~
                (propCr != undefined ? ",thrust_N,prop_rpm,J,eta_prop_pct,motor_A,throttle_pct,batt_A,batt_W,Wh_per_km,max_thrust_N,in_limits,thrust_couple_Nm,thrust_angle_deg,thrust_vert_N,trim_cg_powered_mm,static_margin_powered_pct" : ""));
            var v = definition.vTakeoff;
            while (v <= definition.vMax + 1e-9)
            {
                const p = trimPoint(ctx, v / 3.6);
                var row = fmt(v, 1) ~ "," ~ fmt(p.alpha * 180 / PI, 2) ~ "," ~ fmt(p.CLw, 3) ~ "," ~ fmt(p.CLs, 3) ~ "," ~ fmt(p.Re / 1e6, 3) ~ "," ~
                    fmt(p.D, 1) ~ "," ~ fmt(p.Di, 1) ~ "," ~ fmt(p.D - p.Di - p.Dmast - p.Dbody, 1) ~ "," ~ fmt(p.LD, 2) ~ "," ~ fmt(p.P, 0) ~ "," ~
                    (ctx.hasStab ? fmt(p.xcg * 1000, 1) ~ "," ~ fmt((xnp - p.xcg) / macW * 100, 1) : ",") ~ "," ~
                    fmt(maxLocalClRatio(wing, Lw, p.alpha, clMaxWing, clMaxTip) * 100, 0) ~ "," ~ fmt(p.Dmast, 1) ~ "," ~ fmt(p.Dbody, 1);
                if (propCr != undefined)
                {
                    // thrust = drag at the powered ride depth, which differs from drag_N when that is the pod-in depth
                    const pp = trimPoint(pctx, v / 3.6);
                    const Tp = pp.T;
                    const o = propOperate(pr, v / 3.6, Tp);
                    row = row ~ "," ~ fmt(Tp, 1) ~ "," ~ fmt(o.rpm, 0) ~ "," ~ fmt(o.J, 3) ~ "," ~ fmt(o.eta0 * 100, 1) ~ "," ~ fmt(o.iMotor, 1) ~ "," ~
                        fmt(o.throttle * 100, 0) ~ "," ~ fmt(o.iBatt, 1) ~ "," ~ fmt(o.pBatt, 0) ~ "," ~ fmt(o.whKm, 1) ~ "," ~
                        fmt(propFullPower(pr, v / 3.6).T, 1) ~ "," ~ (o.ok ? "1" : "0") ~ "," ~ fmt(pp.Mthrust, 1) ~ "," ~ fmt(pp.thrustAngle, 1) ~ "," ~ fmt(pp.Tz, 1) ~ "," ~ fmt(pp.xcg * 1000, 1) ~ "," ~
                        (ctx.hasStab ? fmt((xnp - pp.xcg) / macW * 100, 1) : "");
                }
                println(row);
                v += definition.vStep;
            }
            println("===== END =====");
        }
    });

export enum MoldKeyStyle
{
    annotation { "Name" : "Printed keys" }
    PRINTED,
    annotation { "Name" : "Dowel holes" }
    DOWEL
}

export enum MastTaper
{
    annotation { "Name" : "Symmetric" }
    SYMMETRIC,
    annotation { "Name" : "Straight leading edge" }
    LEADING,
    annotation { "Name" : "Straight trailing edge" }
    TRAILING
}

export enum MoldOf
{
    annotation { "Name" : "The part" }
    PART,
    annotation { "Name" : "Its foam core" }
    CORE
}

export enum MoldClosing
{
    annotation { "Name" : "Clamps against a board" }
    CLAMPS,
    annotation { "Name" : "Vacuum bag round the mold" }
    BAG
}

export enum MoldSource
{
    annotation { "Name" : "Wing" }
    WING,
    annotation { "Name" : "Stabiliser" }
    STAB,
    annotation { "Name" : "Mast" }
    MAST
}

annotation { "Feature Type Name" : "Foil mold",
             "Feature Type Description" : "Printable molds for a Foil wing, stabiliser or mast: two shells parted along each section's camber line so they release (three parts for the mast, with a plate tray), with locator keys, a pinch-off groove, plugs, undersized bolt cones, and tiles sized to your printer bed. Also works out the layup from the part (woven skins, UD caps with a cut list, tow, resin, what to buy), checks stiffness and strength, and can cut a template plate of every fabric shape for DXF export. One instance per part." }
export const foilMold = defineFeature(function(context is Context, id is Id, definition is map)
    precondition
    {
        annotation { "Group Name" : "Part", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Part",
                         "Filter" : EntityType.BODY && BodyType.SOLID,
                         "MaxNumberOfPicks" : 1,
                         "Description" : "The wing or stabiliser solid to mold (the whole body, tube socket or mount pad included). One Foil mold per component - add a separate instance for the wing and for the stab." }
            definition.part is Query;

            annotation { "Name" : "Source model",
                         "Description" : "Which feature built Part; it must match the body selected above. Wing / Stabiliser: the parting follows that feature's own planform, twist, droop and section. Mast: the mold is built on a copy of the mast laid flat 400 mm below the origin (span along -Y, thickness up), parting on the mast's mid-plane, in three parts (left, right and a tray for the plate); the plate is molded with it (drill its holes after cure) and the motor pod is molded too, with a plug shaped from the pod's cavity. The cavity and the plate tray are cut from the mast part as it stands, so direct edits made above this feature (plate fillets or chamfers, another plate outline, a thicker plate, a hand-modelled pod interior) are followed; only the bolt pins stay on the Foil mast's pattern." }
            definition.moldSource is MoldSource;

            annotation { "Name" : "Mold of", "Default" : "PART",
                         "Description" : "The part: the two halves form the part's outside, as always. Its foam core: needs Core = Foam core in the layup group; the feature first builds the core body itself - the part's sections offset inward by the skins, with a groove in each face where the UD caps run, so the finished core plus caps plus skins is the part - and then molds THAT, so the foam can be cast or shaped in a mold rather than carved from sheet. No socket plug, bolt cones or mount pad in a core mold. Add it as a second Foil mold on the same part; the core body is left as its own part for reference." }
            definition.moldOf is MoldOf;

            annotation { "Name" : "Parts group", "Default" : "OFF",
                         "Description" : "Off (default): every mold piece is a normal part, named. Closed / Open collect everything this feature makes - shells, tiles, plugs, pins and the template plate - into one composite part named after the source (Wing mold, Stab mold, Mast mold). Closed: the parts list shows one expandable entry and the pieces live inside it (expand it to reach a tile; export from there). Open: the pieces stay listed as parts and the group appears under Composite parts, which is how Onshape treats open composites. Closed can hide every piece inside a group that is itself hidden, which is why the default is Off." }
            definition.partsGroup is PartsGroup;

            annotation { "Name" : "Split stations",
                         "Description" : "Spanwise stations used to build the parting surface, root to tip. Limits 5-80. Typical 15-25; 22 or more for a wing with a Tip profile (the Silk V2 example needed 22, and fails at 15); 40-80 for a tip with all its sweep and droop concentrated in the last fifth of the span (Sweep exp / Drop exp of 3-4), where the parting must turn sharply. Each station is a sketch and a ruled loft, so regeneration time grows with the count. Packed toward the tip by Tip bias." }
            isInteger(definition.splitStations, { (unitless) : [5, 15, 80] } as IntegerBoundSpec);

            annotation { "Name" : "Tip bias",
                         "Description" : "How strongly the stations crowd toward the tip: station i of n sits at span fraction 1 - (1 - i/n)^bias. Limits 1-4. Typical 2. 1 = evenly spaced; 2 = close to the cosine packing used before; 3-4 = most stations in the outer third, for planforms whose sweep and droop are concentrated there. Raise this before raising Split stations." }
            isReal(definition.tipBias, { (unitless) : [1, 2, 4] } as RealBoundSpec);
        }

        annotation { "Group Name" : "Mold body", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Flange width",
                         "Description" : "Mold material around the planform, from the part's edge to the outside of the block. Limits 10-60 mm. Typical 20-30 mm for a clamped printed mold: wide enough to seat clamps and a pinch-off groove, narrow enough not to waste print time. The parting surface runs out through the flange, so the two halves meet on it all the way round." }
            isLength(definition.flangeWidth, { (millimeter) : [10, 25, 60] } as LengthBoundSpec);

            annotation { "Name" : "Base thickness",
                         "Description" : "Mold material between the cavity and the outer (clamped) face of each half, measured at the deepest point. Limits 5-40 mm. Typical 15-25 mm for a printed mold clamped against a rigid board: enough not to flex between clamps or print through to the cavity, without a long print, and it is the layer the tile keys sit in (at least Pin dia + 4 mm and Key height + 4 mm). The slicer sets walls and infill; the body is solid here." }
            isLength(definition.baseThick, { (millimeter) : [5, 20, 40] } as LengthBoundSpec);

        }

        annotation { "Group Name" : "Tube socket", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Socket plug", "Default" : true,
                         "Description" : "Wing molds only, when the Foil wing has its Tube socket on. The socket's bore is not molded by the halves (two half-round cores would leave a seam down the bore): the cavity is cut with the bore and pin holes filled, and a separate cylindrical plug part - the bore diameter, the socket's full depth plus Plug extension - is made to lay the carbon around. Both halves get a half-round channel behind the nacelle's rear face that holds the plug coaxial when the mold is closed; pull the plug after cure and drill the pin holes to the wing's pattern. Off = the bore and pin holes are molded as half cores (not recommended)." }
            definition.plugOn is boolean;

            annotation { "Name" : "Plug extension",
                         "Description" : "How far the plug reaches behind the nacelle's rear face into the channel in the flanges. Limits 10-60 mm, and at most Flange width - 3 mm. Typical 15-20 mm: enough to hold it square and to grip when pulling. Pin fit sets the channel clearance." }
            isLength(definition.plugExt, { (millimeter) : [10, 20, 60] } as LengthBoundSpec);
        }

        annotation { "Group Name" : "Bolt cones", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Bolt cones", "Default" : true,
                         "Description" : "Stabiliser molds only. Puts a tapered cone at each of the stab's own Mount bolts, standing on the pad face in the half that holds the pad and pointing through the section to Cone web short of the far skin, so the holes come out of the mold on the pattern the Foil fuselage is tapped to. Undersized and tapered so the part releases; drill to the stab's Bolt dia after cure. Off = drill from the fuselage as a jig." }
            definition.conesOn is boolean;

            if (definition.conesOn)
            {
                annotation { "Name" : "Cone dia",
                             "Description" : "Diameter of each cone at the pad face, the wide end. Limits 2-12 mm. Typical 4-5 mm for M6-M8, leaving 1.5-2 mm a side to drill out to clearance. Keep it below the fuselage's Stab bolt dia so the drilled hole cleans the molded surface." }
                isLength(definition.coneDia, { (millimeter) : [2, 5, 12] } as LengthBoundSpec);

                annotation { "Name" : "Cone taper",
                             "Description" : "Half-angle of the cone. Limits 2-15 deg. Typical 5-8 deg: enough draft to pull a clamped part off without levering, on a hole that will be drilled anyway." }
                isAngle(definition.coneTaper, { (degree) : [2, 6, 15] } as AngleBoundSpec);

                annotation { "Name" : "Cone web",
                             "Description" : "Laminate left between the cone tip and the top surface, so the cone never touches the upper half and the hole is closed by a thin web you drill through. Limits 0.5-5 mm. Typical 1-1.5 mm." }
                isLength(definition.coneWeb, { (millimeter) : [0.5, 1, 5] } as LengthBoundSpec);
            }
        }

        annotation { "Group Name" : "Pinch-off", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Pinch-off groove", "Default" : true,
                         "Description" : "A channel in the lower half's parting face running right round the cavity: a narrow land at the cavity edge where the closing mold pinches the laminate and squeezes the excess resin and fibre out, then a groove for that flash to run into. Follows the planform (leading edge, tips, trailing edge, the tube socket nacelle) and the parting surface down the dropped tips. Off for a mold you will bag rather than clamp." }
            definition.grooveOn is boolean;

            if (definition.grooveOn)
            {
                annotation { "Name" : "Land width",
                             "Description" : "Flat land between the cavity edge and the groove. Limits 1-10 mm. Typical 2-4 mm: narrow enough to build real pinch pressure, wide enough to print cleanly and survive the clamps." }
                isLength(definition.landWidth, { (millimeter) : [1, 3, 10] } as LengthBoundSpec);

                annotation { "Name" : "Groove width",
                             "Description" : "Width of the flash groove. Limits 1-10 mm. Typical 3-5 mm." }
                isLength(definition.grooveWidth, { (millimeter) : [1, 4, 10] } as LengthBoundSpec);

                annotation { "Name" : "Groove depth",
                             "Description" : "Depth of the flash groove below the parting face. Limits 0.5-5 mm. Typical 1-2 mm for a clamped mold at 5 % overcharge; 3 mm with a 6 mm groove for a bagged mold, whose groove is also the vent path. The notice reports the groove's volume against the overcharge's flash and warns when it is too small." }
                isLength(definition.grooveDepth, { (millimeter) : [0.5, 1.5, 5] } as LengthBoundSpec);
            }
        }

        annotation { "Group Name" : "Closing", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Closing", "Default" : "CLAMPS",
                         "Description" : "How the closed mold is pressed shut while the resin cures. Clamps: G or F clamps on the flanges against a rigid board, the default, any force you like but concentrated at the clamp points. Vacuum bag: the whole closed mold, tiles glued, goes inside a bag with breather over it and the atmosphere clamps it, uniformly, with a closing force of the bag pressure times the block's plan area (about 5.7 kN on a stab mold, 14.5 kN on a 950 cm2 wing mold at 85 kPa) and a pressure on the laminate of that force over the part's plan area, 1.5-4 bar. With the bag: the block's outer edges are rounded so the bag is not cut, the pinch-off groove is vented to the outside at each span end so the bag can evacuate it (a sealed groove is a pocket of air the flash cannot enter), and Overcharge should drop to 3-5 %. Reported in the notice with the groove volume against the flash volume." }
            definition.closing is MoldClosing;

            if (definition.closing == MoldClosing.BAG)
            {
                annotation { "Name" : "Bag vacuum kPa",
                             "Description" : "Vacuum the pump holds in the bag, below atmospheric, in kPa. Limits 50-100. Typical 80-90 for a shop pump (100 kPa is a perfect vacuum, unreachable). Sets the closing force and the pressure on the laminate the notice reports." }
                isReal(definition.bagVac, { (unitless) : [50, 85, 100] } as RealBoundSpec);

                annotation { "Name" : "Groove vents", "Default" : true,
                             "Description" : "A 1 mm slot from the pinch-off groove out through the flange to the block's outer face at each span end, in the lower half, as deep as the groove. Inside a bag the groove is otherwise a sealed pocket of air at atmospheric pressure, so the flash cannot flow into it and the halves stop short; the vents let the bag evacuate the groove, and the laminate through it, before the resin gels. Needs the Pinch-off groove on." }
                definition.ventOn is boolean;

                annotation { "Name" : "Edge round",
                             "Description" : "Radius on the block's twelve outer edges so the bag wraps them without being cut. Limits 0-10 mm. Typical 4-6. 0 leaves them sharp (the tiles' joint faces and the parting face are never rounded). Not applied to the mast's plate tray." }
                isLength(definition.edgeRound, { (millimeter) : [0, 5, 10] } as LengthBoundSpec);
            }
        }

        annotation { "Group Name" : "Printer", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Printer X",
                         "Description" : "Build volume across the chord (tile width). Limits 50-1000 mm. Typical 200-300. The report shows how many tiles each half needs; a tile can be rotated on the bed, so enter the bed's shorter side here and its longer side as Printer Y." }
            isLength(definition.printerX, { (millimeter) : [50, 250, 1000] } as LengthBoundSpec);

            annotation { "Name" : "Printer Y",
                         "Description" : "Build volume along the span (tile length). Limits 50-1000 mm. Typical 200-300." }
            isLength(definition.printerY, { (millimeter) : [50, 250, 1000] } as LengthBoundSpec);

            annotation { "Name" : "Printer Z",
                         "Description" : "Build height. Limits 50-1000 mm. Typical 200-300. Each half is printed cavity-up, so this only has to clear the half's own height (cavity depth plus Base thickness)." }
            isLength(definition.printerZ, { (millimeter) : [50, 250, 1000] } as LengthBoundSpec);

            annotation { "Name" : "Tile margin",
                         "Description" : "Clearance kept between a tile and the printer's limits in every axis. Limits 0-30 mm. Typical 5 mm for brims, skirts and bed-edge adhesion." }
            isLength(definition.tileMargin, { (millimeter) : [0, 5, 30] } as LengthBoundSpec);

            annotation { "Name" : "Stagger joints", "Default" : true,
                         "Description" : "Offsets the upper half's spanwise cuts by half a tile from the lower half's, so no joint runs through both halves at the same place: the assembled mold braces itself and the seams never line up through the laminate. The upper half then has one extra tile (two half-length end tiles). Off = the same cuts in both halves." }
            definition.staggerJoints is boolean;
        }

        annotation { "Group Name" : "Joints", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Key style",
                         "Description" : "How tiles locate on each other and the halves on one another. Printed keys: a tapered round boss on one side of every joint and a matching socket on the other, printed with the mold - nothing to buy. Bosses always point +Y (span joints), +X (chord joints) and up from the lower half, so they print without support with the halves cavity-up. Dowel holes: a plain hole either side of every joint for a steel or wooden dowel." }
            definition.keyStyle is MoldKeyStyle;

            annotation { "Name" : "Pin dia",
                         "Description" : "Diameter at the base of each tile-joint key (or the tile dowel). Limits 3-30 mm, and at most Base thickness - 4 mm (the keys sit in the base layer) and Flange width - 4 mm. Typical 10-16 mm for printed keys, 6-8 mm for steel dowels. Two per spanwise joint sit in the front and rear flanges; one per tile crosses each chordwise joint under the cavity. All of them sit in the base layer of each half, so none can break into the cavity." }
            isLength(definition.pinDia, { (millimeter) : [3, 12, 30] } as LengthBoundSpec);

            annotation { "Name" : "Half keys", "Default" : true,
                         "Description" : "Registration between the two halves: a key (or dowel hole) through the parting surface in the front and rear flanges, one pair per spanwise tile a quarter tile in from the tile joint - clear of every cut and tile key in both halves. Printed keys stand up from the lower half into sockets in the upper. Off = the halves locate on the clamps and board alone." }
            definition.keysOn is boolean;

            annotation { "Name" : "Key dia",
                         "Description" : "Base diameter of the half-to-half keys (or dowel). Limits 3-30 mm, and at most Flange width - 4 mm. Typical 12-20 mm for printed keys, 6-8 mm for dowels." }
            isLength(definition.keyDia, { (millimeter) : [3, 14, 30] } as LengthBoundSpec);

            if (definition.keyStyle == MoldKeyStyle.PRINTED)
            {
                annotation { "Name" : "Key height",
                             "Description" : "Height of every printed boss above its face; the socket is 0.3 mm deeper so the boss bottoms on the joint face, not in the socket. Limits 2-25 mm, and at most Base thickness - 4 mm (the socket must not break through the other side). Typical 8-12 mm. Taller locates better but the tip must stay over 2 mm across (see Key draft)." }
                isLength(definition.keyHeight, { (millimeter) : [2, 8, 25] } as LengthBoundSpec);

                annotation { "Name" : "Key draft",
                             "Description" : "Taper of the boss sides, so it finds its socket as the parts come together. Limits 3-30 deg. Typical 10-15 deg. Tip diameter = base - 2 x height x tan(draft), and must stay over 2 mm." }
                isAngle(definition.keyDraft, { (degree) : [3, 12, 30] } as AngleBoundSpec);
            }
            else
            {
                annotation { "Name" : "Pin length",
                             "Description" : "Total tile dowel length, half in each tile. Limits 10-60 mm. Typical 20-30 mm." }
                isLength(definition.pinLen, { (millimeter) : [10, 24, 60] } as LengthBoundSpec);

                annotation { "Name" : "Key length",
                             "Description" : "Total half-to-half dowel length, half in each half. Limits 8-40 mm, and at most 2 x (Base thickness - 3 mm) so the hole never breaks through the thinner half at a dropped tip. Typical 16-20 mm." }
                isLength(definition.keyLen, { (millimeter) : [8, 16, 40] } as LengthBoundSpec);
            }

            annotation { "Name" : "Pin fit",
                         "Description" : "Clearance added on the radius of every socket over its key, or to the hole diameter over the dowel. Limits 0-0.5 mm. Typical 0.15-0.25 mm for printed key in printed socket (add more if your printer prints holes small); 0.1-0.2 for a steel dowel." }
            isLength(definition.pinFit, { (millimeter) : [0, 0.2, 0.5] } as LengthBoundSpec);
        }

        annotation { "Group Name" : "Layup", "Collapsed By Default" : true }
        {
            annotation { "Name" : "Skin plies",
                         "Description" : "Bidirectional (woven) plies on each face of the part, full planform, laid first against the mold. Limits 0-10. Typical 1-2 for a foil wing or stab, 2-3 for a mast. They give the surface finish and torsional stiffness; the UD caps and tow carry the bending. Sized from the part's own surface area." }
            isInteger(definition.skinPlies, { (unitless) : [0, 2, 10] } as IntegerBoundSpec);

            annotation { "Name" : "Skin gsm",
                         "Description" : "Areal weight of the woven skin cloth, g/m2. Limits 50-800. Typical 160-245 (2x2 twill), 100-200 for a fine finish. Cured ply thickness is derived from this and Fibre vol %: gsm / (1780 x Vf), which gives 0.22 mm for 200 gsm at 50 %." }
            isReal(definition.skinGsm, { (unitless) : [50, 200, 800] } as RealBoundSpec);

            annotation { "Name" : "UD gsm",
                         "Description" : "Areal weight of the unidirectional spar-cap fabric, g/m2. Limits 50-1200. Typical 200-300 wet layup, 150-300 prepreg, 400-600 for a thick root. Sets the cured UD ply thickness (gsm / (1780 x Vf)) and so the cap ply count." }
            isReal(definition.udGsm, { (unitless) : [50, 300, 1200] } as RealBoundSpec);

            annotation { "Name" : "Cap width %",
                         "Description" : "Width of the UD spar caps as % of local chord, centred on the section's thickest point. Limits 10-70 %. Typical 35-50 %. Wider caps move fibre from tow into UD, which is where bending strength comes from, at the cost of more UD to cut." }
            isReal(definition.capWidthPct, { (unitless) : [10, 40, 70] } as RealBoundSpec);

            annotation { "Name" : "Cap thick %",
                         "Description" : "Thickness of the two UD caps together (top + bottom) as % of the core thickness at the thickest point - the local section less both skins. Limits 0-100 %. Typical 50-70 %. The cap ply count follows the section taper, dropping plies along the span - the console prints the cut list, per cap: cut every UD template twice, one for each face. What the skins and caps do not fill is filled with tow, so fewer skin plies means more UD at the same %." }
            isReal(definition.capThickPct, { (unitless) : [0, 60, 100] } as RealBoundSpec);

            annotation { "Name" : "Core",
                         "Description" : "What fills the section between the skins and the UD caps. Tow fill: carbon roving laid along the span, wetted out, the whole part is laminate (the heaviest and stiffest fill). Foam core: a shaped structural foam (Corecell, PVC, PET) inside the skins and caps, the way most production wings are built - a third to a half lighter, and the caps and skins carry all the bending, so the stiffness check drops; the core is cut from sheet and shaped to the cavity less the skins. Monolithic: woven plies fill the section, as on high-modulus production wings; same weight as tow, bought as cloth. Printed core: the same core shape as the foam core, 3D printed instead - this feature generates it as a part, split to your printer bed along the span, to be glued end to end and laid up in the part mold like a foam core; no core mold needed." }
            definition.coreType is CoreType;

            if (definition.coreType == CoreType.FOAM || definition.coreType == CoreType.PRINTED)
            {
                annotation { "Name" : "Core kg/m^3",
                             "Description" : "Density of the core as built. Limits 30-1300. Typical: foam 80-100 (Corecell M80 and PVC H80 about 85 and 80, PET 100-110), 60 for a light core in a big low-speed wing, 130-200 for a hard core under a mast plate. Printed: the print's average density, walls and infill together - PLA at 15 % gyroid with 2 walls is about 350-450, PETG similar, 1240 for solid PLA." }
                isReal(definition.coreDensity, { (unitless) : [30, 85, 1300] } as RealBoundSpec);

                annotation { "Name" : "Core GPa",
                             "Description" : "Modulus of the core along the span, for the stiffness check. Limits 0.02-5. Typical: foam 0.08-0.12 for an 80-100 kg/m^3 structural foam (Corecell M80 about 0.1), 0.2-0.3 at 200. Printed: about 0.5-1 for PLA at 15-20 % infill with walls, 3.5 solid; PETG 20 % lower. Small against carbon either way: the caps and skins do the work." }
                isReal(definition.coreModulus, { (unitless) : [0.02, 0.1, 5] } as RealBoundSpec);
            }

            if (definition.coreType == CoreType.TOW)
            {
            annotation { "Name" : "Tow tex",
                         "Description" : "Linear density of the carbon tow (roving) that fills the lens core, leading and trailing edges and the socket nacelle, g/km. Limits 100-4000. Typical 800 (12k); 3k = 200, 24k = 1600 tex. Used only to turn the tow mass into a length to buy." }
            isReal(definition.towTex, { (unitless) : [100, 800, 4000] } as RealBoundSpec);
            }

            annotation { "Name" : "Fibre vol %",
                         "Description" : "Fibre volume fraction of the cured laminate. Limits 30-65 %. Typical 45-50 wet layup clamped in a matched mold, 55-60 vacuum-bagged or prepreg, 35-40 wet hand layup with no pressure. Sets the cured ply thicknesses and the split of the part's volume between carbon (1.78 g/cm3) and epoxy (1.15 g/cm3)." }
            isReal(definition.fibreVolPct, { (unitless) : [30, 50, 65] } as RealBoundSpec);

            annotation { "Name" : "Overcharge %",
                         "Description" : "Extra material laid over the exact cavity fill, as %. Limits 0-30 %. Typical 5-10 % for a clamped matched-die mold: closing under pressure squeezes the excess out as flash at the pinch-off, which is what packs the laminate void-free; 3-5 % with Closing = Vacuum bag, whose 1-4 bar closes to the land but cannot force much flash out. The notice compares the flash volume with what the groove holds. 0 for a loose vacuum bag. Scales the ply counts and every material figure." }
            isReal(definition.overchargePct, { (unitless) : [0, 8, 30] } as RealBoundSpec);

            annotation { "Name" : "Cloth waste %",
                         "Description" : "Cutting waste added to the woven and UD areas to buy. Limits 0-100 %. Typical 20-30 % (bias cuts, tapered UD plies, selvedge)." }
            isReal(definition.clothWastePct, { (unitless) : [0, 25, 100] } as RealBoundSpec);

            annotation { "Name" : "Resin waste %",
                         "Description" : "Resin mixed beyond what stays in the part: mixing-pot loss, wet-out of the tow, brushes, and the flash squeezed out at the pinch-off. Limits 0-150 %. Typical 30-50 % wet layup, 10 % prepreg (only the tow needs wetting)." }
            isReal(definition.resinWastePct, { (unitless) : [0, 40, 150] } as RealBoundSpec);

            annotation { "Name" : "Cap run-out",
                         "Description" : "Mast only. Length each UD cap ply runs past the plate's underside, folded outward over the root fillet onto the plate between its fill plies, so the cap's tension enters the plate by shear instead of peeling off the corner. Limits 0-100 mm. 0 = as far as the plate edge allows (2 mm short of it). Typical 30-50 mm; the stiffness line says how much the junction needs." }
            isLength(definition.capRunOut, { (millimeter) : [0, 0, 100] } as LengthBoundSpec);

            annotation { "Name" : "Tab plies",
                         "Description" : "Mast only. UD tab plies per face interleaved with the cap plies at the plate: each runs Tab length down the mast face and Cap run-out out over the plate, alternating with the caps so the two surfaces are stitched together through the stack rather than by one bond line. Limits 0-12. Typical 3-5. They take their thickness from the tow core over Tab length; the layup line warns if that core runs out." }
            isInteger(definition.tabPlies, { (unitless) : [0, 4, 12] } as IntegerBoundSpec);

            annotation { "Name" : "Tab length",
                         "Description" : "Mast only. How far each tab ply runs down the mast face from the plate. Limits 10-200 mm. Typical 40-80 mm, at least the Cap run-out." }
            isLength(definition.tabLength, { (millimeter) : [10, 50, 200] } as LengthBoundSpec);
        }

        annotation { "Group Name" : "Stiffness", "Collapsed By Default" : true }
        {
            annotation { "Name" : "UD GPa",
                         "Description" : "Tensile modulus of the cured UD carbon along the fibre. Limits 80-200. Typical 110-130 at 50 % fibre volume wet layup, 140-160 prepreg, 200+ for high-modulus fibre. Sets the spar caps' contribution to bending stiffness." }
            isReal(definition.udModulus, { (unitless) : [80, 120, 200] } as RealBoundSpec);

            annotation { "Name" : "Woven GPa",
                         "Description" : "In-plane modulus of the cured woven skin along the span. Limits 30-100. Typical 55-65 for a 0/90 twill at 50 % fibre volume; about 15 if the skin is laid at 45 deg, in which case it adds torsion, not bending." }
            isReal(definition.wovenModulus, { (unitless) : [30, 60, 100] } as RealBoundSpec);

            if (definition.coreType == CoreType.TOW)
            {
            annotation { "Name" : "Tow GPa",
                         "Description" : "Effective modulus of the tow-filled core along the span. Limits 10-80. Typical 30 for tow laid roughly along the span, 10 for chopped or random fill. A foam core uses Core GPa, a monolithic fill uses Woven GPa." }
            isReal(definition.towModulus, { (unitless) : [10, 30, 80] } as RealBoundSpec);
            }

            annotation { "Name" : "Mast side g",
                         "Description" : "Mast load case: a sideways force of this many times the all-up weight, applied at the fuselage end with the plate held by the board and rider, bending the mast about its chord - a hard carve or a fall. Limits 0.2-3. Typical 0.5-1. Reported as the deflection at the fuselage end and the UD cap stress at the plate, with the mast's own layup, taper and thickening; the moment peaks at the plate, which is why the top is thickened." }
            isReal(definition.mastSideG, { (unitless) : [0.2, 1, 3] } as RealBoundSpec);

            annotation { "Name" : "Shear allow",
                         "Description" : "Interlaminar shear strength of the cured laminate, MPa, for the junction check at the mast plate: the cap force at the plate divided by the bonded run-out area (the cap's plate face plus both faces of every tab ply) against this value with a factor of 2. Limits 10-80. Typical 25-35 wet layup, 50-70 prepreg. The line says the run-out the junction needs at this allowable." }
            isReal(definition.shearAllow, { (unitless) : [10, 30, 80] } as RealBoundSpec);
        }

        annotation { "Group Name" : "Cut templates", "Collapsed By Default" : true }
        {
            annotation { "Name" : "Cut templates", "Default" : false,
                         "Description" : "Makes a flat 1 mm plate beside the mold with every fabric shape cut through it: the woven skin outline (the planform developed along the droop, cut once per skin ply per face) and one tapered strip per UD cap ply from the cut list (cut twice, one per face - the tally holes say so), each grown by Trim margin. Right-click the plate's top face in Onshape and Export as DXF to get every outline in one file for a cutter or a printed paper template. The console prints the order they appear in. Off = no plate." }
            definition.templatesOn is boolean;

            annotation { "Name" : "Trim margin",
                         "Description" : "Allowance added round every template outline, for trimming and for the fabric's own slack. Limits 0-20 mm. Typical 5 mm woven, 3-5 mm UD." }
            isLength(definition.tplMargin, { (millimeter) : [0, 5, 20] } as LengthBoundSpec);

            annotation { "Name" : "Template gap",
                         "Description" : "Space between neighbouring outlines on the plate. Limits 5-40 mm. Typical 10 mm." }
            isLength(definition.tplGap, { (millimeter) : [5, 10, 40] } as LengthBoundSpec);
        }

        annotation { "Name" : "Log inputs", "Default" : true,
                     "Description" : "Prints every parameter on this feature to the FeatureScript console as one line, so the whole set can be pasted elsewhere (e.g. back to an AI assistant) along with the notice." }
        definition.logInputs is boolean;
    }
    {
        if (definition.logInputs)
            println(moldInputLog(definition));

        const isMast = definition.moldSource == MoldSource.MAST;
        const coreMold = definition.moldOf == MoldOf.CORE;
        if (coreMold && isMast)
            throw regenError("A core mold is for a wing or stabiliser: the mast has no foam core", ["moldOf"]);
        if (coreMold && definition.coreType != CoreType.FOAM)
            throw regenError(definition.coreType == CoreType.PRINTED ? "A printed core is generated as a part by this feature and needs no mold: set Mold of back to The part" : "A core mold needs Core = Foam core in the layup group", ["moldOf", "coreType"]);
        var m;
        var mastM;
        if (definition.moldSource == MoldSource.WING)
            try silent { m = getVariable(context, "foilWingModel"); }
        else if (definition.moldSource == MoldSource.STAB)
        {
            try silent { m = getVariable(context, "foilStabModel"); }
            // the stab's real pivot height: Seat on tube may have shifted the part after its model
            // was built, and foilStabHeight is the value the shift was applied to
            var hStab;
            try silent { hStab = getVariable(context, "foilStabHeight"); }
            if (m != undefined && hStab != undefined)
                m.baseZ = hStab / meter;
        }
        else
            try silent { mastM = getVariable(context, "foilMastModel"); }
        if (m != undefined && m.wingletOn == 1 && m.wingletAngle > 75 * degree / radian)
            throw regenError("A winglet steeper than 75 deg cannot release from a two-part mold pulled vertically: reduce Winglet angle in the " ~
                (definition.moldSource == MoldSource.WING ? "Foil wing" : "Foil stabiliser") ~ " feature (it is " ~ fmt(m.wingletAngle * 180 / PI, 0) ~ " deg)", ["moldSource"]);
        if (isMast)
        {
            if (mastM == undefined)
                throw regenError("Source model not found - add a Foil mast feature above this one");
            if (mastM.plateLength == undefined)
                throw regenError("The Foil mast above is older than this Foil mold - paste the whole Feature Studio over again so both are the same build");
            if (mastM.podOn == 1 && mastM.cavDia == undefined)
                throw regenError("The Foil mast above is older than this Foil mold - paste the whole Feature Studio over again so both are the same build");
        }
        else
        {
            if (m == undefined)
                throw regenError("Source model not found - add a Foil wing or Foil stabiliser feature above this one, matching Source model");
            if (m.profileName == undefined)
                throw regenError("The Foil wing / Foil stabiliser above is older than this Foil mold - paste the whole Feature Studio over again so both are the same build");
        }
        var sock;
        if (definition.moldSource == MoldSource.WING)
            try silent { sock = getVariable(context, "foilWingSocket"); }
        const sockOn = sock != undefined && sock.on == 1 && !coreMold;
        var stabRoot;
        if (definition.moldSource == MoldSource.STAB)
            try silent { stabRoot = getVariable(context, "foilStabRoot"); }
        // the stab owns its bolt pattern (Mount bolts) and pad plane; the cones need both
        const conesOn = definition.conesOn == true && !coreMold && definition.moldSource == MoldSource.STAB && stabRoot != undefined && stabRoot.boltX != undefined
            && size(stabRoot.boltX) > 0 && stabRoot.padOn == 1;
        if (definition.conesOn == true && definition.moldSource == MoldSource.STAB && !conesOn)
            println("STAB_CONES: off - " ~
                (stabRoot == undefined ? "no foilStabRoot variable (no Foil stabiliser above)" :
                 (stabRoot.boltX == undefined ? "the Foil stabiliser above is older than this mold - paste the whole Feature Studio again" :
                  (size(stabRoot.boltX) == 0 ? "the stab has Stab bolts = 0 (Mount bolts group)" : "the stab's Mount pad is off"))));

        const capStartEta = isMast ? 1 : (m.capOn == 1 ? max(0, 1 - m.capLength / (m.span / 2)) : 1);

        // ---------------- undercut check (spanwise droop only - see note in the notice) ----------------
        var dropCheck = "ok (droop is monotonic in +Z)";
        if (!isMast)
        {
            const h = m.span / 2;
            const td = tan(m.rootDihedral * radian);
            var sign = 0;
            var flip = false;
            for (var i = 1; i <= 40; i += 1)
            {
                const eta = capStartEta * i / 40;
                const ps = dropSlope(m, eta);
                const slope = -m.tipDrop * ps + h * td * (1 - ps); // d(zOff)/d(eta), h cancels in sign only
                const s = slope > 1e-9 ? 1 : (slope < -1e-9 ? -1 : 0);
                if (sign != 0 && s != 0 && s != sign)
                    flip = true;
                if (s != 0)
                    sign = s;
            }
            dropCheck = flip
                ? "WARNING - spanwise droop reverses direction (gull): likely undercut in +Z, the halves will not release; reduce Root dihedral or Drop exponent"
                : "ok (droop is monotonic in +Z)";
        }

        // ---------------- layup: skins + UD caps + tow, sized from the part itself ----------------
        // The part's volume (evVolume) is the laminate volume; its surface area carries the woven
        // skins; the UD caps fill Cap thick % of the section over Cap width % of the chord; tow fills
        // the rest. Fibre vol % splits every volume into carbon and epoxy. Evaluated on the original
        // part before any mold operation so the queries are fresh.
        const rhoF = 1.78;   // g/cm3 carbon fibre
        const rhoR = 1.15;   // g/cm3 cured epoxy
        const vf = definition.fibreVolPct / 100;
        const over = 1 + definition.overchargePct / 100;
        const tSkin = definition.skinGsm / (rhoF * 1e6 * vf) * 1000;    // mm cured ply
        const tUd = definition.udGsm / (rhoF * 1e6 * vf) * 1000;        // mm cured ply
        const partVol = evVolume(context, { "entities" : definition.part }) / (centimeter * centimeter * centimeter);   // cm3
        const partArea = evArea(context, { "entities" : qOwnedByBody(definition.part, EntityType.FACE) }) / (meter * meter); // m2
        // UD caps: cap thickness = Cap thick % of the local section thickness, over Cap width % of chord
        const capW = definition.capWidthPct / 100;
        const capF = definition.capThickPct / 100;
        const tSkins = 2 * definition.skinPlies * tSkin;                     // mm taken by the skins, both faces
        // mast plate: a solid block filled with woven plies between its skins (the usual hand-layup
        // choice - the tracks load it both ways, so UD would be stiff one way only); counted with the
        // skins, so it comes out of the tow. Build 117 left the whole plate as tow with no cut count
        var plateFill = 0;                                                    // woven plies inside the plate
        var plateArea = 0;                                                    // m2, one ply
        // the plate as modelled: measured off the part (a copy split at the plate's underside), so a
        // plate the user has edited by hand above this feature - fillets, chamfers, another outline, a
        // thicker plate - is what the tray, the fill count and the template follow (user). Nominal
        // numbers from the Foil mast if the measurement fails
        var plateAct;
        if (isMast && mastM.plateLength != undefined)
        {
            plateAct = moldPlateMeasure(context, id + "plateMeasure", definition.part, mastM);
            const tP = plateAct != undefined ? (plateAct.zBoard - plateAct.zTop) / millimeter : mastM.plateThick * 1000;
            plateFill = max(0, round((tP - tSkins) / tSkin));
            plateArea = plateAct != undefined ? (plateAct.x1 - plateAct.x0) * (plateAct.y1 - plateAct.y0) / (meter * meter) : mastM.plateLength * mastM.plateWidth;
            const nomL = mastM.plateLength * 1000;
            const nomW = mastM.plateWidth * 1000;
            const nomT = mastM.plateThick * 1000;
            if (plateAct == undefined)
                println("MAST_PLATE: could not measure the plate off the part - the tray uses the Foil mast's " ~ fmt(nomL, 1) ~ " x " ~ fmt(nomW, 1) ~ " x " ~ fmt(nomT, 1) ~ " mm");
            else
            {
                const mL = (plateAct.x1 - plateAct.x0) / millimeter;
                const mW = (plateAct.y1 - plateAct.y0) / millimeter;
                const edited = abs(mL - nomL) > 0.2 || abs(mW - nomW) > 0.2 || abs(tP - nomT) > 0.2;
                println("MAST_PLATE: measured off the part " ~ fmt(mL, 1) ~ " x " ~ fmt(mW, 1) ~ " x " ~ fmt(tP, 1) ~ " mm (Foil mast: " ~ fmt(nomL, 1) ~ " x " ~ fmt(nomW, 1) ~ " x " ~ fmt(nomT, 1) ~ ")" ~
                    (edited ? " - direct edits found, the tray follows the part" : ""));
            }
        }
        const skinArea = partArea * definition.skinPlies + plateArea * plateFill;   // m2 of cloth laid
        const skinVol = skinArea * tSkin / 1000 * 1e6;                      // cm3
        // the caps fill Cap thick % of the CORE inside the skins, so the skin count changes the UD
        // count and skins + caps can never exceed the section (build 114 measured against the whole
        // section, so halving the skins left the UD count unchanged - user)
        var capVol = 0;          // cm3
        var capPliesRoot = 0;
        var capPliesTip = 0;
        var capLen = 0;          // m, one cap from root to the cap start (mast: its height)
        var capCut = "";         // console cut list
        var tplEnds = [];        // per UD ply: the last station index it reaches (wing / stab)
        var tplCAt = [];         // chord per station, mm, for the templates and the stiffness check
        var tplTAt = [];         // section thickness per station, mm
        var runOut = 0;          // mm, mast: cap run-out onto the plate
        var tabN = 0;            // mast: tab plies per face
        var tabLen = 0;          // mm, mast: tab length down the mast
        var tabNote = "";
        if (isMast)
        {
            // stations from the plate (s = 1, the thick end and the peak moment) down to the fuselage
            // end (s = 0), so the cut list reads like the wing's: ply k runs from the plate to the last
            // station still k plies thick per cap; the thickened top adds short plies at the plate end
            const nS = 40;
            const cTopM = mastM.chordTop != undefined ? mastM.chordTop : mastM.chord;
            const tTopM = mastM.thickTop != undefined ? mastM.thickTop : mastM.thick;
            const s0M = mastM.thickenFrom != undefined ? mastM.thickenFrom : 1;
            var tAt = makeArray(nS + 1);                                      // section thickness, mm
            var cAt = makeArray(nS + 1);                                      // chord, mm
            for (var i = 0; i <= nS; i += 1)
            {
                const sF = 1 - i / nS;
                const uM = s0M >= 1 ? 0 : min(max((sF - s0M) / (1 - s0M), 0), 1);
                cAt[i] = (mastM.chord + (cTopM - mastM.chord) * sF) * 1000;
                tAt[i] = (mastM.thick + (tTopM - mastM.thick) * uM * uM * (3 - 2 * uM)) * 1000;
                if (i > 0)
                    capVol += capW * (cAt[i] + cAt[i - 1]) / 2 * capF * max((tAt[i] + tAt[i - 1]) / 2 - tSkins, 0) * (mastM.height * 1000 / nS) / 1000;   // mm3 -> cm3
            }
            capPliesRoot = round(capF * max(tAt[0] - tSkins, 0) / 2 * over / tUd);
            capPliesTip = round(capF * max(tAt[nS] - tSkins, 0) / 2 * over / tUd);
            capLen = mastM.height;
            // junction: every cap ply runs out over the root fillet onto the plate (Cap run-out, or to
            // 2 mm short of the plate edge), and Tab plies per face of UD interleave with the caps,
            // Tab length down the mast and the same run-out out over the plate (user: alternating
            // layers of UD to tab the two surfaces together). Both displace tow / plate fill
            const roomOut = mastM.plateWidth != undefined ? max((mastM.plateWidth - tTopM) / 2 * 1000 - 2, 0) : 0;
            runOut = definition.capRunOut > 0 ? min(definition.capRunOut / millimeter, roomOut) : roomOut;
            tabN = definition.tabPlies;
            tabLen = definition.tabLength / millimeter;
            const wPl = capW * cAt[0];                                        // mm, cap width at the plate
            capVol += 2 * capPliesRoot * runOut * wPl * tUd / 1000;           // cap run-outs, both faces, cm3
            capVol += 2 * tabN * (runOut + tabLen) * wPl * tUd / 1000;        // tabs, both faces, cm3
            const coreP = max(tAt[0] - tSkins, 0) * (1 - capF);               // mm of tow core at the plate
            if (tabN > 0)
            {
                tabNote = " | tabs " ~ tabN ~ " per face x " ~ fmt(runOut + tabLen, 0) ~ " x " ~ fmt(wPl, 0) ~ " mm UD, fold at " ~ fmt(runOut, 0) ~ " mm, one after every " ~
                    max(1, ceil(capPliesRoot / tabN)) ~ " cap plies; they take " ~ fmt(2 * tabN * tUd, 1) ~ " mm of the " ~ fmt(coreP, 1) ~ " mm tow core at the plate over " ~ fmt(tabLen, 0) ~ " mm" ~
                    (2 * tabN * tUd > coreP ? " - MORE THAN THE CORE: fewer Tab plies or a thicker Top thick" : "");
            }
            capCut = "UD_CAP_PLIES (per cap, cut 2 - one for each face; outermost first; length from the plate down PLUS " ~ fmt(runOut, 0) ~ " mm run-out folded over the fillet onto the plate - fold at " ~ fmt(runOut, 0) ~ " mm from the plate end; width at the plate / at the end): ply,length_mm,width_plate_mm,width_end_mm";
            for (var k = 1; k <= capPliesRoot; k += 1)
            {
                var iEnd = 0;
                for (var i = 0; i <= nS; i += 1)
                    if (capF * max(tAt[i] - tSkins, 0) / 2 * over / tUd >= k - 0.5)
                        iEnd = i;
                iEnd = max(iEnd, 1);
                capCut = capCut ~ "\n" ~ k ~ "," ~ fmt(iEnd / nS * mastM.height * 1000 + runOut, 0) ~ "," ~ fmt(wPl, 0) ~ "," ~ fmt(capW * cAt[iEnd], 0);
                tplEnds = append(tplEnds, iEnd);
            }
            if (tabN > 0)
                capCut = capCut ~ "\nUD_TABS: " ~ tabN ~ " per face (cut " ~ 2 * tabN ~ ") x " ~ fmt(runOut + tabLen, 0) ~ " mm x " ~ fmt(wPl, 0) ~ " mm, fold at " ~ fmt(runOut, 0) ~ " mm (plate leg), " ~ fmt(tabLen, 0) ~ " mm down the mast; lay one after every " ~ max(1, ceil(capPliesRoot / tabN)) ~ " cap plies, outermost first";
            tplCAt = cAt;
            tplTAt = tAt;
        }
        else
        {
            const nS = 40;
            const halves = m.mirror == 1 ? 2 : 1;
            const dy = capStartEta * m.span / 2 / nS;                        // m per station, one half
            var tAt = makeArray(nS + 1);                                      // local section thickness, mm
            var cAt = makeArray(nS + 1);                                      // local chord, mm
            for (var i = 0; i <= nS; i += 1)
            {
                const eta = capStartEta * i / nS;
                const chord = m.c0 * chordFactor(m, eta);
                const thickFrac = m.rootT + (m.tipT - m.rootT) * eta ^ m.thicknessExp;
                cAt[i] = chord * 1000;
                tAt[i] = thickFrac * chord * 1000;
                if (i < nS)
                {
                    const etaM = capStartEta * (i + 0.5) / nS;
                    const cM = m.c0 * chordFactor(m, etaM);
                    const tM = (m.rootT + (m.tipT - m.rootT) * etaM ^ m.thicknessExp) * cM;
                    capVol += capW * cM * capF * max(tM - tSkins / 1000, 0) * dy * 1e6 * halves;
                }
            }
            // nearest-ply rounding: ply k covers the span where the stack is at least k - 0.5 plies
            // thick, so the innermost ply is never a zero-length line (ceil gave one on build 79)
            capPliesRoot = round(capF * max(tAt[0] - tSkins, 0) / 2 * over / tUd);
            capPliesTip = round(capF * max(tAt[nS] - tSkins, 0) / 2 * over / tUd);
            capLen = capStartEta * m.span / 2 * halves;
            // cut list: ply k (outermost first) runs out to the last station still k plies thick; a
            // mirrored foil's cap is one piece across the root, so its length is both halves
            capCut = "UD_CAP_PLIES (per cap, cut 2 - one for each face; outermost first; length root-to-root" ~ (halves == 2 ? " across the centre" : "") ~ ", width at root / at the end): ply,length_mm,width_root_mm,width_end_mm";
            for (var k = 1; k <= capPliesRoot; k += 1)
            {
                var iEnd = 0;
                for (var i = 0; i <= nS; i += 1)
                    if (capF * max(tAt[i] - tSkins, 0) / 2 * over / tUd >= k - 0.5)
                        iEnd = i;
                iEnd = max(iEnd, 1);
                const len = capStartEta * iEnd / nS * m.span / 2 * halves * 1000;
                capCut = capCut ~ "\n" ~ k ~ "," ~ fmt(len, 0) ~ "," ~ fmt(capW * cAt[0], 0) ~ "," ~ fmt(capW * cAt[iEnd], 0);
                tplEnds = append(tplEnds, iEnd);
            }
            tplCAt = cAt;
            tplTAt = tAt;
        }
        println(capCut);
        var towVol = partVol - skinVol - capVol;                             // cm3
        var towNote = "";
        if (towVol < 0)
        {
            towNote = "skins + UD caps (" ~ fmt(skinVol + capVol, 0) ~ " cm3) exceed the part (" ~ fmt(partVol, 0) ~ " cm3) - lower Cap thick %, Cap width % or Skin plies";
            towVol = 0;
        }
        // the core: tow (laminate, as the rest), foam (its own density, no fibre or resin inside it),
        // or monolithic (woven plies, bought as cloth). Build 157
        const coreType = definition.coreType == undefined ? CoreType.TOW : definition.coreType;
        const isPrinted = coreType == CoreType.PRINTED;
        const isFoam = coreType == CoreType.FOAM || isPrinted;              // both: a core of its own density, no fibre or resin inside
        const lamVol = isFoam ? partVol - towVol : partVol;                  // cm3 of laminate
        const fibreMass = vf * lamVol * rhoF * over;                          // g, all carbon in the part
        const resinMass = (1 - vf) * lamVol * rhoR + (isFoam ? 0.05 * towVol * rhoR : 0);   // g, cured; a little resin wets a foam core's surface
        const skinMass = skinArea * definition.skinGsm * over;
        const capMass = capVol * vf * rhoF * over;
        const towMass = isFoam ? towVol * definition.coreDensity / 1000 : towVol * vf * rhoF * over;   // g: foam by density, else laminate
        const towLen = coreType == CoreType.TOW ? towMass / (definition.towTex / 1000) : 0;          // m of tow
        const fillArea = coreType == CoreType.SOLID ? towVol / (tSkin * 0.1) / 10000 : 0;             // m2 of woven to fill a monolithic core
        const coreSheet = isMast ? 0 : max(m.rootT * m.c0 * 1000 - tSkins, 0);                    // mm, foam sheet thickness at the root
        const refArea = isMast ? 1 : (m.area == undefined ? 1 : m.area);                             // m2, for the monolithic ply count
        const capArea = capMass / definition.udGsm;                           // m2
        const wasteC = 1 + definition.clothWastePct / 100;
        const wasteR = 1 + definition.resinWastePct / 100;
        const layupMsg = "layup " ~ fmt(partVol, 0) ~ " cm3, " ~ fmt((fibreMass + resinMass + (isFoam ? towMass : 0)) / 1000, 2) ~ " kg cured at Vf " ~ fmt(vf * 100, 0) ~ "%" ~
            (isFoam ? " with a " ~ fmt(definition.coreDensity, 0) ~ " kg/m3 " ~ (isPrinted ? "printed" : "foam") ~ " core" : (coreType == CoreType.SOLID ? " monolithic" : "")) ~
            " | skin " ~ fmt(definition.skinPlies, 0) ~ " x " ~ fmt(definition.skinGsm, 0) ~ " gsm each face (" ~ fmt(tSkin, 2) ~ " mm/ply): " ~ fmt(skinArea, 2) ~ " m2, " ~ fmt(skinMass, 0) ~ " g" ~
            (plateFill > 0 ? " incl. the plate's fill: " ~ plateFill ~ " woven plies inside its skins, " ~ fmt(plateArea * plateFill * definition.skinGsm * over, 0) ~ " g" : "") ~
            " | UD caps " ~ fmt(definition.udGsm, 0) ~ " gsm (" ~ fmt(tUd, 2) ~ " mm/ply), " ~ fmt(capW * 100, 0) ~ "% chord: " ~ fmt(capPliesRoot, 0) ~ " plies per cap at the " ~
            (isMast ? "plate to " ~ fmt(capPliesTip, 0) ~ " at the fuselage end" : "root to " ~ fmt(capPliesTip, 0) ~ " at the tip") ~ " (cut 2 of each), " ~ fmt(capLen * 1000, 0) ~ " mm long, " ~ fmt(capArea, 2) ~ " m2, " ~ fmt(capMass, 0) ~ " g" ~
            tabNote ~
            (coreType == CoreType.TOW ? " | tow " ~ fmt(definition.towTex, 0) ~ " tex: " ~ fmt(towMass, 0) ~ " g, " ~ fmt(towLen, 0) ~ " m" :
             (isPrinted ? " | printed core " ~ fmt(towVol, 0) ~ " cm3, " ~ fmt(towMass, 0) ~ " g at " ~ fmt(definition.coreDensity, 0) ~ " kg/m3: generated as a part, see the notice" :
              (isFoam ? " | foam core " ~ fmt(towVol, 0) ~ " cm3, " ~ fmt(towMass, 0) ~ " g: cut from sheet at least " ~ fmt(coreSheet, 0) ~ " mm thick, shaped to the cavity less " ~ fmt(tSkins / 2, 2) ~ " mm of skin each face" :
              " | monolithic fill: " ~ fmt(fillArea, 2) ~ " m2 woven (" ~ fmt(towVol / (tSkin * 0.1) / 10000 / max(refArea, 1e-6), 0) ~ " plies at the section's mean), " ~ fmt(towMass, 0) ~ " g"))) ~
            " | resin " ~ fmt(resinMass, 0) ~ " g in the part, mix " ~ fmt(resinMass * wasteR, 0) ~ " g" ~
            " | buy " ~ fmt((skinArea + fillArea) * wasteC, 2) ~ " m2 woven, " ~ fmt(capArea * wasteC, 2) ~ " m2 UD (+" ~ fmt(definition.clothWastePct, 0) ~ "%)" ~
            (isFoam && !isPrinted ? ", " ~ fmt(towVol * 1.3, 0) ~ " cm3 of foam (+30%)" : "") ~ ", cut list on the console";
        println("LAYUP: " ~ layupMsg);

        // ---------------- stiffness: the layup's bending stiffness against the published loads ----------------
        // EI per station from the caps (UD, at +/- their offset), the skins (woven, on the surface, 0.7 of
        // the extreme fibre for their curvature) and the tow core (a lens, ~0.02 c t^3); curvature M / EI
        // integrated twice from the root for the tip deflection. Wing / stab: the spanwise moment the
        // Foil performance feature publishes at its load factor. Mast: a side load at the plate.
        var stiffMsg = "";
        {
            const Eud = definition.udModulus * 1e9;
            const Ew = definition.wovenModulus * 1e9;
            const Etow = (coreType == CoreType.FOAM ? definition.coreModulus : (coreType == CoreType.SOLID ? definition.wovenModulus : definition.towModulus)) * 1e9;   // the core's modulus, whatever fills it
            const tsF = definition.skinPlies * tSkin / 1000;          // m, one face's skins
            if (isMast)
            {
                var loadsM;
                try silent { loadsM = getVariable(context, "foilWingLoads"); }
                if (loadsM == undefined)
                    stiffMsg = " | stiffness: add a Foil performance feature above for the mast side-load check";
                else
                {
                    // fixed at the plate (the board and rider are the anchor), the side force from the
                    // wing at the fuselage end: moment F z from the base, greatest at the plate. Build
                    // 116 had it the other way round, so the peak landed on the thin base section
                    const H = mastM.height;
                    const F = definition.mastSideG * loadsM.W;
                    const nZ = 40;
                    var slope = 0;
                    var defl = 0;
                    var sigBase = 0;
                    var sigMax = 0;             // MPa, the worst cap stress along the height ...
                    var zSigMax = 0;            // ... and where (m above the fuselage end)
                    var capForceP = 0;          // N, one cap's force at the plate
                    var wCapP = 0;              // m, cap width at the plate
                    var kPrev = 0;
                    for (var i = nZ; i >= 0; i -= 1)
                    {
                        const sF = i / nZ;
                        const c = mastM.chord + ((mastM.chordTop != undefined ? mastM.chordTop : mastM.chord) - mastM.chord) * sF;
                        const s0 = mastM.thickenFrom != undefined ? mastM.thickenFrom : 1;
                        const u = s0 >= 1 ? 0 : min(max((sF - s0) / (1 - s0), 0), 1);
                        const t = mastM.thick + ((mastM.thickTop != undefined ? mastM.thickTop : mastM.thick) - mastM.thick) * u * u * (3 - 2 * u);
                        const capT = max(capF * (t - 2 * tsF), 0) / 2;
                        const wCap = capW * c;
                        const dC = t / 2 - tsF - capT / 2;
                        const Icap = 2 * (wCap * capT ^ 3 / 12 + wCap * capT * dC * dC);
                        const dS = 0.7 * (t / 2 - tsF / 2);
                        const Iskin = 2 * (c * tsF ^ 3 / 12 + c * tsF * dS * dS);
                        const Icore = 0.02 * c * t ^ 3 * max(0, 1 - (2 * capT + 2 * tsF) / t);
                        const EI = Eud * Icap + Ew * Iskin + Etow * Icore;
                        const M = F * H * sF;
                        const kap = EI > 0 ? M / EI : 0;
                        const sigHere = EI > 0 ? Eud * M * (t / 2 - tsF) / EI / 1e6 : 0;
                        if (sigHere > sigMax)
                        {
                            sigMax = sigHere;
                            zSigMax = sF * H;
                        }
                        if (i == nZ)
                        {
                            sigBase = sigHere;
                            capForceP = EI > 0 ? Eud * M * dC / EI * wCap * capT : 0;
                            wCapP = wCap;
                        }
                        if (i < nZ)
                        {
                            const dz = H / nZ;
                            const slopeNew = slope + 0.5 * (kPrev + kap) * dz;
                            defl += 0.5 * (slope + slopeNew) * dz;
                            slope = slopeNew;
                        }
                        kPrev = kap;
                    }
                    // the plate hands that moment to the board through the two tracks, Track spacing
                    // apart: one track in tension, the other in compression, shared by the bolts of a row
                    const boltT = mastM.trackSpacing != undefined && mastM.trackSpacing > 0 ? F * H / mastM.trackSpacing / max(1, mastM.boltsPerRow) / 1000 : 0;   // kN per bolt
                    const boltNote = boltT > 0 ? ", track bolts " ~ fmt(boltT, 1) ~ " kN each (M / track spacing / bolts per row - the plate's pull-through and the board's inserts must take this)" : "";
                    // junction: the cap's force leaves the UD by shear over its run-out on the plate; every
                    // tab ply adds two bonded faces. Allowable = Shear allow / 2. Plate: a beam between the
                    // two tracks, loaded by the row force at the section's edge
                    const nIf = 1 + 2 * tabN;
                    const allowJ = definition.shearAllow / 2;
                    const shearJ = runOut > 0 && wCapP > 0 ? capForceP / (runOut / 1000 * wCapP * nIf) / 1e6 : 0;
                    const needRun = wCapP > 0 ? capForceP / (allowJ * 1e6 * wCapP * nIf) * 1000 : 0;
                    const tPl = mastM.plateThick != undefined ? mastM.plateThick : 0;
                    const tTopJ = mastM.thickTop != undefined ? mastM.thickTop : mastM.thick;
                    const sigPlate = boltT > 0 && tPl > 0 ? (F * H / mastM.trackSpacing) * max(mastM.trackSpacing / 2 - tTopJ / 2, 0) * (tPl / 2) / (mastM.plateLength * tPl ^ 3 / 12) / 1e6 : 0;
                    const fillet = mastM.rootFillet != undefined ? mastM.rootFillet * 1000 : 0;
                    const junctionNote = " | junction: cap force " ~ fmt(capForceP / 1000, 1) ~ " kN at the plate, shear " ~ fmt(shearJ, 1) ~ " MPa over " ~ fmt(runOut, 0) ~ " mm run-out with " ~ tabN ~
                        " tabs per face (allow " ~ fmt(allowJ, 0) ~ " = Shear allow / 2), needs " ~ fmt(needRun, 0) ~ " mm" ~
                        (shearJ > allowJ ? " - OVER: more Tab plies, Cap run-out, Top thick or Plate width" : "") ~
                        (fillet <= 0 ? "; no Root fillet on Foil mast - the plies fold through a sharp corner" : "; root fillet " ~ fmt(fillet, 0) ~ " mm") ~
                        (sigPlate > 0 ? "; plate bending " ~ fmt(sigPlate, 0) ~ " MPa between the tracks (woven takes about 300)" : "");
                    stiffMsg = " | stiffness (" ~ fmt(definition.mastSideG, 1) ~ " g side load, " ~ fmt(F, 0) ~ " N at the fuselage, plate fixed): fuselage-end deflection " ~ fmt(defl * 1000, 1) ~
                        " mm, moment at the plate " ~ fmt(F * H, 0) ~ " Nm, UD cap stress there " ~ fmt(sigBase, 0) ~ " MPa" ~
                        (sigMax > sigBase + 1 ? ", worst " ~ fmt(sigMax, 0) ~ " MPa at " ~ fmt(zSigMax * 1000, 0) ~ " mm above the fuselage (where the thickening starts: lower Thicken from % or raise Thickness in Foil mast)" : "") ~
                        (sigMax > 450 ? " - OVER the cap limit" : "") ~ boltNote ~ junctionNote;
                    println("STIFFNESS: mast side " ~ fmt(definition.mastSideG, 1) ~ " g at the fuselage, plate fixed: F=" ~ fmt(F, 0) ~ " N, deflection at the fuselage " ~ fmt(defl * 1000, 1) ~ " mm, cap stress at the plate " ~ fmt(sigBase, 0) ~ " MPa, worst " ~ fmt(sigMax, 0) ~ " MPa at " ~ fmt(zSigMax * 1000, 0) ~ " mm" ~
                        (boltT > 0 ? ", track bolt tension " ~ fmt(boltT, 2) ~ " kN each" : "") ~
                        ", junction: cap force " ~ fmt(capForceP / 1000, 2) ~ " kN, shear " ~ fmt(shearJ, 2) ~ " MPa over " ~ fmt(runOut, 0) ~ " mm x (1 + 2 x " ~ tabN ~ " tabs), allow " ~ fmt(allowJ, 1) ~ ", needs " ~ fmt(needRun, 0) ~ " mm, plate bending " ~ fmt(sigPlate, 0) ~ " MPa, fillet " ~ fmt(fillet, 0) ~ " mm");
                }
            }
            else
            {
                var loads;
                try silent { loads = getVariable(context, definition.moldSource == MoldSource.WING ? "foilWingLoads" : "foilStabLoads"); }
                if (loads == undefined)
                    stiffMsg = " | stiffness: add a Foil performance feature above for the deflection check";
                else
                {
                    const h = m.span / 2;
                    const nSt = size(tplCAt) - 1;
                    var slope = 0;
                    var defl = 0;
                    var kPrev = 0;
                    var sigRoot = 0;
                    var eiRoot = 0;
                    for (var i = 0; i <= nSt; i += 1)
                    {
                        const eta = capStartEta * i / nSt;
                        const t = tplTAt[i] / 1000;
                        const c = tplCAt[i] / 1000;
                        const capT = max(capF * (t - 2 * tsF), 0) / 2;
                        const wCap = capW * c;
                        const dC = t / 2 - tsF - capT / 2;
                        const Icap = 2 * (wCap * capT ^ 3 / 12 + wCap * capT * dC * dC);
                        const dS = 0.7 * (t / 2 - tsF / 2);
                        const Iskin = 2 * (c * tsF ^ 3 / 12 + c * tsF * dS * dS);
                        const Icore = 0.02 * c * t ^ 3 * max(0, 1 - (2 * capT + 2 * tsF) / t);
                        const EI = Eud * Icap + Ew * Iskin + Etow * Icore;
                        // published moment at 21 stations, interpolated
                        const pj = eta * 20;
                        const j0 = min(floor(pj), 19);
                        const M = loads.M[j0] + (loads.M[j0 + 1] - loads.M[j0]) * (pj - j0);
                        const kap = EI > 0 ? M / EI : 0;
                        if (i == 0)
                        {
                            eiRoot = EI;
                            sigRoot = EI > 0 ? Eud * M * (t / 2 - tsF) / EI / 1e6 : 0;
                        }
                        if (i > 0)
                        {
                            const dy = capStartEta * h / nSt;
                            const slopeNew = slope + 0.5 * (kPrev + kap) * dy;
                            defl += 0.5 * (slope + slopeNew) * dy;
                            slope = slopeNew;
                        }
                        kPrev = kap;
                    }
                    stiffMsg = " | stiffness at " ~ fmt(loads.n, 1) ~ " g: tip deflection " ~ fmt(defl * 1000, 1) ~ " mm (" ~ fmt(defl * 1000 / loads.n, 1) ~ " mm at 1 g, " ~
                        fmt(defl / h * 100, 1) ~ "% of the half span), root moment " ~ fmt(loads.M[0], 0) ~ " Nm, UD cap stress " ~ fmt(sigRoot, 0) ~ " MPa";
                    println("STIFFNESS: " ~ fmt(loads.n, 1) ~ " g: tip deflection " ~ fmt(defl * 1000, 1) ~ " mm (" ~ fmt(defl * 1000 / loads.n, 1) ~ " mm at 1 g), root EI " ~
                        fmt(eiRoot, 0) ~ " N m2, root cap stress " ~ fmt(sigRoot, 0) ~ " MPa");
                }
            }
        }

        // ---------------- block ----------------
        const f = definition.flangeWidth;
        // the mast is molded from a copy laid flat: rotated 90 deg about X (span -> -Y, thickness ->
        // Z) and dropped to zPart, where its mid-plane - the parting - then lies
        const zPart = -400 * millimeter;
        var moldPart = definition.part;
        var coreNote = "";
        var coreVent;       // core mold: the tip vents, cut with the cavity then removed
        if (!isMast && definition.coreType == CoreType.PRINTED && !coreMold)
        {
            // printed core (build 159): the same core body as the foam core, generated as a part and
            // split along the span to the longest printer axis, to print and glue end to end
            const skinFaceP = definition.skinPlies * tSkin * millimeter;
            const miniP = sectionDefFromModel(m);
            const coreP = moldCoreBody(context, id, m, miniP, vector(m.baseX, 0, m.baseZ) * meter, skinFaceP, capW, capF, tSkins * millimeter, definition.splitStations, definition.tipBias, 0 * meter);
            if (coreP == undefined)
                throw regenError("No room for a printed core: the section is thinner than the skins plus 0.6 mm everywhere - fewer Skin plies, a lighter skin or a thicker section", ["skinPlies", "skinGsm"]);
            const bed = max(definition.printerX, definition.printerY) - 2 * definition.tileMargin;
            const cbox = evBox3d(context, { "topology" : coreP.body, "tight" : true });
            const spanC = cbox.maxCorner[1] - cbox.minCorner[1];
            const nSeg = max(1, ceil(spanC / bed));
            var cutsP = [];
            for (var k = 1; k < nSeg; k += 1)
            {
                const yc = cbox.minCorner[1] + spanC * k / nSeg;
                cutsP = append(cutsP, moldCut(context, id + ("coreCut" ~ k), coreP.body, vector(0 * meter, yc, 0 * meter), Y_DIRECTION, cbox.minCorner - vector(1, 1, 1) * 50 * millimeter, cbox.maxCorner + vector(1, 1, 1) * 50 * millimeter));
            }
            if (size(cutsP) > 0)
                opDeleteBodies(context, id + "coreCutTools", { "entities" : qUnion(cutsP) });
            // dowel holes across each joint (user: the segments need keying): a hole along the span,
            // 15 mm into each segment, at the section's thickest point where the core is at least
            // 4 mm thick under the cap groove; diameter half that thickness, 3 to 8 mm, for a carbon
            // or hardwood rod. Not in the winglet (the joint would not be square to the span there)
            var dowels = [];
            var dowelNote = "";
            for (var k = 1; k < nSeg; k += 1)
            {
                const yc = cbox.minCorner[1] + spanC * k / nSeg;
                const etaD = min(abs(yc) / (m.span / 2 * meter), 1);
                if (m.wingletOn == 1 && etaD > m.wingletEta)
                    continue;
                const hD = m.span / 2 * meter;
                const chord0 = m.c0 * meter * chordFactor(m, etaD);
                const tailAdd = m.c0 * meter * tailFactor(m, etaD);
                const thick0 = (m.rootT + (m.tipT - m.rootT) * etaD ^ m.thicknessExp) * (chord0 - tailAdd) / chord0;
                const twist = (m.incidence - m.washout * etaD ^ m.washoutExp) * radian;
                const chordBase = (chord0 - tailAdd) / capPlanFactor(m, etaD);
                const alignShift = (m.pivotFrac - m.align) * (chordBase - m.c0 * meter) + m.pivotFrac * tailAdd + (0.5 - m.pivotFrac) * (chordBase - (chord0 - tailAdd));
                const bump = bumpOffset(m, etaD, hD);
                const chord = chord0 + bump;
                const thick = thick0 * chord0 / chord;
                const xOff = m.sweepTip * meter * etaD ^ m.sweepExp + alignShift - (1 - m.pivotFrac) * bump;
                const zOff = wingletFrame(m, etaD).z;
                const sec = buildSectionAt(miniP, thick, min(m.teThick * meter, 0.03 * chord) / chord, 40, sectionWeightAt(miniP, etaD));
                const placed = placeSection(sec, chord, m.pivotFrac, cos(twist), sin(twist));
                const np = size(placed);
                var xT = 0 * meter;
                var zT = 0 * meter;
                var tMax = 0 * meter;
                for (var q = 0; q < 40; q += 1)
                {
                    const xs = placed[0][0] + (placed[(np + 1) / 2 - 1][0] - placed[0][0]) * (q + 0.5) / 40;
                    var zLo = 1 * meter;
                    var zHi = -1 * meter;
                    for (var i = 0; i < np; i += 1)
                    {
                        const p = placed[i];
                        const r = placed[(i + 1) % np];
                        if ((p[0] - xs) * (r[0] - xs) <= 0 * meter * meter && abs(r[0] - p[0]) > 1e-9 * meter)
                        {
                            const z = p[1] + (r[1] - p[1]) * ((xs - p[0]) / (r[0] - p[0]));
                            zLo = min(zLo, z);
                            zHi = max(zHi, z);
                        }
                    }
                    if (zHi - zLo > tMax)
                    {
                        tMax = zHi - zLo;
                        xT = xs;
                        zT = 0.5 * (zLo + zHi);
                    }
                }
                const capTd = capF * max(thick * chord - tSkins * millimeter, 0 * meter) / 2;
                const tCore = tMax - 2 * skinFaceP - 2 * capTd;
                if (tCore < 4 * millimeter)
                    continue;
                const dD = min(8 * millimeter, 0.5 * tCore);
                const cD = vector(m.baseX * meter + xOff + xT, yc, m.baseZ * meter + zOff + zT);
                dowels = append(dowels, moldPin(context, id + ("coreDowel" ~ k), cD - vector(0 * meter, 15 * millimeter, 0 * meter), cD + vector(0 * meter, 15 * millimeter, 0 * meter), dD / 2));
                dowelNote = dowelNote ~ (dowelNote == "" ? "" : ", ") ~ fmt(dD / millimeter, 1) ~ " mm at y " ~ fmt(yc / millimeter, 0);
            }
            if (size(dowels) > 0)
            {
                opBoolean(context, id + "coreDowelCut", {
                            "tools" : qUnion(dowels),
                            "targets" : qBodyType(qHasAttribute("foilCoreBody"), BodyType.SOLID),
                            "operationType" : BooleanOperationType.SUBTRACTION
                        });
            }
            const segs = evaluateQuery(context, qBodyType(qHasAttribute("foilCoreBody"), BodyType.SOLID));
            for (var k = 0; k < size(segs); k += 1)
                setProperty(context, { "entities" : segs[k], "propertyType" : PropertyType.NAME, "value" : (definition.moldSource == MoldSource.WING ? "Wing" : "Stab") ~ " printed core " ~ (k + 1) ~ " of " ~ size(segs) });
            coreNote = " | PRINTED CORE: " ~ size(segs) ~ " segment" ~ (size(segs) == 1 ? "" : "s") ~ " for a " ~ fmt(bed / millimeter, 0) ~ " mm bed (sections less " ~ fmt(definition.skinPlies * tSkin, 2) ~
                " mm of skin each face, cap grooves " ~ fmt(capW * 100, 0) ~ "% chord wide)" ~
                (dowelNote == "" ? (nSeg > 1 ? "; joints too thin for dowels" : "") : "; dowel holes 30 mm long across the joints, " ~ dowelNote ~ " (carbon or hardwood rod)") ~
                "; print flat, glue end to end on a flat table, then lay up in this mold";
        }
        if (coreMold)
        {
            // the foam core: sections offset inward by one face's skins, the UD caps' grooves cut in
            const skinFace = definition.skinPlies * tSkin * millimeter;
            const miniC = sectionDefFromModel(m);
            const coreR = moldCoreBody(context, id, m, miniC, vector(m.baseX, 0, m.baseZ) * meter, skinFace, capW, capF, tSkins * millimeter, definition.splitStations, definition.tipBias, f + 30 * millimeter);
            if (coreR == undefined)
                throw regenError("No room for a foam core: the section is thinner than the skins plus 0.6 mm everywhere - fewer Skin plies, a lighter skin or a thicker section", ["skinPlies", "skinGsm"]);
            setProperty(context, { "entities" : coreR.body, "propertyType" : PropertyType.NAME, "value" : (definition.moldSource == MoldSource.WING ? "Wing" : "Stab") ~ " foam core" });
            moldPart = coreR.body;
            coreVent = coreR.vent;
            coreNote = " | CORE MOLD: cavity is the foam core (sections less " ~ fmt(definition.skinPlies * tSkin, 2) ~ " mm of skin each face, cap grooves " ~ fmt(capW * 100, 0) ~ "% chord wide), open at both tips so a poured foam can expand out; the core body is kept as a part";
        }
        // stab with the pad underneath (Pad side Bottom): the parting, prism and cones are written for
        // a pad on top, so the mold is built on a copy mirrored in Z about the stab pivot - its pad is
        // on top and the model, the mount map and the section are mirrored to match. A Y-symmetric
        // stab molded upside down and turned over IS the stab (build 130: the pad-under stab's
        // curtain loft failed on build 128)
        var flipZ = false;
        var flipNote = "";
        if (!coreMold && definition.moldSource == MoldSource.STAB && stabRoot != undefined && stabRoot.padOn == 1 && stabRoot.padSide == -1)
        {
            flipZ = true;
            const zFlip = m.baseZ * meter;
            opPattern(context, id + "stabFlip", {
                        "entities" : definition.part,
                        "transforms" : [mirrorAcross(plane(vector(0 * meter, 0 * meter, zFlip), Z_DIRECTION))],
                        "instanceNames" : ["f"]
                    });
            moldPart = qCreatedBy(id + "stabFlip", EntityType.BODY);
            m.incidence = -m.incidence;
            m.washout = -m.washout;
            m.tipDrop = -m.tipDrop;
            m.rootDihedral = -m.rootDihedral;
            m.camber = -m.camber;
            m.inverted = m.inverted == 1 ? 0 : 1;
            var sr = stabRoot;
            sr.padSide = 1;
            sr.padZ = 2 * m.baseZ - stabRoot.padZ;
            sr.bottomZ = 2 * m.baseZ - stabRoot.topZ;
            sr.topZ = 2 * m.baseZ - stabRoot.bottomZ;
            var cm = [];
            for (var cp in stabRoot.contour)
                cm = append(cm, [cp[0], 2 * m.baseZ - cp[1]]);
            sr.contour = cm;
            stabRoot = sr;
            flipNote = " | pad underneath in the design: molded upside down (pad up) - turn the finished part over";
        }
        if (isMast)
        {
            opPattern(context, id + "mastCopy", {
                        "entities" : definition.part,
                        "transforms" : [transform(vector(0 * meter, 0 * meter, zPart)) * rotationAround(line(vector(0, 0, 0) * meter, X_DIRECTION), 90 * degree)],
                        "instanceNames" : ["flat"]
                    });
            moldPart = qCreatedBy(id + "mastCopy", EntityType.BODY);
        }
        const pbox = evBox3d(context, { "topology" : moldPart, "tight" : true });
        var lo = vector(pbox.minCorner[0] - f, pbox.minCorner[1] - f, pbox.minCorner[2] - definition.baseThick);
        const hi = vector(pbox.maxCorner[0] + f, pbox.maxCorner[1] + f, pbox.maxCorner[2] + definition.baseThick);
        // mast: the two halves stop at the plate's underside (0.5 mm into the plate, a locating
        // recess); the plate itself is formed by a third piece, a tray, built after the cavity cut.
        // Molding the plate in the halves made a 10 mm wide, 60 mm deep slot in each (user: three
        // parts, left, right and a top piece for the plate)
        if (isMast)
            lo[1] = -(mastM.baseZ + mastM.height) * meter - 0.5 * millimeter;

        // ---------------- parting surface: each section's camber line, extended to the block ----------------
        // The camber (mean) line lies inside the section everywhere, so a sheet through it meets the
        // part surface exactly at the leading and trailing edges - no tongue of mold under a cambered
        // nose or tail, whatever the camber, twist or droop. Beyond the LE/TE it continues straight
        // along the local chord direction out through the flange. Where the wing's tube socket
        // nacelle sits (a body of revolution aft of the root TE), the aft extension is aimed through
        // the nacelle axis instead, so the round section also splits on its diameter.
        const e = 5 * millimeter;
        var curtain = [];
        var curtainDown = [];
        var outLE = [];     // planform outline in plan (x, y) for the pinch-off groove, -Y to +Y
        var outTE = [];
        const seam = 0.4 * millimeter;
        var mini = {};
        var h = 1 * meter;
        var base = vector(0, 0, 0) * meter;
        var padMap;         // the stab's mount (foilStabRoot) when the parting must follow its pad plane
        var wTab;           // winglet parting table (build 151), when the part has a winglet
        var wY0 = 1 * meter;    // |y| where the winglet's bend starts; stations beyond it use wTab
        if (isMast)
        {
            // flat parting at zPart: the curtain is one box up to it; outline = mast rectangle + plate
            moldBox(context, id + "curtainM", vector(lo[0] - e, lo[1] - e, lo[2] - e), vector(hi[0] + e, hi[1] + e, zPart));
            curtain = [qCreatedBy(id + "curtainM", EntityType.BODY)];
            if (definition.grooveOn)
            {
                moldBox(context, id + "curtainDownM", vector(lo[0] - 2 * e, lo[1] - 2 * e, lo[2] - 2 * e), vector(hi[0] + 2 * e, hi[1] + 2 * e, zPart - definition.grooveDepth));
                curtainDown = [qCreatedBy(id + "curtainDownM", EntityType.BODY)];
            }
            const leX = mastM.leX * meter;
            const teX = (mastM.leX + mastM.chord) * meter;
            const leTop = (mastM.leXTop != undefined ? mastM.leXTop : mastM.leX) * meter;
            const teTop = leTop + (mastM.chordTop != undefined ? mastM.chordTop : mastM.chord) * meter;
            const yBase = -mastM.baseZ * meter;
            const yTopM = -(mastM.baseZ + mastM.height) * meter;
            outLE = [vector(leTop, lo[1] - 10 * millimeter), vector(leTop, yTopM)];      // closes outside the halves, so no groove across the root
            outTE = [vector(teTop, lo[1] - 10 * millimeter), vector(teTop, yTopM)];
            if (mastM.podOn == 1)
            {
                // the pod laid flat: a bar across the plan at y' = -podZ, Motor dia wide, nose to rear face
                const yP = -mastM.podZ * meter;
                const rP = mastM.podDia / 2 * meter;
                const xN = mastM.podNoseX * meter;
                const xRp = mastM.podRearX * meter;
                // the mast's edges at the pod band's two edges (the taper makes them a trapezoid)
                const sA = min(max((yP - rP - yBase) / (yTopM - yBase), 0), 1);
                const sB = min(max((yP + rP - yBase) / (yTopM - yBase), 0), 1);
                const leA = leX + (leTop - leX) * sA;
                const leB = leX + (leTop - leX) * sB;
                const teA = teX + (teTop - teX) * sA;
                const teB = teX + (teTop - teX) * sB;
                outLE = concatenateArrays([outLE, [vector(leA, yP - rP), vector(min(xN, leA), yP - rP), vector(min(xN, leB), yP + rP), vector(leB, yP + rP)]]);
                outTE = concatenateArrays([outTE, [vector(teA, yP - rP), vector(xRp, yP - rP), vector(xRp, yP + rP), vector(teB, yP + rP)]]);
            }
            outLE = append(outLE, vector(leX, yBase));
            outTE = append(outTE, vector(teX, yBase));
        }
        else
        {
        mini = sectionDefFromModel(m);
        h = m.span / 2 * meter;
        base = vector(m.baseX, 0, m.baseZ) * meter;
        var etas = [];
        for (var i = 0; i < definition.splitStations; i += 1)
            etas = append(etas, 1 - (1 - i / (definition.splitStations - 1)) ^ definition.tipBias);
        if (sockOn)
        {
            const rN = sock.nacelleDia / 2 * meter;
            if (rN < h)
                etas = append(etas, rN / h);
        }
        if (!isMast && m.tipOn == 1)
        {
            // twelve parting stations across the section blend (build 167). Build 169 tried adding
            // every loft station instead and broke molds that had passed; reverted in 171
            for (var k = 0; k <= 12; k += 1)
                etas = append(etas, m.blendFrom + (1 - m.blendFrom) * k / 12);
        }
        if (!isMast && m.bumpOn == 1)
        {
            // six parting stations per bump pitch, as the foil itself has: a ruled parting between a
            // peak and a trough would cut the corner of the wavy leading edge
            var yb = m.bumpFrom * h;
            const yEnd = min(m.bumpTo * h, h - 0.5 * millimeter);
            while (yb <= yEnd)
            {
                etas = append(etas, yb / h);
                yb += m.bumpPitch * meter / 6;
            }
        }
        // stab mount: two stations just INSIDE the pad's edge, so the parting steps from the pad plane
        // to the camber line over 0.4 mm and that step face lies inside the part, where the cavity cut
        // removes it. Build 87 straddled the edge (+/- 0.4 mm) and left a 0.4 mm lip of the lower half
        // overhanging the skin beside the pad - unattached slivers, and an undercut
        padMap = (!coreMold && definition.moldSource == MoldSource.STAB && stabRoot != undefined && stabRoot.padOn == 1 && stabRoot.padSide != undefined && stabRoot.padRampPct != undefined) ? stabRoot : undefined;
        etas = sort(etas, function(a, b) { return a - b; });
        var uniq = [];
        for (var eta in etas)
            if (size(uniq) == 0 || eta - uniq[size(uniq) - 1] > 1e-4)
                uniq = append(uniq, eta);
        etas = uniq;
        // world y per curve, root outwards; the beyond-tip curve repeats the tip section. No station
        // sits exactly on the part's own seams - the root plane (mirror join edges) or the tip end
        // face plane: a sheet seam lying in a face or on edges of the part makes the boolean invalid
        var plus = [];
        for (var eta in etas)
            plus = append(plus, [eta, eta == 0 ? seam : (eta == 1 ? h - seam : h * eta)]);
        if (!isMast && m.wingletOn == 1)
        {
            // stations through the bend (its start and four along the arc) so the ruled curtain
            // follows the winglet, the tip station just inside the tip, and one beyond the tip
            // continued straight along the winglet, far enough in y to clear the block
            const arcEta = m.wingletR * meter * m.wingletAngle / h;
            const tipF = wingletFrame(m, 1);
            const sEnd = h + max((hi[1] + e - tipF.y) / max(cos(tipF.phi), 0.2), 5 * millimeter) + 5 * millimeter;
            wTab = moldWingletTable(m, mini, base, sEnd);
            wY0 = wTab.yStart;
            // inboard stations keep their y = eta h; those past the bend take the path's y; the eta 1
            // station moves just inside the tip; one station beyond the tip at the block edge
            var inner = [];
            for (var p in plus)
                if (p[0] < 1 - 1e-6)
                    inner = append(inner, [p[0], p[0] > m.wingletEta ? wingletFrame(m, p[0]).y : p[1]]);
            plus = inner;
            for (var k = 0; k <= 4; k += 1)
            {
                const ek = min(m.wingletEta + arcEta * k / 4, 1 - seam / h);
                plus = append(plus, [ek, wingletFrame(m, ek).y]);
            }
            plus = append(plus, [1 - seam / h, wingletFrame(m, 1 - seam / h).y]);
            plus = append(plus, [1, hi[1] + e]);
            plus = sort(plus, function(a, b) { return (a[1] - b[1]) / meter; });
            var pu = [];
            for (var p in plus)
                if (size(pu) == 0 || p[1] - pu[size(pu) - 1][1] > 0.2 * millimeter)
                    pu = append(pu, p);
            plus = pu;
        }
        else
            plus = append(plus, [1, hi[1] + e]);
        var rows = [];
        if (m.mirror == 1)
        {
            for (var i = size(plus) - 1; i >= 0; i -= 1)
                rows = append(rows, [plus[i][0], -plus[i][1]]);
        }
        else
            rows = append(rows, [0, lo[1] - e]);
        rows = concatenateArrays([rows, plus]);

        // Built as a SOLID under the camber surface (closed planar profiles: camber-line spline plus
        // three lines down to a floor below the block - the same sketch-and-loft pattern as the foil
        // itself), then booleaned with the block: lower half = block AND curtain, upper = block minus
        // lower. A surface loft through the open curves was refused by Onshape (LOFT_INVALID).
        const zFloor = lo[2] - e;
        var profiles = [];
        var sketchBodies = [];
        for (var i = 0; i < size(rows); i += 1)
        {
            const eta = rows[i][0];
            const y = rows[i][1];
            var pp;
            if (wTab != undefined && abs(y) > wY0 + 0.01 * millimeter)
                pp = moldPartingPointsWinglet(wTab, abs(y), y < 0 * meter ? -1 : 1, lo[0] - e, hi[0] + e);
            else
                pp = moldPartingPointsPad(m, mini, eta, y, base, lo[0] - e, hi[0] + e, sockOn && abs(y) <= sock.nacelleDia / 2 * meter * 1.0001 ? sock : undefined, undefined);
            if (abs(y) <= h + seam)
            {
                var teX = pp.camber[size(pp.camber) - 1][0];
                if (sockOn)
                {
                    // nacelle in plan: full rear-face x within its radius, faired back to the TE over R + 20 mm
                    const rN = sock.nacelleDia / 2 * meter;
                    const sBump = min(max(1 - (abs(y) - rN) / (rN + 20 * millimeter), 0), 1);
                    teX = teX + (max(sock.rearX * meter, teX) - teX) * sBump;
                }
                if (padMap != undefined && padMap.tailOn == 1 && abs(y) <= padMap.padWidth / 2 * meter)
                {
                    // tail fairing plan: half-width hE + (hW - hE)(1 - t)^exp -> the end x at this y
                    const hW = padMap.padWidth / 2 * meter;
                    const hE = padMap.tailEndWidth / 2 * meter;
                    const tt = abs(y) <= hE ? 1 : 1 - ((abs(y) - hE) / (hW - hE)) ^ (1 / padMap.tailExp);
                    teX = max(teX, padMap.teX * meter + padMap.tailLength * meter * tt);
                }
                outLE = append(outLE, vector(pp.camber[0][0], y));
                outTE = append(outTE, vector(teX, y));
            }
            const sid = id + ("pc" ~ i);
            var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(0 * meter, y, 0 * meter), -Y_DIRECTION, X_DIRECTION) });
            // sketch (u, v) = world (x, z): horizontal line to the LE, camber spline LE -> TE,
            // horizontal line from the TE, then down, floor, up. LE and TE are vertices so the loft
            // matches them station to station and the parting tracks the camber line in between
            var sp = [];
            for (var p in pp.camber)
                sp = append(sp, vector(p[0], p[2]));
            const front = vector(pp.front[0], pp.front[2]);
            const back = vector(pp.aft[0], pp.aft[2]);
            skLineSegment(sk, "front", { "start" : front, "end" : sp[0] });
            skFitSpline(sk, "camber", { "points" : sp });
            skLineSegment(sk, "aft", { "start" : sp[size(sp) - 1], "end" : back });
            skLineSegment(sk, "down", { "start" : back, "end" : vector(back[0], zFloor) });
            skLineSegment(sk, "floor", { "start" : vector(back[0], zFloor), "end" : vector(front[0], zFloor) });
            skLineSegment(sk, "up", { "start" : vector(front[0], zFloor), "end" : front });
            skSolve(sk);
            profiles = append(profiles, qSketchRegion(sid));
            sketchBodies = append(sketchBodies, qCreatedBy(sid, EntityType.BODY));
        }
        // one ruled loft per pair of neighbouring stations: a two-profile loft cannot fold, which an
        // interpolating loft through 30-odd profiles of very different proportions did (LOFT_INVALID)
        for (var i = 0; i + 1 < size(profiles); i += 1)
        {
            const segId = id + ("seg" ~ i);
            opLoft(context, segId, { "profileSubqueries" : [profiles[i], profiles[i + 1]] });
            curtain = append(curtain, qCreatedBy(segId, EntityType.BODY));
        }
        // stab mount: the parting over the pad's plan is the pad-side skin (nose, ramp, pad plane out
        // to the block edge), as a prism with exactly vertical walls 0.05 mm inside the pad's own
        // walls, added to the curtain. The whole section, the pad walls and the tail fairing then sit
        // in the half away from the pad and the other half forms only the flat face (Axis layout).
        // Build 87/88 did this with extra stations at the pad edge, whose sloped step face showed as
        // slivers along the T; a prism has no such face
        if (padMap != undefined)
        {
            const pp = moldPartingPointsPad(m, mini, seam / h, 0 * meter, base, lo[0] - e, hi[0] + e, undefined, padMap);
            // 0.2 mm inside the pad wall: build 89's 0.05 mm left near-coincident faces that made the
            // lower cavity cut BOOLEAN_INVALID; build 88's 0.1-0.5 mm step cut cleanly. The lower half's
            // T is 0.4 mm narrower than the pad and the upper half's slot beside the pad is 0.2 mm,
            // which prints solid and only marks the pad's top edge
            const hpW = padMap.padWidth / 2 * meter - 0.2 * millimeter;
            var padProfiles = [];
            const yP = [-hpW, hpW];
            for (var i = 0; i < 2; i += 1)
            {
                const sid = id + ("padPrism" ~ i);
                var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(0 * meter, yP[i], 0 * meter), -Y_DIRECTION, X_DIRECTION) });
                // the prism top sits 0.15 mm under the pad-side skin (toward the section), so no mold
                // face coincides with the part's flat pad face or its ramp: the lower cavity cut was
                // BOOLEAN_INVALID with them coincident. The upper half then forms the top 0.15 mm of
                // the pad - a recess too shallow to print, so the halves still close on the pad face
                const dip = 0.15 * millimeter * (padMap.padSide == 1 ? -1 : 1);
                var sp = [];
                for (var q in pp.camber)
                    sp = append(sp, vector(q[0], q[2] + dip));
                const front = vector(pp.front[0], pp.front[2] + dip);
                const back = vector(pp.aft[0], pp.aft[2] + dip);
                skLineSegment(sk, "front", { "start" : front, "end" : sp[0] });
                skFitSpline(sk, "skin", { "points" : sp });
                skLineSegment(sk, "aft", { "start" : sp[size(sp) - 1], "end" : back });
                skLineSegment(sk, "down", { "start" : back, "end" : vector(back[0], zFloor) });
                skLineSegment(sk, "floor", { "start" : vector(back[0], zFloor), "end" : vector(front[0], zFloor) });
                skLineSegment(sk, "up", { "start" : vector(front[0], zFloor), "end" : front });
                skSolve(sk);
                padProfiles = append(padProfiles, qSketchRegion(sid));
                sketchBodies = append(sketchBodies, qCreatedBy(sid, EntityType.BODY));
            }
            opLoft(context, id + "padPrismLoft", { "profileSubqueries" : padProfiles });
            curtain = append(curtain, qCreatedBy(id + "padPrismLoft", EntityType.BODY));
        }
        opDeleteBodies(context, id + "deleteCurves", { "entities" : qUnion(sketchBodies) });
        if (definition.grooveOn)
        {
            // the same curtain lowered by Groove depth: its top is the groove floor
            opPattern(context, id + "curtainDown", {
                        "entities" : qUnion(curtain),
                        "transforms" : [transform(vector(0 * meter, 0 * meter, -definition.grooveDepth))],
                        "instanceNames" : ["d"]
                    });
            curtainDown = [qCreatedBy(id + "curtainDown", EntityType.BODY)];
        }
        }

        // ---------------- halves and cavity ----------------
        // upper = block minus everything under the camber surface; lower = a second block minus upper
        // every solid of this feature EXCEPT the lowered curtain kept for the groove: it touches the
        // block bottom, so moldHalves took it for a lower body and the cavity and channel cuts carved
        // it too - the pod pocket left a core in it that was severed, joined into the pod plug, and
        // gave the plug the curtain's identity, so the groove's gFloor consumed the plug as a tool
        // the mold's own solids: not the pinch-off tool, and not a core body this feature made (the
        // core mold's cavity master, or the printed core's segments), which live on as parts
        const solids = qSubtraction(qBodyType(qCreatedBy(id, EntityType.BODY), BodyType.SOLID),
                                    qUnion([qCreatedBy(id + "curtainDown", EntityType.BODY), qCreatedBy(id + "curtainDownM", EntityType.BODY), qHasAttribute("foilCoreBody")]));
        moldBox(context, id + "blockA", lo, hi);
        // bag closing: round the block's outer edges before anything is cut from it, so every tile
        // inherits them and the joint and parting faces stay sharp
        const roundOn = definition.closing == MoldClosing.BAG && definition.edgeRound > 0.1 * millimeter;
        var roundFailed = false;
        if (roundOn)
        {
            try silent { opFillet(context, id + "roundA", { "entities" : qCreatedBy(id + "blockA", EntityType.EDGE), "radius" : definition.edgeRound }); }
            catch { roundFailed = true; }
        }
        opBoolean(context, id + "upperCut", {
                    "tools" : qUnion(curtain),
                    "targets" : qCreatedBy(id + "blockA", EntityType.BODY),
                    "operationType" : BooleanOperationType.SUBTRACTION
                });
        moldBox(context, id + "blockB", lo, hi);
        if (roundOn)
        {
            try silent { opFillet(context, id + "roundB", { "entities" : qCreatedBy(id + "blockB", EntityType.EDGE), "radius" : definition.edgeRound }); }
            catch { roundFailed = true; }
        }
        var hv = moldHalves(context, solids, lo, hi);      // upper only: the fresh block touches both faces
        opBoolean(context, id + "lowerCut", {
                    "tools" : hv.upper,
                    "targets" : qCreatedBy(id + "blockB", EntityType.BODY),
                    "operationType" : BooleanOperationType.SUBTRACTION,
                    "keepTools" : true
                });
        // with the tube socket and Socket plug on, the cavity is cut with a copy of the wing whose bore
        // and pin holes are filled, so the halves mold the nacelle's outside only
        const plugOn = sockOn && definition.plugOn;
        var cavTool = coreVent != undefined ? qUnion([moldPart, coreVent]) : moldPart;
        if (plugOn)
        {
            if (definition.plugExt > f - 3 * millimeter)
                throw regenError("Plug extension must be at most Flange width - 3 mm - the plug channel lives in the rear flange", ["plugExt", "flangeWidth"]);
            opPattern(context, id + "partFill", {
                        "entities" : definition.part,
                        "transforms" : [identityTransform()],
                        "instanceNames" : ["c"]
                    });
            const zAx = sock.axisZ * meter;
            const xR = sock.rearX * meter;
            var fills = [qCreatedBy(id + "partFill", EntityType.BODY)];
            fills = append(fills, moldPin(context, id + "fillBore", vector(xR - sock.depth * meter - 1 * millimeter, 0 * meter, zAx), vector(xR + 1 * millimeter, 0 * meter, zAx), sock.boreDia / 2 * meter + 0.3 * millimeter));
            const pinSpan = (sock.pins - 1) * sock.pinPitch * meter;
            for (var j = 0; j < sock.pins; j += 1)
            {
                const px = sock.pinCenterX * meter - pinSpan / 2 + j * sock.pinPitch * meter;
                fills = append(fills, moldPin(context, id + ("fillPin" ~ j), vector(px, 0 * meter, zAx - sock.nacelleDia * meter), vector(px, 0 * meter, zAx + sock.nacelleDia * meter), sock.pinDia / 2 * meter + 0.3 * millimeter));
            }
            opBoolean(context, id + "fillJoin", { "tools" : qUnion(fills), "operationType" : BooleanOperationType.UNION });
            cavTool = qCreatedBy(id + "partFill", EntityType.BODY);
        }
        // one half at a time, so a failure names the half. The usual cause is the part's tip: the cap
        // thins the section to Cap end % of an already thin tip chord, and a boolean through a
        // sliver a few hundredths of a millimetre thick is invalid - and unmouldable in carbon anyway
        const endChord = isMast ? 0 : m.c0 * chordFactor(m, m.capEta == undefined ? 1 : m.capEta) * 1000;   // chord at the cap start
        const tipT = isMast ? mastM.te * 1000 : m.tipT * endChord;                                  // mm at the cap start (mast: its TE)
        const capEndT = isMast ? tipT : tipT * (m.capOn == 1 ? m.capEnd : 1);                       // mm at the very end of the cap (with plan rounding the thickness law is divided by the chord shrink, so this holds either way)
        const tipAdvice = " Tip section is " ~ fmt(tipT, 2) ~ " mm thick at the cap start, " ~ fmt(capEndT, 2) ~ " mm at its end: raise End ratio (or turn on Min tip), Cap end % or Tip thick % in the " ~
            (definition.moldSource == MoldSource.WING ? "Foil wing" : "Foil stabiliser") ~ " feature (1 mm or more molds reliably), or try more Split stations";
        hv = moldHalves(context, solids, lo, hi);
        try
        {
            opBoolean(context, id + "cavityUpper", {
                        "tools" : cavTool,
                        "targets" : hv.upper,
                        "operationType" : BooleanOperationType.SUBTRACTION,
                        "keepTools" : true
                    });
        }
        catch
        {
            throw regenError("Could not cut the cavity into the UPPER half." ~ tipAdvice, ["splitStations"]);
        }
        hv = moldHalves(context, solids, lo, hi);
        try
        {
            opBoolean(context, id + "cavityLower", {
                        "tools" : cavTool,
                        "targets" : hv.lower,
                        "operationType" : BooleanOperationType.SUBTRACTION,
                        "keepTools" : true
                    });
        }
        catch
        {
            throw regenError("Could not cut the cavity into the LOWER half." ~ tipAdvice, ["splitStations"]);
        }
        if (flipZ)
            opDeleteBodies(context, id + "deleteStabFlip", { "entities" : moldPart });
        if (coreVent != undefined)
            opDeleteBodies(context, id + "deleteCoreVent", { "entities" : coreVent });

        // from here on the halves (and later the tiles) are found by geometry after every operation -
        // a body touching the block's top face is upper, one touching the bottom is lower - because a
        // query frozen before a boolean can come back empty after it (build 59 and 61 failures)

        var trayNote = "";
        if (isMast)
        {
            // plate tray: the third piece. Plate outline + flange in x, the block's full height in z',
            // Base thickness beyond the plate's board face in y', opening at the halves' end faces. The
            // mast copy cuts the plate pocket into it; the plate's bolt holes come out as pins
            // sized from the measured plate (plateAct, flat frame: y' = -z, z' = y + zPart); the bolt
            // pattern stays on the Foil mast's own centre and rows
            const pA = plateAct != undefined;
            const xcNom = (mastM.plateXc != undefined ? mastM.plateXc : mastM.leX + mastM.chord / 2) * meter;
            const xcT = pA ? (plateAct.x0 + plateAct.x1) / 2 : xcNom;
            const hlT = pA ? (plateAct.x1 - plateAct.x0) / 2 : mastM.plateLength / 2 * meter;
            const hwT = pA ? (plateAct.y1 - plateAct.y0) / 2 : mastM.plateWidth / 2 * meter;
            const zcT = pA ? (plateAct.y0 + plateAct.y1) / 2 + zPart : zPart;
            const yPlateT = pA ? -plateAct.zBoard : -(mastM.baseZ + mastM.height + mastM.plateThick) * meter;
            const tPlateT = -yPlateT - (mastM.baseZ + mastM.height) * meter;     // the plate's thickness as modelled
            moldBox(context, id + "plateTray", vector(xcT - hlT - f, yPlateT - definition.baseThick, lo[2]), vector(xcT + hlT + f, lo[1], hi[2]));
            setAttribute(context, { "entities" : qCreatedBy(id + "plateTray", EntityType.BODY), "name" : "foilPlateTray", "attribute" : 1 });
            opBoolean(context, id + "trayCut", {
                        "tools" : moldPart,
                        "targets" : qHasAttribute("foilPlateTray"),
                        "operationType" : BooleanOperationType.SUBTRACTION,
                        "keepTools" : true
                    });
            // the copy's holes leave pins carrying the countersink at their free end (the mast's
            // countersinks are on its underside, which faces the tray's opening): mushroom heads that
            // would lock the plate in (user). Clear each of them with a cylinder of the head diameter
            // + 0.3 mm (a box over the whole pocket, build 172 and before, squared off any edited
            // plate outline) and stand straight pins instead, 0.5 mm under the bolt diameter, on the
            // mast's own pattern; countersink after cure
            var nPins = 0;
            if (mastM.trackSpacing != undefined)
            {
                const rowSpan = (mastM.boltsPerRow - 1) * mastM.plateBoltPitch * meter;
                const rPin = mastM.plateBoltDia / 2 * meter - 0.25 * millimeter;
                const rClear = (mastM.plateHeadDia != undefined && mastM.countersink == 1 ? mastM.plateHeadDia / 2 : mastM.plateBoltDia / 2) * meter + 0.3 * millimeter;
                var pins = [qHasAttribute("foilPlateTray")];
                var cleans = [];
                for (var row = 0; row < 2; row += 1)
                {
                    const zRow = zPart + (row == 0 ? -1 : 1) * mastM.trackSpacing / 2 * meter;    // world Y -> z'
                    for (var j = 0; j < mastM.boltsPerRow; j += 1)
                    {
                        const bx = xcNom - rowSpan / 2 + j * mastM.plateBoltPitch * meter;
                        cleans = append(cleans, moldPin(context, id + ("trayClean" ~ nPins), vector(bx, yPlateT + 0.05 * millimeter, zRow), vector(bx, lo[1] + e, zRow), rClear));
                        pins = append(pins, moldPin(context, id + ("trayPin" ~ nPins), vector(bx, yPlateT - 0.5 * millimeter, zRow), vector(bx, lo[1], zRow), rPin));
                        nPins += 1;
                    }
                }
                opBoolean(context, id + "trayCleanCut", {
                            "tools" : qUnion(cleans),
                            "targets" : qHasAttribute("foilPlateTray"),
                            "operationType" : BooleanOperationType.SUBTRACTION
                        });
                opBoolean(context, id + "trayPinJoin", { "tools" : qUnion(pins), "operationType" : BooleanOperationType.UNION });
            }
            const trayX = 2 * (hlT + f);
            const trayZ = hi[2] - lo[2];
            trayNote = " | plate tray " ~ fmt(trayX / millimeter, 0) ~ " x " ~ fmt(trayZ / millimeter, 0) ~ " x " ~ fmt((lo[1] - yPlateT + definition.baseThick) / millimeter, 0) ~
                " mm, " ~ fmt(tPlateT / millimeter - 0.5, 1) ~ " mm pocket" ~ (pA ? " from the plate as modelled" : "") ~ ", " ~ nPins ~ " straight pins " ~ fmt((mastM.plateBoltDia * 1000 - 0.5), 1) ~ " mm for the bolt holes - drill and countersink after cure" ~
                (trayX > definition.printerX - definition.tileMargin || trayZ > definition.printerY - definition.tileMargin ? " (WARNING: larger than the bed - reduce Flange width)" : "");
            opDeleteBodies(context, id + "deleteMastCopy", { "entities" : moldPart });
        }
        // ---------------- pod plug: the pod's inside, whatever it is ----------------
        // The cavity cut leaves the pod's internal void as cores of mold, one per half, joined to the
        // block only through the pod's rear opening. A channel almost the pod's radius behind the rear
        // face severs them, whatever the opening's shape; the severed cores are then exactly the
        // void - the placeholder pocket or any custom inside modelled before this feature (motor
        // tabs, a hollowed shell) - and are joined to a handle in the channel as "Mast pod plug".
        // The plug's shoulder forms the pod's rear face. With undercuts inside, print the plug as a
        // sacrificial core.
        const podPlug = isMast && mastM.podOn == 1;
        var podPlugLen = 0 * meter;
        var podPlugQ;
        var podPlugNote = "";
        if (podPlug)
        {
            // the pod's axis in the laid-flat frame, with its tilt (world rotation about Y becomes a
            // rotation about z' here, so the axis stays in the parting plane): rear-face centre and
            // direction from the pod centre
            const tilt = mastM.podTilt != undefined ? mastM.podTilt : 0;
            const xC = mastM.podX * meter;
            const Lr = (mastM.podRearX - mastM.podX) * meter;
            const ax = vector(cos(tilt * radian), -sin(tilt * radian), 0);          // nose-down tilt: the rear rises (world +Z -> -y')
            const cR = vector(xC, -mastM.podZ * meter, zPart) + Lr * ax;
            const xR = cR[0];
            const rH = mastM.podDia / 2 * meter - 1 * millimeter;               // handle: 1 mm inside the pod's outer radius
            podPlugLen = min(definition.plugExt, (hi[0] - 2 * millimeter - xR) / max(cos(tilt * radian), 0.5));
            const chan = moldPin(context, id + "podChan", cR - 0.5 * millimeter * ax, cR + (podPlugLen + 1 * millimeter) * ax, rH + definition.pinFit);
            hv = moldHalves(context, solids, lo, hi);
            opBoolean(context, id + "podChanCut", {
                        "tools" : chan,
                        "targets" : qUnion([hv.upper, hv.lower]),
                        "operationType" : BooleanOperationType.SUBTRACTION
                    });
            // everything that is now neither an upper nor a lower body is a core of the void
            const cores = evaluateQuery(context, moldFloating(context, solids, lo, hi));
            const handle = moldPin(context, id + "podHandle", cR - 0.5 * millimeter * ax, cR + podPlugLen * ax, rH);
            if (size(cores) > 0)
                opBoolean(context, id + "podPlugJoin", { "tools" : qUnion(append(cores, handle)), "operationType" : BooleanOperationType.UNION });
            // the merged body keeps a core's identity, not the handle's (build 97: CANNOT_RESOLVE_ENTITIES
            // on the handle query) - so find the plug by geometry too: the one body touching neither face
            podPlugQ = moldFloating(context, solids, lo, hi);
            // an attribute survives every later boolean, unlike a creation query or a box test
            setAttribute(context, { "entities" : podPlugQ, "name" : "foilPodPlug", "attribute" : 1 });
            const pb = evBox3d(context, { "topology" : podPlugQ, "tight" : true });
            println("MAST_PLUG: cores=" ~ size(cores) ~ "; depth_mm=" ~ fmt((xR - pb.minCorner[0]) / millimeter, 1) ~ "; handle_mm=" ~ fmt(podPlugLen / millimeter, 1));
            podPlugNote = "; pod plug = the pod's inside (" ~ fmt((xR - pb.minCorner[0]) / millimeter, 0) ~ " mm deep, " ~ size(cores) ~ " core" ~ (size(cores) == 1 ? "" : "s") ~
                ") on a " ~ fmt(2 * rH / millimeter, 0) ~ " mm handle " ~ fmt(podPlugLen / millimeter, 0) ~ " mm long behind the rear face" ~
                (size(cores) == 0 ? " - no void found in the pod: is Cavity length 0, or the inside closed off?" : "; with undercuts inside, print it as a sacrificial core");
        }
        if (plugOn)
        {
            opDeleteBodies(context, id + "deleteFill", { "entities" : cavTool });
            // half-round plug channel in both halves, behind the nacelle's rear face
            const zAx = sock.axisZ * meter;
            const xR = sock.rearX * meter;
            const chan = moldPin(context, id + "plugChan", vector(xR - 1 * millimeter, 0 * meter, zAx), vector(xR + definition.plugExt + 1 * millimeter, 0 * meter, zAx), sock.boreDia / 2 * meter + definition.pinFit);
            hv = moldHalves(context, solids, lo, hi);
            opBoolean(context, id + "plugChanCut", {
                        "tools" : chan,
                        "targets" : qUnion([hv.upper, hv.lower]),
                        "operationType" : BooleanOperationType.SUBTRACTION
                    });
        }

        // ---------------- bolt cones (lower half, on the fuselage's bolt pattern) ----------------
        // A frustum per bolt from just inside the lower half's pad face up to Cone web under the root
        // section's top surface at that X, unioned into the lower half. Undersized and drafted: the
        // part pulls off and the holes are drilled to clearance after cure.
        var coneNote = "";
        var nCones = 0;
        if (conesOn)
        {
            // the cone stands on the pad face (in the half that holds the pad) and points through the
            // section to Cone web short of the far skin: pad on top -> from the upper half downwards,
            // pad underneath -> from the lower half upwards
            const rootSec = placeSection(buildSection(mini, m.rootT, min(m.teThick * meter, 0.03 * m.c0 * meter) / (m.c0 * meter), 40), m.c0 * meter, m.pivotFrac, cos(m.incidence * radian), sin(m.incidence * radian));
            const sideDn = stabRoot.padSide == 1;                 // cone points down
            const zPad = stabRoot.padZ * meter;
            const r0 = definition.coneDia / 2;
            var coneQs = [];
            var coneLog = "STAB_CONES: padSide=" ~ stabRoot.padSide ~ "; padZ_mm=" ~ fmt(zPad / millimeter, 2) ~ "; baseX_mm=" ~ fmt(base[0] / millimeter, 1) ~ "; baseZ_mm=" ~ fmt(base[2] / millimeter, 1) ~ "; bolts=" ~ size(stabRoot.boltX);
            for (var j = 0; j < size(stabRoot.boltX); j += 1)
            {
                const bx = stabRoot.boltX[j] * meter;
                // far skin of the root section over the bolt's footprint: the extreme away from the
                // pad sets the cone length, the extreme toward the pad is where the mold's own pin
                // (the part's through hole, copied into the cavity) merges into the cavity floor
                var zFar = sideDn ? 1 * meter : -1 * meter;
                var zNear = sideDn ? -1 * meter : 1 * meter;
                var found = false;
                const rHole = stabRoot.boltDia / 2 * meter;
                for (var i = 0; i < size(rootSec); i += 1)
                {
                    const wx = base[0] + rootSec[i][0];
                    if (abs(wx - bx) <= rHole + 0.5 * millimeter)
                    {
                        zFar = sideDn ? min(zFar, base[2] + rootSec[i][1]) : max(zFar, base[2] + rootSec[i][1]);
                        zNear = sideDn ? max(zNear, base[2] + rootSec[i][1]) : min(zNear, base[2] + rootSec[i][1]);
                        found = true;
                    }
                }
                if (found && rHole > 0 * meter)
                {
                    // remove that pin from both halves: a cylinder a little wider than the hole, from
                    // where the skin is nearest the pad through the parting. The stub left below it
                    // (the skin's curvature under the hole, a few tenths) is inside the hole that gets
                    // drilled after cure, so it never reaches the part
                    // only from the half away from the pad: build 92 cut both and took the cone's
                    // seat out of the pad-side half, leaving the cones as floating parts
                    const dzp = sideDn ? -1 : 1;
                    const pinCut = moldPin(context, id + ("pinCut" ~ j), vector(bx, 0 * meter, zNear), vector(bx, 0 * meter, zPad - dzp * 2 * millimeter), rHole + 0.1 * millimeter);
                    hv = moldHalves(context, solids, lo, hi);
                    opBoolean(context, id + ("pinCutDo" ~ j), {
                                "tools" : pinCut,
                                "targets" : sideDn ? hv.lower : hv.upper,
                                "operationType" : BooleanOperationType.SUBTRACTION
                            });
                }
                coneLog = coneLog ~ "; bolt" ~ j ~ ": X_mm=" ~ fmt(bx / millimeter, 1) ~ " farZ_mm=" ~ (found ? fmt(zFar / millimeter, 2) : "none");
                if (!found)
                {
                    coneNote = coneNote ~ " bolt at X " ~ fmt(bx / millimeter, 0) ~ " skipped (behind the root section, in the tail - drill it after cure);";
                    continue;
                }
                const hCone = abs(zFar - zPad) - definition.coneWeb;
                const r1 = r0 - hCone * tan(definition.coneTaper);
                coneLog = coneLog ~ " h_mm=" ~ fmt(hCone / millimeter, 2) ~ " rTip_mm=" ~ fmt(r1 / millimeter, 2);
                if (hCone < 1 * millimeter || r1 < 0.5 * millimeter)
                {
                    coneNote = coneNote ~ " bolt at X " ~ fmt(bx / millimeter, 0) ~ " skipped (section too thin for the cone);";
                    continue;
                }
                const dz = sideDn ? -1 : 1;
                const cq = moldFrustum(context, id + ("cone" ~ j), vector(bx, 0 * meter, zPad - dz * 0.5 * millimeter), vector(bx, 0 * meter, zPad + dz * hCone), r0, r1);
                coneQs = append(coneQs, cq);
                nCones += 1;
            }
            println(coneLog ~ "; made=" ~ nCones);
            if (nCones > 0)
            {
                hv = moldHalves(context, solids, lo, hi);
                opBoolean(context, id + "coneJoin", {
                            "tools" : qUnion(append(coneQs, sideDn ? hv.upper : hv.lower)),
                            "operationType" : BooleanOperationType.UNION
                        });
            }
        }

        // ---------------- pinch-off groove (lower half, before the tiles) ----------------
        // annulus between the outline offset by Land width and by Land + Groove width, as a prism
        // through the whole block, minus the lowered curtain: what is left lies within Groove depth
        // below the parting surface, and only that is cut from the lower half
        var nGroove = 0;
        var grooveFailed = false;
        var nVents = 0;
        var grooveVol = 0;      // cm3
        var loop = [];          // the outline the groove follows, LE then TE back
        const flashVol = partVol * definition.overchargePct / 100;   // cm3 the overcharge squeezes out
        if (definition.grooveOn)
        {
            loop = outLE;
            for (var i = size(outTE) - 1; i >= 0; i -= 1)
                loop = append(loop, outTE[i]);
            const inner = moldOffsetLoop(loop, definition.landWidth);
            const outer = moldOffsetLoop(loop, definition.landWidth + definition.grooveWidth);
            // prisms stay inside the block height so moldHalves never mistakes them for a half. If the
            // offset outline cannot be lofted the mold is finished without its groove and says so,
            // rather than failing whole (build 134)
            try silent
            {
                moldPrism(context, id + "gOuter", outer, lo[2] + e, hi[2] - e);
                moldPrism(context, id + "gInner", inner, lo[2] + e / 2, hi[2] - e / 2);
            }
            catch
            {
                grooveFailed = true;
                opDeleteBodies(context, id + "gFailDel", { "entities" : qUnion([qCreatedBy(id + "gOuter", EntityType.BODY), qCreatedBy(id + "gInner", EntityType.BODY),
                            qCreatedBy(id + "gOuter" + "p0", EntityType.BODY), qCreatedBy(id + "gOuter" + "p1", EntityType.BODY), qCreatedBy(id + "gInner" + "p0", EntityType.BODY), qCreatedBy(id + "gInner" + "p1", EntityType.BODY)]) });
            }
        }
        if (definition.grooveOn && !grooveFailed)
        {
            opBoolean(context, id + "gRing", {
                        "tools" : qCreatedBy(id + "gInner", EntityType.BODY),
                        "targets" : qCreatedBy(id + "gOuter", EntityType.BODY),
                        "operationType" : BooleanOperationType.SUBTRACTION
                    });
            // bag closing: vent slots from the groove to the block's outer face at each span end,
            // 1 mm wide, trimmed to the groove's depth by the same lowered curtain (before the curtain
            // is consumed by the groove's own floor cut). A loop end lying outside the block (the
            // mast's plate end, which already runs off the block) needs none
            var ventQ = [];
            if (definition.closing == MoldClosing.BAG && definition.ventOn)
            {
                const gw = definition.landWidth + definition.grooveWidth;
                for (var k = 0; k < 2; k += 1)
                {
                    const iE = k == 0 ? 0 : size(outLE) - 1;
                    const xe = (outLE[iE][0] + outTE[iE][0]) / 2;
                    const ye = (outLE[iE][1] + outTE[iE][1]) / 2;
                    const inside = k == 0 ? ye - gw > lo[1] + 1 * millimeter : ye + gw < hi[1] - 1 * millimeter;
                    if (inside)
                    {
                        const y0 = k == 0 ? lo[1] - e : ye + definition.landWidth + definition.grooveWidth / 2;
                        const y1 = k == 0 ? ye - definition.landWidth - definition.grooveWidth / 2 : hi[1] + e;
                        moldBox(context, id + ("vent" ~ k), vector(xe - 0.5 * millimeter, y0, lo[2] + e), vector(xe + 0.5 * millimeter, y1, hi[2] - e));
                        ventQ = append(ventQ, qCreatedBy(id + ("vent" ~ k), EntityType.BODY));
                    }
                }
                if (size(ventQ) > 0)
                    opBoolean(context, id + "ventFloor", {
                                "tools" : qUnion(curtainDown),
                                "targets" : qUnion(ventQ),
                                "operationType" : BooleanOperationType.SUBTRACTION,
                                "keepTools" : true
                            });
            }
            nVents = size(ventQ);
            opBoolean(context, id + "gFloor", {
                        "tools" : qUnion(curtainDown),
                        "targets" : qCreatedBy(id + "gOuter", EntityType.BODY),
                        "operationType" : BooleanOperationType.SUBTRACTION
                    });
            if (podPlug)
            {
                // no pinch-off round the pod (user): clear the ring from the pod's band, nose to the
                // block's aft edge, so the plug channel and the pod flanks stay ungrooved
                const yP = -mastM.podZ * meter;
                const rP = mastM.podDia / 2 * meter + definition.landWidth + definition.grooveWidth + 1 * millimeter +
                    (mastM.podTilt != undefined ? abs(sin(mastM.podTilt * radian)) * mastM.podLength / 2 * meter : 0 * meter);
                moldBox(context, id + "gPodClear", vector(mastM.podNoseX * meter - definition.landWidth - definition.grooveWidth - 1 * millimeter, yP - rP, lo[2]),
                        vector(hi[0] + e, yP + rP, hi[2]));
                opBoolean(context, id + "gPodClearCut", {
                            "tools" : qCreatedBy(id + "gPodClear", EntityType.BODY),
                            "targets" : qCreatedBy(id + "gOuter", EntityType.BODY),
                            "operationType" : BooleanOperationType.SUBTRACTION
                        });
            }
            hv = moldHalves(context, solids, lo, hi);
            opBoolean(context, id + "gCut", {
                        "tools" : qCreatedBy(id + "gOuter", EntityType.BODY),
                        "targets" : hv.lower,
                        "operationType" : BooleanOperationType.SUBTRACTION
                    });
            if (nVents > 0)
            {
                hv = moldHalves(context, solids, lo, hi);
                opBoolean(context, id + "ventCut", {
                            "tools" : qUnion(ventQ),
                            "targets" : hv.lower,
                            "operationType" : BooleanOperationType.SUBTRACTION
                        });
            }
            nGroove = 1;
            // what the groove holds against what the overcharge squeezes out
            var per = 0 * meter;
            for (var i = 0; i < size(loop); i += 1)
                per += norm(loop[(i + 1) % size(loop)] - loop[i]);
            grooveVol = per * definition.grooveWidth * definition.grooveDepth / (centimeter * centimeter * centimeter);
        }

        // ---------------- tiles ----------------
        // each half is cut along the span into nY tiles and, if a tile would still be wider than the
        // printer, across the chord into nX. Dowel holes are drilled first, centred on each cut, in
        // the base layer (always solid, base/2 from the outer face); the cuts then leave half a hole
        // in each neighbour. Upper cuts are offset half a tile when Stagger joints is on
        const Lv = hi - lo;
        const L = Lv / millimeter;
        const useXv = definition.printerX - definition.tileMargin;
        const useYv = definition.printerY - definition.tileMargin;
        const useZ = (definition.printerZ - definition.tileMargin) / millimeter;
        const nX = ceil(Lv[0] / useXv);
        const nY = ceil(Lv[1] / useYv);
        const tileX = Lv[0] / nX;
        const tileY = Lv[1] / nY;
        const stagger = definition.staggerJoints && nY > 1;
        if (definition.pinDia > definition.baseThick - 4 * millimeter)
            throw regenError("Pin dia must be at most Base thickness - 4 mm - the tile keys live in the base layer", ["pinDia", "baseThick"]);
        if (definition.pinDia > f - 4 * millimeter || definition.keyDia > f - 4 * millimeter)
            throw regenError("Pin dia and Key dia must be at most Flange width - 4 mm - the keys sit in the flanges", ["pinDia", "keyDia", "flangeWidth"]);

        var yCutsL = [];
        for (var k = 1; k < nY; k += 1)
            yCutsL = append(yCutsL, lo[1] + k * tileY);
        var yCutsU = yCutsL;
        if (stagger)
        {
            yCutsU = [];
            for (var k = 1; k <= nY; k += 1)
                yCutsU = append(yCutsU, lo[1] + (k - 0.5) * tileY);
        }
        // no spanwise seam through the stab's pad and tail, or through the wing's nacelle: a cut that
        // lands within the keep-out is moved to its edge, if the two tiles it makes still fit the bed
        const podTiltSpread = isMast && mastM.podOn == 1 && mastM.podTilt != undefined ? abs(sin(mastM.podTilt * radian)) * mastM.podLength / 2 * meter : 0 * meter;
        const keepY = padMap != undefined ? padMap.padWidth / 2 * meter + 5 * millimeter :
            (sockOn ? sock.nacelleDia / 2 * meter + 5 * millimeter : (isMast && mastM.podOn == 1 ? mastM.podDia / 2 * meter + podTiltSpread + 5 * millimeter : 0 * meter));
        const keepC = isMast && mastM.podOn == 1 ? -mastM.podZ * meter : 0 * meter;    // band centre (the mast's pod lies at y' = -podZ)
        const keepName = padMap != undefined ? "stab pad" : (sockOn ? "nacelle" : "pod");
        var cutNote = "";
        if (keepY > 0 * meter)
        {
            const lists = [yCutsL, yCutsU];
            var fixed = [];
            for (var li = 0; li < 2; li += 1)
            {
                var cuts = lists[li];
                for (var k = 0; k < size(cuts); k += 1)
                {
                    if (abs(cuts[k] - keepC) >= keepY)
                        continue;
                    const prev = k == 0 ? lo[1] : cuts[k - 1];
                    const next = k == size(cuts) - 1 ? hi[1] : cuts[k + 1];
                    var moved = false;
                    for (var sgn in [cuts[k] >= keepC ? 1 : -1, cuts[k] >= keepC ? -1 : 1])
                    {
                        const yc = keepC + sgn * keepY;
                        if (!moved && yc - prev <= useYv && next - yc <= useYv && yc - prev > 20 * millimeter && next - yc > 20 * millimeter)
                        {
                            cuts[k] = yc;
                            moved = true;
                        }
                    }
                    if (!moved)
                        cutNote = " (a spanwise seam still crosses the " ~ keepName ~ " - the tiles either side would not fit the bed)";
                    else
                        cutNote = " (seam moved off the " ~ keepName ~ ")";
                }
                fixed = append(fixed, cuts);
            }
            yCutsL = fixed[0];
            yCutsU = fixed[1];
        }
        var xCuts = [];
        for (var k = 1; k < nX; k += 1)
            xCuts = append(xCuts, lo[0] + k * tileX);
        // with the tube socket on, keep the nacelle and its bore core in one tile: put a single
        // chordwise cut just ahead of where the nacelle starts, if both tiles still fit the printer
        var chordCutNote = "";
        if (sockOn && nX == 2)
        {
            const xc = sock.axisX * meter - 5 * millimeter;
            if (xc - lo[0] <= useXv && hi[0] - xc <= useXv && xc - lo[0] > 20 * millimeter)
            {
                xCuts = [xc];
                chordCutNote = " (ahead of the tube socket)";
            }
            else
                chordCutNote = " (through the tube socket - a narrower Flange width or a wider printer would let it clear)";
        }

        const printed = definition.keyStyle == MoldKeyStyle.PRINTED;
        var rT = 0 * meter;
        if (printed)
        {
            rT = definition.pinDia / 2 - definition.keyHeight * tan(definition.keyDraft);
            const rTk = definition.keyDia / 2 - definition.keyHeight * tan(definition.keyDraft);
            if (rT < 1 * millimeter || rTk < 1 * millimeter)
                throw regenError("Key tip would be under 2 mm across - lower Key height or Key draft, or raise Pin dia / Key dia", ["keyHeight", "keyDraft", "pinDia", "keyDia"]);
            if (definition.keyHeight > definition.baseThick - 4 * millimeter)
                throw regenError("Key height must be at most Base thickness - 4 mm so the sockets stay inside the base layer", ["keyHeight", "baseThick"]);
        }

        // dowel holes (Dowel holes style) - drilled before the cuts, centred on each cut
        const rHole = (definition.pinDia + definition.pinFit) / 2;
        const hp = printed ? 0 * meter : definition.pinLen / 2;
        const zPinU = hi[2] - definition.baseThick / 2;
        const zPinL = lo[2] + definition.baseThick / 2;
        const xFront = lo[0] + f / 2;
        const xAft = hi[0] - f / 2;
        var nPins = 0;
        var nSkippedKeys = 0;      // key positions with no tile under them (a seam crossing the plug channel)
        for (var side = 0; side < (printed ? 0 : 2); side += 1)
        {
            const yCuts = side == 0 ? yCutsU : yCutsL;
            const zPin = side == 0 ? zPinU : zPinL;
            var holes = [];
            for (var yc in yCuts)
            {
                holes = append(holes, moldPin(context, id + ("h" ~ side ~ "f" ~ size(holes)), vector(xFront, yc - hp, zPin), vector(xFront, yc + hp, zPin), rHole));
                holes = append(holes, moldPin(context, id + ("h" ~ side ~ "a" ~ size(holes)), vector(xAft, yc - hp, zPin), vector(xAft, yc + hp, zPin), rHole));
            }
            // chordwise joints: one pin per spanwise tile, at that tile's mid-span
            var bounds = concatenateArrays([[lo[1]], yCuts, [hi[1]]]);
            for (var xc in xCuts)
                for (var k = 0; k + 1 < size(bounds); k += 1)
                {
                    const ym = 0.5 * (bounds[k] + bounds[k + 1]);
                    holes = append(holes, moldPin(context, id + ("h" ~ side ~ "x" ~ size(holes)), vector(xc - hp, ym, zPin), vector(xc + hp, ym, zPin), rHole));
                }
            nPins += size(holes);
            if (size(holes) > 0 && !printed)
            {
                hv = moldHalves(context, solids, lo, hi);
                opBoolean(context, id + ("drill" ~ side), {
                            "tools" : qUnion(holes),
                            "targets" : side == 0 ? hv.upper : hv.lower,
                            "operationType" : BooleanOperationType.SUBTRACTION
                        });
            }
        }

        // registration keys: vertical holes through the parting surface in both flanges, subtracted
        // from both halves at once so each gets its half. Height comes from the parting itself
        var nKeys = 0;
        if (definition.keysOn && !printed)
        {
            if (definition.keyLen / 2 > definition.baseThick - 3 * millimeter)
                throw regenError("Key length must be at most 2 x (Base thickness - 3 mm) - the hole would break through the thinner half", ["keyLen", "baseThick"]);
            const rKey = (definition.keyDia + definition.pinFit) / 2;
            const hk = definition.keyLen / 2;
            var keys = [];
            for (var k = 0; k < nY; k += 1)
            {
                var yk = lo[1] + (k + 0.25) * tileY;
                if (keepY > 0 * meter && abs(yk - keepC) < keepY + rKey + 2 * millimeter)
                    yk = keepC + (yk >= keepC ? 1 : -1) * (keepY + rKey + 2 * millimeter);   // clear of the pad / nacelle / pod channel
                var zf = zPart;
                var za = zPart;
                if (!isMast)
                {
                    const pp = wTab != undefined && abs(yk) > wY0 ? moldPartingPointsWinglet(wTab, abs(yk), yk < 0 * meter ? -1 : 1, lo[0] - e, hi[0] + e) : moldPartingPointsPad(m, mini, min(abs(yk) / h, 1), yk, base, lo[0] - e, hi[0] + e, sockOn && abs(yk) <= sock.nacelleDia / 2 * meter * 1.0001 ? sock : undefined, abs(yk) < (padMap != undefined ? padMap.padWidth / 2 * meter : 0 * meter) ? padMap : undefined);
                    zf = pp.front[2];
                    za = pp.aft[2];
                }
                keys = append(keys, moldPin(context, id + ("kf" ~ k), vector(xFront, yk, zf - hk), vector(xFront, yk, zf + hk), rKey));
                keys = append(keys, moldPin(context, id + ("ka" ~ k), vector(xAft, yk, za - hk), vector(xAft, yk, za + hk), rKey));
            }
            nKeys = size(keys);
            hv = moldHalves(context, solids, lo, hi);
            opBoolean(context, id + "keyCut", {
                        "tools" : qUnion(keys),
                        "targets" : qUnion([hv.upper, hv.lower]),
                        "operationType" : BooleanOperationType.SUBTRACTION
                    });
        }

        // cuts: upper first (everything except the still-single lower body), then the lower, then the
        // chordwise cuts through everything
        var cutBodies = [];
        var kc = 0;
        for (var yc in yCutsU)
        {
            hv = moldHalves(context, solids, lo, hi);
            cutBodies = append(cutBodies, moldCut(context, id + ("cut" ~ kc), hv.upper, vector(0 * meter, yc, 0 * meter), Y_DIRECTION, lo, hi));
            kc += 1;
        }
        for (var yc in yCutsL)
        {
            hv = moldHalves(context, solids, lo, hi);
            cutBodies = append(cutBodies, moldCut(context, id + ("cut" ~ kc), hv.lower, vector(0 * meter, yc, 0 * meter), Y_DIRECTION, lo, hi));
            kc += 1;
        }
        for (var xc in xCuts)
        {
            hv = moldHalves(context, solids, lo, hi);
            cutBodies = append(cutBodies, moldCut(context, id + ("cut" ~ kc), qUnion([hv.upper, hv.lower]), vector(xc, 0 * meter, 0 * meter), X_DIRECTION, lo, hi));
            kc += 1;
        }
        if (size(cutBodies) > 0)
            opDeleteBodies(context, id + "deleteCuts", { "entities" : qUnion(cutBodies) });

        // ---------------- printed keys (after the cuts, so no boss straddles a joint) ----------------
        if (printed)
        {
            const rB = definition.pinDia / 2;
            const hb = definition.keyHeight;
            const fit = definition.pinFit;
            var kk = 0;
            for (var side = 0; side < 2; side += 1)
            {
                const yCuts = side == 0 ? yCutsU : yCutsL;
                const zPin = side == 0 ? zPinU : zPinL;
                var locs = [];
                for (var yc in yCuts)
                {
                    locs = append(locs, [vector(xFront, yc, zPin), Y_DIRECTION]);
                    locs = append(locs, [vector(xAft, yc, zPin), Y_DIRECTION]);
                }
                const bounds = concatenateArrays([[lo[1]], yCuts, [hi[1]]]);
                for (var xc in xCuts)
                    for (var k = 0; k + 1 < size(bounds); k += 1)
                        locs = append(locs, [vector(xc, 0.5 * (bounds[k] + bounds[k + 1]), zPin), X_DIRECTION]);
                for (var loc in locs)
                {
                    if (moldPrintedKey(context, id + ("tk" ~ (kk + nSkippedKeys)), solids, lo, hi, side, side,
                            loc[0] - 1 * millimeter * loc[1], loc[0] + (hb + 1 * millimeter) * loc[1], loc[0], loc[1], rB, rT, hb, fit))
                        kk += 1;
                    else
                        nSkippedKeys += 1;
                }
            }
            nPins = kk;
            if (definition.keysOn)
            {
                const rBk = definition.keyDia / 2;
                const rTk = rBk - hb * tan(definition.keyDraft);
                for (var k = 0; k < nY; k += 1)
                {
                    var yk = lo[1] + (k + 0.25) * tileY;
                    if (keepY > 0 * meter && abs(yk - keepC) < keepY + rBk + 2 * millimeter)
                        yk = keepC + (yk >= keepC ? 1 : -1) * (keepY + rBk + 2 * millimeter);   // clear of the pad / nacelle / pod channel
                    var zf = zPart;
                    var za = zPart;
                    if (!isMast)
                    {
                        const pp = wTab != undefined && abs(yk) > wY0 ? moldPartingPointsWinglet(wTab, abs(yk), yk < 0 * meter ? -1 : 1, lo[0] - e, hi[0] + e) : moldPartingPointsPad(m, mini, min(abs(yk) / h, 1), yk, base, lo[0] - e, hi[0] + e, sockOn && abs(yk) <= sock.nacelleDia / 2 * meter * 1.0001 ? sock : undefined, abs(yk) < (padMap != undefined ? padMap.padWidth / 2 * meter : 0 * meter) ? padMap : undefined);
                        zf = pp.front[2];
                        za = pp.aft[2];
                    }
                    const pts = [vector(xFront, yk, zf), vector(xAft, yk, za)];
                    for (var j = 0; j < 2; j += 1)
                    {
                        if (moldPrintedKey(context, id + ("hk" ~ k ~ "_" ~ j), solids, lo, hi, 1, 0, pts[j], pts[j], pts[j], Z_DIRECTION, rBk, rTk, hb, fit))
                            nKeys += 1;
                        else
                            nSkippedKeys += 1;
                    }
                }
            }
        }

        // ---------------- plate tray keys (mast): two printed keys on the tray's opening face ----------------
        if (isMast)
        {
            const pA = plateAct != undefined;
            const xcT = pA ? (plateAct.x0 + plateAct.x1) / 2 : (mastM.plateXc != undefined ? mastM.plateXc : mastM.leX + mastM.chord / 2) * meter;
            const zcT = pA ? (plateAct.y0 + plateAct.y1) / 2 + zPart : zPart;
            const hbT = definition.keyHeight;
            const rBT = definition.keyDia / 2;
            const rTT = rBT - hbT * tan(definition.keyDraft);
            const zK = (pA ? (plateAct.y1 - plateAct.y0) / 2 : mastM.plateWidth / 2 * meter) + definition.baseThick / 2;      // in the flange beyond the plate
            for (var k = 0; k < 2; k += 1)
            {
                const pk = vector(xcT, lo[1], zcT + (k == 0 ? zK : -zK));
                const dY = Y_DIRECTION;
                const sockT = moldFrustum(context, id + ("trayKeyS" ~ k), pk - 1 * millimeter * dY, pk + (hbT + 0.3 * millimeter) * dY, rBT + definition.pinFit, rTT + definition.pinFit);
                hv = moldHalves(context, solids, lo, hi);
                opBoolean(context, id + ("trayKeyCut" ~ k), {
                            "tools" : sockT,
                            "targets" : moldTileAt(context, k == 0 ? hv.upper : hv.lower, pk + 2 * millimeter * dY),
                            "operationType" : BooleanOperationType.SUBTRACTION
                        });
                const bossT = moldFrustum(context, id + ("trayKeyB" ~ k), pk - 1 * millimeter * dY, pk + hbT * dY, rBT, rTT);
                opBoolean(context, id + ("trayKeyJoin" ~ k), {
                            "tools" : qUnion([qHasAttribute("foilPlateTray"), bossT]),
                            "operationType" : BooleanOperationType.UNION
                        });
            }
        }
        // ---------------- names ----------------
        // "<Wing|Stab> mold <upper|lower> <k> of <n>" from the -Y end, with fwd/aft when cut across the chord
        const nTilesU = (stagger ? nY + 1 : nY) * nX;
        const nTilesL = nY * nX;
        hv = moldHalves(context, solids, lo, hi);
        // anything that is neither an upper nor a lower tile at this point is a key that did not attach
        const nFloating = size(evaluateQuery(context, solids)) - hv.nUpper - hv.nLower - (podPlug ? 1 : 0);
        const partName = (definition.moldSource == MoldSource.WING ? "Wing " : (isMast ? "Mast " : "Stab ")) ~ (coreMold ? "core mold" : "mold");
        for (var side = 0; side < 2; side += 1)
        {
            const tiles = moldSortTiles(context, side == 0 ? hv.upper : hv.lower);
            const nRows = size(tiles) / nX;
            for (var i = 0; i < size(tiles); i += 1)
            {
                const row = floor(i / nX) + 1;
                const col = i % nX;
                const nm = partName ~ (isMast ? (side == 0 ? " left " : " right ") : (side == 0 ? " upper " : " lower ")) ~ row ~ " of " ~ nRows ~
                    (nX > 1 ? (col == 0 ? " fwd" : (col == nX - 1 ? " aft" : " mid" ~ col)) : "");
                setProperty(context, { "entities" : tiles[i], "propertyType" : PropertyType.NAME, "value" : nm });
            }
        }
        // ---------------- socket plug part ----------------
        if (plugOn)
        {
            const zAx = sock.axisZ * meter;
            const xR = sock.rearX * meter;
            const plug = moldPin(context, id + "plug", vector(xR - sock.depth * meter, 0 * meter, zAx), vector(xR + definition.plugExt, 0 * meter, zAx), sock.boreDia / 2 * meter);
            setProperty(context, { "entities" : plug, "propertyType" : PropertyType.NAME, "value" : "Wing socket plug" });
        }
        if (isMast)
            setProperty(context, { "entities" : qHasAttribute("foilPlateTray"), "propertyType" : PropertyType.NAME, "value" : "Mast plate mold" });
        var plugLost = false;
        if (podPlug)
        {
            var pq = qHasAttribute("foilPodPlug");
            if (size(evaluateQuery(context, pq)) == 0)
                pq = moldFloating(context, solids, lo, hi);
            if (size(evaluateQuery(context, pq)) > 0)
                setProperty(context, { "entities" : pq, "propertyType" : PropertyType.NAME, "value" : "Mast pod plug" });
            else
                plugLost = true;
        }
        const nAll = size(evaluateQuery(context, solids));
        const hUp = (hi[2] - lo[2]) / millimeter;     // a half is at most the block height
        var warnings = [];
        // closing: what presses the halves together
        var closingNote = "";
        {
            const blockArea = (hi[0] - lo[0]) * (hi[1] - lo[1]) / (centimeter * centimeter);         // cm2, plan
            const partPlan = (pbox.maxCorner[0] - pbox.minCorner[0]) * (pbox.maxCorner[1] - pbox.minCorner[1]) / (centimeter * centimeter);
            if (definition.closing == MoldClosing.BAG)
            {
                const forceN = definition.bagVac * 1000 * blockArea * 1e-4;                           // Pa x m2
                const lamBar = definition.bagVac / 100 * blockArea / max(partPlan, 1);
                closingNote = " | closing: vacuum bag at " ~ fmt(definition.bagVac, 0) ~ " kPa gives " ~ fmt(forceN / 1000, 1) ~ " kN on the " ~ fmt(blockArea, 0) ~ " cm2 block, " ~
                    fmt(lamBar, 1) ~ " bar on the laminate" ~ (roundOn && !roundFailed ? "; outer edges rounded " ~ fmt(definition.edgeRound / millimeter, 0) ~ " mm" : "") ~
                    (roundFailed ? "; EDGE ROUND FAILED (the tiles are sharp-edged: pad the corners under the bag)" : "") ~
                    "; glue the tiles first, breather over the whole mold, check the flange gap with feelers before the resin gels";
                if (definition.overchargePct > 6)
                    warnings = append(warnings, "Overcharge " ~ fmt(definition.overchargePct, 0) ~ " % is more than a bag can squeeze out: 3-5 % with Closing = Vacuum bag");
                if (definition.grooveOn && nVents == 0 && definition.ventOn)
                    warnings = append(warnings, "no groove vents were cut (both loop ends lie outside the block) - the groove is a sealed pocket in the bag; check the flange gap");
            }
            else
                closingNote = " | closing: clamps on the flanges against a rigid board (" ~ fmt(blockArea, 0) ~ " cm2 block; a vacuum bag would give " ~ fmt(85 * 1000 * blockArea * 1e-4 / 1000, 1) ~ " kN at 85 kPa)";
            if (nGroove > 0 && grooveVol > 0 && flashVol > grooveVol)
                warnings = append(warnings, "the pinch-off groove holds " ~ fmt(grooveVol, 0) ~ " cm3 but " ~ fmt(definition.overchargePct, 0) ~ " % overcharge makes " ~ fmt(flashVol, 0) ~ " cm3 of flash: deepen Groove depth, widen Groove width, or lower Overcharge %");
        }
        const nExtra = plugOn ? 1 : 0;
        if (hv.nUpper != nTilesU || hv.nLower != nTilesL || nAll != nTilesU + nTilesL + nExtra)
            warnings = append(warnings, "expected " ~ nTilesU ~ " upper and " ~ nTilesL ~ " lower tiles" ~ (plugOn ? " plus the socket plug" : "") ~ ", found " ~ hv.nUpper ~ " / " ~ hv.nLower ~ " (" ~ nAll ~ " bodies) - a cut or the cavity split something unexpectedly; inspect the bodies");
        if (hUp > useZ)
            warnings = append(warnings, "the block is " ~ fmt(hUp, 0) ~ " mm tall, over the " ~ fmt(useZ, 0) ~ " mm usable print height - reduce Base thickness or tip droop, or use a taller printer");
        if (tipT < 1 && !isMast)
            warnings = append(warnings, "tip section only " ~ fmt(tipT, 2) ~ " mm thick where the cap starts - too thin to lay up; raise End ratio (or turn on Min tip) in the Foil " ~
                (definition.moldSource == MoldSource.WING ? "wing" : "stabiliser") ~ ", or Tip thick %. The cap beyond it runs out to " ~ fmt(capEndT, 2) ~ " mm and is tow and resin");
        if (sockOn && !plugOn)
            warnings = append(warnings, "tube socket nacelle molded in with its bore as a half-round core in each half - turn Socket plug on for a seamless bore");
        if (dropCheck != "ok (droop is monotonic in +Z)")
            warnings = append(warnings, dropCheck);
        if (towNote != "")
            warnings = append(warnings, towNote);
        if (nFloating > 0)
            warnings = append(warnings, nFloating ~ " key bodies did not attach to a tile and are floating as their own parts - please report this with the mold's inputs");
        if (grooveFailed)
            warnings = append(warnings, "pinch-off groove skipped: its offset outline could not be built (a narrow tail plan, usually) - the mold is complete without it; add a groove by hand or turn Pinch-off off; please report this with the mold's inputs");
        if (plugLost)
            warnings = append(warnings, "the pod plug was made but is no longer a separate body by the end - please report the MAST_PLUG console lines");

        const msg = "Mold block " ~ fmt(L[0], 0) ~ " x " ~ fmt(L[1], 0) ~ " x " ~ fmt(L[2], 0) ~ " mm (chord x span x height)" ~
            " | tiles: upper " ~ nTilesU ~ ", lower " ~ nTilesL ~ " = " ~ (nTilesU + nTilesL) ~ " prints, up to " ~ fmt(tileY / millimeter, 0) ~ " x " ~ fmt(tileX / millimeter, 0) ~
            " mm on the bed (" ~ nY ~ " along the span" ~ cutNote ~ (nX > 1 ? " x " ~ nX ~ " across the chord" ~ chordCutNote : "") ~ (stagger ? ", staggered" : "") ~ "; usable " ~
            fmt(useYv / millimeter, 0) ~ " x " ~ fmt(useXv / millimeter, 0) ~ " x " ~ fmt(useZ, 0) ~ ")" ~
            " | " ~ nPins ~ (printed ? " printed tile keys " : " tile dowels ") ~ fmt(definition.pinDia / millimeter, 0) ~ " mm" ~ (nKeys > 0 ? ", " ~ nKeys ~ " half keys " ~ fmt(definition.keyDia / millimeter, 0) ~ " mm" : "") ~ (nSkippedKeys > 0 ? ", " ~ nSkippedKeys ~ " skipped where a seam crosses the plug channel" : "") ~
            flipNote ~ coreNote ~
            (isMast ? " | mast laid flat 400 mm below the origin, parting on its mid-plane: left and right halves for the blade, plus the plate tray" ~ trayNote ~
                (podPlug ? "; pod molded with the mast" ~ podPlugNote : "") : "") ~
            (plugOn ? " | socket plug " ~ fmt(sock.boreDia * 1000, 1) ~ " mm x " ~ fmt(sock.depth * 1000 + definition.plugExt / millimeter, 0) ~ " mm, channel in both flanges; drill the pin holes after cure" : "") ~
            (nCones > 0 ? " | " ~ nCones ~ " bolt cones " ~ fmt(definition.coneDia / millimeter, 1) ~ " mm at " ~ fmt(definition.coneTaper / degree, 0) ~ " deg on the stab's pattern, " ~ fmt(definition.coneWeb / millimeter, 1) ~ " mm web at the far skin; the part's own holes are not molded - drill to " ~ fmt(stabRoot.boltDia * 1000, 1) ~ " mm" ~ (stabRoot.headDia != undefined && stabRoot.headDia > 0 ? " and countersink " ~ fmt(stabRoot.headDia * 1000, 1) ~ " mm" : "") ~ " after cure" : "") ~
            (definition.conesOn == true && definition.moldSource == MoldSource.STAB && nCones == 0 ? " | no bolt cones: " ~
                (stabRoot == undefined ? "no Foil stabiliser above this feature" :
                 (stabRoot.boltX == undefined ? "the Foil stabiliser above is older than this Foil mold - paste the whole Feature Studio again" :
                  (size(stabRoot.boltX) == 0 ? "the stab has no Mount bolts" :
                   (stabRoot.padOn != 1 ? "the stab's Mount pad is off" : "every bolt was skipped (see below)")))) : "") ~
            (coneNote != "" ? " |" ~ coneNote : "") ~
            (nGroove > 0 ? " | pinch-off: land " ~ fmt(definition.landWidth / millimeter, 1) ~ " mm, groove " ~ fmt(definition.grooveWidth / millimeter, 1) ~ " x " ~ fmt(definition.grooveDepth / millimeter, 1) ~ " mm in the lower half, holds " ~ fmt(grooveVol, 0) ~ " cm3 against " ~ fmt(flashVol, 0) ~ " cm3 of flash at " ~ fmt(definition.overchargePct, 0) ~ " % overcharge" ~
                (nVents > 0 ? ", vented to the outside at " ~ nVents ~ (nVents == 1 ? " end" : " ends") : "") : "") ~
            closingNote ~
            " | " ~ layupMsg ~ stiffMsg;
        if (size(warnings) > 0)
        {
            var w = "";
            for (var s in warnings)
                w = w ~ (w == "" ? "" : "; ") ~ s;
            reportFeatureWarning(context, id, msg ~ " | WARNING: " ~ w);
        }
        else
            reportFeatureInfo(context, id, msg);

        // ---------------- cut templates: one flat plate, every ply outline cut through it ----------------
        // Built last, below the block, so no mold operation ever sees it. Export its top face as DXF.
        if (definition.templatesOn)
        {
            const mg = definition.tplMargin;
            const gap = definition.tplGap;
            const zP = lo[2] - 60 * millimeter;
            var shapes = [];            // each: array of 2D points (u along the chord, v along the developed span), closed
            var names = [];
            var cuts = [];              // how many pieces to cut from each outline: one tally hole per cut on the plate
            if (isMast)
            {
                // skins: one face developed (chord + thickness, at the plate and at the fuselage end) x
                // height, the plate end at the bottom of the strip, plus the plate's top face; UD: the
                // tapered strips of the cut list, plate end at the bottom
                const cBotM = (mastM.chord + mastM.thick) * meter;
                const cTopS = ((mastM.chordTop != undefined ? mastM.chordTop : mastM.chord) + (mastM.thickTop != undefined ? mastM.thickTop : mastM.thick)) * meter;
                const hM = mastM.height * meter;
                shapes = append(shapes, [vector(-mg, -mg), vector(cTopS + mg, -mg), vector(cBotM + mg, hM + mg), vector(-mg, hM + mg)]);
                names = append(names, "mast skin (one face, plate end at the bottom of the strip, cut " ~ definition.skinPlies * 2 ~ ")");
                cuts = append(cuts, definition.skinPlies * 2);
                const pl = plateAct != undefined ? plateAct.x1 - plateAct.x0 : mastM.plateLength * meter;
                const pw = plateAct != undefined ? plateAct.y1 - plateAct.y0 : mastM.plateWidth * meter;
                shapes = append(shapes, [vector(-mg, -mg), vector(pl + mg, -mg), vector(pl + mg, pw + mg), vector(-mg, pw + mg)]);
                names = append(names, "plate (cut " ~ (definition.skinPlies * 2 + plateFill) ~ ": " ~ definition.skinPlies * 2 ~ " skins + " ~ plateFill ~ " fill)");
                cuts = append(cuts, definition.skinPlies * 2 + plateFill);
                // UD caps: the plate end at v = 0 with the run-out below it and a 2 mm notch in each
                // edge at the fold line; tabs the same with Tab length above the fold
                const nSM = size(tplCAt) - 1;
                const rO = runOut * millimeter;
                const nk = 2 * millimeter;
                const wP = capW * tplCAt[0] * millimeter;                     // at the plate
                for (var k = 0; k < size(tplEnds); k += 1)
                {
                    const lenK = tplEnds[k] / nSM * hM;
                    const wE = capW * tplCAt[tplEnds[k]] * millimeter;        // at the ply's end
                    var strip = [vector(-mg, -rO - mg), vector(wP + mg, -rO - mg)];
                    if (rO > 0)
                        strip = concatenateArrays([strip, [vector(wP + mg, -nk), vector(wP + mg - nk, 0 * meter), vector(wP + mg, nk)]]);
                    strip = concatenateArrays([strip, [vector(wE + mg, lenK + mg), vector(-mg, lenK + mg)]]);
                    if (rO > 0)
                        strip = concatenateArrays([strip, [vector(-mg, nk), vector(-mg + nk, 0 * meter), vector(-mg, -nk)]]);
                    shapes = append(shapes, strip);
                    names = append(names, "UD ply " ~ (k + 1) ~ " (" ~ fmt(lenK / millimeter, 0) ~ " mm from the plate" ~ (rO > 0 ? " + " ~ fmt(runOut, 0) ~ " mm run-out, fold at the notches" : "") ~ ", cut 2)");
                    cuts = append(cuts, 2);
                }
                if (tabN > 0)
                {
                    const tL = tabLen * millimeter;
                    shapes = append(shapes, [vector(-mg, -rO - mg), vector(wP + mg, -rO - mg), vector(wP + mg, -nk), vector(wP + mg - nk, 0 * meter), vector(wP + mg, nk),
                            vector(wP + mg, tL + mg), vector(-mg, tL + mg), vector(-mg, nk), vector(-mg + nk, 0 * meter), vector(-mg, -nk)]);
                    names = append(names, "UD tab (" ~ fmt(runOut, 0) ~ " mm on the plate + " ~ fmt(tabLen, 0) ~ " mm down the mast, fold at the notches, cut " ~ 2 * tabN ~ ")");
                    cuts = append(cuts, 2 * tabN);
                }
            }
            else
            {
                // developed span: arc length along the droop / dihedral curve, per station of a fine grid
                const nT = 60;
                const hh = m.span / 2 * meter;
                var sDev = makeArray(nT + 1);
                var xLE = makeArray(nT + 1);
                var cT = makeArray(nT + 1);
                var zPrev = 0 * meter;
                sDev[0] = 0 * meter;
                for (var i = 0; i <= nT; i += 1)
                {
                    const eta = i / nT;
                    const chord = m.c0 * meter * chordFactor(m, eta) * (m.capOn == 1 && m.planRound != 1 && eta > capStartEta ? (1 - (1 - m.capEnd) * (eta - capStartEta) / max(1 - capStartEta, 1e-6)) : 1);
                    const fD = dropShape(m, eta);
                    const zOff = -m.tipDrop * meter * fD + hh * tan(m.rootDihedral * radian) * (eta - fD);
                    if (i > 0)
                        sDev[i] = sDev[i - 1] + sqrt((hh / nT) * (hh / nT) + (zOff - zPrev) * (zOff - zPrev));
                    zPrev = zOff;
                    const tailAdd = m.c0 * meter * tailFactor(m, eta);
                    const chordBase = (chord - tailAdd) / capPlanFactor(m, eta);
                    const xOff = m.sweepTip * meter * eta ^ m.sweepExp + (m.pivotFrac - m.align) * (chordBase - m.c0 * meter) + m.pivotFrac * tailAdd + (0.5 - m.pivotFrac) * (chordBase - (chord - tailAdd));
                    xLE[i] = xOff - m.pivotFrac * chord;
                    cT[i] = chord;
                }
                const both = m.mirror == 1;
                // woven skin: the whole developed planform (both halves if mirrored), LE and TE curves.
                // Every second station: the sketch stays a few hundred lines rather than thousands
                var skin = [];
                const idxS = tplIndices(both ? -nT : 0, nT, 2);
                for (var i in idxS)
                {
                    const a = abs(i);
                    skin = append(skin, vector(xLE[a] - mg, (i < 0 ? -1 : 1) * (sDev[a] + (a == nT ? mg : 0 * meter))));
                }
                for (var q = size(idxS) - 1; q >= 0; q -= 1)
                {
                    const i = idxS[q];
                    const a = abs(i);
                    skin = append(skin, vector(xLE[a] + cT[a] + mg, (i < 0 ? -1 : 1) * (sDev[a] + (a == nT ? mg : 0 * meter))));
                }
                shapes = append(shapes, skin);
                names = append(names, "woven skin - one outline, cut " ~ definition.skinPlies * 2 ~ " (" ~ definition.skinPlies ~ " per face" ~
                    (definition.skinPlies >= 2 ? "; turn the weave 45 deg on the outer ply of each face for torsion" : "") ~ ")");
                cuts = append(cuts, definition.skinPlies * 2);
                // UD plies: a strip about the thickest-point line (30 % chord), half-width Cap width % / 2
                // of the local chord, out to the ply's end station, grown by the margin
                const nSL = size(tplCAt) - 1;
                for (var k = 0; k < size(tplEnds); k += 1)
                {
                    const etaEnd = capStartEta * tplEnds[k] / nSL;
                    const iEndT = max(1, round(etaEnd * nT));
                    var strip = [];
                    const idxU = tplIndices(both ? -iEndT : 0, iEndT, max(1, round(iEndT / 10)));
                    for (var i in idxU)
                    {
                        const a = abs(i);
                        const xc = xLE[a] + 0.3 * cT[a];
                        strip = append(strip, vector(xc - capW * cT[a] / 2 - mg, (i < 0 ? -1 : 1) * (sDev[a] + (a == iEndT ? mg : 0 * meter))));
                    }
                    for (var q = size(idxU) - 1; q >= 0; q -= 1)
                    {
                        const i = idxU[q];
                        const a = abs(i);
                        const xc = xLE[a] + 0.3 * cT[a];
                        strip = append(strip, vector(xc + capW * cT[a] / 2 + mg, (i < 0 ? -1 : 1) * (sDev[a] + (a == iEndT ? mg : 0 * meter))));
                    }
                    shapes = append(shapes, strip);
                    names = append(names, "UD ply " ~ (k + 1) ~ " (" ~ fmt(2 * (sDev[iEndT] + mg) / millimeter * (both ? 1 : 0.5), 0) ~ " mm, cut 2)");
                    cuts = append(cuts, 2);
                }
            }
            // layout: shapes side by side along X, each in its own column, centred on a common V axis
            var uOff = 0 * meter;
            var vMax = -10 * meter;
            var vMin = 10 * meter;       // the plate is sized from the shapes' real extent (build 123: the
            var cols = [];               // mast's one-sided shapes left half the plate empty)
            for (var sh in shapes)
            {
                var uMin = 1 * meter;
                var uMax = -1 * meter;
                for (var q in sh)
                {
                    uMin = min(uMin, q[0]);
                    uMax = max(uMax, q[0]);
                    vMax = max(vMax, q[1]);
                    vMin = min(vMin, q[1]);
                }
                cols = append(cols, uOff - uMin);
                uOff += (uMax - uMin) + gap;
            }
            const plateW = uOff - gap + 2 * gap;
            var maxCuts = 1;
            for (var cnt in cuts)
                maxCuts = max(maxCuts, cnt);
            const tallyRows = ceil(maxCuts / 10);                       // tally holes wrap 10 to a row (a 40-ply plate)
            const tallyH = 6 * millimeter * tallyRows + 6 * millimeter;          // room for the tally rows under each shape
            const plateH = (vMax - vMin) + 2 * gap + tallyH;
            const x0P = lo[0] - plateW - 50 * millimeter;
            const y0P = lo[1];
            moldBox(context, id + "tplPlate", vector(x0P, y0P, zP), vector(x0P + plateW, y0P + plateH, zP + 1 * millimeter));
            const sid = id + "tplSketch";
            var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(x0P + gap, y0P + gap + tallyH - vMin, zP + 1 * millimeter), Z_DIRECTION, X_DIRECTION) });
            for (var n = 0; n < size(shapes); n += 1)
            {
                const sh = shapes[n];
                var uMinS = 1 * meter;
                var vMinS = 1 * meter;
                for (var q = 0; q < size(sh); q += 1)
                {
                    const a = sh[q];
                    const b = sh[(q + 1) % size(sh)];
                    uMinS = min(uMinS, a[0]);
                    vMinS = min(vMinS, a[1]);
                    if (norm(b - a) > 0.01 * millimeter)
                        skLineSegment(sk, "s" ~ n ~ "_" ~ q, { "start" : vector(a[0] + cols[n], a[1]), "end" : vector(b[0] + cols[n], b[1]) });
                }
                // tally: one 3 mm hole per piece to cut, rows of 10 under the shape's lower-left corner
                for (var t = 0; t < cuts[n]; t += 1)
                    skCircle(sk, "t" ~ n ~ "_" ~ t, { "center" : vector(uMinS + cols[n] + 2 * millimeter + (t % 10) * 6 * millimeter, vMinS - 6 * millimeter - floor(t / 10) * 6 * millimeter), "radius" : 1.5 * millimeter });
            }
            skSolve(sk);
            opExtrude(context, id + "tplCut", {
                        "entities" : qSketchRegion(sid),
                        "direction" : -Z_DIRECTION,
                        "endBound" : BoundingType.BLIND,
                        "endDepth" : 3 * millimeter
                    });
            opBoolean(context, id + "tplCutDo", {
                        "tools" : qCreatedBy(id + "tplCut", EntityType.BODY),
                        "targets" : qCreatedBy(id + "tplPlate", EntityType.BODY),
                        "operationType" : BooleanOperationType.SUBTRACTION
                    });
            opDeleteBodies(context, id + "tplSketchDel", { "entities" : qCreatedBy(sid, EntityType.BODY) });
            setProperty(context, { "entities" : qCreatedBy(id + "tplPlate", EntityType.BODY), "propertyType" : PropertyType.NAME,
                        "value" : (definition.moldSource == MoldSource.WING ? "Wing" : (isMast ? "Mast" : "Stab")) ~ " cut templates" });
            var key = "TEMPLATES (left to right on the plate, +" ~ fmt(mg / millimeter, 0) ~ " mm margin; the 3 mm holes under each shape (rows of 10) are its cut count; export the plate's top face as DXF):";
            for (var n = 0; n < size(names); n += 1)
                key = key ~ "\n" ~ (n + 1) ~ ": " ~ names[n];
            println(key);
        }

        // ---------------- parts group: one open composite of everything this feature made ----------------
        if (definition.partsGroup != PartsGroup.OFF)
        {
            try silent
            {
                opCreateCompositePart(context, id + "group", {
                            "bodies" : qBodyType(qCreatedBy(id, EntityType.BODY), BodyType.SOLID),
                            "closed" : definition.partsGroup == PartsGroup.CLOSED
                        });
                setProperty(context, { "entities" : qBodyType(qCreatedBy(id + "group", EntityType.BODY), BodyType.COMPOSITE), "propertyType" : PropertyType.NAME,
                            "value" : (definition.moldSource == MoldSource.WING ? "Wing" : (isMast ? "Mast" : "Stab")) ~ " mold" });
            }
        }
    });

/** Integer indices from a to b inclusive at the given stride, always ending on b (and passing 0 when the range straddles it). */
function tplIndices(a is number, b is number, stride is number) returns array
{
    var out = [];
    var i = a;
    while (i < b)
    {
        out = append(out, i);
        i += stride;
    }
    out = append(out, b);
    return out;
}

/** Solid box between two opposite corners, as a loft of two rectangles (the pattern this file already relies on). */
/**
 * The mast's plate as modelled, measured off the part: a copy (offset 2 m in Y so nothing coincides)
 * is split 0.05 mm above the plate's underside plane and the bounding boxes of the pieces on the
 * plate side are merged. Returns { x0, x1, y0, y1 (world), zTop (the underside plane), zBoard (the
 * board face) } or undefined when the split or the query fails; every temporary body is deleted
 * either way. Direct edits to the plate above the mold (fillets, chamfers, an outline, thickness)
 * are then what the tray follows (build 173).
 */
function moldPlateMeasure(context is Context, mid is Id, part is Query, mastM is map)
{
    const off = 2 * meter;
    const zTop = (mastM.baseZ + mastM.height) * meter;
    var result;
    try silent
    {
        opPattern(context, mid + "copy", {
                    "entities" : part,
                    "transforms" : [transform(vector(0 * meter, off, 0 * meter))],
                    "instanceNames" : ["p"]
                });
        const copy = qCreatedBy(mid + "copy", EntityType.BODY);
        const cb = evBox3d(context, { "topology" : copy, "tight" : true });
        const tool = moldCut(context, mid + "cut", copy, vector(0 * meter, off, zTop + 0.05 * millimeter), Z_DIRECTION, cb.minCorner, cb.maxCorner);
        const pieces = qUnion([copy, qCreatedBy(mid + "cut" + "split", EntityType.BODY), qCreatedBy(mid + "cut" + "split2", EntityType.BODY)]);
        var pb;
        for (var b in evaluateQuery(context, pieces))
        {
            const bb = evBox3d(context, { "topology" : b, "tight" : true });
            if (bb.minCorner[2] > zTop - 0.2 * millimeter)
            {
                if (pb == undefined)
                    pb = bb;
                else
                    pb = { "minCorner" : vector(min(pb.minCorner[0], bb.minCorner[0]), min(pb.minCorner[1], bb.minCorner[1]), min(pb.minCorner[2], bb.minCorner[2])),
                           "maxCorner" : vector(max(pb.maxCorner[0], bb.maxCorner[0]), max(pb.maxCorner[1], bb.maxCorner[1]), max(pb.maxCorner[2], bb.maxCorner[2])) };
            }
        }
        opDeleteBodies(context, mid + "del", { "entities" : qUnion([pieces, tool]) });
        if (pb != undefined && pb.maxCorner[2] > zTop + 0.5 * millimeter)
            result = { "x0" : pb.minCorner[0], "x1" : pb.maxCorner[0], "y0" : pb.minCorner[1] - off, "y1" : pb.maxCorner[1] - off,
                       "zTop" : zTop, "zBoard" : pb.maxCorner[2] };
    }
    // anything left behind by a failure part-way
    try silent
    {
        opDeleteBodies(context, mid + "del2", { "entities" : qUnion([qCreatedBy(mid + "copy", EntityType.BODY), qCreatedBy(mid + "cut" + "plane", EntityType.BODY),
                    qCreatedBy(mid + "cut" + "sheet", EntityType.BODY), qCreatedBy(mid + "cut" + "split", EntityType.BODY), qCreatedBy(mid + "cut" + "split2", EntityType.BODY)]) });
    }
    return result;
}

function moldBox(context is Context, boxId is Id, lo is Vector, hi is Vector)
{
    var sketchBodies = [];
    var profiles = [];
    for (var k = 0; k < 2; k += 1)
    {
        const z = k == 0 ? lo[2] : hi[2];
        const sid = boxId + ("r" ~ k);
        var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(0 * meter, 0 * meter, z), Z_DIRECTION, X_DIRECTION) });
        const c = [vector(lo[0], lo[1]), vector(hi[0], lo[1]), vector(hi[0], hi[1]), vector(lo[0], hi[1])];
        for (var j = 0; j < 4; j += 1)
            skLineSegment(sk, "s" ~ j, { "start" : c[j], "end" : c[(j + 1) % 4] });
        skSolve(sk);
        profiles = append(profiles, qSketchRegion(sid));
        sketchBodies = append(sketchBodies, qCreatedBy(sid, EntityType.BODY));
    }
    opLoft(context, boxId, { "profileSubqueries" : profiles });
    opDeleteBodies(context, boxId + "del", { "entities" : qUnion(sketchBodies) });
}

/** Tiles of one half ordered by span position (-Y first), then chord position (-X first). */
function moldSortTiles(context is Context, tiles is Query) returns array
{
    var rows = [];
    for (var b in evaluateQuery(context, tiles))
    {
        const bx = evBox3d(context, { "topology" : b, "tight" : false });
        rows = append(rows, { "q" : b, "y" : (bx.minCorner[1] + bx.maxCorner[1]) / 2 / meter, "x" : (bx.minCorner[0] + bx.maxCorner[0]) / 2 / meter });
    }
    rows = sort(rows, function(a, b) { return abs(a.y - b.y) > 1e-4 ? a.y - b.y : a.x - b.x; });
    var out = [];
    for (var r in rows)
        out = append(out, r.q);
    return out;
}

/**
 * Closed loop offset outward by d: each edge shifted along its outward normal, convex corners
 * bevelled (both offset endpoints kept), reflex corners mitred (the two offset edges intersected)
 * so the result does not cross itself. pts are 2D (x, y) with units.
 */
function moldOffsetLoop(pts is array, d is ValueWithUnits) returns array
{
    const n = size(pts);
    var area2 = 0 * meter * meter;
    for (var i = 0; i < n; i += 1)
        area2 += pts[i][0] * pts[(i + 1) % n][1] - pts[(i + 1) % n][0] * pts[i][1];
    const sgn = area2 > 0 * meter * meter ? 1 : -1;
    var starts = [];
    var ends = [];
    var dirs = [];
    for (var i = 0; i < n; i += 1)
    {
        const a = pts[i];
        const b = pts[(i + 1) % n];
        const t = b - a;
        const len = norm(t);
        if (len < 1e-6 * meter)
            continue;
        const u = t / len;
        const nrm = vector(u[1], -u[0]) * sgn;
        starts = append(starts, a + nrm * d);
        ends = append(ends, b + nrm * d);
        dirs = append(dirs, u);
    }
    const ne = size(starts);
    var out = [];
    for (var i = 0; i < ne; i += 1)
    {
        const j = (i + 1) % ne;
        const cross = (dirs[i][0] * dirs[j][1] - dirs[i][1] * dirs[j][0]) * sgn;
        if (cross >= -1e-9)
        {
            out = append(out, ends[i]);            // convex or straight: bevel
        }
        else
        {
            // reflex: intersect edge i (ends[i] - dirs[i] s) with edge j (starts[j] + dirs[j] t).
            // Build 134 tried a miter limit here (bevel when the intersection is far) and it removed
            // the groove from every mold - this is the build 51-133 code, which works on the wing,
            // the pad-top stab and the mast; a loop that still cannot be lofted is skipped upstream
            const w = starts[j] - ends[i];
            const den = dirs[i][0] * dirs[j][1] - dirs[i][1] * dirs[j][0];
            const sPar = (w[0] * dirs[j][1] - w[1] * dirs[j][0]) / den;
            out = append(out, ends[i] + dirs[i] * sPar);
            starts[j] = out[size(out) - 1];
        }
    }
    // drop the bevel duplicates: each edge contributes its start when it differs from the previous point
    var loop = [];
    for (var i = 0; i < ne; i += 1)
    {
        const p = starts[i];
        if (size(loop) == 0 || norm(p - loop[size(loop) - 1]) > 1e-6 * meter)
            loop = append(loop, p);
        const q = out[i];
        if (norm(q - loop[size(loop) - 1]) > 1e-6 * meter)
            loop = append(loop, q);
    }
    return loop;
}

/** Prism of a closed 2D (x, y) loop between z0 and z1, as a loft of two polygon sketches. */
function moldPrism(context is Context, prismId is Id, loop is array, z0 is ValueWithUnits, z1 is ValueWithUnits)
{
    var sketchBodies = [];
    var profiles = [];
    const zs = [z0, z1];
    for (var k = 0; k < 2; k += 1)
    {
        const sid = prismId + ("p" ~ k);
        var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(0 * meter, 0 * meter, zs[k]), Z_DIRECTION, X_DIRECTION) });
        for (var i = 0; i < size(loop); i += 1)
            skLineSegment(sk, "e" ~ i, { "start" : loop[i], "end" : loop[(i + 1) % size(loop)] });
        skSolve(sk);
        profiles = append(profiles, qSketchRegion(sid));
        sketchBodies = append(sketchBodies, qCreatedBy(sid, EntityType.BODY));
    }
    opLoft(context, prismId, { "profileSubqueries" : profiles });
    opDeleteBodies(context, prismId + "del", { "entities" : qUnion(sketchBodies) });
}

/**
 * Every solid of this feature sorted by which block face it touches: upper touches the top only, lower the
 * bottom only. Called immediately before every operation that needs a half or a tile - the transient
 * queries evaluateQuery returns are only valid until the next operation changes the context, so no body
 * reference is ever held across one.
 */
/** The bodies among solids that touch neither the block's top nor its bottom face: cores, plugs, loose keys. */
function moldFloating(context is Context, solids is Query, lo is Vector, hi is Vector) returns Query
{
    // tight boxes: a loose box on a lofted core can overshoot the block face and hide the body
    var fl = [];
    for (var b in evaluateQuery(context, solids))
    {
        const bx = evBox3d(context, { "topology" : b, "tight" : true });
        if (bx.maxCorner[2] <= hi[2] - 0.5 * millimeter && bx.minCorner[2] >= lo[2] + 0.5 * millimeter)
            fl = append(fl, b);
    }
    return qUnion(fl);
}

function moldHalves(context is Context, solids is Query, lo is Vector, hi is Vector) returns map
{
    var up = [];
    var dn = [];
    for (var b in evaluateQuery(context, solids))
    {
        const bx = evBox3d(context, { "topology" : b, "tight" : false });
        const top = bx.maxCorner[2] > hi[2] - 0.5 * millimeter;
        const bottom = bx.minCorner[2] < lo[2] + 0.5 * millimeter;
        if (top && !bottom)
            up = append(up, b);
        else if (bottom && !top)
            dn = append(dn, b);
        // touching both (an uncut block) or neither (a tool) is not a half
    }
    return { "upper" : qUnion(up), "lower" : qUnion(dn), "nUpper" : size(up), "nLower" : size(dn) };
}

/** Cylinder between two centre points (axis along X, Y or Z). Returns its body query. */
function moldPin(context is Context, pinId is Id, c0 is Vector, c1 is Vector, r is ValueWithUnits) returns Query
{
    return moldFrustum(context, pinId, c0, c1, r, r);
}

/** Truncated cone from c0 (radius r0) to c1 (radius r1), as a loft of two circles. Returns its body query. */
function moldFrustum(context is Context, pinId is Id, c0 is Vector, c1 is Vector, r0 is ValueWithUnits, r1 is ValueWithUnits) returns Query
{
    const axis = normalize(c1 - c0);
    const xdir = abs(axis[0]) > 0.5 ? Y_DIRECTION : X_DIRECTION;
    const cs = [c0, c1];
    const rs = [r0, r1];
    var regions = [];
    for (var i = 0; i < 2; i += 1)
    {
        const sid = pinId + ("c" ~ i);
        var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(cs[i], axis, xdir) });
        skCircle(sk, "c", { "center" : vector(0, 0) * meter, "radius" : rs[i] });
        skSolve(sk);
        regions = append(regions, qSketchRegion(sid));
    }
    opLoft(context, pinId + "loft", { "profileSubqueries" : regions });
    opDeleteBodies(context, pinId + "del", { "entities" : qUnion([qCreatedBy(pinId + "c0", EntityType.BODY), qCreatedBy(pinId + "c1", EntityType.BODY)]) });
    return qCreatedBy(pinId + "loft", EntityType.BODY);
}

/**
 * One printed key across a joint at point p, boss pointing along d. The socket (radius + fit, 0.3 mm
 * deeper) is cut into the tile of half sideB (0 upper, 1 lower) whose footprint holds pB, then the
 * boss is joined to the tile of half sideA holding pA, base sunk 1 mm in. Both tiles are looked up
 * after their tool body exists, never held across an operation.
 */
/**
 * One printed key across a tile seam: a socket cut into the tile under pB, a boss joined to the
 * tile under pA. Returns false and makes nothing when either point is not on a tile - a seam
 * that crosses the socket plug channel has its flange cut away there, and build 127 joined the
 * boss to the nearest tile anyway, leaving it floating as its own part.
 */
function moldPrintedKey(context is Context, keyId is Id, solids is Query, lo is Vector, hi is Vector, sideA is number, sideB is number,
    pA is Vector, pB is Vector, p is Vector, d is Vector, rB is ValueWithUnits, rT is ValueWithUnits, hb is ValueWithUnits, fit is ValueWithUnits) returns boolean
{
    const sink = 1 * millimeter;
    var hv = moldHalves(context, solids, lo, hi);
    const nearB = moldTileNear(context, sideB == 0 ? hv.upper : hv.lower, pB);
    const nearA = moldTileNear(context, sideA == 0 ? hv.upper : hv.lower, pA);
    if (nearA.d > 1 * millimeter || nearB.d > 1 * millimeter)
        return false;
    const sock = moldFrustum(context, keyId + "s", p - sink * d, p + (hb + 0.3 * millimeter) * d, rB + fit, rT + fit);
    opBoolean(context, keyId + "cut", { "tools" : sock, "targets" : nearB.body, "operationType" : BooleanOperationType.SUBTRACTION });
    const boss = moldFrustum(context, keyId + "b", p - sink * d, p + hb * d, rB, rT);
    hv = moldHalves(context, solids, lo, hi);
    opBoolean(context, keyId + "join", { "tools" : qUnion([moldTileAt(context, sideA == 0 ? hv.upper : hv.lower, pA), boss]), "operationType" : BooleanOperationType.UNION });
    return true;
}

/** The nearest tile (of one half) to point pt, and its distance. */
function moldTileNear(context is Context, tiles is Query, pt is Vector) returns map
{
    // nearest body to the point (the key points lie on or just inside their tile, so the distance
    // is ~0). Build 82 used loose bounding-box containment, which on the drooped wing tips matched
    // a neighbouring tile first: the boss was "unioned" with a body it never touched and was left
    // floating as its own part
    var best;
    var bestD = 1 * meter;
    for (var b in evaluateQuery(context, tiles))
    {
        const d = evDistance(context, { "side0" : b, "side1" : pt }).distance;
        if (best == undefined || d < bestD)
        {
            best = b;
            bestD = d;
        }
    }
    if (best == undefined)
        throw regenError("No tile found under a key position - inspect the bodies");
    return { "body" : best, "d" : bestD };
}

/** The tile (of one half) nearest to point pt. */
function moldTileAt(context is Context, tiles is Query, pt is Vector) returns Query
{
    return moldTileNear(context, tiles, pt).body;
}

/**
 * Splits targets with a plane through origin, normal n. Tries a construction plane first; if
 * Onshape refuses that as a split tool, a planar sheet lofted between two lines. Returns the
 * tool body to delete afterwards.
 */
function moldCut(context is Context, cutId is Id, targets is Query, origin is Vector, n is Vector, lo is Vector, hi is Vector) returns Query
{
    const big = 2 * max(hi[0] - lo[0], max(hi[1] - lo[1], hi[2] - lo[2]));
    try
    {
        opPlane(context, cutId + "plane", { "plane" : plane(origin, n), "width" : big, "height" : big });
        opSplitPart(context, cutId + "split", { "targets" : targets, "tool" : qCreatedBy(cutId + "plane", EntityType.FACE) });
        return qCreatedBy(cutId + "plane", EntityType.BODY);
    }
    catch
    {
        // sheet: two parallel lines in the cut plane, lofted as a surface
        const xdir = abs(n[1]) > 0.5 ? X_DIRECTION : Y_DIRECTION;   // in-plane direction
        const c = origin;
        const zlo = lo[2] - 10 * millimeter;
        const zhi = hi[2] + 10 * millimeter;
        var edges = [];
        for (var i = 0; i < 2; i += 1)
        {
            const sid = cutId + ("l" ~ i);
            var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(c, n, xdir) });
            const z = i == 0 ? zlo : zhi;
            skLineSegment(sk, "e", { "start" : vector(-big, z - c[2]), "end" : vector(big, z - c[2]) });
            skSolve(sk);
            edges = append(edges, qCreatedBy(sid, EntityType.EDGE));
        }
        opLoft(context, cutId + "sheet", { "profileSubqueries" : edges, "bodyType" : ToolBodyType.SURFACE });
        opDeleteBodies(context, cutId + "dl", { "entities" : qUnion([qCreatedBy(cutId + "l0", EntityType.BODY), qCreatedBy(cutId + "l1", EntityType.BODY)]) });
        opSplitPart(context, cutId + "split2", { "targets" : targets, "tool" : qCreatedBy(cutId + "sheet", EntityType.FACE) });
        return qCreatedBy(cutId + "sheet", EntityType.BODY);
    }
}

/**
 * World points of the parting curve at one station: the section's camber line (mean of upper and
 * lower), placed with the same chord, twist, sweep and droop as buildFoil, extended straight along
 * the local chord direction to xMin forward and xMax aft. With a socket map, the aft run is aimed
 * through the nacelle axis instead.
 */
/**
 * Parting curve at one station. With a stab mount map (foilStabRoot with padOn) the parting over the pad's
 * plan (|y| within Pad width / 2) is the pad-side skin of the part instead of the camber line: the
 * nose, the ramp up to the pad plane, then the pad plane itself out to the block edge. The whole
 * section, the pad's side walls and the tail fairing then sit in the half away from the pad, and
 * the other half only forms the flat pad face - the Axis mold layout. Nothing changes off the pad.
 */
function moldPartingPointsPad(m is map, mini is map, eta is number, y is ValueWithUnits, base is Vector, xMin is ValueWithUnits, xMax is ValueWithUnits, sock, pad) returns map
{
    const onPad = pad != undefined && pad.padOn == 1 && pad.padSide != 0 && abs(y) <= pad.padWidth / 2 * meter;
    const h = m.span / 2 * meter;
    const chord0 = m.c0 * meter * chordFactor(m, eta);
    const tailAdd = m.c0 * meter * tailFactor(m, eta);
    const thick0 = (m.rootT + (m.tipT - m.rootT) * eta ^ m.thicknessExp) * (chord0 - tailAdd) / chord0;
    const twist = (m.incidence - m.washout * eta ^ m.washoutExp) * radian;
    const chordBase = (chord0 - tailAdd) / capPlanFactor(m, eta);
    const alignShift = (m.pivotFrac - m.align) * (chordBase - m.c0 * meter) + m.pivotFrac * tailAdd + (0.5 - m.pivotFrac) * (chordBase - (chord0 - tailAdd));
    const fDropM = dropShape(m, eta);
    const bump = bumpOffset(m, eta, h);                  // leading-edge bumps, as buildFoil places them
    const chord = chord0 + bump;
    const thick = thick0 * chord0 / chord;
    const xOff = m.sweepTip * meter * eta ^ m.sweepExp + alignShift - (1 - m.pivotFrac) * bump;
    const zOff = -m.tipDrop * meter * fDropM + h * tan(m.rootDihedral * radian) * (eta - fDropM);
    const cosT = cos(twist);
    const sinT = sin(twist);

    // the parting line of a vertical pull is the section's silhouette from above: from its most
    // forward point to its most aft point, along the midline of its vertical extent at each x.
    // Computed on the PLACED (twisted, scaled) outline, so it is exact for any profile - a mean line
    // through the profile table's (0, 0) is not: E818's drooped nose has its lower surface above that
    // point and the mean line left the section there (tongue in the upper half, BOOLEAN_INVALID)
    const teFrac = min(m.teThick * meter, 0.03 * chord) / chord;
    const sec = buildSectionAt(mini, thick, teFrac, 40, sectionWeightAt(mini, eta));
    const placed = placeSection(sec, chord, m.pivotFrac, cosT, sinT);
    const np = size(placed);
    var iMin = 0;
    var iMax = 0;
    for (var i = 1; i < np; i += 1)
    {
        if (placed[i][0] < placed[iMin][0])
            iMin = i;
        if (placed[i][0] > placed[iMax][0])
            iMax = i;
    }
    const xNose = placed[iMin][0];
    const xTail = placed[iMax][0] - 0.1 * millimeter;      // just ahead of the trailing-edge face
    const origin = base + vector(xOff, y, zOff);
    // 30 samples, cosine-packed towards nose and tail: an aft-loaded section (E818) bends its
    // midline hard where it is under a millimetre thick, and a coarser spline strays outside it
    const nS = 30;
    var cam = [origin + vector(placed[iMin][0], 0 * meter, placed[iMin][1])];
    // pad: plane and ramp in this station's frame (the pad plane is horizontal in world)
    var padRel = 0 * meter;
    var xR0 = 0 * meter;
    var xR1 = 0 * meter;
    if (onPad)
    {
        padRel = pad.padZ * meter - origin[2];
        xR0 = pad.padX0 * meter - origin[0];
        xR1 = pad.leX * meter - origin[0] + pad.padRampPct / 100 * (pad.teX - pad.leX) * meter;
    }
    for (var k = 1; k < nS; k += 1)
    {
        const xs = xNose + (xTail - xNose) * 0.5 * (1 - cos((PI * k / (nS - 1)) * radian));
        var zLo = 1 * meter;
        var zHi = -1 * meter;
        for (var i = 0; i < np; i += 1)
        {
            const p = placed[i];
            const q = placed[(i + 1) % np];
            if ((p[0] - xs) * (q[0] - xs) <= 0 * meter * meter && abs(q[0] - p[0]) > 1e-9 * meter)
            {
                const z = p[1] + (q[1] - p[1]) * ((xs - p[0]) / (q[0] - p[0]));
                zLo = min(zLo, z);
                zHi = max(zHi, z);
            }
        }
        if (onPad)
        {
            // pad-side skin with the mount's own ramp law (smoothstep from the nose to Pad ramp %)
            const skin = pad.padSide == 1 ? zHi : zLo;
            const t = min(max((xs - xR0) / (xR1 - xR0), 0), 1);
            const sm = t * t * (3 - 2 * t);
            cam = append(cam, origin + vector(xs, 0 * meter, skin + (padRel - skin) * sm));
        }
        else
            cam = append(cam, origin + vector(xs, 0 * meter, 0.5 * (zLo + zHi)));
    }
    const le = cam[0];
    const te = cam[size(cam) - 1];

    // horizontal runs out to xMin forward and xMax aft (a corner at the LE/TE is fine for the loft;
    // an extension collinear with a straight mean line was not). At the wing socket the aft run
    // rises to the nacelle axis, so its round section splits within 0.05 mm of a diameter. Over the
    // pad the aft run is the pad plane itself, which also forms the tail fairing's flat face
    const front = vector(xMin, y, le[2]);
    const aft = vector(xMax, y, onPad ? origin[2] + padRel : (sock == undefined ? te[2] : sock.axisZ * meter));
    return { "front" : front, "camber" : cam, "aft" : aft };
}

/**
 * Winglet parting table (build 151): the part's mid-thickness surface over the bent tip, sampled on
 * sub-stations along the span line from the bend start to sEnd (beyond the tip, where the tip
 * section is repeated), as world points on the +Y side. Row j holds x[i], y[i], z[i] for i = 0 (LE)
 * to nS - 1 (TE), each on that sub-station's own tilted section plane, so every point is on the true
 * mid-surface. moldPartingPointsWinglet cuts the table with a vertical plane, which is exact to the
 * table's spacing; build 149's "lift the midline by 1 / cos(phi)" left slivers at the LE/TE and the
 * cavity cut failed.
 */
function moldWingletTable(m is map, mini is map, base is Vector, sEnd is ValueWithUnits) returns map
{
    const h = m.span / 2 * meter;
    const s0 = m.wingletEta * h;
    const N = 48;
    const nS = 30;
    var rows = [];
    for (var j = 0; j <= N; j += 1)
    {
        const sj = s0 + (sEnd - s0) * j / N;
        var wf = wingletFrame(m, sj / h);
        if (sj > h)
        {
            // beyond the tip the parting runs FLAT outward at the tip's height, not on up the
            // winglet's line: continued at 45 deg it reached the block's top face at the edge, the
            // lower half then touched top and bottom and moldHalves no longer saw it as a half
            // (CANNOT_RESOLVE_ENTITIES cutting the LOWER cavity, build 151)
            const tf = wingletFrame(m, 1);
            wf = { "on" : true, "y" : tf.y + (sj - h), "z" : tf.z, "phi" : 0 * degree };
        }
        const eta = min(sj / h, 1);
        const chord = m.c0 * meter * chordFactor(m, eta);
        const tailAdd = m.c0 * meter * tailFactor(m, eta);
        const thick = (m.rootT + (m.tipT - m.rootT) * eta ^ m.thicknessExp) * (chord - tailAdd) / chord;
        const twist = (m.incidence - m.washout * eta ^ m.washoutExp) * radian;
        const chordBase = (chord - tailAdd) / capPlanFactor(m, eta);
        const alignShift = (m.pivotFrac - m.align) * (chordBase - m.c0 * meter) + m.pivotFrac * tailAdd + (0.5 - m.pivotFrac) * (chordBase - (chord - tailAdd));
        const bump = bumpOffset(m, eta, h);
        const chordB = chord + bump;
        const xOff = m.sweepTip * meter * eta ^ m.sweepExp + alignShift - (1 - m.pivotFrac) * bump;
        const teFrac = min(m.teThick * meter, 0.03 * chordB) / chordB;
        const sec = buildSectionAt(mini, thick * chord / chordB, teFrac, 40, sectionWeightAt(mini, eta));
        const placed = placeSection(sec, chordB, m.pivotFrac, cos(twist), sin(twist));
        const np = size(placed);
        var iMin = 0;
        var iMax = 0;
        for (var i = 1; i < np; i += 1)
        {
            if (placed[i][0] < placed[iMin][0])
                iMin = i;
            if (placed[i][0] > placed[iMax][0])
                iMax = i;
        }
        const xNose = placed[iMin][0];
        const xTail = placed[iMax][0] - 0.1 * millimeter;
        var lx = [placed[iMin][0]];
        var lz = [placed[iMin][1]];
        for (var k = 1; k < nS; k += 1)
        {
            const xs = xNose + (xTail - xNose) * 0.5 * (1 - cos((PI * k / (nS - 1)) * radian));
            var zLo = 1 * meter;
            var zHi = -1 * meter;
            for (var i = 0; i < np; i += 1)
            {
                const p = placed[i];
                const q = placed[(i + 1) % np];
                if ((p[0] - xs) * (q[0] - xs) <= 0 * meter * meter && abs(q[0] - p[0]) > 1e-9 * meter)
                {
                    const z = p[1] + (q[1] - p[1]) * ((xs - p[0]) / (q[0] - p[0]));
                    zLo = min(zLo, z);
                    zHi = max(zHi, z);
                }
            }
            lx = append(lx, xs);
            lz = append(lz, 0.5 * (zLo + zHi));
        }
        const vy = -sin(wf.phi);
        const vz = cos(wf.phi);
        var px = [];
        var py = [];
        var pz = [];
        for (var i = 0; i < nS; i += 1)
        {
            px = append(px, base[0] + xOff + lx[i]);
            py = append(py, wf.y + lz[i] * vy);
            pz = append(pz, base[2] + wf.z + lz[i] * vz);
        }
        rows = append(rows, { "x" : px, "y" : py, "z" : pz });
    }
    return { "rows" : rows, "nS" : nS, "yStart" : wingletFrame(m, m.wingletEta).y };
}

/** Parting points of the winglet mid-surface on the vertical plane |y| = yAbs; sgnY picks the side. */
function moldPartingPointsWinglet(tab is map, yAbs is ValueWithUnits, sgnY is number, xMin is ValueWithUnits, xMax is ValueWithUnits) returns map
{
    const rows = tab.rows;
    const nR = size(rows);
    var cam = [];
    for (var i = 0; i < tab.nS; i += 1)
    {
        var j = 0;
        while (j < nR - 2 && rows[j + 1].y[i] < yAbs)
            j += 1;
        const y0 = rows[j].y[i];
        const y1 = rows[j + 1].y[i];
        const t = y1 > y0 ? min(max((yAbs - y0) / (y1 - y0), 0), 1) : 0;
        cam = append(cam, vector(rows[j].x[i] + t * (rows[j + 1].x[i] - rows[j].x[i]), sgnY * yAbs, rows[j].z[i] + t * (rows[j + 1].z[i] - rows[j].z[i])));
    }
    return { "front" : vector(xMin, sgnY * yAbs, cam[0][2]), "camber" : cam, "aft" : vector(xMax, sgnY * yAbs, cam[tab.nS - 1][2]) };
}

/**
 * Foam core body (build 158): the part's sections offset inward by one face's skin thickness, with
 * the UD caps' grooves cut into both faces where the caps run, lofted through the part's own
 * stations (with its bumps and winglet frame). skinFace, tSkins are lengths; capW is the cap width
 * as a fraction of chord; capF the caps' share of the core thickness. Returns the body (mirrored
 * and joined if the part is), or undefined when no station has room for a core.
 */
function moldCoreBody(context is Context, id is Id, m is map, mini is map, base is Vector, skinFace is ValueWithUnits, capW is number, capF is number, tSkins is ValueWithUnits, nStations is number, tipBias is number, ventLen is ValueWithUnits)
{
    const h = m.span / 2 * meter;
    var etas = [];
    const N = max(nStations, 24);
    for (var i = 0; i <= N; i += 1)
        etas = append(etas, 1 - (1 - i / N) ^ tipBias);
    if (m.bumpOn == 1)
    {
        var yb = m.bumpFrom * h;
        const yEnd = min(m.bumpTo * h, h);
        while (yb <= yEnd)
        {
            etas = append(etas, yb / h);
            yb += m.bumpPitch * meter / 6;
        }
    }
    if (m.wingletOn == 1)
    {
        const arcEta = m.wingletR * meter * m.wingletAngle / h;
        for (var k = 0; k <= 4; k += 1)
            etas = append(etas, min(m.wingletEta + arcEta * k / 4, 1));
    }
    etas = sort(etas, function(a, b) { return a - b; });
    var uniq = [];
    for (var e in etas)
    {
        const ec = min(max(e, 0), 0.995);        // from the root plane itself, so the mirrored halves meet and join (build 160: 0.002 left a 1.9 mm gap, two core bodies)
        if (size(uniq) == 0 || ec - uniq[size(uniq) - 1] > 1e-3)
            uniq = append(uniq, ec);
    }
    var profiles = [];
    var sketches = [];
    var lastCore;                                                            // the outermost core outline and its frame, for the tip vent
    var lastOrigin;
    var lastNormal;
    for (var i = 0; i < size(uniq); i += 1)
    {
        const eta = uniq[i];
        const chord0 = m.c0 * meter * chordFactor(m, eta);
        const tailAdd = m.c0 * meter * tailFactor(m, eta);
        const thick0 = (m.rootT + (m.tipT - m.rootT) * eta ^ m.thicknessExp) * (chord0 - tailAdd) / chord0;
        const twist = (m.incidence - m.washout * eta ^ m.washoutExp) * radian;
        const chordBase = (chord0 - tailAdd) / capPlanFactor(m, eta);
        const alignShift = (m.pivotFrac - m.align) * (chordBase - m.c0 * meter) + m.pivotFrac * tailAdd + (0.5 - m.pivotFrac) * (chordBase - (chord0 - tailAdd));
        const bump = bumpOffset(m, eta, h);
        const chord = chord0 + bump;
        var thick = thick0 * chord0 / chord;
        if (m.capOn == 1 && m.capLength > 0)
        {
            // the tip cap's thickness law, as buildFoil applies it
            const capStartEta = 1 - m.capLength / (m.span / 2);
            if (eta > capStartEta)
            {
                const d = min((eta - capStartEta) / (1 - capStartEta), 1);
                thick = thick * (m.capEnd + (1 - m.capEnd) * sqrt(max(1 - d * d, 0))) / (m.planRound == 1 ? capPlanFactor(m, eta) : 1);
            }
        }
        const xOff = m.sweepTip * meter * eta ^ m.sweepExp + alignShift - (1 - m.pivotFrac) * bump;
        const wf = wingletFrame(m, eta);
        const teFrac = min(m.teThick * meter, 0.03 * chord) / chord;
        const sec = buildSectionAt(mini, thick, teFrac, 40, sectionWeightAt(mini, eta));
        const placed = placeSection(sec, chord, m.pivotFrac, cos(twist), sin(twist));
        const capT = capF * max(thick * chord - tSkins, 0 * meter) / 2;      // one cap's thickness here
        const core = coreOutline(placed, skinFace, capW * chord, capT);
        if (core == undefined)
            break;                                                           // too thin from here out: the core ends
        const origin = base + vector(xOff, wf.y, wf.z);
        const nrm = vector(0, -cos(wf.phi), -sin(wf.phi));
        profiles = append(profiles, coreSketch(context, id + ("core" ~ i), origin, nrm, core));
        sketches = append(sketches, qCreatedBy(id + ("core" ~ i), EntityType.BODY));
        lastCore = core;
        lastOrigin = origin;
        lastNormal = nrm;
    }
    if (size(profiles) < 2)
        return undefined;
    opLoft(context, id + "coreLoft", { "profileSubqueries" : profiles });
    // tip vent (user: leave the tips open so a poured foam can expand out): the outermost core
    // section carried straight out along +Y past the block's side, cut with the cavity and then
    // removed, so the cavity is a channel open at the tip. Straight in Y, not up a winglet, so it
    // stays with the parting's flat continuation beyond the tip. ventLen 0 = no vent (printed core)
    const withVent = ventLen > 0 * meter;
    var ventQ = qNothing();
    if (withVent)
    {
        const v0 = coreSketch(context, id + "ventA", lastOrigin, lastNormal, lastCore);
        const v1 = coreSketch(context, id + "ventB", lastOrigin + vector(0 * meter, ventLen, 0 * meter), lastNormal, lastCore);
        opLoft(context, id + "coreVent", { "profileSubqueries" : [v0, v1] });
        sketches = append(sketches, qCreatedBy(id + "ventA", EntityType.BODY));
        sketches = append(sketches, qCreatedBy(id + "ventB", EntityType.BODY));
        ventQ = qCreatedBy(id + "coreVent", EntityType.BODY);
    }
    opDeleteBodies(context, id + "coreSketches", { "entities" : qUnion(sketches) });
    if (m.mirror == 1)
    {
        opPattern(context, id + "coreMirror", {
                    "entities" : qCreatedBy(id + "coreLoft", EntityType.BODY),
                    "transforms" : [mirrorAcross(plane(WORLD_ORIGIN, Y_DIRECTION))],
                    "instanceNames" : ["left"]
                });
        if (withVent)
        {
            opPattern(context, id + "ventMirror", {
                        "entities" : qCreatedBy(id + "coreVent", EntityType.BODY),
                        "transforms" : [mirrorAcross(plane(WORLD_ORIGIN, Y_DIRECTION))],
                        "instanceNames" : ["left"]
                    });
            ventQ = qUnion([qCreatedBy(id + "coreVent", EntityType.BODY), qCreatedBy(id + "ventMirror", EntityType.BODY)]);
        }
        opBoolean(context, id + "coreJoin", {
                    "tools" : qUnion([qCreatedBy(id + "coreLoft", EntityType.BODY), qCreatedBy(id + "coreMirror", EntityType.BODY)]),
                    "operationType" : BooleanOperationType.UNION
                });
    }
    // the core is whatever solid this feature has made so far that is not a vent (a union's result
    // is not reliably "created by" either of its inputs); tag both so later queries stay valid
    const coreQ = qSubtraction(qBodyType(qCreatedBy(id, EntityType.BODY), BodyType.SOLID), ventQ);
    setAttribute(context, { "entities" : coreQ, "name" : "foilCoreBody", "attribute" : 1 });
    if (withVent)
        setAttribute(context, { "entities" : ventQ, "name" : "foilCoreVent", "attribute" : 1 });   // an empty query throws (printed core, build 161)
    return { "body" : qHasAttribute("foilCoreBody"), "vent" : withVent ? qHasAttribute("foilCoreVent") : undefined };
}

/** One core section as a closed sketch region on the plane (origin, normal, X): upper spline, nose line, lower spline, tail line. */
function coreSketch(context is Context, sid is Id, origin is Vector, nrm is Vector, core is map) returns Query
{
    var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(origin, nrm, X_DIRECTION) });
    skFitSpline(sk, "upper", { "points" : core.upper });
    skLineSegment(sk, "nose", { "start" : core.upper[size(core.upper) - 1], "end" : core.lower[0] });
    skFitSpline(sk, "lower", { "points" : core.lower });
    skLineSegment(sk, "tail", { "start" : core.lower[size(core.lower) - 1], "end" : core.upper[0] });
    skSolve(sk);
    return qSketchRegion(sid);
}

/**
 * Core outline of one placed section: the closed loop offset inward along its normals by skin,
 * re-read as upper and lower curves of x, clipped where they come within 0.6 mm of each other
 * (a blunt nose and tail), with each face lowered by capT over a band bandW wide centred on the
 * thickest point (the UD cap's groove, ramped over a tenth of the band at each edge). Returns
 * { upper : TE -> nose, lower : nose -> TE } as sketch points, or undefined if nothing is left.
 */
function coreOutline(placed is array, skin is ValueWithUnits, bandW is ValueWithUnits, capT is ValueWithUnits)
{
    const n = size(placed);
    var area2 = 0 * meter * meter;
    for (var i = 0; i < n; i += 1)
    {
        const j = (i + 1) % n;
        area2 += placed[i][0] * placed[j][1] - placed[j][0] * placed[i][1];
    }
    const sgn = area2 > 0 * meter * meter ? 1 : -1;                          // CCW: the left normal points in
    var off = [];
    for (var i = 0; i < n; i += 1)
    {
        // one-sided tangents at the two trailing-edge corners: a tangent across the TE face pushed
        // the corner point back along the chord and the face walk below broke on it
        const a = i == 0 ? placed[0] : placed[i - 1];
        const b = i == n - 1 ? placed[n - 1] : placed[i + 1];
        var tx = (b[0] - a[0]) / meter;
        var ty = (b[1] - a[1]) / meter;
        const len = sqrt(tx * tx + ty * ty);
        if (len < 1e-12)
            continue;
        tx = tx / len;
        ty = ty / len;
        off = append(off, vector(placed[i][0] - sgn * ty * skin, placed[i][1] + sgn * tx * skin));
    }
    // the loop runs upper TE -> LE -> lower TE; split at the original nose, then keep the part of
    // each offset curve that is still monotonic in x from the TE end (the offset folds at the nose)
    const nLE = (n + 1) / 2 - 1;
    var up = [];                                                              // TE -> nose, x decreasing
    for (var i = 0; i <= nLE && i < size(off); i += 1)
    {
        if (size(up) > 0 && off[i][0] >= up[size(up) - 1][0])
            break;
        up = append(up, off[i]);
    }
    var lo = [];                                                              // TE -> nose too (walk the lower curve backwards)
    for (var i = size(off) - 1; i >= nLE; i -= 1)
    {
        if (size(lo) > 0 && off[i][0] >= lo[size(lo) - 1][0])
            break;
        lo = append(lo, off[i]);
    }
    if (size(up) < 3 || size(lo) < 3)
        return undefined;
    const xTail = min(up[0][0], lo[0][0]);
    const xNose0 = max(up[size(up) - 1][0], lo[size(lo) - 1][0]);
    if (xTail - xNose0 < 2 * millimeter)
        return undefined;
    const gap = 0.6 * millimeter;
    // fine scan for where the faces close up at the tail and at the nose
    const nScan = 120;
    var xA;
    var xB;
    for (var k = 0; k <= nScan; k += 1)
    {
        const x = xTail - (xTail - xNose0) * k / nScan;
        const t = coreYAt(up, x) - coreYAt(lo, x);
        if (t >= gap)
        {
            if (xA == undefined)
                xA = x;
            xB = x;
        }
    }
    if (xA == undefined || xA - xB < 2 * millimeter)
        return undefined;
    // thickest point of the core, for the cap band
    var xT = xA;
    var tMax = 0 * meter;
    for (var k = 0; k <= 60; k += 1)
    {
        const x = xA - (xA - xB) * k / 60;
        const t = coreYAt(up, x) - coreYAt(lo, x);
        if (t > tMax)
        {
            tMax = t;
            xT = x;
        }
    }
    var upper = [];
    var lower = [];
    const nS = 32;
    for (var k = 0; k <= nS; k += 1)
    {
        const x = xA - (xA - xB) * 0.5 * (1 - cos((PI * k / nS) * radian));   // TE -> nose, cosine packed at both ends
        var yu = coreYAt(up, x);
        var yl = coreYAt(lo, x);
        const dx = abs(x - xT);
        if (capT > 0 * meter && dx < bandW / 2)
        {
            const edge = 0.1 * bandW / 2;
            const ramp = dx > bandW / 2 - edge ? (bandW / 2 - dx) / edge : 1;
            const cut = min(capT * ramp, (yu - yl - gap) / 2);
            yu = yu - cut;
            yl = yl + cut;
        }
        upper = append(upper, vector(x, yu));
        lower = append(lower, vector(x, yl));
    }
    var lowerFwd = [];                                                        // nose -> TE
    for (var k = size(lower) - 1; k >= 0; k -= 1)
        lowerFwd = append(lowerFwd, lower[k]);
    return { "upper" : upper, "lower" : lowerFwd };
}

/** y of a polyline (points with x decreasing) at x, linear, clamped at its ends. */
function coreYAt(pts is array, x is ValueWithUnits) returns ValueWithUnits
{
    const last = size(pts) - 1;
    if (x >= pts[0][0])
        return pts[0][1];
    if (x <= pts[last][0])
        return pts[last][1];
    for (var i = 0; i < last; i += 1)
    {
        if (x <= pts[i][0] && x >= pts[i + 1][0] && pts[i][0] > pts[i + 1][0])
        {
            const t = (pts[i][0] - x) / (pts[i][0] - pts[i + 1][0]);
            return pts[i][1] + t * (pts[i + 1][1] - pts[i][1]);
        }
    }
    return pts[last][1];
}

function profileFromName(name is string) returns FoilProfile
{
    if (name == "E817") return FoilProfile.E817;
    if (name == "E818") return FoilProfile.E818;
    if (name == "NACA63412") return FoilProfile.NACA63412;
    if (name == "CLARKY") return FoilProfile.CLARKY;
    return FoilProfile.NACA4;
}

function moldInputLog(definition is map) returns string
{
    return "MOLD_INPUTS: toolVersion=" ~ FOIL_MOLD_VERSION
        ~ "; moldSource=" ~ (definition.moldSource == MoldSource.WING ? "WING" : (definition.moldSource == MoldSource.MAST ? "MAST" : "STAB"))
        ~ "; partsGroup=" ~ (definition.partsGroup == PartsGroup.CLOSED ? "CLOSED" : (definition.partsGroup == PartsGroup.OPEN ? "OPEN" : "OFF")) ~ "; splitStations=" ~ definition.splitStations ~ "; tipBias=" ~ fmt(definition.tipBias, 2) ~ "; templatesOn=" ~ (definition.templatesOn ? "1" : "0") ~ "; udModulus=" ~ fmt(definition.udModulus, 0) ~ "; wovenModulus=" ~ fmt(definition.wovenModulus, 0) ~ "; towModulus=" ~ fmt(definition.towModulus, 0) ~ "; mastSideG=" ~ fmt(definition.mastSideG, 2)
        ~ "; flangeWidth_mm=" ~ fmt(definition.flangeWidth / millimeter, 1)
        ~ "; baseThick_mm=" ~ fmt(definition.baseThick / millimeter, 1)
        ~ "; plugOn=" ~ (definition.plugOn ? "1" : "0") ~ "; plugExt_mm=" ~ fmt(definition.plugExt / millimeter, 1)
        ~ "; conesOn=" ~ (definition.conesOn == true ? "1" : "0")
        ~ (definition.conesOn == true ? "; coneDia_mm=" ~ fmt(definition.coneDia / millimeter, 2) ~ "; coneTaper_deg=" ~ fmt(definition.coneTaper / degree, 1) ~ "; coneWeb_mm=" ~ fmt(definition.coneWeb / millimeter, 2) : "")
        ~ "; closing=" ~ (definition.closing == MoldClosing.BAG ? "BAG" : "CLAMPS")
        ~ (definition.closing == MoldClosing.BAG ? "; bagVac_kPa=" ~ fmt(definition.bagVac, 0) ~ "; ventOn=" ~ (definition.ventOn ? "1" : "0") ~ "; edgeRound_mm=" ~ fmt(definition.edgeRound / millimeter, 1) : "")
        ~ "; grooveOn=" ~ (definition.grooveOn ? "1" : "0")
        ~ (definition.grooveOn ? "; landWidth_mm=" ~ fmt(definition.landWidth / millimeter, 1) ~ "; grooveWidth_mm=" ~ fmt(definition.grooveWidth / millimeter, 1) ~ "; grooveDepth_mm=" ~ fmt(definition.grooveDepth / millimeter, 2) : "")
        ~ "; printerX_mm=" ~ fmt(definition.printerX / millimeter, 0)
        ~ "; printerY_mm=" ~ fmt(definition.printerY / millimeter, 0)
        ~ "; printerZ_mm=" ~ fmt(definition.printerZ / millimeter, 0)
        ~ "; tileMargin_mm=" ~ fmt(definition.tileMargin / millimeter, 1)
        ~ "; staggerJoints=" ~ (definition.staggerJoints ? "1" : "0")
        ~ "; keyStyle=" ~ (definition.keyStyle == MoldKeyStyle.PRINTED ? "PRINTED" : "DOWEL")
        ~ (definition.keyStyle == MoldKeyStyle.PRINTED ? "; keyHeight_mm=" ~ fmt(definition.keyHeight / millimeter, 1) ~ "; keyDraft_deg=" ~ fmt(definition.keyDraft / degree, 1) : "")
        ~ "; pinDia_mm=" ~ fmt(definition.pinDia / millimeter, 2)
        ~ (definition.keyStyle == MoldKeyStyle.DOWEL ? "; pinLen_mm=" ~ fmt(definition.pinLen / millimeter, 1) : "")
        ~ "; pinFit_mm=" ~ fmt(definition.pinFit / millimeter, 2)
        ~ "; keysOn=" ~ (definition.keysOn ? "1" : "0")
        ~ "; keyDia_mm=" ~ fmt(definition.keyDia / millimeter, 2)
        ~ (definition.keyStyle == MoldKeyStyle.DOWEL ? "; keyLen_mm=" ~ fmt(definition.keyLen / millimeter, 1) : "")
        ~ "; skinPlies=" ~ fmt(definition.skinPlies, 0)
        ~ "; skinGsm=" ~ fmt(definition.skinGsm, 0)
        ~ "; udGsm=" ~ fmt(definition.udGsm, 0)
        ~ "; capWidthPct=" ~ fmt(definition.capWidthPct, 1)
        ~ "; capThickPct=" ~ fmt(definition.capThickPct, 1)
        ~ "; moldOf=" ~ (definition.moldOf == MoldOf.CORE ? "CORE" : "PART")
        ~ "; core=" ~ (definition.coreType == CoreType.FOAM ? "FOAM" : (definition.coreType == CoreType.SOLID ? "SOLID" : (definition.coreType == CoreType.PRINTED ? "PRINTED" : "TOW")))
        ~ (definition.coreType == CoreType.FOAM || definition.coreType == CoreType.PRINTED ? "; coreDensity=" ~ fmt(definition.coreDensity, 0) ~ "; coreModulus=" ~ fmt(definition.coreModulus, 2) : "")
        ~ (definition.coreType == CoreType.TOW ? "; towTex=" ~ fmt(definition.towTex, 0) : "")
        ~ "; fibreVolPct=" ~ fmt(definition.fibreVolPct, 1)
        ~ "; overchargePct=" ~ fmt(definition.overchargePct, 1)
        ~ "; clothWastePct=" ~ fmt(definition.clothWastePct, 1)
        ~ "; resinWastePct=" ~ fmt(definition.resinWastePct, 1)
        ~ "; capRunOut_mm=" ~ fmt(definition.capRunOut / millimeter, 1) ~ "; tabPlies=" ~ definition.tabPlies ~ "; tabLength_mm=" ~ fmt(definition.tabLength / millimeter, 1)
        ~ "; shearAllow=" ~ fmt(definition.shearAllow, 1);
}

annotation { "Feature Type Name" : "Foil mast",
             "Feature Type Description" : "Hydrofoil mast from the fuselage to a bolted board plate: symmetric sections, chord taper on the leading or trailing edge, thickening toward the plate, a root fillet into the plate, bolts chosen by size, and an optional motor pod with a placeholder motor cavity that the Foil mold turns into a plug. Positioned from the wing's root pivot." }
export const foilMast = defineFeature(function(context is Context, id is Id, definition is map)
    precondition
    {
        annotation { "Group Name" : "Mast", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Height",
                         "Description" : "Mast length from its base (top of the fuselage) to the underside of the board plate. Limits 300-1300 mm. Typical 600-1000 mm; eFoil masts often 650-850 mm. Longer = more clearance in chop, more drag and more bending at the base." }
            isLength(definition.mastHeight, { (millimeter) : [300, 750, 1300] } as LengthBoundSpec);

            annotation { "Name" : "Width",
                         "Description" : "Mast chord (fore-aft width). Limits 60-200 mm. Typical 100-140 mm. Wider = stiffer in bending and torsion, more wetted area and drag." }
            isLength(definition.mastWidth, { (millimeter) : [60, 120, 200] } as LengthBoundSpec);

            annotation { "Name" : "Thickness",
                         "Description" : "Maximum mast thickness (side to side). Limits 6-40 mm, and 4-25 % of Width. Typical 13-19 mm (about 11-15 % of chord). Thinner = less drag and spray; thicker = stiffer and stronger. The notice reports the resulting t/c." }
            isLength(definition.mastThick, { (millimeter) : [6, 16, 40] } as LengthBoundSpec);

            annotation { "Name" : "TE thickness",
                         "Description" : "Trailing edge thickness of the mast section. Limits 0.1-3 mm, and at most 3 % of Width. Typical 0.6-1.0 mm for wet-laid carbon in printed molds." }
            isLength(definition.mastTe, { (millimeter) : [0.1, 0.8, 3] } as LengthBoundSpec);

            annotation { "Name" : "Points/surface",
                         "Description" : "Limits 10-120. Typical 30-40. Cosine-spaced points on each side of the symmetric NACA 00xx mast section." }
            isInteger(definition.mastPoints, { (unitless) : [10, 36, 120] } as IntegerBoundSpec);
        }

        annotation { "Group Name" : "Taper and top", "Collapsed By Default" : true }
        {
            annotation { "Name" : "Top chord",
                         "Description" : "Chord of the mast at the top, where it meets the plate; Width is the chord at the base. Limits 30-400 mm. Typical equal to Width (no taper), or 10-30 % more for stiffness where the bending moment peaks, or less for a slimmer mast where it pierces the surface." }
            isLength(definition.topChord, { (millimeter) : [30, 120, 400] } as LengthBoundSpec);

            annotation { "Name" : "Taper side",
                         "Description" : "Where the chord change goes. Symmetric: both edges move equally about the mid-chord. Straight leading edge: the leading edge stays vertical and the trailing edge moves. Straight trailing edge: the trailing edge stays vertical and the leading edge moves. Only matters when Top chord differs from Width." }
            definition.mastTaper is MastTaper;

            annotation { "Name" : "Top thick",
                         "Description" : "Section thickness at the top of the mast; Thickness is the value at the base. Limits 4-40 mm, and 4-25 % of the local chord. Typical equal to Thickness, or 20-50 % more to carry the bending and torsion where the mast meets the plate. The section stays a NACA 00xx, scaled." }
            isLength(definition.topThick, { (millimeter) : [4, 16, 40] } as LengthBoundSpec);

            annotation { "Name" : "Thicken from %",
                         "Description" : "Height, as % of Height from the base, where the thickness starts to grow from Thickness toward Top thick, following a smooth S-curve to the top. Limits 0-95 %. Typical 60-80 %: the lower mast keeps its drag-optimised section and only the loaded top end thickens." }
            isReal(definition.thickenFrom, { (unitless) : [0, 70, 95] } as RealBoundSpec);

            annotation { "Name" : "Root fillet",
                         "Description" : "Fillet radius where the mast meets the plate's underside, all round the section. Limits 0-30 mm. Typical 8-15 mm; 0 = sharp corner. Gives the UD caps and the tab plies a radius to turn through into the plate instead of a 90 deg fold, and spreads the peel at the corner where the side-load moment peaks. Held to 2 mm less than the room between the section and the plate edge. The fillet runs round the section's surface and stops at the trailing-edge line (a 0.8 mm edge cannot carry it), leaving a notch of TE thickness there; the console's MAST_FILLET line reports the seam and the attempt used." }
            isLength(definition.rootFillet, { (millimeter) : [0, 10, 30] } as LengthBoundSpec);
        }

        annotation { "Group Name" : "Position", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Mast X",
                         "Description" : "Mast leading edge position along X relative to the wing root pivot (world origin), positive = aft. Limits -300 to +300 mm. Typical -40 to 0 mm, i.e. the mast sits over the forward part of the wing. This is where the rider's weight enters the foil, so compare it with the Foil performance trim CG." }
            isLength(definition.mastX, { (millimeter) : [-300, -20, 300] } as LengthBoundSpec);

            annotation { "Name" : "Base height",
                         "Description" : "Z of the mast's bottom end, measured from the wing root pivot. Limits -150 to +150 mm; negative is normal when the mast sits in a Foil fuselage pocket, whose floor can be below the pivot. Typical: the value the Foil fuselage warning asks for, so the mast sits on the pocket floor." }
            isLength(definition.baseHeight, { (millimeter) : [-150, 30, 150] } as LengthBoundSpec);
        }

        annotation { "Group Name" : "Motor pod", "Collapsed By Default" : true }
        {
            annotation { "Name" : "Motor pod", "Default" : false,
                         "Description" : "Adds a streamlined motor pod on the mast (eFoil). Off for pump, SUP, surf, wing, wind and kite foils." }
            definition.podOn is boolean;

            if (definition.podOn)
            {
                annotation { "Name" : "Motor dia",
                             "Description" : "Pod outside diameter (motor can plus housing). Limits 30-150 mm. Typical 60-90 mm for eFoil motors." }
                isLength(definition.podDia, { (millimeter) : [30, 70, 150] } as LengthBoundSpec);

                annotation { "Name" : "Pod height",
                             "Description" : "Height of the pod centreline above the mast base. Limits 0-1200 mm, and the pod must stay within the mast height. Typical 100-250 mm; lower keeps the prop deeper, higher keeps it away from the wing." }
                isLength(definition.podHeight, { (millimeter) : [0, 150, 1200] } as LengthBoundSpec);

                annotation { "Name" : "Nose start %",
                             "Description" : "Where the blend starts along the mast chord, as % from the mast leading edge. Limits 0-80 %. Typical 2-10 %: an early start gives the longest, gentlest blend and least drag. The first section matches the mast's own thickness there, so the pod grows out of the mast faces and never protrudes ahead of the mast." }
                isReal(definition.podNoseStartPct, { (unitless) : [0, 5, 80] } as RealBoundSpec);

                annotation { "Name" : "Fairing length",
                             "Description" : "Length of the blend from the mast section to the full motor diameter. Limits 20-400 mm. Typical 2-3 x Motor dia; longer means a gentler flank angle and lower drag. Must fit between the nose tip and the rear face." }
                isLength(definition.podFairLength, { (millimeter) : [20, 150, 400] } as LengthBoundSpec);

                annotation { "Name" : "Blend height %",
                             "Description" : "Height of the first blend section as % of the motor diameter. Limits 30-100 %. Typical 70-100 %. 100 % = the pod starts at full motor height and grows only in width out of the mast faces; lower also tapers it vertically for a softer entry." }
                isReal(definition.podBlendHeightPct, { (unitless) : [30, 100, 100] } as RealBoundSpec);

                annotation { "Name" : "Aft extension",
                             "Description" : "How far the pod extends behind the mast trailing edge, ending in a flat rear face for modelling the motor mount by hand. Limits 0-400 mm. Typical 60-150 mm, enough to clear the mast for the motor and prop." }
                isLength(definition.podAft, { (millimeter) : [0, 100, 400] } as LengthBoundSpec);

                annotation { "Name" : "Cavity dia",
                             "Description" : "Diameter of the placeholder motor cavity in the pod's rear face. Limits 5-140 mm, and at most Motor dia minus 4 mm (2 mm of pod wall each side). Typical 20 mm as a placeholder, a small locating pocket to open out to the motor by hand. The Foil mold molds the pod's outside with the mast and makes a plug of this cavity, pulled after cure." }
                isLength(definition.cavDia, { (millimeter) : [5, 20, 140] } as LengthBoundSpec);

                annotation { "Name" : "Cavity length",
                             "Description" : "Depth of the placeholder cavity from the pod's flat rear face forward. Limits 2-400 mm; shortened if it would run into the nose blend. Typical 10 mm as a placeholder, then the motor can length plus 5 mm once it is chosen." }
                isLength(definition.cavLength, { (millimeter) : [2, 10, 400] } as LengthBoundSpec);

                annotation { "Name" : "Pod tilt",
                             "Description" : "Rotation of the whole pod about its centre, nose-down positive. Limits -15 to 15 deg. Typical 5-8 deg for an eFoil: the board rides nose-up at low speed, so a nose-down pod keeps the prop nearer the flow at take-off and its thrust's downward component behind the CG lifts the nose against the thrust-height couple. 0 = axis parallel to the fuselage. Foil performance reports the thrust angle to the flow at every speed." }
                isAngle(definition.podTilt, { (degree) : [-15, 0, 15] } as AngleBoundSpec);
            }
        }

        annotation { "Group Name" : "Plate", "Collapsed By Default" : true }
        {
            annotation { "Name" : "Plate length",
                         "Description" : "Board plate length along X. Limits 80-300 mm. Typical 150-180 mm." }
            isLength(definition.plateLength, { (millimeter) : [80, 165, 300] } as LengthBoundSpec);

            annotation { "Name" : "Plate width",
                         "Description" : "Board plate width across Y; must exceed Track spacing plus a bolt diameter. Limits 60-200 mm. Typical 110-130 mm." }
            isLength(definition.plateWidth, { (millimeter) : [60, 120, 200] } as LengthBoundSpec);

            annotation { "Name" : "Plate thick",
                         "Description" : "Board plate thickness. Limits 4-30 mm. Typical 8-12 mm; must be deeper than the countersink." }
            isLength(definition.plateThick, { (millimeter) : [4, 10, 30] } as LengthBoundSpec);

            annotation { "Name" : "Track spacing",
                         "Description" : "Distance between the two rows of bolts (the board's two tracks). Limits 30-180 mm. Typical 90 mm, the common twin-track spacing; check your board." }
            isLength(definition.trackSpacing, { (millimeter) : [30, 90, 180] } as LengthBoundSpec);

            annotation { "Name" : "Bolts/row",
                         "Description" : "Bolts in each of the two rows. Limits 1-4. Typical 2." }
            isInteger(definition.boltsPerRow, { (unitless) : [1, 2, 4] } as IntegerBoundSpec);

            annotation { "Name" : "Bolt pitch",
                         "Description" : "Spacing between bolts along each row, centred on the plate. Limits 10-200 mm. Typical 40-60 mm. Ignored with one bolt per row." }
            isLength(definition.boltPitch, { (millimeter) : [10, 40, 200] } as LengthBoundSpec);

            annotation { "Name" : "Bolt", "Default" : "M8",
                         "Description" : "The track bolts. Sets the plate's clearance hole (M6 6.5, M8 8.5 mm: 0.1 mm looser than the stab's close fit, since four holes must line up with the tracks) and the countersink. Typical M8 (most boards), M6 on some. Custom hole sizes: type the hole below." }
            definition.plateBolt is BoltSize;

            if (definition.plateBolt == BoltSize.CUSTOM)
            {
                annotation { "Name" : "Bolt dia",
                             "Description" : "Bolt clearance hole diameter (Custom only). Limits 3-12 mm. Typical 8.5 mm for M8, 6.5 mm for M6." }
                isLength(definition.boltDia, { (millimeter) : [3, 8.5, 12] } as LengthBoundSpec);
            }

            annotation { "Name" : "Countersink", "Default" : true,
                         "Description" : "90 deg countersink for flat-head bolts on the plate's underside (the mast side), to the ISO 10642 head diameter of the chosen Bolt (M6 13.4, M8 17.9 mm; Custom: twice the hole). Bolts go in from below, through the plate, into the board's track nuts, so the heads sit flush with the underside." }
            definition.countersink is boolean;
        }

        annotation { "Name" : "Log inputs", "Default" : true,
                     "Description" : "Prints every parameter on this feature to the FeatureScript console as one line, so the whole set can be pasted elsewhere (e.g. back to an AI assistant)." }
        definition.logInputs is boolean;
    }
    {
        if (definition.logInputs)
            println(mastInputLog(definition));

        // ---------------- validation ----------------
        const c = definition.mastWidth;
        const tc = definition.mastThick / c;
        if (tc < 0.04 || tc > 0.25)
            throw regenError("Mast thickness must be 4-25% of Width (currently " ~ fmt(tc * 100, 1) ~ "%)", ["mastThick", "mastWidth"]);
        const cTop = definition.topChord;
        const tTop = definition.topThick;
        if (tTop / cTop < 0.04 || tTop / cTop > 0.25)
            throw regenError("Top thick must be 4-25% of Top chord (currently " ~ fmt(tTop / cTop * 100, 1) ~ "%)", ["topThick", "topChord"]);
        if (definition.mastTe > 0.03 * c)
            throw regenError("Mast TE thickness exceeds 3% of Width", ["mastTe"]);
        const dBolt = definition.plateBolt == BoltSize.CUSTOM ? definition.boltDia : (boltDims(definition.plateBolt).clear + 0.1) * millimeter;
        const headR = boltHead(definition.plateBolt, dBolt) / 2;   // 90 deg countersunk head, ISO 10642 dk (Custom: twice the hole)
        const cskDepth = headR - dBolt / 2;
        if (definition.countersink && cskDepth >= definition.plateThick)
            throw regenError("Countersink is deeper than the plate - use a thicker plate or a smaller Bolt", ["plateThick", "plateBolt"]);
        if (definition.plateWidth < definition.trackSpacing + 2 * headR)
            throw regenError("Plate width must exceed Track spacing plus a bolt head", ["plateWidth", "trackSpacing"]);
        if (definition.trackSpacing / 2 - headR < max(definition.mastThick, definition.topThick) / 2 + 1 * millimeter)
            throw regenError("Bolt heads under the plate would hit the mast - increase Track spacing or choose a smaller Bolt", ["trackSpacing", "plateBolt"]);
        const rowSpan = (definition.boltsPerRow - 1) * definition.boltPitch;
        if (definition.plateLength < rowSpan + 2 * headR)
            throw regenError("Plate length is too short for the bolt row", ["plateLength", "boltPitch", "boltsPerRow"]);

        const z0 = definition.baseHeight;
        const z1 = z0 + definition.mastHeight;
        const x0 = definition.mastX;
        var sketchBodies = [];

        // ---------------- mast: loft through horizontal sections up the height ----------------
        // chord runs linearly from Width at the base to Top chord at the top, the change taken at
        // both edges, the trailing edge or the leading edge (Taper side); thickness holds Thickness up
        // to Thicken from %, then eases to Top thick with a smoothstep. plane normal +Z with
        // x-direction X gives sketch u = world X, v = world Y (thickness sideways)
        const nSec = (abs(cTop - c) < 0.01 * millimeter && abs(tTop - definition.mastThick) < 0.01 * millimeter) ? 2 : 13;
        var mastRegions = [];
        for (var i = 0; i < nSec; i += 1)
        {
            const sFrac = i / (nSec - 1);
            const law = mastLaw(definition, sFrac);
            const secI = naca4Section(0, 0.4, law.t / law.c, definition.mastTe / law.c, definition.mastPoints);
            const ptsI = placeSection(secI, law.c, 0, 1, 0); // leading edge at the sketch origin, no rotation
            const sid = id + ("mastSec" ~ i);
            var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(law.xLE, 0 * meter, z0 + definition.mastHeight * sFrac), Z_DIRECTION, X_DIRECTION) });
            skFitSpline(sk, "surface", { "points" : ptsI });
            skLineSegment(sk, "trailingEdge", { "start" : ptsI[0], "end" : ptsI[size(ptsI) - 1] });
            skSolve(sk);
            mastRegions = append(mastRegions, qSketchRegion(sid));
            sketchBodies = append(sketchBodies, qCreatedBy(sid, EntityType.BODY));
        }
        opLoft(context, id + "mastLoft", { "profileSubqueries" : mastRegions });
        const lawTop = mastLaw(definition, 1);

        // ---------------- plate: loft between two rectangles, centred on the top chord ----------------
        const xc = lawTop.xLE + lawTop.c / 2;
        const hl = definition.plateLength / 2;
        const hw = definition.plateWidth / 2;
        const corners = [vector(-hl, -hw), vector(hl, -hw), vector(hl, hw), vector(-hl, hw)];
        var plateRegions = [];
        const pzs = [z1, z1 + definition.plateThick];
        for (var i = 0; i < 2; i += 1)
        {
            const sid = id + ("plateSec" ~ i);
            var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(xc, 0 * meter, pzs[i]), Z_DIRECTION, X_DIRECTION) });
            for (var k = 0; k < 4; k += 1)
                skLineSegment(sk, "edge" ~ k, { "start" : corners[k], "end" : corners[(k + 1) % 4] });
            skSolve(sk);
            plateRegions = append(plateRegions, qSketchRegion(sid));
            sketchBodies = append(sketchBodies, qCreatedBy(sid, EntityType.BODY));
        }
        opLoft(context, id + "plateLoft", { "profileSubqueries" : plateRegions });

        // ---------------- bolt holes (and countersinks) cut from the plate ----------------
        var holeIds = [];
        const zTop = z1 + definition.plateThick;
        const e = 0.5 * millimeter;
        var n = 0;
        for (var row = 0; row < 2; row += 1)
        {
            const by = (row == 0 ? -1 : 1) * definition.trackSpacing / 2;
            for (var j = 0; j < definition.boltsPerRow; j += 1)
            {
                const bx = xc - rowSpan / 2 + j * definition.boltPitch;
                // through hole
                const holeBase = id + ("hole" ~ n);
                holeIds = append(holeIds, circleLoft(context, holeBase, bx, by, z1 - e, dBolt / 2, zTop + e, dBolt / 2));
                sketchBodies = append(sketchBodies, qCreatedBy(holeBase + "a", EntityType.BODY));
                sketchBodies = append(sketchBodies, qCreatedBy(holeBase + "b", EntityType.BODY));
                if (definition.countersink)
                {
                    // 90 deg cone on the UNDERSIDE (mast side): bolts go in from below, through the plate,
                    // into the board's track nuts. Head diameter at the underside, narrowing upward.
                    const cskBase = id + ("csk" ~ n);
                    holeIds = append(holeIds, circleLoft(context, cskBase, bx, by, z1 - e, headR + e, z1 + cskDepth, dBolt / 2));
                    sketchBodies = append(sketchBodies, qCreatedBy(cskBase + "a", EntityType.BODY));
                    sketchBodies = append(sketchBodies, qCreatedBy(cskBase + "b", EntityType.BODY));
                }
                n += 1;
            }
        }

        // ---------------- motor pod: loft through circular sections along X ----------------
        var podNote = "no pod";
        var podZ = 0 * meter;
        var podXc = 0 * meter;
        if (definition.podOn)
        {
            // Pod blends out of the mast from Nose start %, reaches full motor diameter after
            // Fairing length, then runs as a cylinder to a flat rear face Aft extension behind the TE.
            const R = definition.podDia / 2;
            podZ = z0 + definition.podHeight;
            if (definition.podHeight - R < 0 * meter || definition.podHeight + R > definition.mastHeight)
                throw regenError("Motor pod does not fit within the mast height at this Pod height", ["podHeight", "podDia"]);
            const lawP = mastLaw(definition, definition.podHeight / definition.mastHeight);
            const xNose = lawP.xLE + lawP.c * definition.podNoseStartPct / 100;
            const xRear = lawP.xLE + lawP.c + definition.podAft;
            const Lf = definition.podFairLength;
            if (xNose + Lf > xRear)
                throw regenError("Fairing length does not fit between the nose tip and the rear face - shorten it, move Nose start % forward or add Aft extension", ["podFairLength", "podNoseStartPct", "podAft"]);
            podXc = (xNose + xRear) / 2;
            // Blend: elliptical sections in the YZ plane. The first matches the mast's own
            // half-thickness at the nose start (inset 5 % so it sits just inside the mast faces);
            // width and height ease to the motor radius with (1 - cos(pi s)) / 2, which has zero
            // slope at both ends - the pod swells out of the mast and meets the cylinder tangent.
            const tcM = lawP.t / lawP.c;
            const teM = definition.mastTe / lawP.c;
            const w0 = 0.95 * lawP.c * nacaHalfThickness(tcM, teM, definition.podNoseStartPct / 100);
            const h0 = R * definition.podBlendHeightPct / 100;
            var xs = [];
            var ays = [];
            var azs = [];
            const nB = 10;
            for (var k = 0; k <= nB; k += 1)
            {
                const sb = k / nB;
                const ease = (1 - cos((PI * sb) * radian)) / 2;
                xs = append(xs, xNose + Lf * sb);
                ays = append(ays, w0 + (R - w0) * ease);
                azs = append(azs, h0 + (R - h0) * ease);
            }
            if (xRear - (xNose + Lf) > 0.5 * millimeter)
            {
                xs = append(xs, xRear);
                ays = append(ays, R);
                azs = append(azs, R);
            }
            var podRegions = [];
            for (var k = 0; k < size(xs); k += 1)
            {
                const sid = id + ("podSec" ~ k);
                // plane normal +X with x-direction Y gives sketch u = world Y, v = world Z
                var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(xs[k], 0 * meter, podZ), X_DIRECTION, Y_DIRECTION) });
                ellipseSplines(sk, ays[k], azs[k], 24);
                skSolve(sk);
                podRegions = append(podRegions, qSketchRegion(sid));
                sketchBodies = append(sketchBodies, qCreatedBy(sid, EntityType.BODY));
            }
            opLoft(context, id + "podLoft", { "profileSubqueries" : podRegions });
            if (abs(definition.podTilt) > 0.01 * degree)
                opTransform(context, id + "podTilt", {
                            "bodies" : qCreatedBy(id + "podLoft", EntityType.BODY),
                            "transform" : rotationAround(line(vector(podXc, 0 * meter, podZ), Y_DIRECTION), -definition.podTilt)   // +Y rotation lifts the nose, so nose-down is negative
                        });
            podNote = "pod " ~ fmt(definition.podDia / millimeter, 0) ~ " mm, blends from the mast at X " ~ fmt(xNose / millimeter, 0) ~ " mm to full diameter at X " ~ fmt((xNose + Lf) / millimeter, 0) ~ " mm, flat rear face at X " ~
                fmt(xRear / millimeter, 0) ~ " mm, Z " ~ fmt(podZ / millimeter, 0) ~ " mm";
        }

        opDeleteBodies(context, id + "deleteSketches", { "entities" : qUnion(sketchBodies) });

        // holes out of the plate first, then join mast + plate (+ pod)
        var holeQueries = [];
        for (var h in holeIds)
            holeQueries = append(holeQueries, qCreatedBy(h, EntityType.BODY));
        opBoolean(context, id + "cutHoles", {
                    "targets" : qCreatedBy(id + "plateLoft", EntityType.BODY),
                    "tools" : qUnion(holeQueries),
                    "operationType" : BooleanOperationType.SUBTRACTION
                });
        var parts = [qCreatedBy(id + "mastLoft", EntityType.BODY), qCreatedBy(id + "plateLoft", EntityType.BODY)];
        if (definition.podOn)
            parts = append(parts, qCreatedBy(id + "podLoft", EntityType.BODY));
        opBoolean(context, id + "join", { "tools" : qUnion(parts), "operationType" : BooleanOperationType.UNION });
        // root fillet: the edges the union made where the section meets the plate's underside (they
        // all lie in that plane; the pod's junction edges lie far below it). The mold follows it
        // because its cavity is cut from this part. Held inside the plate with 2 mm to spare
        var rF = 0 * meter;
        var filletNote = "";
        if (definition.rootFillet > 0)
        {
            const roomY = (definition.plateWidth - lawTop.t) / 2 - 2 * millimeter;
            const roomX = (definition.plateLength - lawTop.c) / 2 - 2 * millimeter;
            rF = min(definition.rootFillet, min(roomY, roomX));
            if (rF < 0.5 * millimeter)
            {
                rF = 0 * meter;
                filletNote = " · no root fillet: no room on the plate (widen Plate width / Plate length)";
            }
            else
            {
                // the seam: edges of the joined solid lying flat in the plate's underside plane and
                // inside the section's footprint (the plate outline, its vertical corners and the
                // countersink rims all touch that plane too, so pick by bounding box, not by query)
                var seam = [];
                const solidJ = qBodyType(qCreatedBy(id, EntityType.BODY), BodyType.SOLID);
                for (var e in evaluateQuery(context, qIntersectsPlane(qOwnedByBody(solidJ, EntityType.EDGE), plane(vector(0 * meter, 0 * meter, z1), Z_DIRECTION))))
                {
                    const bx = evBox3d(context, { "topology" : e });
                    if (bx.maxCorner[2] - bx.minCorner[2] < 0.02 * millimeter &&
                        abs(bx.minCorner[1]) < lawTop.t / 2 + 0.5 * millimeter && abs(bx.maxCorner[1]) < lawTop.t / 2 + 0.5 * millimeter &&
                        bx.minCorner[0] > lawTop.xLE - 0.5 * millimeter && bx.maxCorner[0] < lawTop.xLE + lawTop.c + 0.5 * millimeter)
                        seam = append(seam, e);
                }
                // the seam is the section's fit spline plus its 0.8 mm trailing-edge line: a ladder of
                // attempts, each silent so the feature always regenerates - all edges, then without
                // tangent propagation, then the long edges only (a tiny TE notch is cosmetic), then half
                // the radius. Console MAST_FILLET says what was found and what worked
                var diag = "MAST_FILLET: " ~ size(seam) ~ " seam edges at Z " ~ fmt(z1 / millimeter, 1) ~ " mm";
                var longEdges = [];
                for (var e in seam)
                {
                    const bx = evBox3d(context, { "topology" : e });
                    const len = evLength(context, { "entities" : e });
                    diag = diag ~ "; edge " ~ fmt(len / millimeter, 1) ~ " mm long, X " ~ fmt(bx.minCorner[0] / millimeter, 1) ~ ".." ~ fmt(bx.maxCorner[0] / millimeter, 1) ~ ", Y " ~ fmt(bx.minCorner[1] / millimeter, 1) ~ ".." ~ fmt(bx.maxCorner[1] / millimeter, 1);
                    if (len > 3 * millimeter)
                        longEdges = append(longEdges, e);
                }
                if (size(seam) == 0)
                {
                    filletNote = " · ROOT FILLET: no seam edges found at the plate underside (send the console's MAST_FILLET line)";
                    rF = 0 * meter;
                }
                else
                {
                    // build 121 in Onshape: only "long edges only, no propagation" works - the 0.8 mm
                    // TE line edge cannot carry a 10 mm fillet, so it is left as a notch of TE thickness
                    const attempts = [
                        { "name" : "long edges only, no propagation", "edges" : longEdges, "r" : rF, "prop" : false },
                        { "name" : "all edges", "edges" : seam, "r" : rF, "prop" : true },
                        { "name" : "long edges at half radius", "edges" : longEdges, "r" : rF / 2, "prop" : false },
                        { "name" : "all edges at half radius", "edges" : seam, "r" : rF / 2, "prop" : true }
                    ];
                    var done = false;
                    var tried = "";
                    for (var a = 0; a < size(attempts) && !done; a += 1)
                    {
                        const at = attempts[a];
                        if (size(at.edges) == 0)
                            continue;
                        try silent
                        {
                            opFillet(context, id + ("rootFillet" ~ a), { "entities" : qUnion(at.edges), "radius" : at.r, "tangentPropagation" : at.prop });
                            done = true;
                            rF = at.r;
                            filletNote = " · root fillet " ~ fmt(rF / millimeter, 1) ~ " mm (" ~ at.name ~ ")" ~ (rF < definition.rootFillet - 0.01 * millimeter ? " - held below Root fillet" : "");
                            diag = diag ~ " | OK: " ~ at.name ~ " at " ~ fmt(at.r / millimeter, 1) ~ " mm";
                        }
                        if (!done)
                            tried = tried ~ (tried == "" ? "" : ", ") ~ at.name ~ " at " ~ fmt(at.r / millimeter, 1) ~ " mm";
                    }
                    if (!done)
                    {
                        diag = diag ~ " | FAILED: " ~ tried;
                        filletNote = " · ROOT FILLET FAILED (" ~ tried ~ ") - add a manual Fillet feature on this seam between Foil mast and Foil mold; the mold cuts its cavity from the part so it will follow";
                        rF = 0 * meter;
                    }
                }
                println(diag);
            }
        }
        // motor cavity: a blind bore from the pod's rear face, the placeholder the mold's plug follows
        var cavR = 0 * meter;
        var cavL = 0 * meter;
        var podRearX = 0 * meter;
        var podNoseX = 0 * meter;
        if (definition.podOn)
        {
            const lawP2 = mastLaw(definition, definition.podHeight / definition.mastHeight);
            podRearX = lawP2.xLE + lawP2.c + definition.podAft;
            podNoseX = lawP2.xLE + lawP2.c * definition.podNoseStartPct / 100;
            cavR = min(definition.cavDia, definition.podDia - 4 * millimeter) / 2;
            if (cavR < definition.cavDia / 2 - 0.01 * millimeter)
                podNote = podNote ~ " (Cavity dia limited to " ~ fmt(2 * cavR / millimeter, 0) ~ " mm for 2 mm of wall)";
            cavL = min(definition.cavLength, podRearX - podNoseX - 2 * millimeter);
            if (cavL < definition.cavLength - 0.01 * millimeter)
                podNote = podNote ~ " (Cavity length shortened to " ~ fmt(cavL / millimeter, 0) ~ " mm to clear the nose)";
            const cid = id + "podCav";
            xCylinder(context, cid, podRearX - cavL, podRearX + 1 * millimeter, 0 * meter, podZ, cavR);
            if (abs(definition.podTilt) > 0.01 * degree)
                opTransform(context, id + "podCavTilt", {
                            "bodies" : qCreatedBy(cid + "loft", EntityType.BODY),
                            "transform" : rotationAround(line(vector(podXc, 0 * meter, podZ), Y_DIRECTION), -definition.podTilt)
                        });
            opBoolean(context, id + "podCavCut", {
                        "targets" : qSubtraction(qBodyType(qCreatedBy(id, EntityType.BODY), BodyType.SOLID), qCreatedBy(cid + "loft", EntityType.BODY)),
                        "tools" : qCreatedBy(cid + "loft", EntityType.BODY),
                        "operationType" : BooleanOperationType.SUBTRACTION
                    });
            opDeleteBodies(context, id + "deleteCavSketches", { "entities" : qUnion([qCreatedBy(cid + "s0", EntityType.BODY), qCreatedBy(cid + "s1", EntityType.BODY)]) });
            podNote = podNote ~ ", cavity " ~ fmt(2 * cavR / millimeter, 0) ~ " x " ~ fmt(cavL / millimeter, 0) ~ " mm from the rear face";
        }
        nameSolids(context, id, "Mast");

        // ---------------- publish ----------------
        setVariable(context, "foilMastModel", {
                    "chord" : c / meter, "thick" : definition.mastThick / meter, "tc" : tc,
                    "chordTop" : cTop / meter, "thickTop" : tTop / meter, "thickenFrom" : definition.thickenFrom / 100,
                    "taperSide" : definition.mastTaper == MastTaper.SYMMETRIC ? 0 : (definition.mastTaper == MastTaper.LEADING ? 1 : 2),
                    "leXTop" : lawTop.xLE / meter, "plateXc" : xc / meter,
                    "te" : definition.mastTe / meter, "points" : definition.mastPoints,
                    "height" : definition.mastHeight / meter, "baseZ" : z0 / meter, "leX" : x0 / meter,
                    "podOn" : definition.podOn ? 1 : 0,
                    "podDia" : definition.podOn ? definition.podDia / meter : 0,
                    "podLength" : definition.podOn ? (definition.mastX + c + definition.podAft - (definition.mastX + c * definition.podNoseStartPct / 100)) / meter : 0,
                    "podFairLength" : definition.podOn ? definition.podFairLength / meter : 0,
                    "podZ" : podZ / meter, "podX" : podXc / meter,
                    "podRearX" : podRearX / meter, "podNoseX" : podNoseX / meter, "cavDia" : 2 * cavR / meter, "cavLength" : cavL / meter,
                    "podTilt" : definition.podOn ? definition.podTilt / radian : 0,
                    "plateLength" : definition.plateLength / meter, "plateWidth" : definition.plateWidth / meter, "plateThick" : definition.plateThick / meter,
                    "trackSpacing" : definition.trackSpacing / meter, "boltsPerRow" : definition.boltsPerRow, "plateBoltPitch" : definition.boltPitch / meter,
                    "plateBoltDia" : dBolt / meter, "plateHeadDia" : 2 * headR / meter, "countersink" : definition.countersink ? 1 : 0,
                    "rootFillet" : rF / meter
                });

        reportFeatureInfo(context, id,
            "Mast " ~ fmt(definition.mastHeight / millimeter, 0) ~ " mm · chord " ~ fmt(c / millimeter, 0) ~
            (abs(cTop - c) > 0.01 * millimeter ? " -> " ~ fmt(cTop / millimeter, 0) ~ " at the top (" ~ (definition.mastTaper == MastTaper.SYMMETRIC ? "symmetric" : (definition.mastTaper == MastTaper.LEADING ? "straight LE" : "straight TE")) ~ ")" : "") ~
            " mm · t/c " ~ fmt(tc * 100, 1) ~ "%" ~
            (abs(tTop - definition.mastThick) > 0.01 * millimeter ? " · thickens from " ~ fmt(definition.thickenFrom, 0) ~ "% height to " ~ fmt(tTop / millimeter, 1) ~ " mm at the top" : "") ~
            " · LE " ~ fmt(x0 / millimeter, 0) ~ " mm, TE " ~ fmt((x0 + c) / millimeter, 0) ~ " mm from wing pivot" ~ filletNote ~
            " | " ~ podNote ~
            " | plate " ~ fmt(definition.plateLength / millimeter, 0) ~ " x " ~ fmt(definition.plateWidth / millimeter, 0) ~ " mm, " ~
            fmt(2 * definition.boltsPerRow, 0) ~ " bolts on " ~ fmt(definition.trackSpacing / millimeter, 0) ~ " mm tracks");
    });

/**
 * Chord, thickness and leading-edge X of the mast at height fraction s (0 base, 1 top): chord linear
 * from Width to Top chord with the change at both edges / the TE / the LE (Taper side); thickness
 * constant to Thicken from %, then a smoothstep to Top thick.
 */
function mastLaw(definition is map, s is number) returns map
{
    const c0 = definition.mastWidth;
    const c1 = definition.topChord;
    const cs = c0 + (c1 - c0) * s;
    var xLE = definition.mastX;
    if (definition.mastTaper == MastTaper.SYMMETRIC)
        xLE = definition.mastX + (c0 - cs) / 2;
    else if (definition.mastTaper == MastTaper.TRAILING)
        xLE = definition.mastX + (c0 - cs);
    const s0 = definition.thickenFrom / 100;
    const u = s0 >= 1 ? 0 : min(max((s - s0) / (1 - s0), 0), 1);
    const sm = u * u * (3 - 2 * u);
    const t = definition.mastThick + (definition.topThick - definition.mastThick) * sm;
    return { "c" : cs, "t" : t, "xLE" : xLE };
}

/** Half-thickness / chord of the symmetric NACA 00xx section at chord fraction x (same law as naca4Section). */
function nacaHalfThickness(t is number, teFrac is number, x is number) returns number
{
    const xc = min(max(x, 0), 1);
    return 5 * t * (0.2969 * sqrt(xc) - 0.1260 * xc - 0.3516 * xc ^ 2 + 0.2843 * xc ^ 3 - 0.1036 * xc ^ 4) + 0.5 * teFrac * xc;
}

/**
 * Ellipse with half-axes a (sketch u) and b (sketch v) as two fitted splines, upper and lower
 * halves, sharing their two end points exactly so the region closes. Every section built this
 * way has the same topology (two edges), which keeps a loft through them well matched.
 */
function ellipseSplines(sketch is Sketch, a is ValueWithUnits, b is ValueWithUnits, n is number)
{
    var upper = [];
    var lower = [];
    for (var k = 0; k <= n; k += 1)
    {
        const th = PI * k / n;
        upper = append(upper, vector(a * cos(th * radian), b * sin(th * radian)));
        lower = append(lower, vector(-a * cos(th * radian), -b * sin(th * radian)));
    }
    // force exact shared end points: upper runs (a,0) -> (-a,0), lower runs (-a,0) -> (a,0)
    upper[0] = vector(a, 0 * meter);
    upper[n] = vector(-a, 0 * meter);
    lower[0] = vector(-a, 0 * meter);
    lower[n] = vector(a, 0 * meter);
    skFitSpline(sketch, "upper", { "points" : upper });
    skFitSpline(sketch, "lower", { "points" : lower });
}

/**
 * Z of a section outline at X, by linear interpolation between consecutive points (the first
 * segment spanning X wins). pts are chord-scaled (X, Z) Vectors as returned by placeSection.
 */
function profileZAt(pts is array, x is ValueWithUnits) returns ValueWithUnits
{
    for (var i = 0; i < size(pts) - 1; i += 1)
    {
        const xa = pts[i][0];
        const xb = pts[i + 1][0];
        if (xa != xb && (x - xa) * (x - xb) <= 0 * meter * meter)
            return pts[i][1] + (x - xa) / (xb - xa) * (pts[i + 1][1] - pts[i][1]);
    }
    throw regenError("Mount pad or bolt reaches outside the stab root chord - move Flat start or Bolt 1 at toward the pivot, or shorten Bolt pitch", ["flatStart", "bolt1At", "boltPitch"]);
}

/** Horizontal cylinder along X, radius r, from x0 to x1, axis at (y, z) - two ellipseSplines sections lofted. Returns the loft id. */
function xCylinder(context is Context, baseId is Id, x0 is ValueWithUnits, x1 is ValueWithUnits, y is ValueWithUnits, z is ValueWithUnits, r is ValueWithUnits) returns Id
{
    const xs = [x0, x1];
    var regions = [];
    for (var i = 0; i < 2; i += 1)
    {
        const sid = baseId + ("s" ~ i);
        var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(xs[i], y, z), X_DIRECTION, Y_DIRECTION) });
        ellipseSplines(sk, r, r, 24);
        skSolve(sk);
        regions = append(regions, qSketchRegion(sid));
    }
    const loftId = baseId + "loft";
    opLoft(context, loftId, { "profileSubqueries" : regions });
    return loftId;
}

/**
 * Wing root tube socket: a low-drag nacelle about an X axis through the root section's
 * mid-thickness at its thickest point. It starts there hidden inside the wing (full tube width,
 * 95 % of the wing thickness), eases up to a round section over Blend length, runs past the
 * trailing edge by Rear extension, and eases down onto the tube over Rear fairing. Unioned
 * with the wing, then a bore open at the rear face
 * and optional vertical pin holes cut through nacelle, wing and bore. The root section is rebuilt
 * with the same buildSection / placeSection calls buildFoil used, so the axis follows camber,
 * thickness and incidence. Returns { "model" : published map, "note" : notice text }.
 */
function buildWingSocket(context is Context, id is Id, definition is map, m is map) returns map
{
    if (!definition.socketOn)
        return { "model" : { "on" : 0 }, "note" : "" };

    // ---- axis: mid-thickness at the thickest point of the root section ----
    const c0 = m.rootChord;
    const n = definition.pointsPerSurface;
    const pf = pivotFraction(definition.pivot);
    const teLocal = min(definition.teThickness, 0.03 * c0);
    const sec = buildSection(definition, definition.rootThickness / 100, teLocal / c0, n);
    const pts = placeSection(sec, c0, pf, cos(definition.incidence), sin(definition.incidence));
    var upper = [];
    var lower = [];
    for (var i = 0; i < n; i += 1)
        upper = append(upper, pts[i]);
    for (var i = n - 1; i < size(pts); i += 1)
        lower = append(lower, pts[i]);
    const xLE = -pf * c0;
    var bestT = 0 * meter;
    var axisX = 0 * meter;
    var axisZ = 0 * meter;
    for (var k = 1; k < 60; k += 1)
    {
        const x = xLE + c0 * k / 60;
        const zu = profileZAt(upper, x);
        const zl = profileZAt(lower, x);
        if (zu - zl > bestT)
        {
            bestT = zu - zl;
            axisX = x;
            axisZ = (zu + zl) / 2;
        }
    }

    // ---- dimensions and checks ----
    const rTube = definition.tubeDia / 2;
    const rBore = rTube + definition.tubeClearance / 2;
    const R = rTube + definition.socketWall;
    const rLip = rBore + 0.5 * definition.socketWall; // rear face keeps half the wall around the bore
    const xTE = (1 - pf) * c0;
    const xStart = axisX;                              // thickest point of the root
    const xFull = xStart + definition.socketBlend;
    const xRear = xTE + definition.socketRearExt;
    const xFairStart = xRear - definition.nacelleRearFair;
    const h0 = 0.95 * bestT / 2;                       // start section hidden inside the wing
    if (R <= bestT / 2)
        throw regenError("Nacelle diameter (" ~ fmt(2 * R / millimeter, 1) ~ " mm) is no bigger than the root thickness (" ~ fmt(bestT / millimeter, 1) ~ " mm) - increase Tube dia or Wall", ["tubeDia", "socketWall"]);
    if (xFull > xFairStart)
        throw regenError("Blend length + Rear fairing do not fit between the root's thickest point and the rear face - shorten them or add Rear extension", ["socketBlend", "nacelleRearFair", "socketRearExt"]);
    const rRear = rLip; // diameter the taper actually reaches at the rear face - this is what Foil fuselage matches, not R
    if (xRear - definition.socketDepth < xFull)
        throw regenError("Socket depth reaches forward into the blend, where the nacelle is not yet full diameter - shorten Socket depth, shorten Blend length or add Rear extension", ["socketDepth", "socketBlend", "socketRearExt"]);
    if (xRear - definition.socketDepth < xLE)
        throw regenError("Socket depth reaches past the wing's own leading edge (X " ~ fmt(xLE / millimeter, 0) ~ " mm) - the bore would poke through the nose. Shorten Socket depth", ["socketDepth"]);
    const pinSpan = (definition.socketPins - 1) * definition.socketPinPitch;
    const pinD = definition.socketPinBolt == BoltSize.CUSTOM ? definition.socketPinDia : (boltDims(definition.socketPinBolt).clear + 0.1) * millimeter;
    if (definition.socketPins > 0 && pinSpan + 2 * pinD > definition.socketDepth)
        throw regenError("Pins do not fit within Socket depth", ["socketPins", "socketPinPitch", "socketDepth"]);
    if (pinD >= rTube)
        throw regenError("Pin bolt should be well under half the tube diameter", ["socketPinBolt", "tubeDia"]);

    // ---- nacelle sections along X: half-width a (Y), half-height b (Z) ----
    // Blend: full tube width across the span (hidden in the wing, which is wide in Y), height eased
    // from just inside the wing thickness to R with (1 - cos(pi s)) / 2 - zero slope at both ends,
    // so the nacelle rises smoothly out of the upper and lower surfaces.
    var xs = [];
    var halfW = [];
    var halfH = [];
    const nB = 10;
    for (var k = 0; k <= nB; k += 1)
    {
        const sb = k / nB;
        xs = append(xs, xStart + definition.socketBlend * sb);
        halfW = append(halfW, R);
        halfH = append(halfH, h0 + (R - h0) * (1 - cos((PI * sb) * radian)) / 2);
    }
    if (definition.nacelleRearFair > 0.5 * millimeter)
    {
        const nF = 5;
        for (var k = 0; k <= nF; k += 1)
        {
            const sF = k / nF;
            const r = R + (rLip - R) * (1 - cos((PI * sF) * radian)) / 2;
            xs = append(xs, xFairStart + definition.nacelleRearFair * sF);
            halfW = append(halfW, r);
            halfH = append(halfH, r);
        }
    }
    else
    {
        xs = append(xs, xRear);
        halfW = append(halfW, R);
        halfH = append(halfH, R);
    }
    var sketchBodies = [];
    var regions = [];
    for (var k = 0; k < size(xs); k += 1)
    {
        if (k == 0 || xs[k] - xs[k - 1] >= 0.2 * millimeter)      // skip a duplicate station at the nose/body joint
        {
            const sid = id + ("nacSec" ~ k);
            var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(xs[k], 0 * meter, axisZ), X_DIRECTION, Y_DIRECTION) });
            ellipseSplines(sk, halfW[k], halfH[k], 24);
            skSolve(sk);
            regions = append(regions, qSketchRegion(sid));
            sketchBodies = append(sketchBodies, qCreatedBy(sid, EntityType.BODY));
        }
    }
    opLoft(context, id + "nacelleLoft", { "profileSubqueries" : regions });
    opDeleteBodies(context, id + "deleteNacelleSketches", { "entities" : qUnion(sketchBodies) });
    opBoolean(context, id + "nacelleJoin", {
                "tools" : qBodyType(qCreatedBy(id, EntityType.BODY), BodyType.SOLID),
                "operationType" : BooleanOperationType.UNION
            });

    // ---- bore (open at the rear face) and vertical pin holes ----
    const e = 0.5 * millimeter;
    var toolIds = [xCylinder(context, id + "bore", xRear - definition.socketDepth, xRear + e, 0 * meter, axisZ, rBore)];
    var toolSketches = [qCreatedBy(id + "bore" + "s0", EntityType.BODY), qCreatedBy(id + "bore" + "s1", EntityType.BODY)];
    const xPinC = xRear - definition.socketDepth / 2;
    for (var j = 0; j < definition.socketPins; j += 1)
    {
        const px = xPinC - pinSpan / 2 + j * definition.socketPinPitch;
        const pbase = id + ("pin" ~ j);
        toolIds = append(toolIds, circleLoft(context, pbase, px, 0 * meter, axisZ - R - e, pinD / 2, axisZ + R + e, pinD / 2));
        toolSketches = append(toolSketches, qCreatedBy(pbase + "a", EntityType.BODY));
        toolSketches = append(toolSketches, qCreatedBy(pbase + "b", EntityType.BODY));
    }
    opDeleteBodies(context, id + "deleteToolSketches", { "entities" : qUnion(toolSketches) });
    var toolQueries = [];
    for (var t in toolIds)
        toolQueries = append(toolQueries, qCreatedBy(t, EntityType.BODY));
    const tools = qUnion(toolQueries);
    opBoolean(context, id + "socketCut", {
                "targets" : qSubtraction(qBodyType(qCreatedBy(id, EntityType.BODY), BodyType.SOLID), tools),
                "tools" : tools,
                "operationType" : BooleanOperationType.SUBTRACTION
            });

    return {
            "model" : { "on" : 1, "axisX" : axisX / meter, "axisZ" : axisZ / meter, "rearX" : xRear / meter, "fullX" : xFull / meter,
                        "tubeDia" : definition.tubeDia / meter, "boreDia" : 2 * rBore / meter,
                        "nacelleDia" : 2 * R / meter, "rearDia" : 2 * rRear / meter, "depth" : definition.socketDepth / meter,
                        "pins" : definition.socketPins, "pinPitch" : definition.socketPinPitch / meter,
                        "pinDia" : pinD / meter, "pinBolt" : boltDims(definition.socketPinBolt).name, "pinCenterX" : xPinC / meter },
            "note" : " | tube socket: " ~ fmt(definition.tubeDia / millimeter, 1) ~ " mm tube, nacelle " ~ fmt(2 * R / millimeter, 0) ~
                " mm, blends from the thickest point (X " ~ fmt(xStart / millimeter, 0) ~ ", Z " ~ fmt(axisZ / millimeter, 1) ~ " mm) to full diameter at X " ~
                fmt(xFull / millimeter, 0) ~ ", root TE at X " ~ fmt(xTE / millimeter, 0) ~ ", tapers to " ~ fmt(2 * rRear / millimeter, 1) ~
                " mm by the rear face at X " ~ fmt(xRear / millimeter, 0) ~ " mm, bore " ~ fmt(definition.socketDepth / millimeter, 0) ~ " mm deep"
        };
}

/**
 * Solid of revolution about a vertical axis at (x, y): lofts a circle of radius r0 at height z0
 * to a circle of radius r1 at height z1 (a cylinder when r0 == r1, a cone otherwise). Sketch ids
 * are baseId + "a" and baseId + "b"; the caller deletes the sketch bodies. Returns the loft id.
 */
function circleLoft(context is Context, baseId is Id, x is ValueWithUnits, y is ValueWithUnits,
    z0 is ValueWithUnits, r0 is ValueWithUnits, z1 is ValueWithUnits, r1 is ValueWithUnits) returns Id
{
    const idA = baseId + "a";
    const idB = baseId + "b";
    var ska = newSketchOnPlane(context, idA, { "sketchPlane" : plane(vector(x, y, z0), Z_DIRECTION, X_DIRECTION) });
    skCircle(ska, "c", { "center" : vector(0, 0) * meter, "radius" : r0 });
    skSolve(ska);
    var skb = newSketchOnPlane(context, idB, { "sketchPlane" : plane(vector(x, y, z1), Z_DIRECTION, X_DIRECTION) });
    skCircle(skb, "c", { "center" : vector(0, 0) * meter, "radius" : r1 });
    skSolve(skb);
    const loftId = baseId + "loft";
    opLoft(context, loftId, { "profileSubqueries" : [qSketchRegion(idA), qSketchRegion(idB)] });
    return loftId;
}

function mastInputLog(definition is map) returns string
{
    var s = "MAST_INPUTS: toolVersion=" ~ FOIL_MAST_VERSION
        ~ "; mastHeight_mm=" ~ fmt(definition.mastHeight / millimeter, 1)
        ~ "; topChord_mm=" ~ fmt(definition.topChord / millimeter, 1) ~ "; taperSide=" ~ (definition.mastTaper == MastTaper.SYMMETRIC ? "SYMMETRIC" : (definition.mastTaper == MastTaper.LEADING ? "LEADING" : "TRAILING"))
        ~ "; topThick_mm=" ~ fmt(definition.topThick / millimeter, 1) ~ "; thickenFromPct=" ~ fmt(definition.thickenFrom, 0)
        ~ "; mastWidth_mm=" ~ fmt(definition.mastWidth / millimeter, 1)
        ~ "; mastThick_mm=" ~ fmt(definition.mastThick / millimeter, 2)
        ~ "; mastTe_mm=" ~ fmt(definition.mastTe / millimeter, 2)
        ~ "; mastPoints=" ~ fmt(definition.mastPoints, 0)
        ~ "; mastX_mm=" ~ fmt(definition.mastX / millimeter, 1)
        ~ "; baseHeight_mm=" ~ fmt(definition.baseHeight / millimeter, 1)
        ~ "; podOn=" ~ (definition.podOn ? "true" : "false");
    if (definition.podOn)
        s = s ~ "; podDia_mm=" ~ fmt(definition.podDia / millimeter, 1) ~ "; podTilt_deg=" ~ fmt(definition.podTilt / degree, 1)
            ~ "; podHeight_mm=" ~ fmt(definition.podHeight / millimeter, 1)
            ~ "; podNoseStartPct=" ~ fmt(definition.podNoseStartPct, 1)
            ~ "; podFairLength_mm=" ~ fmt(definition.podFairLength / millimeter, 1)
            ~ "; podBlendHeightPct=" ~ fmt(definition.podBlendHeightPct, 1)
            ~ "; podAft_mm=" ~ fmt(definition.podAft / millimeter, 1)
            ~ "; cavDia_mm=" ~ fmt(definition.cavDia / millimeter, 1) ~ "; cavLength_mm=" ~ fmt(definition.cavLength / millimeter, 1);
    s = s ~ "; plateLength_mm=" ~ fmt(definition.plateLength / millimeter, 1)
        ~ "; plateWidth_mm=" ~ fmt(definition.plateWidth / millimeter, 1)
        ~ "; plateThick_mm=" ~ fmt(definition.plateThick / millimeter, 1)
        ~ "; trackSpacing_mm=" ~ fmt(definition.trackSpacing / millimeter, 1)
        ~ "; boltsPerRow=" ~ fmt(definition.boltsPerRow, 0)
        ~ "; boltPitch_mm=" ~ fmt(definition.boltPitch / millimeter, 1)
        ~ "; bolt=" ~ boltDims(definition.plateBolt).name ~ "; boltDia_mm=" ~ fmt((definition.plateBolt == BoltSize.CUSTOM ? definition.boltDia : (boltDims(definition.plateBolt).clear + 0.1) * millimeter) / millimeter, 2)
        ~ "; countersink=" ~ (definition.countersink ? "true" : "false")
        ~ "; rootFillet_mm=" ~ fmt(definition.rootFillet / millimeter, 1);
    return s;
}




annotation { "Feature Type Name" : "Foil fuselage",
             "Feature Type Description" : "Round hydrofoil fuselage: a spigot into the Foil wing's tube socket, a body running past the mast to a tapered tail, seated on the stabiliser's mount pad with blind tapped holes on its bolt pattern (stab under or on top), and an optional mast pocket. Conflicts are shown as warnings that name the fix in the other feature." }
export const foilFuselage = defineFeature(function(context is Context, id is Id, definition is map)
    precondition
    {
        annotation { "Group Name" : "Body", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Parallel aft",
                         "Description" : "How far the full-diameter body continues behind the mast trailing edge before it tapers. Limits 0-300 mm. Typical 20-60 mm." }
            isLength(definition.fusParAft, { (millimeter) : [0, 40, 300] } as LengthBoundSpec);

            annotation { "Name" : "Tail dia",
                         "Description" : "Body diameter under the stab, after the taper. Limits 6-60 mm; clamped to the body diameter. Typical: equal to Tube dia (no taper before the stab - the fuselage is a high-stress part and the stab block needs a full body under it), tapering only in the tip. Smaller only for a lightly loaded foil." }
            isLength(definition.fusTailDia, { (millimeter) : [6, 24, 60] } as LengthBoundSpec);

            annotation { "Name" : "Overhang",
                         "Description" : "Where the fuselage ends: the X of its pointed tip, measured from the stab root trailing edge. Positive = behind the stab, negative = the tip ends under the stab. Limits -200 to +300 mm. Typical 40-80 mm (tip fully behind the stab, untouched by the seat)." }
            isLength(definition.overhang, { (millimeter) : [-200, 60, 300] } as LengthBoundSpec);

            annotation { "Name" : "Tip length",
                         "Description" : "Length of the elliptical tip, from Tail dia down to a point. Independent of Overhang, so the tip is always a full ellipse. Limits 5-200 mm. Typical 2-3 x Tail dia; longer is lower drag." }
            isLength(definition.tipLength, { (millimeter) : [5, 40, 200] } as LengthBoundSpec);
        }

        annotation { "Group Name" : "Stab seat", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Stab block", "Default" : true,
                         "Description" : "A rectangular block as wide as the stab's Mount pad and as long as the seat, between the body axis and the pad plane, so the seat is the full pad width whatever the tube diameter and the tapped holes have solid material. With Pad side Top it hangs under the body (the fuselage passes over the stab); with Bottom it stands on top. Off = the seat is just a flat cut on the round tube." }
            definition.seatBlock is boolean;

            annotation { "Name" : "Seat margin",
                         "Description" : "Extra seat (and block) length beyond the stab root chord at each end (never past the fuselage tip). Limits 0-30 mm. Typical 2-5 mm." }
            isLength(definition.seatMargin, { (millimeter) : [0, 3, 30] } as LengthBoundSpec);

            annotation { "Name" : "Stab bolt dia",
                         "Description" : "Tapping drill for the stab bolts, used ONLY when the Foil stabiliser's Bolt is set to Custom hole sizes; with a named bolt (M4-M10) the drill comes from the stab (M6 5.0, M8 6.8 mm) and this field is ignored. Limits 3-10 mm. Typical 6.8 (M8) or 5 (M6). The positions come from the stab's Mount bolts (Bolt 1 at, Bolt pitch), so the two always match." }
            isLength(definition.stabBoltDia, { (millimeter) : [3, 6.8, 10] } as LengthBoundSpec);

            annotation { "Name" : "Bolt depth",
                         "Description" : "Depth of each blind tapped hole from the seat plane into the body. Limits 3-40 mm. Typical 1.5-2 x bolt diameter. With the fuselage over the stab (Pad side Top) the hole goes up: the depth available is the pad plane's drop below the axis plus the local radius, less 1 mm of wall (about 15 mm on a 24 mm tail seated 4 mm under the axis). A hole that would break through is skipped with the fix named." }
            isLength(definition.boltDepth, { (millimeter) : [3, 14, 40] } as LengthBoundSpec);
        }

        annotation { "Group Name" : "Mast pocket", "Collapsed By Default" : false }
        {
            annotation { "Name" : "Mast pocket", "Default" : true,
                         "Description" : "Cuts a pocket in the top of the fuselage for the mast's bottom end, shaped to the Foil mast's own section plus Clearance. Its position AND depth follow the mast: the floor is at the mast's Base height, so moving the mast reshapes the pocket. Needs a Foil mast feature above this one." }
            definition.pocketOn is boolean;

            if (definition.pocketOn)
            {
                annotation { "Name" : "Clearance",
                             "Description" : "Gap between the mast and the pocket walls, all round. Limits 0-2 mm. Typical 0.1-0.3 mm for a bonded or bolted fit." }
                isLength(definition.pocketClearance, { (millimeter) : [0, 0.2, 2] } as LengthBoundSpec);
            }
        }

        annotation { "Name" : "Wing pin holes", "Default" : true,
                     "Description" : "Holes through the spigot matching the wing socket's Pins, Pin bolt and Pin pitch, at the same clearance size." }
        definition.matchWingPins is boolean;

        annotation { "Name" : "Log inputs", "Default" : true,
                     "Description" : "Prints every parameter on this feature to the FeatureScript console as one line, so the whole set can be pasted elsewhere (e.g. back to an AI assistant)." }
        definition.logInputs is boolean;
    }
    {
        if (definition.logInputs)
            println(fuselageInputLog(definition));

        // ---------------- neighbours (read, never set) ----------------
        var sock;
        var stabRoot;
        var mast;
        try silent { sock = getVariable(context, "foilWingSocket"); }
        try silent { stabRoot = getVariable(context, "foilStabRoot"); }
        try silent { mast = getVariable(context, "foilMastModel"); }
        if (sock == undefined || sock.on != 1)
            throw regenError("The fuselage needs a Foil wing above it with Tube socket turned on");
        if (stabRoot == undefined)
            throw regenError("The fuselage needs a Foil stabiliser above it");

        var warnings = [];
        const e = 0.5 * millimeter;
        const R = sock.rearDia / 2 * meter;              // flush with the socket's own rear-face diameter
        const rSp = sock.tubeDia / 2 * meter;            // spigot fits the bore
        const zA = sock.axisZ * meter;
        const xRear = sock.rearX * meter;
        const xFront = (sock.rearX - sock.depth) * meter;
        const rT = min(definition.fusTailDia / 2, R);       // clamped: no more than the body
        if (stabRoot.padSide == undefined || stabRoot.boltX == undefined)
            throw regenError("The Foil stabiliser above is older than this Foil fuselage - paste the whole Feature Studio over again so both are the same build");
        const sLE = stabRoot.leX * meter;
        const sTE = stabRoot.teX * meter;
        // the stab owns the joint: Pad side Top = this fuselage passes over the stab and seats on the
        // pad plane (Axis layout); Bottom or no pad = the stab sits on top of the fuselage tail
        const over = stabRoot.padSide == 1;
        const sBot = over ? stabRoot.padZ * meter : stabRoot.bottomZ * meter;   // the plane the fuselage seats on
        const hasTail = over && stabRoot.tailOn == 1;
        const xSeat0 = sLE - definition.seatMargin;
        // with a stab tail fairing the fuselage ends where the tail ends and its tip is the upper
        // half of that taper (starting at the stab trailing edge); otherwise Overhang + Tip length
        const xEnd = hasTail ? stabRoot.tailEndX * meter : sTE + definition.overhang;
        // with a tail fairing the tip tapers from the stab's Tail start (fixed to its pivot, build 125),
        // not from its trailing edge, so the fuselage is the same for every stab with the same Arm
        const xTip = hasTail ? min(stabRoot.tailStartX != undefined ? stabRoot.tailStartX * meter : sTE, xEnd - 1 * millimeter) : xEnd - definition.tipLength;
        const xTail = min(xSeat0, xTip);                  // body reaches Tail dia here

        var xPar = xRear + definition.fusParAft;
        if (mast != undefined)
        {
            const mLE = mast.leX * meter;
            const mTE = (mast.leX + mast.chord) * meter;
            xPar = max(mTE, xRear) + definition.fusParAft;
            if (mLE < xRear)
                warnings = append(warnings, "the mast leading edge (X " ~ fmt(mLE / millimeter, 0) ~ " mm) is over the wing socket, not the fuselage - set Foil mast's Mast X to at least " ~ fmt(xRear / millimeter, 0) ~ " mm");
            if (!definition.pocketOn && abs(mast.baseZ * meter - (zA + R)) > 0.5 * millimeter)
                warnings = append(warnings, "the mast base (Z " ~ fmt(mast.baseZ * 1000, 1) ~ " mm) does not sit on the fuselage top - set Foil mast's Base height to " ~
                    fmt((zA + R) / millimeter, 1) ~ " mm, or turn on Mast pocket");
        }
        if (xPar >= xTail - 1 * millimeter)
        {
            warnings = append(warnings, "the parallel section runs into the tail taper - shortened; move the mast forward, the stab aft, or reduce Parallel aft");
            xPar = xTail - 1 * millimeter;
        }
        if (xPar <= xRear)
            throw regenError("No room for the body between the wing socket and the tail - move the stab aft (Arm), or increase Overhang", ["overhang"]);

        // ---------------- body profile (same stations as the reference model) ----------------
        var xs = [xRear, xPar];
        var rs = [R, R];
        for (var k = 1; k <= 8; k += 1)
        {
            const s = k / 8;
            xs = append(xs, xPar + (xTail - xPar) * s);
            rs = append(rs, R + (rT - R) * (1 - cos((PI * s) * radian)) / 2);   // zero slope both ends
        }
        if (xTip - xTail > 0.2 * millimeter)
        {
            xs = append(xs, xTip);
            rs = append(rs, rT);
        }
        var zcs = [];              // section centre drop below the axis (0 except in a tail-matched tip)
        for (var k = 0; k < size(xs); k += 1)
            zcs = append(zcs, 0 * meter);
        for (var k = 1; k <= 10; k += 1)
        {
            const t = k / 10;
            if (hasTail && stabRoot.tailEndWidth != undefined)
            {
                // the upper half of the stab's own tail taper: radius scaled from its plan law, the
                // circle dropping to stay tangent to the pad plane once it is smaller than the drop
                const hW = stabRoot.padWidth / 2 * meter;
                const hE = stabRoot.tailEndWidth / 2 * meter;
                const r = max(rT * (hE + (hW - hE) * (1 - t) ^ stabRoot.tailExp) / hW, 0.001 * rT);
                xs = append(xs, xTip + (xEnd - xTip) * t);
                rs = append(rs, r);
                // the circle dips 0.3 mm below the pad plane rather than sitting tangent to it: the
                // seat cut was BOOLEAN_INVALID with the plane tangent to the tip's cylinders
                zcs = append(zcs, max(0 * meter, zA - (sBot + r) + 0.3 * millimeter));
            }
            else
            {
                // true quarter-ellipse: x and r from one shared angle
                const phi = (PI / 2 * t) * radian;
                xs = append(xs, xTip + (xEnd - xTip) * sin(phi));
                rs = append(rs, max(rT * cos(phi), 0.001 * rT));
                zcs = append(zcs, 0 * meter);
            }
        }
        var sketchBodies = [];
        var regions = [];
        for (var k = 0; k < size(xs); k += 1)
        {
            const sid = id + ("sec" ~ k);
            var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(xs[k], 0 * meter, zA - zcs[k]), X_DIRECTION, Y_DIRECTION) });
            ellipseSplines(sk, rs[k], rs[k], 24);
            skSolve(sk);
            regions = append(regions, qSketchRegion(sid));
            sketchBodies = append(sketchBodies, qCreatedBy(sid, EntityType.BODY));
        }
        opLoft(context, id + "bodyLoft", { "profileSubqueries" : regions });
        xCylinder(context, id + "spigot", xFront, xRear + 1 * millimeter, 0 * meter, zA, rSp);
        sketchBodies = append(sketchBodies, qCreatedBy(id + "spigot" + "s0", EntityType.BODY));
        sketchBodies = append(sketchBodies, qCreatedBy(id + "spigot" + "s1", EntityType.BODY));
        opBoolean(context, id + "joinSpigot", {
                    "tools" : qBodyType(qCreatedBy(id, EntityType.BODY), BodyType.SOLID),
                    "operationType" : BooleanOperationType.UNION
                });

        // ---------------- tools: seat, blind stab bolt holes, wing pin holes ----------------
        var toolIds = [];
        var seatNote = " | no stab seat";
        // the tapping drill: from the stab's named bolt, else this feature's own field (Custom)
        const tapFromStab = stabRoot.tapDia != undefined && stabRoot.tapDia > 0;
        const tapDia = tapFromStab ? stabRoot.tapDia * meter : definition.stabBoltDia;
        const tapNote = tapFromStab ? " for " ~ stabRoot.boltName : "";
        if (!tapFromStab && stabRoot.boltDia != undefined && stabRoot.boltDia > 0 && stabRoot.boltDia * meter < definition.stabBoltDia + 0.3 * millimeter)
            warnings = append(warnings, "the stab's clearance hole (" ~ fmt(stabRoot.boltDia * 1000, 1) ~ " mm) is not bigger than this feature's tapping drill (" ~ fmt(definition.stabBoltDia / millimeter, 1) ~
                " mm) - pick a named Bolt in Foil stabiliser, or for M6 set its Bolt dia 6.4 and Stab bolt dia 5 here; for M8, 8.4 and 6.8");
        var boltXs = [];      // world X of every stab bolt hole actually made
        const xSeat1 = min(sTE + definition.seatMargin, xEnd);
        const padW = stabRoot.padWidth != undefined && stabRoot.padWidth > 0 ? stabRoot.padWidth * meter : 2 * R;
        const rb = tapDia / 2;
        const stabBolts = stabRoot.boltX;
        var blockNote = "";
        var seatOn = false;
        var holeDir = 1;           // holes start at the seat plane and go +1 up into the body (over) or -1 down (under)
        if (over)
        {
            // fuselage over the stab: the seat is the underside, cut flat at the pad plane. A round
            // tail gives a full-width flat only if the plane sits a few mm under the axis
            const drop = zA - sBot;
            if (drop < -0.01 * millimeter)
                warnings = append(warnings, "the stab's pad plane (Z " ~ fmt(sBot / millimeter, 1) ~ " mm) is above the fuselage centreline (Z " ~ fmt(zA / millimeter, 1) ~
                    " mm), so there is nothing to seat on - set Foil stabiliser's Height to 0 or below (-4 mm is typical); no seat cut");
            else
            {
                seatOn = true;
                holeDir = 1;
                const seatW = drop < rT ? 2 * sqrt(rT * rT - drop * drop) : 2 * rT;
                if (drop > rT)
                    warnings = append(warnings, "the pad plane is " ~ fmt((drop - rT) / millimeter, 1) ~ " mm below the tube - the block carries the stab that far under the body; set Foil stabiliser's Height nearer the centreline (-4 mm is typical) for a flush seat");
                else if (seatW < padW - 1 * millimeter && !definition.seatBlock)
                    warnings = append(warnings, "the flat seat on the tube is only " ~ fmt(seatW / millimeter, 1) ~ " mm wide against a " ~ fmt(padW / millimeter, 0) ~
                        " mm pad - turn Stab block on, or set Foil stabiliser's Height closer to 0 for a wider flat");
                // block: pad width, from just above the axis (merging into the body) down to the pad
                // plane, only under the FLAT part of the pad (from the ramp's end) and only ahead of
                // the tip, where the tube's own width may fall short of the pad. Build 105 ran it from
                // the seat start to the seat end and down to the ramp's nose: a tooth hung below the
                // tube ahead of the stab and a tab stuck out past the shrinking tip ("patchwork")
                const xRampEnd = stabRoot.padRampPct != undefined ? sLE + stabRoot.padRampPct / 100 * (sTE - sLE) : xSeat0;
                const xB0 = max(xSeat0, xRampEnd);
                const xB1 = min(xSeat1, xTip);
                if (definition.seatBlock && xB1 - xB0 > 2 * millimeter)
                {
                    const hb = padW / 2;
                    const bc = [vector(xB0, -hb), vector(xB1, -hb), vector(xB1, hb), vector(xB0, hb)];
                    const bz = [sBot - e, zA + 1 * millimeter];
                    var blockRegions = [];
                    for (var i = 0; i < 2; i += 1)
                    {
                        const sid = id + ("blockSec" ~ i);
                        var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(0 * meter, 0 * meter, bz[i]), Z_DIRECTION, X_DIRECTION) });
                        for (var k = 0; k < 4; k += 1)
                            skLineSegment(sk, "edge" ~ k, { "start" : bc[k], "end" : bc[(k + 1) % 4] });
                        skSolve(sk);
                        blockRegions = append(blockRegions, qSketchRegion(sid));
                        sketchBodies = append(sketchBodies, qCreatedBy(sid, EntityType.BODY));
                    }
                    opLoft(context, id + "stabBlock", { "profileSubqueries" : blockRegions });
                    opBoolean(context, id + "joinBlock", {
                                "tools" : qBodyType(qCreatedBy(id, EntityType.BODY), BodyType.SOLID),
                                "operationType" : BooleanOperationType.UNION
                            });
                    blockNote = " | stab block " ~ fmt(padW / millimeter, 0) ~ " x " ~ fmt((xB1 - xB0) / millimeter, 0) ~ " mm under the flat of the pad";
                }
                // seat: everything below the stab's mount contour (ramp from the nose, then the pad
                // plane) from the seat start to the end of the fuselage - a prism whose top is that
                // contour, lofted across the body. Build 104 cut a flat plane at the pad plane and
                // left a wedge open over the ramp (user: "a large gap at the front of the stab")
                const hw = max(R, padW / 2) + 1 * millimeter;
                const zBelow = zA - R - 2 * millimeter;
                var top = [];
                if (stabRoot.contour != undefined && size(stabRoot.contour) > 1)
                {
                    top = append(top, vector(xSeat0, stabRoot.contour[0][1] * meter));
                    for (var cp in stabRoot.contour)
                        if (cp[0] * meter > xSeat0 + 0.2 * millimeter && cp[0] * meter < xEnd - 0.2 * millimeter)
                            top = append(top, vector(cp[0] * meter, cp[1] * meter));
                }
                else
                    top = append(top, vector(xSeat0, sBot));
                top = append(top, vector(xEnd + e, sBot));
                // the cut's floor must lie under every point of the contour - with a deep seat the
                // ramp's nose end sits below the tube and the region folded over itself (build 135:
                // LOFT_FAILED at Height -10 on a 19 mm tail)
                var zBelowC = zBelow;
                for (var tp in top)
                    zBelowC = min(zBelowC, tp[1] - 2 * millimeter);
                var seatRegions = [];
                const ySeat = [-hw, hw];
                for (var i = 0; i < 2; i += 1)
                {
                    const sid = id + ("seatSec" ~ i);
                    var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(0 * meter, ySeat[i], 0 * meter), -Y_DIRECTION, X_DIRECTION) });
                    if (size(top) > 2)
                        skFitSpline(sk, "contour", { "points" : top });
                    else
                        skLineSegment(sk, "contour", { "start" : top[0], "end" : top[1] });
                    skLineSegment(sk, "aft", { "start" : top[size(top) - 1], "end" : vector(xEnd + e, zBelowC) });
                    skLineSegment(sk, "floor", { "start" : vector(xEnd + e, zBelowC), "end" : vector(xSeat0, zBelowC) });
                    skLineSegment(sk, "fore", { "start" : vector(xSeat0, zBelowC), "end" : top[0] });
                    skSolve(sk);
                    seatRegions = append(seatRegions, qSketchRegion(sid));
                    sketchBodies = append(sketchBodies, qCreatedBy(sid, EntityType.BODY));
                }
                opLoft(context, id + "seatCut", { "profileSubqueries" : seatRegions });
                toolIds = append(toolIds, id + "seatCut");
                seatNote = " | seats on the stab's mount contour, X " ~ fmt(xSeat0 / millimeter, 0) ~ "-" ~ fmt(xEnd / millimeter, 0) ~ ", pad plane Z " ~ fmt(sBot / millimeter, 1) ~
                    " mm (" ~ fmt(drop / millimeter, 1) ~ " mm under the axis)" ~ (hasTail ? ", tip over the stab's tail to X " ~ fmt(xEnd / millimeter, 0) : "") ~ blockNote;
            }
        }
        else
        {
            // stab on top of the fuselage (Pad side Bottom, or no pad): seat cut down to the stab's
            // lowest point, block from the axis up to it, holes down from the seat
            var blockOn = definition.seatBlock && sBot > zA;
            if (blockOn)
            {
                const hb = padW / 2;
                const bc = [vector(xSeat0, -hb), vector(xSeat1, -hb), vector(xSeat1, hb), vector(xSeat0, hb)];
                const bz = [zA - 1 * millimeter, sBot];
                var blockRegions = [];
                for (var i = 0; i < 2; i += 1)
                {
                    const sid = id + ("blockSec" ~ i);
                    var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(0 * meter, 0 * meter, bz[i]), Z_DIRECTION, X_DIRECTION) });
                    for (var k = 0; k < 4; k += 1)
                        skLineSegment(sk, "edge" ~ k, { "start" : bc[k], "end" : bc[(k + 1) % 4] });
                    skSolve(sk);
                    blockRegions = append(blockRegions, qSketchRegion(sid));
                    sketchBodies = append(sketchBodies, qCreatedBy(sid, EntityType.BODY));
                }
                opLoft(context, id + "stabBlock", { "profileSubqueries" : blockRegions });
                opBoolean(context, id + "joinBlock", {
                            "tools" : qBodyType(qCreatedBy(id, EntityType.BODY), BodyType.SOLID),
                            "operationType" : BooleanOperationType.UNION
                        });
                const above = sBot - (zA + rT);
                // a flat into the top of the body is the mirror of the seat under it (Seat on tube puts
                // the stab's underside Seat drop above the axis): accept it down to the same few mm
                // above the axis the over case uses, and only warn below that (build 126: the under
                // case warned for any flat at all, while the over case cut one by design)
                const wantU = min(4 * millimeter, 0.35 * rT);
                blockNote = " | stab block " ~ fmt(padW / millimeter, 0) ~ " x " ~ fmt((xSeat1 - xSeat0) / millimeter, 0) ~ " mm, top " ~
                    (above > 0 * meter ? fmt(above / millimeter, 1) ~ " mm above the body" : "flat " ~ fmt(-above / millimeter, 1) ~ " mm into the top of the body (" ~ fmt((sBot - zA) / millimeter, 1) ~ " mm above the axis)");
                if (sBot < zA - 0.01 * millimeter)
                    warnings = append(warnings, "the stab's underside is " ~ fmt((zA - sBot) / millimeter, 1) ~ " mm below the fuselage centreline, so the flat would take more than half the body - set Foil stabiliser's Height to 0 or above (+4 mm is typical)");
                else if (sBot < zA + wantU && above < 0 * meter)
                    blockNote = blockNote ~ " (a flat to the centreline; Height +3 to +5 leaves more tube)";
                else if (above > 1.5 * rT)
                    warnings = append(warnings, "the stab block stands " ~ fmt(above / millimeter, 0) ~ " mm above the body - a tall tower; lower Foil stabiliser's Height by about " ~ fmt((above - rT) / millimeter, 0) ~ " mm");
            }
            if (!blockOn && sBot > zA + rT)
                warnings = append(warnings, "the stab sits " ~ fmt((sBot - zA - rT) / millimeter, 1) ~ " mm above the fuselage - lower Foil stabiliser's Height by that much, or turn Stab block on; no seat cut");
            else if (sBot < zA)
                warnings = append(warnings, "the stab's lowest point is below the fuselage axis - raise Foil stabiliser's Height by " ~ fmt((zA + 0.5 * rT - sBot) / millimeter, 1) ~ " mm; no seat cut");
            else
            {
                seatOn = true;
                holeDir = -1;
                const hw = R + 1 * millimeter;
                const corners = [vector(xSeat0, -hw), vector(xSeat1 + e, -hw), vector(xSeat1 + e, hw), vector(xSeat0, hw)];
                const zs = [sBot, zA + R + 1 * millimeter];
                var boxRegions = [];
                for (var i = 0; i < 2; i += 1)
                {
                    const sid = id + ("seatSec" ~ i);
                    var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(0 * meter, 0 * meter, zs[i]), Z_DIRECTION, X_DIRECTION) });
                    for (var k = 0; k < 4; k += 1)
                        skLineSegment(sk, "edge" ~ k, { "start" : corners[k], "end" : corners[(k + 1) % 4] });
                    skSolve(sk);
                    boxRegions = append(boxRegions, qSketchRegion(sid));
                    sketchBodies = append(sketchBodies, qCreatedBy(sid, EntityType.BODY));
                }
                opLoft(context, id + "seatCut", { "profileSubqueries" : boxRegions });
                toolIds = append(toolIds, id + "seatCut");
                seatNote = " | stab seat on top, X " ~ fmt(xSeat0 / millimeter, 0) ~ "-" ~ fmt(xSeat1 / millimeter, 0) ~ " at Z " ~ fmt(sBot / millimeter, 1) ~ " mm" ~ blockNote;
            }
        }
        // blind tapped holes on the stab's own bolt pattern, from the seat plane into the body; each
        // must sit on the seat and leave >= 1 mm of wall beyond its end at its own X
        if (seatOn)
        {
            var made = 0;
            const xSeatEnd = over ? xEnd : xSeat1;
            for (var j = 0; j < size(stabBolts); j += 1)
            {
                const bx = stabBolts[j] * meter;
                const rLocal = min(profileRadiusAt(xs, rs, bx - rb), profileRadiusAt(xs, rs, bx + rb));
                const zcLocal = max(profileRadiusAt(xs, zcs, bx - rb), profileRadiusAt(xs, zcs, bx + rb));
                const zFar = holeDir > 0 ? zA - zcLocal + rLocal : zA - rLocal;            // body surface beyond the hole
                // the seat surface at this bolt: the mount contour where it is a ramp, else the pad plane
                var zSeat = sBot;
                if (over && stabRoot.contour != undefined && size(stabRoot.contour) > 1)
                {
                    const cpts = stabRoot.contour;
                    for (var i = 0; i < size(cpts) - 1; i += 1)
                        if (bx >= cpts[i][0] * meter && bx <= cpts[i + 1][0] * meter)
                            zSeat = (cpts[i][1] + (cpts[i + 1][1] - cpts[i][1]) * (bx / meter - cpts[i][0]) / (cpts[i + 1][0] - cpts[i][0])) * meter;
                }
                const zHoleEnd = zSeat + holeDir * definition.boltDepth;
                const wall = holeDir * (zFar - zHoleEnd);
                if (bx - rb < xSeat0 || bx + rb > xSeatEnd)
                    warnings = append(warnings, "stab bolt at X " ~ fmt(bx / millimeter, 0) ~ " mm skipped - it is off the seat; change Foil stabiliser's Bolt 1 at or Bolt pitch");
                else if (wall < 1 * millimeter)
                {
                    const maxDepth = holeDir * (zFar - zSeat) - 1 * millimeter;
                    warnings = append(warnings, "stab bolt at X " ~ fmt(bx / millimeter, 0) ~ " mm skipped - the body is only " ~ fmt((holeDir * (zFar - zSeat)) / millimeter, 1) ~ " mm deep there and a " ~
                        fmt(definition.boltDepth / millimeter, 0) ~ " mm hole would " ~
                        (wall < 0 * meter ? "break through by " ~ fmt(-wall / millimeter, 1) ~ " mm" : "leave only " ~ fmt(wall / millimeter, 1) ~ " mm") ~
                        ". Fix: Bolt depth to " ~ fmt(max(maxDepth, 0 * meter) / millimeter, 1) ~ " mm or less" ~
                        (over ? ", or lower Foil stabiliser's Height by " ~ fmt((definition.boltDepth + 1 * millimeter - holeDir * (zFar - zSeat)) / millimeter, 1) ~ " mm" :
                                ", or move the bolt forward onto the full Tail dia (Foil stabiliser's Bolt from LE / Bolt pitch)"));
                }
                else
                {
                    const base = id + ("stabBolt" ~ j);
                    const z0 = min(zSeat - holeDir * e, zHoleEnd);
                    const z1 = max(zSeat - holeDir * e, zHoleEnd);
                    toolIds = append(toolIds, circleLoft(context, base, bx, 0 * meter, z0, rb, z1, rb));
                    sketchBodies = append(sketchBodies, qCreatedBy(base + "a", EntityType.BODY));
                    sketchBodies = append(sketchBodies, qCreatedBy(base + "b", EntityType.BODY));
                    boltXs = append(boltXs, bx / meter);
                    made += 1;
                }
            }
            seatNote = seatNote ~ ", " ~ fmt(made, 0) ~ " of " ~ size(stabBolts) ~ " tapped holes " ~ fmt(tapDia / millimeter, 1) ~ " mm" ~ tapNote ~ (size(stabBolts) == 0 ? " (the stab has no Mount bolts)" : "");
        }
        var pocketNote = "";
        if (definition.pocketOn)
        {
            if (mast == undefined)
                warnings = append(warnings, "Mast pocket is on but there is no Foil mast above this feature - add one, or turn Mast pocket off; no pocket cut");
            else if (mast.baseZ * meter >= zA + R)
                warnings = append(warnings, "the mast base (Z " ~ fmt(mast.baseZ * 1000, 1) ~ " mm) is above the fuselage top (Z " ~ fmt((zA + R) / millimeter, 1) ~
                    " mm), so there is no pocket to cut - lower Foil mast's Base height (e.g. to " ~ fmt((zA + R - 20 * millimeter) / millimeter, 1) ~ " mm for a 20 mm deep pocket)");
            else
            {
                // floor follows the mast: its Base height, limited to leave >= 2 mm under the floor
                const zTop = zA + R;
                const zMin = zA - R + 2 * millimeter;
                var zFloor = mast.baseZ * meter;
                if (zFloor < zMin)
                {
                    warnings = append(warnings, "the mast base (Z " ~ fmt(zFloor / millimeter, 1) ~ " mm) is too low - the pocket would leave less than 2 mm under its floor. Pocket stopped at Z " ~
                        fmt(zMin / millimeter, 1) ~ " mm; raise Foil mast's Base height to at least " ~ fmt(zMin / millimeter, 1) ~ " mm");
                    zFloor = zMin;
                }
                const cl = definition.pocketClearance;
                const mc = mast.chord * meter;
                const pc = mc + 2 * cl;                               // pocket chord
                const pt = mast.thick * meter + 2 * cl;               // pocket thickness
                const psec = naca4Section(0, 0.4, pt / pc, (mast.te * meter + 2 * cl) / pc, mast.points);
                const ppts = placeSection(psec, pc, 0, 1, 0);
                const pzs = [zFloor, zA + R + 1 * millimeter];
                var pRegions = [];
                for (var i = 0; i < 2; i += 1)
                {
                    const sid = id + ("pocketSec" ~ i);
                    // same plane convention as the mast itself: normal +Z, sketch u = X, v = Y
                    var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(mast.leX * meter - cl, 0 * meter, pzs[i]), Z_DIRECTION, X_DIRECTION) });
                    skFitSpline(sk, "surface", { "points" : ppts });
                    skLineSegment(sk, "trailingEdge", { "start" : ppts[0], "end" : ppts[size(ppts) - 1] });
                    skSolve(sk);
                    pRegions = append(pRegions, qSketchRegion(sid));
                    sketchBodies = append(sketchBodies, qCreatedBy(sid, EntityType.BODY));
                }
                opLoft(context, id + "pocketCut", { "profileSubqueries" : pRegions });
                toolIds = append(toolIds, id + "pocketCut");
                pocketNote = " | mast pocket " ~ fmt((zTop - zFloor) / millimeter, 1) ~ " mm deep (floor at the mast base, Z " ~ fmt(zFloor / millimeter, 1) ~ " mm)";
            }
        }
        if (definition.matchWingPins && sock.pins > 0)
        {
            const pSpan = (sock.pins - 1) * sock.pinPitch * meter;
            for (var j = 0; j < sock.pins; j += 1)
            {
                const px = sock.pinCenterX * meter - pSpan / 2 + j * sock.pinPitch * meter;
                const base = id + ("wingPin" ~ j);
                toolIds = append(toolIds, circleLoft(context, base, px, 0 * meter, zA - rSp - e, sock.pinDia / 2 * meter, zA + rSp + e, sock.pinDia / 2 * meter));
                sketchBodies = append(sketchBodies, qCreatedBy(base + "a", EntityType.BODY));
                sketchBodies = append(sketchBodies, qCreatedBy(base + "b", EntityType.BODY));
            }
        }
        opDeleteBodies(context, id + "deleteSketches", { "entities" : qUnion(sketchBodies) });
        if (size(toolIds) > 0)
        {
            var toolQueries = [];
            for (var t in toolIds)
                toolQueries = append(toolQueries, qCreatedBy(t, EntityType.BODY));
            const tools = qUnion(toolQueries);
            opBoolean(context, id + "cutTools", {
                        "targets" : qSubtraction(qBodyType(qCreatedBy(id, EntityType.BODY), BodyType.SOLID), tools),
                        "tools" : tools,
                        "operationType" : BooleanOperationType.SUBTRACTION
                    });
        }

        // external wetted area from the profile itself (frustum sum), rear face to tip - the solid's
        // own faces include the spigot, holes and pocket, which are not in the flow
        var wetExt = 0 * meter * meter;
        for (var k = 0; k < size(xs) - 1; k += 1)
            wetExt += PI * (rs[k] + rs[k + 1]) * sqrt((xs[k + 1] - xs[k]) ^ 2 + (rs[k + 1] - rs[k]) ^ 2);
        nameSolids(context, id, "Fuselage");
        setVariable(context, "foilFuselageModel", {
                    "xFront" : xFront / meter, "xEnd" : xEnd / meter, "axisZ" : zA / meter,
                    "dia" : 2 * R / meter, "tailDia" : 2 * rT / meter,
                    "len" : (xEnd - xRear) / meter, "wettedExt" : wetExt / (meter * meter),
                    "stabBoltX" : boltXs, "stabBoltDia" : tapDia / meter,
                    "wetted" : evArea(context, { "entities" : qOwnedByBody(qBodyType(qCreatedBy(id, EntityType.BODY), BodyType.SOLID), EntityType.FACE) }) / (meter * meter)
                });
        reportFeatureInfo(context, id,
            "Body " ~ fmt(2 * R / millimeter, 1) ~ " mm from X " ~ fmt(xRear / millimeter, 0) ~ ", parallel to X " ~ fmt(xPar / millimeter, 0) ~
            ", " ~ fmt(2 * rT / millimeter, 0) ~ " mm from X " ~ fmt(xTail / millimeter, 0) ~ ", elliptical tip X " ~ fmt(xTip / millimeter, 0) ~
            "-" ~ fmt(xEnd / millimeter, 0) ~ " mm (stab TE at X " ~ fmt(sTE / millimeter, 0) ~ ")" ~ seatNote ~ pocketNote);
        var fw = "";
        if (size(warnings) > 0)
        {
            var w = "Conflicts (fix in the named feature): ";
            for (var i = 0; i < size(warnings); i += 1)
                w = w ~ (i > 0 ? " · " : "") ~ warnings[i];
            reportFeatureWarning(context, id, w);
            fw = " | " ~ w;
        }
        // console echo, so a pasted log carries the seat / bolt outcome without the notice
        var bxs = "";
        for (var b in boltXs)
            bxs = bxs ~ (bxs == "" ? "" : ",") ~ fmt(b * 1000, 1);
        println("FUSELAGE_SEAT:" ~ seatNote ~ "; boltX_mm=[" ~ bxs ~ "]" ~ fw);
    });

/** Radius of a piecewise-linear station profile (xs ascending) at x; 0 outside it. */
function profileRadiusAt(xs is array, rs is array, x is ValueWithUnits) returns ValueWithUnits
{
    if (x < xs[0] || x > xs[size(xs) - 1])
        return 0 * meter;
    for (var i = 0; i < size(xs) - 1; i += 1)
    {
        if (x >= xs[i] && x <= xs[i + 1])
        {
            if (xs[i + 1] - xs[i] <= 0 * meter)
                return rs[i];
            return rs[i] + (x - xs[i]) / (xs[i + 1] - xs[i]) * (rs[i + 1] - rs[i]);
        }
    }
    return rs[size(rs) - 1];
}

function fuselageInputLog(definition is map) returns string
{
    return "FUSELAGE_INPUTS: toolVersion=" ~ FOIL_FUSELAGE_VERSION
        ~ "; fusParAft_mm=" ~ fmt(definition.fusParAft / millimeter, 1)
        ~ "; fusTailDia_mm=" ~ fmt(definition.fusTailDia / millimeter, 1)
        ~ "; overhang_mm=" ~ fmt(definition.overhang / millimeter, 1)
        ~ "; tipLength_mm=" ~ fmt(definition.tipLength / millimeter, 1)
        ~ "; seatBlock=" ~ (definition.seatBlock ? "1" : "0")
        ~ "; seatMargin_mm=" ~ fmt(definition.seatMargin / millimeter, 1)
        ~ "; stabBoltDia_mm=" ~ fmt(definition.stabBoltDia / millimeter, 2)
        ~ "; boltDepth_mm=" ~ fmt(definition.boltDepth / millimeter, 1)
        ~ "; pocketOn=" ~ (definition.pocketOn ? "true" : "false")
        ~ (definition.pocketOn ? "; pocketClearance_mm=" ~ fmt(definition.pocketClearance / millimeter, 2) : "")
        ~ "; matchWingPins=" ~ (definition.matchWingPins ? "true" : "false");
}


// ---------------------------------------------------------------------------
// Performance library (all SI numbers: m, m^2, rad, N)
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Input logging - prints every parameter as one pasteable line
// ---------------------------------------------------------------------------

function enumStr_tipProfile(p is TipProfile) returns string
{
    if (p == TipProfile.NACA4) return "NACA4";
    if (p == TipProfile.E817) return "E817";
    if (p == TipProfile.E818) return "E818";
    if (p == TipProfile.NACA63412) return "NACA63412";
    if (p == TipProfile.CLARKY) return "CLARKY";
    return "SAME";
}

/** The FoilProfile a TipProfile names (SAME is never passed here). */
function tipToFoilProfile(p is TipProfile) returns FoilProfile
{
    if (p == TipProfile.E817) return FoilProfile.E817;
    if (p == TipProfile.E818) return FoilProfile.E818;
    if (p == TipProfile.NACA63412) return FoilProfile.NACA63412;
    if (p == TipProfile.CLARKY) return FoilProfile.CLARKY;
    return FoilProfile.NACA4;
}

/**
 * Section map for one surface, from a feature definition (buildFoil) or a published model map
 * (the mold): the root keys buildSection reads (profile, camber, camberPos, invertSection) plus
 * the tip section (tipOn, tipProfile as a FoilProfile, tipCamber, tipCamberPos, blendFrom as a
 * fraction). Build 166.
 */
function sectionDefFromDefinition(definition is map) returns map
{
    const tipOn = definition.tipProfile != undefined && definition.tipProfile != TipProfile.SAME;
    return { "profile" : definition.profile, "camber" : definition.camber, "camberPos" : definition.camberPos, "invertSection" : definition.invertSection == true,
             "tipOn" : tipOn, "tipProfile" : tipOn ? tipToFoilProfile(definition.tipProfile) : definition.profile,
             "tipCamber" : tipOn && definition.tipCamber != undefined ? definition.tipCamber : 0, "tipCamberPos" : tipOn && definition.tipCamberPos != undefined ? definition.tipCamberPos : 40,
             "blendFrom" : tipOn ? definition.blendFrom / 100 : 0 };
}

function sectionDefFromModel(m is map) returns map
{
    const tipOn = m.tipOn == 1;
    return { "profile" : profileFromName(m.profileName), "camber" : m.camber, "camberPos" : m.camberPos, "invertSection" : m.inverted == 1,
             "tipOn" : tipOn, "tipProfile" : tipOn ? profileFromName(m.tipProfileName) : profileFromName(m.profileName),
             "tipCamber" : tipOn ? m.tipCamber : 0, "tipCamberPos" : tipOn ? m.tipCamberPos : 40, "blendFrom" : tipOn ? m.blendFrom : 0 };
}

/** The tip section's own map, for buildSection / sectionAlpha0Cm0. */
function tipSectionDef(d is map) returns map
{
    return { "profile" : d.tipProfile, "camber" : d.tipCamber, "camberPos" : d.tipCamberPos, "invertSection" : d.invertSection };
}

/** Share of the tip section at eta: 0 out to blendFrom, then a smoothstep to 1 at the tip. */
function sectionWeightAt(d is map, eta is number) returns number
{
    if (d.tipOn != true || eta <= d.blendFrom)
        return 0;
    const u = min((eta - d.blendFrom) / max(1 - d.blendFrom, 1e-6), 1);
    return u * u * (3 - 2 * u);
}

/**
 * The section at one station: the root's, the tip's, or a point-by-point blend of the two (both
 * are sampled on the same cosine x stations with the same point count, so index i is the same
 * chordwise place on each).
 */
function buildSectionAt(d is map, thick is number, teFrac is number, n is number, w is number) returns array
{
    if (w <= 0)
        return buildSection(d, thick, teFrac, n);
    const tipPts = buildSection(tipSectionDef(d), thick, teFrac, n);
    if (w >= 1)
        return tipPts;
    const rootPts = buildSection(d, thick, teFrac, n);
    var out = [];
    for (var i = 0; i < size(rootPts); i += 1)
        out = append(out, rootPts[i] * (1 - w) + tipPts[i] * w);
    return out;
}

function enumStr_profile(p is FoilProfile) returns string
{
    if (p == FoilProfile.E817) return "E817";
    if (p == FoilProfile.E818) return "E818";
    if (p == FoilProfile.NACA63412) return "NACA63412";
    if (p == FoilProfile.CLARKY) return "CLARKY";
    return "NACA4";
}

function enumStr_polarSource(p is PolarSource) returns string
{
    if (p == PolarSource.POLAR) return "POLAR";
    if (p == PolarSource.BUILTIN) return "BUILTIN";
    return "ANALYTIC";
}

function enumStr_pivot(p is FoilPivot) returns string
{
    if (p == FoilPivot.LEADING_EDGE) return "LEADING_EDGE";
    if (p == FoilPivot.TRAILING_EDGE) return "TRAILING_EDGE";
    return "QUARTER_CHORD";
}

function enumStr_tipCap(t is TipCap) returns string
{
    return t == TipCap.TAPERED ? "TAPERED" : (t == TipCap.ROUND_PLAN ? "ROUND_PLAN" : "FLAT");
}

/** Shared fields common to the wing and the stab, one "key=value" list, no trailing separator. */
function commonFoilLog(definition is map) returns string
{
    var s = "profile=" ~ enumStr_profile(definition.profile);
    if (definition.profile == FoilProfile.NACA4)
        s = s ~ "; camber=" ~ fmt(definition.camber, 2) ~ "; camberPos=" ~ fmt(definition.camberPos, 1);
    s = s ~ "; tipProfile=" ~ (definition.tipProfile == undefined ? "SAME" : enumStr_tipProfile(definition.tipProfile));
    if (definition.tipProfile != undefined && definition.tipProfile != TipProfile.SAME)
    {
        if (definition.tipProfile == TipProfile.NACA4)
            s = s ~ "; tipCamber=" ~ fmt(definition.tipCamber, 2) ~ "; tipCamberPos=" ~ fmt(definition.tipCamberPos, 1);
        s = s ~ "; blendFrom=" ~ fmt(definition.blendFrom, 1);
    }
    s = s ~ "; rootThickness=" ~ fmt(definition.rootThickness, 2)
        ~ "; tipThickness=" ~ fmt(definition.tipThickness, 2)
        ~ "; teThickness_mm=" ~ fmt(definition.teThickness / millimeter, 3)
        ~ "; pointsPerSurface=" ~ fmt(definition.pointsPerSurface, 0)
        ~ "; planformMode=" ~ (definition.planformMode == PlanformMode.AREA_AR ? "AREA_AR" : "SPAN_CHORD");
    if (definition.planformMode == PlanformMode.AREA_AR)
        s = s ~ "; targetArea_cm2=" ~ fmt(definition.targetArea, 1)
            ~ "; aspectRatio=" ~ fmt(definition.aspectRatio, 2)
            ~ "; areaDefinition=" ~ (definition.areaDefinition == AreaDefinition.PROJECTED ? "PROJECTED" : "DEVELOPED");
    else
        s = s ~ "; span_mm=" ~ fmt(definition.span / millimeter, 1)
            ~ "; rootChord_mm=" ~ fmt(definition.rootChord / millimeter, 1);
    s = s ~ "; chordShape=" ~ (definition.chordShape == ChordShape.SUPERELLIPSE ? "SUPERELLIPSE" : (definition.chordShape == ChordShape.DOUBLE ? "DOUBLE" : "LINEAR"));
    if (definition.chordShape == ChordShape.SUPERELLIPSE)
        s = s ~ "; superN=" ~ fmt(definition.superN, 2) ~ "; endRatio=" ~ fmt(definition.endRatio, 3);
    else if (definition.chordShape == ChordShape.DOUBLE)
        s = s ~ "; breakPct=" ~ fmt(definition.breakPct, 1) ~ "; midRatio=" ~ fmt(definition.midRatio, 3) ~ "; blendPct=" ~ fmt(definition.blendPct, 1) ~ "; tipRatio=" ~ fmt(definition.tipRatio, 3);
    else
        s = s ~ "; tipRatio=" ~ fmt(definition.tipRatio, 3);
    s = s ~ "; minTipOn=" ~ (definition.minTipOn == true ? "1" : "0") ~ (definition.minTipOn == true ? "; minTip_mm=" ~ fmt(definition.minTip / millimeter, 2) : "");
    s = s ~ "; stations=" ~ fmt(definition.stations, 0)
        ~ "; mirror=" ~ (definition.mirror ? "true" : "false")
        ~ "; planformAlign=" ~ fmt(definition.planformAlign, 1)
        ~ "; sweepTip_mm=" ~ fmt(definition.sweepTip / millimeter, 1)
        ~ "; sweepExp=" ~ fmt(definition.sweepExp, 2)
        ~ "; tipDrop_mm=" ~ fmt(definition.tipDrop / millimeter, 1)
        ~ "; bumps=" ~ (definition.bumpOn == true ? "1" : "0")
        ~ (definition.bumpOn == true ? "; bumpAmp_mm=" ~ fmt(definition.bumpAmp / millimeter, 1) ~ "; bumpPitch_mm=" ~ fmt(definition.bumpPitch / millimeter, 1) ~ "; bumpFrom=" ~ fmt(definition.bumpFrom, 1) ~ "; bumpTo=" ~ fmt(definition.bumpTo, 1) : "")
        ~ "; winglet=" ~ (definition.winglet == Winglet.UP ? "UP" : (definition.winglet == Winglet.DOWN ? "DOWN" : "OFF"))
        ~ (definition.winglet != Winglet.OFF ? "; wingletArea_cm2=" ~ fmt(definition.wingletArea, 1) ~ "; wingletAngle_deg=" ~ fmt(definition.wingletAngle / degree, 1) ~ "; wingletRadius_mm=" ~ fmt(definition.wingletRadius / millimeter, 1) : "")
        ~ "; dropLaw=" ~ (definition.dropLaw == DropLaw.SCURVE ? "SCURVE" : "POWER") ~ (definition.dropLaw == DropLaw.SCURVE ? "" : "; dropExp=" ~ fmt(definition.dropExp, 2))
        ~ "; dropFrom=" ~ fmt(definition.dropFrom == undefined ? 0 : definition.dropFrom, 1) ~ "; dropTo=" ~ fmt(definition.dropTo == undefined ? 100 : definition.dropTo, 1)
        ~ "; rootDihedral_deg=" ~ fmt(definition.rootDihedral / degree, 2)
        ~ "; washout_deg=" ~ fmt(definition.washout / degree, 2)
        ~ "; washoutExp=" ~ fmt(definition.washoutExp, 2)
        ~ "; thicknessExp=" ~ fmt(definition.thicknessExp, 2)
        ~ "; incidence_deg=" ~ fmt(definition.incidence / degree, 2)
        ~ "; pivot=" ~ enumStr_pivot(definition.pivot)
        ~ "; tipCap=" ~ enumStr_tipCap(definition.tipCap);
    if (definition.tipCap != TipCap.FLAT)
        s = s ~ "; capLength_mm=" ~ fmt(definition.capLength / millimeter, 2) ~ "; capEnd=" ~ fmt(definition.capEnd, 1);
    s = s ~ "; polarSource=" ~ enumStr_polarSource(definition.polarSource);
    if (definition.polarSource == PolarSource.POLAR)
        s = s ~ "; polarAlpha0_deg=" ~ fmt(definition.polarAlpha0 / degree, 2)
            ~ "; polarCla=" ~ fmt(definition.polarCla, 3) ~ "; polarCm0=" ~ fmt(definition.polarCm0, 4)
            ~ "; polarRe1_M=" ~ fmt(definition.polarRe1, 3) ~ "; polarClmax1=" ~ fmt(definition.polarClmax1, 3)
            ~ "; polarCdmin1=" ~ fmt(definition.polarCdmin1, 4) ~ "; polarClcd1=" ~ fmt(definition.polarClcd1, 3) ~ "; polarK1=" ~ fmt(definition.polarK1, 4)
            ~ "; polarRe2_M=" ~ fmt(definition.polarRe2, 3) ~ "; polarClmax2=" ~ fmt(definition.polarClmax2, 3)
            ~ "; polarCdmin2=" ~ fmt(definition.polarCdmin2, 4) ~ "; polarClcd2=" ~ fmt(definition.polarClcd2, 3) ~ "; polarK2=" ~ fmt(definition.polarK2, 4);
    return s;
}

function wingInputLog(definition is map) returns string
{
    var s = "WING_INPUTS: toolVersion=" ~ FOIL_WING_VERSION ~ "; " ~ commonFoilLog(definition)
        ~ "; socketOn=" ~ (definition.socketOn ? "true" : "false");
    if (definition.socketOn)
        s = s ~ "; tubeDia_mm=" ~ fmt(definition.tubeDia / millimeter, 2)
            ~ "; tubeClearance_mm=" ~ fmt(definition.tubeClearance / millimeter, 2)
            ~ "; socketWall_mm=" ~ fmt(definition.socketWall / millimeter, 2)
            ~ "; socketBlend_mm=" ~ fmt(definition.socketBlend / millimeter, 1)
            ~ "; socketRearExt_mm=" ~ fmt(definition.socketRearExt / millimeter, 1)
            ~ "; nacelleRearFair_mm=" ~ fmt(definition.nacelleRearFair / millimeter, 1)
            ~ "; socketDepth_mm=" ~ fmt(definition.socketDepth / millimeter, 1)
            ~ "; socketPins=" ~ fmt(definition.socketPins, 0)
            ~ "; socketPinBolt=" ~ boltDims(definition.socketPinBolt).name ~ "; socketPinDia_mm=" ~ fmt((definition.socketPinBolt == BoltSize.CUSTOM ? definition.socketPinDia : (boltDims(definition.socketPinBolt).clear + 0.1) * millimeter) / millimeter, 2)
            ~ "; socketPinPitch_mm=" ~ fmt(definition.socketPinPitch / millimeter, 1);
    return s;
}

/**
 * Stab mount pad: a wedge under the stab root. Profile in the XZ plane (same sketch frame as the
 * foil sections: plane normal -Y, u = X, v = Z, origin at the stab pivot): top = the root's own
 * lower surface raised 0.5 mm into the stab (so the union overlaps rather than meeting on a
 * coincident face), bottom = a flat horizontal line Pad height below the lowest point of that
 * surface over the pad. Lofted between two copies at y = +/- Pad width / 2, unioned with the stab.
 * Returns { on, bottomRel (pad bottom Z relative to the stab pivot), note }.
 */
/**
 * Production-style mount on the stab root (Axis layout): a flat pad face on the fuselage side, faired
 * from the leading edge, the full root chord long, optionally continued aft as a tapered tail
 * fairing; plus through bolt holes on the centreline. Built as the intersection of a side-view prism
 * (x-z profile lofted across the span) and a plan-view prism (x-y outline lofted through the height),
 * so a flat face, a curved ramp, a concave plan taper and a sloping tail all come from two sketches.
 * Pad side Bottom is the same geometry mirrored in z. Returns local (pivot-relative) measures.
 */
function buildStabMount(context is Context, id is Id, definition is map, m is map) returns map
{
    const off = { "on" : false, "side" : 0, "padRel" : 0 * meter, "endRel" : 0 * meter, "tailOn" : false, "boltX" : [], "contour" : [], "rampPct" : 0, "tailLen" : 0 * meter, "tailStartRel" : 0 * meter, "note" : "" };
    const pts = m.rootPts;
    const n = (size(pts) + 1) / 2;
    var upper = [];
    var lower = [];
    var xMin = 1 * meter;
    var xMax = -1 * meter;
    for (var i = 0; i < size(pts); i += 1)
    {
        if (i < n)
            upper = append(upper, pts[i]);          // upper TE -> LE
        if (i >= n - 1)
            lower = append(lower, pts[i]);          // LE -> lower TE
        xMin = min(xMin, pts[i][0]);
        xMax = max(xMax, pts[i][0]);
    }
    // an inverted tabulated profile keeps its point order, so "upper" by index is the geometric
    // lower surface: swap them by the mid-chord Z so the pad, its ramp and the countersink land on
    // the right faces (build 143: an inverted Clark Y with the pad on top failed the side loft)
    const xMid = 0.5 * (xMin + xMax);
    if (profileZAt(upper, xMid) < profileZAt(lower, xMid))
    {
        const tmp = upper;
        upper = reverse(lower);   // stays TE -> LE
        lower = reverse(tmp);     // stays LE -> TE
    }
    var result = off;
    var sgn = 0;
    var padM = 0 * meter;      // pad plane in the mirrored frame (z' = sgn * z)
    var xEnd = xMax;
    const arm = definition.arm;
    const hgt = definition.height;
    var sketches = [];
    if (definition.padOn)
    {
        sgn = definition.padSide == PadSide.TOP ? 1 : -1;
        // pad-facing surface in the mirrored frame, as points sorted LE -> TE
        var surf = [];
        if (sgn == 1)
        {
            for (var i = size(upper) - 1; i >= 0; i -= 1)
                surf = append(surf, upper[i]);
        }
        else
        {
            for (var pnt in lower)
                surf = append(surf, vector(pnt[0], -pnt[1]));
        }
        var far = [];              // far surface, same frame (for the overlap lift and the TE point)
        if (sgn == 1)
            far = lower;
        else
            for (var i = size(upper) - 1; i >= 0; i -= 1)
                far = append(far, vector(upper[i][0], -upper[i][1]));
        var zTopM = -1 * meter;
        for (var pnt in surf)
            zTopM = max(zTopM, pnt[1]);
        padM = zTopM + definition.padHeight;
        const chord = xMax - xMin;
        const hair = 0.05 * millimeter;
        const x0 = xMin + 1 * millimeter;                       // the ramp leaves the skin 1 mm behind the nose
        // the fixed interface: Flat start, Tail start and Tail end are mm from the pivot, so the seat
        // plane, its length and the fuselage tip are the same for every stab with the same Arm (build
        // 125). Held inside the section where it does not fit, with a warning in the note
        var fitNote = "";
        var xRamp = definition.flatStart;
        if (xRamp < x0 + 5 * millimeter)
        {
            fitNote = fitNote ~ " | WARNING: Flat start " ~ fmt(definition.flatStart / millimeter, 0) ~ " mm is ahead of the leading edge (" ~ fmt(xMin / millimeter, 0) ~ " mm) - held 5 mm behind it; move Flat start aft to keep the interface fixed";
            xRamp = x0 + 5 * millimeter;
        }
        if (xRamp > xMax - 5 * millimeter)
        {
            fitNote = fitNote ~ " | WARNING: Flat start " ~ fmt(definition.flatStart / millimeter, 0) ~ " mm is behind the trailing edge (" ~ fmt(xMax / millimeter, 0) ~ " mm) - held 5 mm ahead of it; move Flat start forward";
            xRamp = xMax - 5 * millimeter;
        }
        const tailOn = definition.tailOn == true;
        var xTailStart = xMax;
        if (tailOn)
        {
            xEnd = max(definition.tailEnd, xMax + 5 * millimeter);
            if (xEnd > definition.tailEnd + hair)
                fitNote = fitNote ~ " | WARNING: Tail end " ~ fmt(definition.tailEnd / millimeter, 0) ~ " mm is inside the root (TE at " ~ fmt(xMax / millimeter, 0) ~ " mm) - held 5 mm behind the TE; move Tail end aft";
            xTailStart = min(max(definition.tailStart, xMax), xEnd - 5 * millimeter);
            if (xTailStart > definition.tailStart + hair)
                fitNote = fitNote ~ " | WARNING: the trailing edge (" ~ fmt(xMax / millimeter, 0) ~ " mm) is behind Tail start " ~ fmt(definition.tailStart / millimeter, 0) ~ " mm - the taper starts at the TE; move Tail start aft to keep the fuselage tip fixed";
        }
        else
            xEnd = xMax;
        const zTE = profileZAt(surf, xMax - hair);              // trailing-edge point (upper and lower meet)

        // ---- side profile (x, z'), closed ----
        var ramp = [];
        for (var k = 0; k <= 12; k += 1)
        {
            const t = k / 12;
            const x = x0 + (xRamp - x0) * t;
            const sm = t * t * (3 - 2 * t);
            const zs = profileZAt(surf, x);
            ramp = append(ramp, vector(x, zs + (padM - zs) * sm));
        }
        var bottom = [];                                          // inside the stab, TE -> LE
        for (var k = 0; k <= 24; k += 1)
        {
            const x = xMax - hair - (xMax - hair - x0) * k / 24;
            const zs = profileZAt(surf, x);
            const zf = profileZAt(far, x);
            const lift = min(0.5 * millimeter, 0.4 * max(zs - zf, 0 * meter));
            bottom = append(bottom, vector(x, zs - lift));
        }
        var side = [];
        const yS = [-(definition.padWidth / 2 + 2 * millimeter), definition.padWidth / 2 + 2 * millimeter];
        for (var i = 0; i < 2; i += 1)
        {
            const sid = id + ("mountSide" ~ i);
            var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(arm, yS[i], hgt), -Y_DIRECTION, X_DIRECTION) });
            var rampW = [];
            for (var q in ramp)
                rampW = append(rampW, vector(q[0], sgn * q[1]));
            var botW = [];
            for (var q in bottom)
                botW = append(botW, vector(q[0], sgn * q[1]));
            skFitSpline(sk, "ramp", { "points" : rampW });
            const pFlatEnd = vector(xMax + hair, sgn * padM);
            skLineSegment(sk, "flat", { "start" : rampW[size(rampW) - 1], "end" : pFlatEnd });
            skLineSegment(sk, "end", { "start" : pFlatEnd, "end" : botW[0] });
            skFitSpline(sk, "inner", { "points" : botW });
            skLineSegment(sk, "nose", { "start" : botW[size(botW) - 1], "end" : rampW[0] });
            skSolve(sk);
            side = append(side, qSketchRegion(sid));
            sketches = append(sketches, qCreatedBy(sid, EntityType.BODY));
        }
        opLoft(context, id + "mountSideLoft", { "profileSubqueries" : side });

        // ---- plan outline (x, y), closed ----
        const hw = definition.padWidth / 2;
        var zLoW = 1 * meter;
        var zHiW = -1 * meter;
        for (var q in ramp)
        {
            zLoW = min(zLoW, sgn * q[1]);
            zHiW = max(zHiW, sgn * q[1]);
        }
        for (var q in bottom)
        {
            zLoW = min(zLoW, sgn * q[1]);
            zHiW = max(zHiW, sgn * q[1]);
        }
        zLoW = min(zLoW, sgn * padM) - 2 * millimeter;
        zHiW = max(zHiW, sgn * padM) + 2 * millimeter;
        var plan = [];
        const zP = [zLoW, zHiW];
        for (var i = 0; i < 2; i += 1)
        {
            const sid = id + ("mountPlan" ~ i);
            var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(arm, 0 * meter, hgt + zP[i]), Z_DIRECTION, X_DIRECTION) });
            const a = vector(x0 - 0.5 * millimeter, hw);
            const b = vector(xMax, hw);
            const c = vector(xMax, -hw);
            const d = vector(x0 - 0.5 * millimeter, -hw);
            skLineSegment(sk, "front", { "start" : d, "end" : a });
            skLineSegment(sk, "sideP", { "start" : a, "end" : b });
            skLineSegment(sk, "sideN", { "start" : c, "end" : d });
            skLineSegment(sk, "aft", { "start" : b, "end" : c });
            skSolve(sk);
            plan = append(plan, qSketchRegion(sid));
            sketches = append(sketches, qCreatedBy(sid, EntityType.BODY));
        }
        opLoft(context, id + "mountPlanLoft", { "profileSubqueries" : plan });
        opBoolean(context, id + "mountShape", {
                    "tools" : qUnion([qCreatedBy(id + "mountSideLoft", EntityType.BODY), qCreatedBy(id + "mountPlanLoft", EntityType.BODY)]),
                    "operationType" : BooleanOperationType.INTERSECTION
                });
        // ---- tail fairing: a loft of sections along x, flat at the pad plane, a superellipse below
        // whose exponent runs from 12 (a near-rectangle matching the pad body at the trailing edge)
        // to 2 (a half-ellipse at the end), so the edges round off progressively like a fuselage tail.
        // Plan half-width tapers concavely, the far face linearly to End thick. Pairwise ruled lofts,
        // unioned, as the mold does (a single multi-profile loft folded there)
        if (tailOn)
        {
            const nT = 8;
            const hwE = definition.tailEndWidth / 2;
            const dTE = padM - (zTE - 0.5 * millimeter);              // depth at the trailing edge, down to just inside the skin
            var tailRegions = [];
            // stations: just inside the TE, at Tail start if that is aft of the TE (full width between),
            // then nT over the taper to Tail end
            var xsT = [xMax - 1 * millimeter];
            if (xTailStart > xMax + 1 * millimeter)
                xsT = append(xsT, xTailStart);
            for (var k = 1; k <= nT; k += 1)
                xsT = append(xsT, xTailStart + (xEnd - xTailStart) * k / nT);
            for (var k = 0; k < size(xsT); k += 1)
            {
                const x = xsT[k];
                const t = min(max((x - xTailStart) / (xEnd - xTailStart), 0), 1);
                const h = hwE + (hw - hwE) * (1 - t) ^ 1.6;
                const d = dTE + (definition.tailEndThick - dTE) * t;
                const pw = 12 - 10 * t;
                var loop = [];
                for (var q = 0; q <= 24; q += 1)
                {
                    const th = PI + PI * q / 24;
                    const cth = cos(th * radian);
                    const sth = sin(th * radian);
                    const yy = h * (cth < 0 ? -1 : 1) * abs(cth) ^ (2 / pw);
                    const zz = padM - d * abs(sth) ^ (2 / pw);
                    loop = append(loop, vector(yy, sgn * zz));
                }
                const sid = id + ("tailSec" ~ k);
                var sk = newSketchOnPlane(context, sid, { "sketchPlane" : plane(vector(arm + x, 0 * meter, hgt), X_DIRECTION, Y_DIRECTION) });
                skFitSpline(sk, "u", { "points" : loop });
                skLineSegment(sk, "top", { "start" : loop[size(loop) - 1], "end" : loop[0] });
                skSolve(sk);
                tailRegions = append(tailRegions, qSketchRegion(sid));
                sketches = append(sketches, qCreatedBy(sid, EntityType.BODY));
            }
            // one smooth loft through every section (the sections are similar and monotonic, unlike
            // the mold curtain's); pairwise ruled lofts, which read as terraces, only as a fallback
            var smooth = true;
            try silent
            {
                opLoft(context, id + "tailLoft", { "profileSubqueries" : tailRegions });
            }
            catch
            {
                smooth = false;
            }
            if (!smooth)
            {
                var tailBodies = [];
                for (var k = 0; k < size(tailRegions) - 1; k += 1)
                {
                    const lid = id + ("tailLoftR" ~ k);
                    opLoft(context, lid, { "profileSubqueries" : [tailRegions[k], tailRegions[k + 1]] });
                    tailBodies = append(tailBodies, qCreatedBy(lid, EntityType.BODY));
                }
                opBoolean(context, id + "tailJoin", { "tools" : qUnion(tailBodies), "operationType" : BooleanOperationType.UNION });
            }
        }
        opBoolean(context, id + "mountJoin", {
                    "tools" : qBodyType(qCreatedBy(id, EntityType.BODY), BodyType.SOLID),
                    "operationType" : BooleanOperationType.UNION
                });
        // the mount contour the fuselage seats on: ramp from the nose, then the flat pad plane to the end
        var contour = [];
        for (var q in ramp)
            contour = append(contour, [(arm + q[0]) / meter, (hgt + sgn * q[1]) / meter]);
        contour = append(contour, [(arm + xEnd) / meter, (hgt + sgn * padM) / meter]);
        result = { "on" : true, "side" : sgn, "padRel" : sgn * padM, "endRel" : xEnd, "tailOn" : tailOn, "boltX" : [], "contour" : contour,
                   "rampPct" : (xRamp - xMin) / chord * 100, "tailLen" : xEnd - xMax, "tailStartRel" : xTailStart,
                   "note" : " | mount pad " ~ (sgn == 1 ? "on top" : "underneath") ~ ", face " ~ fmt(definition.padHeight / millimeter, 1) ~ " mm off the skin at Z " ~
                       fmt(sgn * padM / millimeter, 1) ~ " mm from the pivot, " ~ fmt(definition.padWidth / millimeter, 0) ~ " mm wide; fixed interface from the pivot: flat from " ~ fmt(xRamp / millimeter, 0) ~ " mm (ramp from the LE at " ~ fmt(xMin / millimeter, 0) ~ ")" ~
                       (tailOn ? ", full width to " ~ fmt(xTailStart / millimeter, 0) ~ ", tail to " ~ fmt(xEnd / millimeter, 0) ~ " mm ending " ~ fmt(definition.tailEndWidth / millimeter, 0) ~ " x " ~ fmt(definition.tailEndThick / millimeter, 0) ~ " mm" : " to the TE at " ~ fmt(xMax / millimeter, 0) ~ " mm (no tail: the interface follows the chord)") ~ fitNote };
    }

    // ---- bolt holes, through everything on the centreline ----
    if (definition.stabBolts > 0)
    {
        var bolts = [];
        var tools = [];
        var skipped = "";
        var nCsk = 0;
        const rb = stabBoltClear(definition) / 2;
        for (var k = 0; k < definition.stabBolts; k += 1)
        {
            const bx = definition.bolt1At + k * definition.boltPitch;
            if (bx + rb > xEnd - 0.5 * millimeter || bx - rb < xMin + 0.5 * millimeter)
            {
                skipped = skipped ~ " bolt " ~ (k + 1) ~ " at X " ~ fmt(bx / millimeter, 0) ~ " mm from the pivot is off the root" ~ (definition.padOn && definition.tailOn == true ? "/tail" : "") ~ " - change Bolt 1 at or Bolt pitch;";
                continue;
            }
            const base = id + ("stabBolt" ~ k);
            tools = append(tools, qCreatedBy(circleLoft(context, base, arm + bx, 0 * meter, hgt - 60 * millimeter, rb, hgt + 60 * millimeter, rb), EntityType.BODY));
            sketches = append(sketches, qCreatedBy(base + "a", EntityType.BODY));
            sketches = append(sketches, qCreatedBy(base + "b", EntityType.BODY));
            bolts = append(bolts, bx);
            // countersink on the far face (away from the pad; the underside with no pad): a 90 deg cone
            // from just outside the skin, head diameter wide, narrowing to the hole over its depth
            if (definition.boltCsk && bx > xMin + 0.5 * millimeter && bx < xMax - 0.5 * millimeter)
            {
                const dOut = sgn == -1 ? 1 : -1;                      // outward, away from the pad
                const farPts = sgn == -1 ? upper : lower;
                const zFar = hgt + profileZAt(farPts, bx);
                const rHead = boltHead(definition.boltSize, 2 * rb) / 2;
                const cskD = rHead - rb;
                const cb = id + ("stabCsk" ~ k);
                tools = append(tools, qCreatedBy(circleLoft(context, cb, arm + bx, 0 * meter, zFar + dOut * 2 * millimeter, rHead + 2 * millimeter, zFar - dOut * cskD, rb), EntityType.BODY));
                sketches = append(sketches, qCreatedBy(cb + "a", EntityType.BODY));
                sketches = append(sketches, qCreatedBy(cb + "b", EntityType.BODY));
                nCsk += 1;
            }
        }
        if (size(tools) > 0)
        {
            const toolQ = qUnion(tools);
            opBoolean(context, id + "stabBoltCut", {
                        "targets" : qSubtraction(qBodyType(qCreatedBy(id, EntityType.BODY), BodyType.SOLID), toolQ),
                        "tools" : toolQ,
                        "operationType" : BooleanOperationType.SUBTRACTION
                    });
        }
        result.boltX = bolts;
        result.note = result.note ~ " | " ~ size(bolts) ~ " " ~ boltDims(definition.boltSize).name ~ " bolt holes " ~ fmt(stabBoltClear(definition) / millimeter, 1) ~ " mm at " ~ fmt(definition.bolt1At / millimeter, 0) ~
            " mm from the pivot" ~ (size(bolts) > 1 ? ", pitch " ~ fmt(definition.boltPitch / millimeter, 0) ~ " mm" : "") ~
            (nCsk > 0 ? ", " ~ nCsk ~ " countersunk " ~ fmt(boltHead(definition.boltSize, stabBoltClear(definition)) / millimeter, 1) ~ " mm on the " ~ (sgn == -1 ? "top" : "underside") : "") ~ (skipped != "" ? " |" ~ skipped : "");
    }
    if (size(sketches) > 0)
        opDeleteBodies(context, id + "deleteMountSketches", { "entities" : qUnion(sketches) });
    return result;
}

function stabInputLog(definition is map, pivotZ is ValueWithUnits) returns string
{
    var s = "STAB_INPUTS: toolVersion=" ~ FOIL_STAB_VERSION ~ "; " ~ commonFoilLog(definition)
        ~ "; arm_mm=" ~ fmt(definition.arm / millimeter, 1)
        ~ "; rootTailOn=" ~ (definition.rootTailOn == true ? "1" : "0")
        ~ (definition.rootTailOn == true ? "; rootTailLen_mm=" ~ fmt(definition.rootTailLen / millimeter, 1) ~ "; rootTailSpan=" ~ fmt(definition.rootTailSpan, 1) : "")
        ~ "; height_mm=" ~ fmt(definition.height / millimeter, 1) ~ "; pivotZ_mm=" ~ fmt(pivotZ / millimeter, 1)
        ~ "; stabLink=" ~ (definition.stabLink == StabLink.LINKED ? "LINKED" : "INDEPENDENT");
    if (definition.stabLink == StabLink.LINKED)
        s = s ~ "; linkAreaRatio=" ~ fmt(definition.linkAreaRatio, 3)
            ~ "; linkAROffset=" ~ fmt(definition.linkAROffset, 2)
            ~ "; linkThicknessOffset=" ~ fmt(definition.linkThicknessOffset, 2)
            ~ "; linkDecalage_deg=" ~ fmt(definition.linkDecalage / degree, 2)
            ;
    if (definition.profile != FoilProfile.NACA4)
        s = s ~ "; invertSection=" ~ (definition.invertSection ? "1" : "0");
    s = s ~ "; padOn=" ~ (definition.padOn ? "true" : "false");
    if (definition.padOn)
    {
        s = s ~ "; padSide=" ~ (definition.padSide == PadSide.TOP ? "TOP" : "BOTTOM")
            ~ "; padWidth_mm=" ~ fmt(definition.padWidth / millimeter, 1)
            ~ "; padHeight_mm=" ~ fmt(definition.padHeight / millimeter, 1)
            ~ "; flatStart_mm=" ~ fmt(definition.flatStart / millimeter, 1)
            ~ "; tailOn=" ~ (definition.tailOn ? "true" : "false");
        if (definition.tailOn)
            s = s ~ "; tailStart_mm=" ~ fmt(definition.tailStart / millimeter, 1) ~ "; tailEnd_mm=" ~ fmt(definition.tailEnd / millimeter, 1)
                ~ "; tailEndWidth_mm=" ~ fmt(definition.tailEndWidth / millimeter, 1)
                ~ "; tailEndThick_mm=" ~ fmt(definition.tailEndThick / millimeter, 1);
    }
    s = s ~ "; stabBolts=" ~ fmt(definition.stabBolts, 0);
    if (definition.stabBolts > 0)
        s = s ~ "; bolt1At_mm=" ~ fmt(definition.bolt1At / millimeter, 1)
            ~ "; boltPitch_mm=" ~ fmt(definition.boltPitch / millimeter, 1)
            ~ "; bolt=" ~ boltDims(definition.boltSize).name ~ "; boltDia_mm=" ~ fmt(stabBoltClear(definition) / millimeter, 2) ~ "; boltCsk=" ~ (definition.boltCsk ? "true" : "false");
    return s;
}

/** The stab's clearance hole: from the Bolt dropdown, or the typed Bolt dia when Custom. */
function stabBoltClear(definition is map) returns ValueWithUnits
{
    return definition.boltSize == BoltSize.CUSTOM ? definition.boltDia : boltDims(definition.boltSize).clear * millimeter;
}

function perfInputLog(definition is map) returns string
{
    return "PERFORMANCE_INPUTS: toolVersion=" ~ FOIL_PERF_VERSION ~ "; mass_kg=" ~ fmt(definition.mass, 1)
        ~ "; extMoment_Nm=" ~ fmt(definition.extMoment, 1)
        ~ "; density=" ~ fmt(definition.density, 1)
        ~ "; waterTemp_C=" ~ fmt(definition.waterTemp, 1)
        ~ "; depth_mm=" ~ fmt(definition.depth / millimeter, 1)
        ~ "; vTakeoff_kmh=" ~ fmt(definition.vTakeoff, 1)
        ~ "; vCruise_kmh=" ~ fmt(definition.vCruise, 1)
        ~ "; vMax_kmh=" ~ fmt(definition.vMax, 1)
        ~ "; vStep_kmh=" ~ fmt(definition.vStep, 2)
        ~ "; clMax=" ~ fmt(definition.clMax, 2)
        ~ "; laminar_pct=" ~ fmt(definition.laminar, 1)
        ~ "; otherDrag_cm2=" ~ fmt(definition.otherDrag, 1)
        ~ "; loadFactor_g=" ~ fmt(definition.loadFactor, 1)
        ~ "; capStress_MPa=" ~ fmt(definition.capStress, 0)
        ~ "; capWidth_pct=" ~ fmt(definition.capWidth, 1)
        ~ "; propOn=" ~ (definition.propOn ? "1" : "0")
        ~ (definition.propOn
            ? "; propDia_mm=" ~ fmt(definition.propDia / millimeter, 1)
            ~ "; propPD=" ~ fmt(definition.propPD, 3)
            ~ "; propEAR=" ~ fmt(definition.propEAR, 3)
            ~ "; propBlades=" ~ definition.propBlades
            ~ "; motorKv=" ~ fmt(definition.motorKv, 1)
            ~ "; cells=" ~ definition.cells
            ~ "; gearRatio=" ~ fmt(definition.gearRatio, 2)
            ~ "; currentLimit_A=" ~ fmt(definition.currentLimit, 1)
            ~ "; windingR_mOhm=" ~ fmt(definition.windingR, 1)
            ~ "; gearEff_pct=" ~ fmt(definition.gearEff, 1)
            ~ "; escEff_pct=" ~ fmt(definition.escEff, 1)
            ~ "; packAh=" ~ fmt(definition.packAh, 1)
            ~ "; usable_pct=" ~ fmt(definition.usable, 1)
            : "");
}


function fmt(x is number, d is number) returns string
{
    const k = 10 ^ d;
    return toString(round(x * k) / k);
}

/** Kinematic viscosity of water, m^2/s (Poiseuille fit), +5 % for seawater. */
function waterViscosity(T is number, rho is number) returns number
{
    const nu = 1.792e-6 / (1 + 0.0337 * T + 0.000221 * T * T);
    return rho > 1010 ? nu * 1.05 : nu;
}

function chordAt(m is map, eta is number) returns number
{
    return m.c0 * chordFactor(m, eta);
}

/** Gaussian elimination with partial pivoting. */
function solveLinear(A is array, b is array) returns array
{
    const n = size(b);
    var M = A;
    var v = b;
    for (var k = 0; k < n; k += 1)
    {
        var p = k;
        for (var i = k + 1; i < n; i += 1)
            if (abs(M[i][k]) > abs(M[p][k]))
                p = i;
        if (p != k)
        {
            const tr = M[k];
            M[k] = M[p];
            M[p] = tr;
            const tv = v[k];
            v[k] = v[p];
            v[p] = tv;
        }
        for (var i = k + 1; i < n; i += 1)
        {
            const f = M[i][k] / M[k][k];
            var row = M[i];
            for (var j = k; j < n; j += 1)
                row[j] = row[j] - f * M[k][j];
            M[i] = row;
            v[i] = v[i] - f * v[k];
        }
    }
    var x = makeArray(n, 0);
    for (var i = n - 1; i >= 0; i -= 1)
    {
        var s = v[i];
        for (var j = i + 1; j < n; j += 1)
            s -= M[i][j] * x[j];
        x[i] = s / M[i][i];
    }
    return x;
}

/**
 * Prandtl lifting line (Glauert, symmetric odd terms). y = (b/2) cos(theta).
 * Solved twice: per radian of body angle (Aa) and for twist + zero-lift angle (A0),
 * so A(alpha) = A0 + alpha Aa. Sweep and anhedral are not modelled.
 */
function liftingLine(m is map, a0 is number, M is number) returns map
{
    // a winglet is credited as effective span for induced drag: projected span plus 0.9 x its
    // height across the pair (the usual first estimate); the chord law still runs over eta
    const b = m.wingletOn == 1 ? m.spanProj + 0.9 * m.wingletHeight : m.span;
    const AR = b * b / m.area;
    var rows = [];
    var ra = [];
    var r0 = [];
    var thetas = [];
    for (var j = 1; j <= M; j += 1)
    {
        const th = j * PI / (2 * M);
        const st = sin(th * radian);
        const eta = cos(th * radian);
        const mu = a0 * chordAt(m, eta) / (4 * b);
        var row = [];
        for (var k = 1; k <= M; k += 1)
        {
            const nn = 2 * k - 1;
            row = append(row, sin(nn * th * radian) * (mu * nn + st));
        }
        rows = append(rows, row);
        const twist = m.incidence - m.washout * eta ^ m.washoutExp;
        ra = append(ra, mu * st);
        r0 = append(r0, mu * st * (twist - alpha0At(m, eta)));
        thetas = append(thetas, th);
    }
    const Aa = solveLinear(rows, ra);
    const A0 = solveLinear(rows, r0);
    return { "Aa" : Aa, "A0" : A0, "AR" : AR, "M" : M, "b" : b, "thetas" : thetas,
            "CL0" : PI * AR * A0[0], "CLa" : PI * AR * Aa[0] };
}

function lltInducedDrag(L is map, alpha is number) returns number
{
    var s = 0;
    for (var k = 0; k < L.M; k += 1)
        s += (2 * k + 1) * (L.A0[k] + alpha * L.Aa[k]) ^ 2;
    return PI * L.AR * s;
}

function spanEfficiency(L is map) returns number
{
    var s = 0;
    for (var k = 0; k < L.M; k += 1)
        s += (2 * k + 1) * L.Aa[k] ^ 2;
    return L.Aa[0] ^ 2 / s;
}

/** Local section cl at theta for body angle alpha. */
function lltLocalCl(m is map, L is map, alpha is number, th is number) returns number
{
    var s = 0;
    for (var k = 0; k < L.M; k += 1)
        s += (L.A0[k] + alpha * L.Aa[k]) * sin((2 * k + 1) * th * radian);
    return 4 * L.b * s / chordAt(m, cos(th * radian));
}

/** Highest local cl inboard of 95 % span. */
/** Zero-lift angle at eta: the root's, blending into the tip section's from Blend from % (build 166). */
function alpha0At(m is map, eta is number) returns number
{
    if (m.tipOn != 1 || m.alpha0Tip == undefined)
        return m.alpha0;
    const b = m.blendFrom;
    if (eta <= b)
        return m.alpha0;
    const u = min((eta - b) / max(1 - b, 1e-6), 1);
    return m.alpha0 + (m.alpha0Tip - m.alpha0) * u * u * (3 - 2 * u);
}

/** Section CL max at eta, blending root and tip values the same way. */
function clMaxAt(m is map, eta is number, clRoot is number, clTip is number) returns number
{
    if (m.tipOn != 1)
        return clRoot;
    const b = m.blendFrom;
    if (eta <= b)
        return clRoot;
    const u = min((eta - b) / max(1 - b, 1e-6), 1);
    return clRoot + (clTip - clRoot) * u * u * (3 - 2 * u);
}

/** Highest local cl / section CL max across the span (tip 5 % excluded), as a fraction. */
function maxLocalClRatio(m is map, L is map, alpha is number, clRoot is number, clTip is number) returns number
{
    var best = -1e9;
    for (var th in L.thetas)
    {
        const eta = cos(th * radian);
        if (eta <= 0.95)
            best = max(best, lltLocalCl(m, L, alpha, th) / clMaxAt(m, eta, clRoot, clTip));
    }
    return best;
}

/** Body angle at which the first section (inboard of 95 % span) reaches clMax. */
function stallAlpha(m is map, L is map, clRoot is number, clTip is number) returns number
{
    var best = 1e9;
    for (var th in L.thetas)
    {
        const eta = cos(th * radian);
        if (eta > 0.95)
            continue;
        const c0 = lltLocalCl(m, L, 0, th);
        const ca = lltLocalCl(m, L, 1, th) - c0;
        if (ca > 0)
            best = min(best, (clMaxAt(m, eta, clRoot, clTip) - c0) / ca);
    }
    return best;
}

/** Spanwise lift centroid as a fraction of the half span. */
/**
 * Bending moment along the half span, N m, at 21 stations (eta = j / 20 from the root), for a half-wing
 * lift halfLift distributed like the lifting line's circulation at alpha: M(y0) = integral over y > y0
 * of L'(y) (y - y0) dy. Cantilever from the root.
 */
function lltMoments(L is map, alpha is number, span is number, halfLift is number) returns array
{
    const N = 100;
    const h = span / 2;
    var lp = makeArray(N + 1);
    var tot = 0;
    // a stab flies with download: its circulation is negative along the whole span, and clipping
    // it at zero gave it no load at all (build 162: stab "deflection 0 mm, 0 MPa"). Use the
    // distribution's own sign, so the moments are the magnitude of the load whichever way it acts
    var raw = makeArray(N + 1);
    var sum = 0;
    for (var i = 0; i <= N; i += 1)
    {
        const th = acos(i / N);                       // y = h cos(theta)
        var gam = 0;
        for (var k = 0; k < L.M; k += 1)
            gam += (L.A0[k] + alpha * L.Aa[k]) * sin((2 * k + 1) * th);
        raw[i] = gam;
        sum += gam;
    }
    const sgn = sum < 0 ? -1 : 1;
    for (var i = 0; i <= N; i += 1)
    {
        lp[i] = max(sgn * raw[i], 0);
        tot += (i == 0 || i == N ? 0.5 : 1) * lp[i];
    }
    const dy = h / N;
    const scale = tot > 0 ? halfLift / (tot * dy) : 0;   // N/m per unit gam
    var out = [];
    for (var j = 0; j <= 20; j += 1)
    {
        const y0 = h * j / 20;
        var M = 0;
        for (var i = 0; i <= N; i += 1)
        {
            const y = h * i / N;
            if (y > y0)
                M += (i == N ? 0.5 : 1) * lp[i] * scale * (y - y0) * dy;
        }
        out = append(out, M);
    }
    return out;
}

function lltCentroid(L is map, alpha is number) returns number
{
    const N = 200;
    var num = 0;
    var den = 0;
    for (var i = 0; i <= N; i += 1)
    {
        const th = PI / 2 * i / N;
        const w = (i == 0 || i == N) ? 1 : ((i % 2 == 1) ? 4 : 2);
        var gam = 0;
        for (var k = 0; k < L.M; k += 1)
            gam += (L.A0[k] + alpha * L.Aa[k]) * sin((2 * k + 1) * th * radian);
        const st = sin(th * radian); // dy = (b/2) sin(theta) dtheta
        num += w * gam * cos(th * radian) * st;
        den += w * gam * st;
    }
    return den != 0 ? num / den : 0;
}

function simpsonEta(m is map, kind is number) returns number
{
    const N = 200;
    var s = 0;
    for (var i = 0; i <= N; i += 1)
    {
        const eta = i / N;
        const w = (i == 0 || i == N) ? 1 : ((i % 2 == 1) ? 4 : 2);
        const c = chordAt(m, eta);
        var v = c;
        if (kind == 1) // chord x quarter-chord x position
            v = c * (m.baseX + m.sweepTip * eta ^ m.sweepExp + (m.pivotFrac - m.align) * (c - m.c0) + (0.25 - m.pivotFrac) * c);
        else if (kind == 2) // chord x thickness
            v = c * (m.rootT + (m.tipT - m.rootT) * eta ^ m.thicknessExp);
        s += w * v;
    }
    return s / (3 * N);
}

/** Area-weighted quarter-chord position (aerodynamic centre), m aft of the wing root pivot. */
function acX(m is map) returns number
{
    return simpsonEta(m, 1) / simpsonEta(m, 0);
}

function meanThickness(m is map) returns number
{
    return simpsonEta(m, 2) / simpsonEta(m, 0);
}

/**
 * Drag of the non-lifting parts at speed V (N): mast = friction on both sides of the SUBMERGED
 * area x a 2D thickness form factor, plus Hoerner spray drag 0.24 q t^2 where it pierces the
 * surface; motor pod (scaled by its wetted fraction, plus spray on its waterline width when it
 * breaks the surface; zero when fully out) and fuselage = body-of-revolution friction x fineness form factor
 * 1 + 1.5 (d/L)^1.5 + 7 (d/L)^3 on their external wetted area. Junction/interference drag and the
 * pod's base drag (normally filled by the prop) are not included - use Other cm^2 for those.
 */
function partsDrag(ctx is map, V is number) returns map
{
    const q = 0.5 * ctx.rho * V * V;
    var mast = 0;
    var spray = 0;      // mast spray only
    var podSpray = 0;
    var body = 0;
    var podFric = 0;    // pod friction only (no spray)
    var fus = 0;
    if (ctx.mastOn && ctx.mastSub > 0)
    {
        mast = q * 2 * skinFriction(V * ctx.mastC / ctx.nu, ctx.lam) * ctx.mastFF * ctx.mastC * ctx.mastSub;
        if (ctx.mastPierces)
            spray = q * 0.24 * ctx.mastT ^ 2;
        mast += spray;
    }
    if (ctx.podOn && ctx.podFrac > 0)
    {
        // friction on the wetted part only, plus spray where the pod breaks the surface
        podFric = q * skinFriction(V * ctx.podL / ctx.nu, ctx.lam) * bodyFormFactor(ctx.podD / ctx.podL) * ctx.podSwet * ctx.podFrac;
        podSpray = q * 0.24 * ctx.podSprayT ^ 2;
        body += podFric + podSpray;
    }
    if (ctx.fusOn)
    {
        fus = q * skinFriction(V * ctx.fusL / ctx.nu, ctx.lam) * bodyFormFactor(ctx.fusD / ctx.fusL) * ctx.fusSwet;
        body += fus;
    }
    return { "mast" : mast, "spray" : spray, "podSpray" : podSpray, "body" : body,
             "pod" : podFric, "fus" : fus };
}

/**
 * Sets the ride-depth-dependent part data on a copy of ctx: wetted mast span (base to surface,
 * surface at Z = depth in the wing-pivot frame), whether the mast pierces the surface, and the
 * motor pod's wetted fraction and waterline width (from the surface height above its axis).
 */
function rideDepth(ctx is map, depth is number) returns map
{
    var c = ctx;
    c.depth = depth;
    if (c.mastOn)
    {
        c.mastSub = min(max(depth - c.mastBase, 0), c.mastH);
        c.mastPierces = depth - c.mastBase < c.mastH;
        if (c.podOn)
        {
            const hPod = depth - c.podZ;
            const rPod = c.podD / 2;
            c.podFrac = hPod >= rPod ? 1 : (hPod <= -rPod ? 0 : 1 - (acos(hPod / rPod) / radian) / PI);   // acos returns an angle (radian units), not a number
            c.podSprayT = abs(hPod) < rPod ? 2 * sqrt(rPod ^ 2 - hPod ^ 2) : 0;                        // waterline width while it breaks the surface
        }
    }
    return c;
}

// ---------------- propulsion: Wageningen B-series open water ----------------
// Oosterveld & van Oossanen (1975). KT and KQ as sums of C * J^s * (P/D)^t * EAR^u * Z^v,
// each row [C, s, t, u, v]. Identical to the B-series blade feature's tables, so the two agree.
// Fitted for P/D 0.5-1.4, EAR 0.3-1.05, Z 2-7. Open water: no pod/mast wake, no free surface.
const PROP_KT_TERMS = [
    [0.00880496, 0, 0, 0, 0], [-0.204554, 1, 0, 0, 0], [0.166351, 0, 1, 0, 0], [0.158114, 0, 2, 0, 0],
    [-0.147581, 2, 0, 1, 0], [-0.481497, 1, 1, 1, 0], [0.415437, 0, 2, 1, 0], [0.0144043, 0, 0, 0, 1],
    [-0.0530054, 2, 0, 0, 1], [0.0143481, 0, 1, 0, 1], [0.0606826, 1, 1, 0, 1], [-0.0125894, 0, 0, 1, 1],
    [0.0109689, 1, 0, 1, 1], [-0.133698, 0, 3, 0, 0], [0.00638407, 0, 6, 0, 0], [-0.00132718, 2, 6, 0, 0],
    [0.168496, 3, 0, 1, 0], [-0.0507214, 0, 0, 2, 0], [0.0854559, 2, 0, 2, 0], [-0.0504475, 3, 0, 2, 0],
    [0.010465, 1, 6, 2, 0], [-0.00648272, 2, 6, 2, 0], [-0.00841728, 0, 3, 0, 1], [0.0168424, 1, 3, 0, 1],
    [-0.00102296, 3, 3, 0, 1], [-0.0317791, 0, 3, 1, 1], [0.018604, 1, 0, 2, 1], [-0.00410798, 0, 2, 2, 1],
    [-0.000606848, 0, 0, 0, 2], [-0.0049819, 1, 0, 0, 2], [0.0025983, 2, 0, 0, 2], [-0.000560528, 3, 0, 0, 2],
    [-0.00163652, 1, 2, 0, 2], [-0.000328787, 1, 6, 0, 2], [0.000116502, 2, 6, 0, 2], [0.000690904, 0, 0, 1, 2],
    [0.00421749, 0, 3, 1, 2], [0.0000565229, 3, 6, 1, 2], [-0.00146564, 0, 3, 2, 2]
];

const PROP_KQ_TERMS = [
    [0.00379368, 0, 0, 0, 0], [0.00886523, 2, 0, 0, 0], [-0.032241, 1, 1, 0, 0], [0.00344778, 0, 2, 0, 0],
    [-0.0408811, 0, 1, 1, 0], [-0.108009, 1, 1, 1, 0], [-0.0885381, 2, 1, 1, 0], [0.188561, 0, 2, 1, 0],
    [-0.00370871, 1, 0, 0, 1], [0.00513696, 0, 1, 0, 1], [0.0209449, 1, 1, 0, 1], [0.00474319, 2, 1, 0, 1],
    [-0.00723408, 2, 0, 1, 1], [0.00438388, 1, 1, 1, 1], [-0.0269403, 0, 2, 1, 1], [0.0558082, 3, 0, 1, 0],
    [0.0161886, 0, 3, 1, 0], [0.00318086, 1, 3, 1, 0], [0.015896, 0, 0, 2, 0], [0.0471729, 1, 0, 2, 0],
    [0.0196283, 3, 0, 2, 0], [-0.0502782, 0, 1, 2, 0], [-0.030055, 3, 1, 2, 0], [0.0417122, 2, 2, 2, 0],
    [-0.0397722, 0, 3, 2, 0], [-0.00350024, 0, 6, 2, 0], [-0.0106854, 3, 0, 0, 1], [0.00110903, 3, 3, 0, 1],
    [-0.000313912, 0, 6, 0, 1], [0.0035985, 3, 0, 1, 1], [-0.00142121, 0, 6, 1, 1], [-0.00383637, 1, 0, 2, 1],
    [0.0126803, 0, 2, 2, 1], [-0.00318278, 2, 3, 2, 1], [0.00334268, 0, 6, 2, 1], [-0.00183491, 1, 1, 0, 2],
    [0.000112451, 3, 2, 0, 2], [-0.0000297228, 3, 6, 0, 2], [0.000269551, 1, 0, 1, 2], [0.00083265, 2, 0, 1, 2],
    [0.00155334, 0, 2, 1, 2], [0.000302683, 0, 6, 1, 2], [-0.0001843, 0, 0, 2, 2], [-0.000425399, 0, 3, 2, 2],
    [0.0000869243, 3, 3, 2, 2], [-0.0004659, 0, 6, 2, 2], [0.0000554194, 1, 6, 2, 2]
];

/** KT or KQ at advance ratio J for the prop in pr (pd, ear, z). */
function propCoef(terms is array, J is number, pr is map) returns number
{
    var total = 0;
    for (var t in terms)
        total += t[0] * J ^ t[1] * pr.pd ^ t[2] * pr.ear ^ t[3] * pr.z ^ t[4];
    return total;
}

/**
 * Plain-SI propulsion model from the Propulsion group: prop D m, P/D, EAR, blades, kV, pack volts
 * (cells x 3.7), gear, current limit A, winding ohm, gearbox/ESC efficiency and usable pack Wh.
 * jZero = the advance ratio where KT reaches zero (the prop's no-thrust, windmill boundary).
 */
function propModel(definition is map, rho is number) returns map
{
    var pr = { "D" : definition.propDia / meter, "pd" : definition.propPD, "ear" : definition.propEAR,
               "z" : definition.propBlades, "kv" : definition.motorKv, "vPack" : definition.cells * 3.7,
               "gear" : definition.gearRatio, "iLim" : definition.currentLimit, "R" : definition.windingR / 1000,
               "etaG" : definition.gearEff / 100, "etaE" : definition.escEff / 100, "rho" : rho };
    pr.kt = 8.27 / pr.kv;                                   // N m per motor amp (blade feature's constant)
    pr.packWh = definition.packAh * pr.vPack * definition.usable / 100;
    pr.nNoLoad = pr.kv * pr.vPack / pr.gear / 60;           // prop rev/s at no load
    var lo = 0;
    var hi = 2;
    for (var i = 0; i < 50; i += 1)
    {
        const mid = (lo + hi) / 2;
        if (propCoef(PROP_KT_TERMS, mid, pr) > 0)
            lo = mid;
        else
            hi = mid;
    }
    pr.jZero = lo;
    return pr;
}

/** Shaft torque (N m at the prop) the motor can deliver at full throttle at prop speed n rev/s. */
function propAvailTorque(pr is map, n is number) returns number
{
    const rpmMotor = n * 60 * pr.gear;
    var amps = pr.iLim;
    if (pr.R > 0)
        amps = min(pr.iLim, max(0, (pr.vPack - rpmMotor / pr.kv) / pr.R));   // back-EMF headroom / winding R
    else if (rpmMotor >= pr.kv * pr.vPack)
        amps = 0;
    return pr.kt * amps * pr.gear * pr.etaG;
}

/** Full-throttle operating point at speed V m/s: prop torque demand meets what the motor can give. */
function propFullPower(pr is map, V is number) returns map
{
    const D = pr.D;
    var lo = 1e-3;
    var hi = pr.nNoLoad;
    for (var i = 0; i < 40; i += 1)
    {
        const mid = (lo + hi) / 2;
        if (propCoef(PROP_KQ_TERMS, V / (mid * D), pr) * pr.rho * mid ^ 2 * D ^ 5 < propAvailTorque(pr, mid))
            lo = mid;
        else
            hi = mid;
    }
    const n = (lo + hi) / 2;
    const J = V / (n * D);
    return { "n" : n, "J" : J, "T" : propCoef(PROP_KT_TERMS, J, pr) * pr.rho * n ^ 2 * D ^ 4 };
}

/** Prop thrust N at speed V m/s and prop speed n rev/s. */
function propThrust(pr is map, V is number, n is number) returns number
{
    return propCoef(PROP_KT_TERMS, V / (n * pr.D), pr) * pr.rho * n ^ 2 * pr.D ^ 4;
}

/** Full-power thrust minus drag at v km/h (positive = still accelerating). */
function propGap(pr is map, pctx is map, v is number) returns number
{
    return propFullPower(pr, v / 3.6).T - trimPoint(pctx, v / 3.6).T;
}

/**
 * Steady operating point: the prop speed that makes thrust T N at speed V m/s (thrust = drag), then
 *   shaft torque Q = KQ rho n^2 D^5, prop efficiency eta0 = J KT / (2 pi KQ),
 *   motor amps Im = Q / (gear x gearbox eff x 8.27/kV), motor volts Vm = motor rpm / kV + Im R,
 *   throttle = Vm / pack V, battery amps = Vm Im / (pack V x ESC eff), Wh/km = battery W / km/h.
 * ok = false when it needs more than the current limit or more than full throttle.
 */
function propOperate(pr is map, V is number, T is number) returns map
{
    const D = pr.D;
    var lo = V / (pr.jZero * D) + 1e-6;
    var hi = max(2 * lo, 5);
    for (var i = 0; i < 30; i += 1)
    {
        if (propThrust(pr, V, hi) >= T)
            break;
        hi = 2 * hi;
    }
    for (var i = 0; i < 40; i += 1)
    {
        const mid = (lo + hi) / 2;
        if (propThrust(pr, V, mid) < T)
            lo = mid;
        else
            hi = mid;
    }
    const n = (lo + hi) / 2;
    const J = V / (n * D);
    const kq = propCoef(PROP_KQ_TERMS, J, pr);
    const Q = kq * pr.rho * n ^ 2 * D ^ 5;
    const eta0 = kq > 0 ? J * propCoef(PROP_KT_TERMS, J, pr) / (2 * PI * kq) : 0;
    const iMotor = Q / (pr.gear * pr.etaG * pr.kt);
    const vMotor = n * 60 * pr.gear / pr.kv + iMotor * pr.R;
    const throttle = vMotor / pr.vPack;
    const iBatt = vMotor * iMotor / (pr.vPack * pr.etaE);
    const pBatt = pr.vPack * iBatt;
    const whKm = pBatt / (V * 3.6);
    return { "rpm" : n * 60, "J" : J, "eta0" : eta0, "Pshaft" : 2 * PI * n * Q, "iMotor" : iMotor,
             "throttle" : throttle, "iBatt" : iBatt, "pBatt" : pBatt, "whKm" : whKm,
             "range" : pr.packWh / whKm, "tip" : PI * D * n, "ok" : iMotor <= pr.iLim && throttle <= 1 };
}

/**
 * Top speed: where full-power thrust falls to the drag at the powered ride depth. Scans from
 * take-off in 2 km/h steps to a bracket, then bisects. Returns km/h; 0 if full power cannot
 * even hold take-off speed; -1 if still accelerating at 100 km/h.
 */
function propTopSpeed(pr is map, pctx is map, vStart is number) returns number
{
    if (propGap(pr, pctx, vStart) < 0)
        return 0;
    var vLo = vStart;
    var vHi = -1;
    var v = vStart + 2;
    while (v <= 100 + 1e-9)
    {
        if (propGap(pr, pctx, v) < 0)
        {
            vHi = v;
            break;
        }
        vLo = v;
        v += 2;
    }
    if (vHi < 0)
        return -1;
    for (var i = 0; i < 15; i += 1)
    {
        const mid = (vLo + vHi) / 2;
        if (propGap(pr, pctx, mid) < 0)
            vHi = mid;
        else
            vLo = mid;
    }
    return (vLo + vHi) / 2;
}

/** Hoerner body-of-revolution form factor from diameter / length. */
function bodyFormFactor(dl is number) returns number
{
    return 1 + 1.5 * dl ^ 1.5 + 7 * dl ^ 3;
}

function formFactor(t is number) returns number
{
    return 1 + 2 * t + 60 * t ^ 4;
}

/** Flat-plate skin friction: Schlichting turbulent, with a laminar run corrected by the Blasius value. */
function skinFriction(Re is number, lam is number) returns number
{
    const turbRe = 0.455 / (log(Re) / log(10)) ^ 2.58;
    if (lam <= 0)
        return turbRe;
    const Rt = lam * Re;
    const turbRt = 0.455 / (log(Rt) / log(10)) ^ 2.58;
    return turbRe - lam * (turbRt - 1.328 / sqrt(Rt));
}

/** True if any of the given Reynolds numbers falls outside a surface's own polarRe1-polarRe2 span. */
function polarOutOfRange(m is map, res is array) returns boolean
{
    const lo = min(m.polarRe1, m.polarRe2);
    const hi = max(m.polarRe1, m.polarRe2);
    for (var Re in res)
        if (Re < lo || Re > hi)
            return true;
    return false;
}

/** Log-Re interpolation of a polar quantity between two given (Re, value) points, clamped flat outside the range. */
function polarInterp(re1 is number, y1 is number, re2 is number, y2 is number, Re is number) returns number
{
    if (re1 == re2)
        return y1;
    const lo = min(re1, re2);
    const hi = max(re1, re2);
    const ylo = re1 <= re2 ? y1 : y2;
    const yhi = re1 <= re2 ? y2 : y1;
    var t = (log(Re) - log(lo)) / (log(hi) - log(lo));
    t = max(0, min(1, t));
    return ylo + t * (yhi - ylo);
}

/**
 * Steady level flight at speed V (m/s): solve body angle for lift = weight,
 * then drag, power and the CG position that trims the pitching moment.
 */
/**
 * Trim at speed V. Under power the thrust vector is fixed to the body: it makes the angle
 * (body angle - Pod tilt) with the flow, so it carries a vertical component Tz that unloads the
 * foil and, acting at the pod's X behind the CG, pitches the nose down. Tz depends on the trim
 * and the trim on Tz, so three passes (Tz is at most a few % of the weight).
 */
function trimPoint(ctx is map, V is number) returns map
{
    var Tz = 0;
    var r = trimPass(ctx, V, 0);
    if (ctx.powered)
    {
        for (var pass = 0; pass < 3; pass += 1)
        {
            const theta = r.alpha - ctx.podTilt;
            Tz = r.D / cos(theta * radian) * sin(theta * radian);
            r = trimPass(ctx, V, Tz);
        }
        const theta = r.alpha - ctx.podTilt;
        r.thrustAngle = theta * 180 / PI;                     // deg, positive = pointing up out of the flow
        r.T = r.D / cos(theta * radian);
        r.Tz = Tz;
    }
    else
    {
        r.thrustAngle = 0;
        r.T = r.D;
        r.Tz = 0;
    }
    return r;
}

function trimPass(ctx is map, V is number, Tz is number) returns map
{
    const q = 0.5 * ctx.rho * V * V;
    const wing = ctx.wing;
    const Lw = ctx.Lw;
    const Sw = wing.area;
    const Ss = ctx.hasStab ? ctx.stab.area : 0;

    // the foil carries the weight less the thrust's vertical component
    const alpha = ((ctx.W - Tz) / q - Sw * Lw.CL0 - Ss * ctx.C1) / (Sw * Lw.CLa + Ss * ctx.C2);
    const CLw = Lw.CL0 + Lw.CLa * alpha;
    const eps = ctx.ke * CLw;

    const Rew = V * wing.mac / ctx.nu;
    const CDiw = lltInducedDrag(Lw, alpha);
    const CDprofw = wing.polarOn == 1
        ? polarInterp(wing.polarRe1, wing.polarCdmin1 + wing.polarK1 * (CLw - wing.polarClcd1) ^ 2,
                      wing.polarRe2, wing.polarCdmin2 + wing.polarK2 * (CLw - wing.polarClcd2) ^ 2, Rew)
        : skinFriction(Rew, ctx.lam) * ctx.cd0Shape_w * (1 + 0.38 * CLw * CLw);
    const CDw = CDprofw + CDiw;
    var D = q * (Sw * CDw + ctx.cdA);
    var Di = q * Sw * CDiw;
    var Mo = -q * Sw * CLw * ctx.xw + q * Sw * wing.mac * wing.cm0 + ctx.Mext;

    var CLs = 0;
    var Ds = 0;
    if (ctx.hasStab)
    {
        const stab = ctx.stab;
        const alphaS = alpha - eps; // stab sees the body angle minus wing downwash
        CLs = ctx.Ls.CL0 + ctx.Ls.CLa * alphaS;
        const Res = V * stab.mac / ctx.nu;
        const CDis = lltInducedDrag(ctx.Ls, alphaS);
        const CDprofs = stab.polarOn == 1
            ? polarInterp(stab.polarRe1, stab.polarCdmin1 + stab.polarK1 * (CLs - stab.polarClcd1) ^ 2,
                          stab.polarRe2, stab.polarCdmin2 + stab.polarK2 * (CLs - stab.polarClcd2) ^ 2, Res)
            : skinFriction(Res, ctx.lam) * ctx.cd0Shape_s * (1 + 0.38 * CLs * CLs);
        const CDs = CDprofs + CDis;
        Ds = q * Ss * CDs;
        D += Ds;
        Di += q * Ss * CDis;
        Mo += -q * Ss * CLs * ctx.xs + q * Ss * stab.mac * stab.cm0;
    }
    const parts = partsDrag(ctx, V);
    D += parts.mast + parts.body;

    // powered: thrust = D along the prop axis (Z = thrustZ, forward) against every drag force at its
    // own height. The two sum to zero, so this is a pure couple - the same about any point, so the
    // CG height does not enter. Nose-up positive: sum(D_i z_i) - D z_thrust. Wing drag and Other
    // cm^2 act at Z = 0 (the wing root pivot); the rest at the heights published by their features.
    var Mthrust = 0;
    if (ctx.powered)
    {
        var dz = Ds * ctx.stabZ + parts.fus * ctx.fusZ;
        if (ctx.mastOn)
        {
            dz += (parts.mast - parts.spray) * (ctx.mastBase + ctx.mastSub / 2) + parts.spray * ctx.depth;
            if (ctx.podOn)
                dz += parts.pod * ctx.podZ + parts.podSpray * ctx.depth;
        }
        Mthrust = dz - D * ctx.thrustZ;
        Mo += Mthrust;
        // the vertical component acts at the pod: upward behind the CG is nose-down
        Mo += -Tz * ctx.podX;
    }
    return { "Mthrust" : Mthrust, "alpha" : alpha, "CLw" : CLw, "CLs" : CLs, "Re" : Rew, "D" : D, "Di" : Di,
            "Dmast" : parts.mast, "Dbody" : parts.body, "Dspray" : parts.spray, "DpodSpray" : parts.podSpray,
            "LD" : ctx.W / D, "P" : D * V, "xcg" : -Mo / ctx.W };
}

/** Quarter-chord pitching moment of a NACA 4-digit mean line (thin-aerofoil theory). About -0.053 for a 2412. */
function momentCoefficient(m is number, p is number) returns number
{
    if (m == 0)
        return 0;
    const N = 400;
    var sum = 0;
    for (var i = 1; i <= N; i += 1)
    {
        const th = PI * (i - 0.5) / N;
        const x = 0.5 * (1 - cos(th * radian));
        const dyc = x < p ? 2 * m / p ^ 2 * (p - x) : 2 * m / (1 - p) ^ 2 * (p - x);
        sum += dyc * (cos(2 * th * radian) - cos(th * radian));
    }
    return 0.5 * sum * PI / N;
}

// ---------------------------------------------------------------------------
// Library
// ---------------------------------------------------------------------------

/**
 * Fitted XFoil polars embedded for the tabulated profiles (Ncrit 9 except E818 Re 0.5M, Ncrit 5;
 * source airfoiltools.com / UIUC, fitted with scripts/polar_summary.py). Returns undefined for
 * profiles without built-in data.
 */
function builtinPolar(profile is FoilProfile, camberFrac is number, camberPosFrac is number, thickFrac is number)
{
    if (profile == FoilProfile.NACA4)
    {
        // Parametric, so there is no single fixed polar. alpha0/cm0 come from the SAME exact
        // thin-aerofoil integral used everywhere else in this file (zeroLiftAngle/momentCoefficient)
        // - not a fit, exact for any camber and camber position. Everything else (lift slope, CLmax,
        // drag bucket) is a linear fit in (thickness, camber) against 4 real XFoil polars fetched
        // and fit with polar_summary.py: NACA 0008, 0018 (thickness range, symmetric) and NACA 2412,
        // 4412 (camber range, fixed 12% thick) - see the developer skill's pitfalls.md for why CLcd
        // is anchored through zero at zero camber (aerodynamic symmetry) rather than fit from the
        // thickness pair, which gave a physically impossible negative value at one data point.
        // Coarse by construction: only 4 anchor points for a 2D surface. Clamped to the same limits
        // as the Polar summary fields, since linear extrapolation misbehaves at the extremes (e.g.
        // lift slope exceeds 7.5/rad above ~20% thickness).
        const dt = thickFrac - 0.12;
        const m = camberFrac;
        return { "alpha0Deg" : zeroLiftAngle(camberFrac, camberPosFrac) / degree, "cm0" : momentCoefficient(camberFrac, camberPosFrac),
                 "cla" : clamp01(6.898 + 10.24 * dt - 13.25 * m, 4, 7.5),
                 "re1M" : 0.1, "clmax1" : clamp01(0.916 + 3.79 * dt + 7.05 * m, 0.6, 1.8),
                 "cdmin1" : clamp01(0.0133 + 0.082 * dt + 0.16 * m, 0.004, 0.03),
                 "clcd1" : clamp01(14.55 * m, -0.3, 1.0), "k1" : clamp01(0.0245 - 0.185 * dt + 0.075 * m, 0.005, 0.05),
                 "re2M" : 1.0, "clmax2" : clamp01(1.205 + 1.04 * dt + 4.45 * m, 0.6, 1.8),
                 "cdmin2" : clamp01(0.00336 + 0.059 * dt + 0.03 * m, 0.004, 0.03),
                 "clcd2" : clamp01(13.25 * m, -0.3, 1.0), "k2" : clamp01(0.00474 + 0.026 * dt + 0.005 * m, 0.005, 0.05) };
    }
    if (profile == FoilProfile.E817)
        return { "alpha0Deg" : -2.96, "cla" : 6.471, "cm0" : -0.1069,
                 "re1M" : 0.2, "clmax1" : 1.062, "cdmin1" : 0.0177, "clcd1" : 0.615, "k1" : 0.0021,
                 "re2M" : 1.0, "clmax2" : 1.147, "cdmin2" : 0.0051, "clcd2" : 0.294, "k2" : 0.0164 };
    if (profile == FoilProfile.E818)
        return { "alpha0Deg" : -2.41, "cla" : 6.258, "cm0" : -0.0914,
                 "re1M" : 0.1, "clmax1" : 0.889, "cdmin1" : 0.0106, "clcd1" : 0.698, "k1" : 0.012,
                 "re2M" : 0.5, "clmax2" : 1.025, "cdmin2" : 0.0062, "clcd2" : 0.312, "k2" : 0.0327 };
    if (profile == FoilProfile.NACA63412)
        return { "alpha0Deg" : -2.98, "cla" : 6.194, "cm0" : -0.0752,
                 "re1M" : 0.2, "clmax1" : 0.99, "cdmin1" : 0.0104, "clcd1" : 0.429, "k1" : 0.0154,
                 "re2M" : 0.5, "clmax2" : 1.311, "cdmin2" : 0.0064, "clcd2" : 0.34, "k2" : 0.0154 };
    if (profile == FoilProfile.CLARKY)   // airfoiltools XFoil xf-clarky-il-200000 / -1000000, Ncrit 9, fit with polar_summary.py
    {
        // fitted at the table's 11.7 %; the section is scaled whole with its thickness (build 168), so
        // the camber-driven numbers (zero-lift angle, moment, bucket centre) scale with it too
        const k = thickFrac / 0.1171;
        return { "alpha0Deg" : -3.56 * k, "cla" : 6.348, "cm0" : -0.0848 * k,
                 "re1M" : 0.2, "clmax1" : 1.397, "cdmin1" : 0.0099, "clcd1" : 0.572 * k, "k1" : 0.0207,
                 "re2M" : 1.0, "clmax2" : 1.524, "cdmin2" : 0.0061, "clcd2" : 0.487 * k, "k2" : 0.0099 };
    }
    return undefined;
}

/** Clamp x to [lo, hi]. */
function clamp01(x is number, lo is number, hi is number) returns number
{
    return min(max(x, lo), hi);
}

/**
 * Section polar data as one map (alpha0Deg, cla, cm0, re1M, clmax1, cdmin1, clcd1, k1, re2M, clmax2,
 * cdmin2, clcd2, k2), from the dialog (Polar summary) or the built-in table (Built-in), or
 * undefined for Analytic. Each dialog parameter is declared exactly once in the precondition -
 * Onshape rejects a parameter declared in more than one branch, so per-profile values live here
 * in code, not as per-branch parameter defaults.
 */
function resolvePolar(definition is map)
{
    if (definition.polarSource == PolarSource.BUILTIN)
    {
        const b = builtinPolar(definition.profile, definition.camber / 100, definition.camberPos / 100, definition.rootThickness / 100);
        if (b == undefined)
            throw regenError("Built-in polar data exists only for NACA 4-digit, E817, E818, NACA 63-412 and Clark Y - choose one of those Profiles, or set Section data to Polar summary or Analytic", ["polarSource"]);
        return b;
    }
    if (definition.polarSource == PolarSource.POLAR)
        return { "alpha0Deg" : definition.polarAlpha0 / degree, "cla" : definition.polarCla, "cm0" : definition.polarCm0,
                 "re1M" : definition.polarRe1, "clmax1" : definition.polarClmax1, "cdmin1" : definition.polarCdmin1,
                 "clcd1" : definition.polarClcd1, "k1" : definition.polarK1,
                 "re2M" : definition.polarRe2, "clmax2" : definition.polarClmax2, "cdmin2" : definition.polarCdmin2,
                 "clcd2" : definition.polarClcd2, "k2" : definition.polarK2 };
    return undefined;
}

/**
 * Shared foil geometry: solves the planform, lofts the half foil through streamwise
 * sections, mirrors and joins. The root pivot is placed at `base`.
 * When the definition has stabLink == LINKED, area, aspect ratio, thickness and
 * incidence are first overridden from the wing variables before solving.
 * Returns the planform metrics as a map.
 */
/** Span and root chord for a chord-shape ratio: area/AR mode solves them (developed area iterates on the droop), span/chord mode reads them. */
/**
 * Span and root chord for a planform law. plCap is the law with capEta unset; planCapLen is the
 * plan-rounding cap length (0 for none): capEta depends on the span, which in area mode depends
 * on the area only (projected) or is iterated (developed), so the law is completed here and
 * returned as pl.
 */
function solvePlanform(definition is map, plCap is map, planCapLen is ValueWithUnits) returns map
{
    var pl = plCap;
    var span;
    var c0;
    if (definition.planformMode == PlanformMode.AREA_AR)
    {
        const target = definition.targetArea * centimeter * centimeter;
        var sProj = target;
        span = sqrt(definition.aspectRatio * sProj);
        pl.capEta = planCapLen > 0 * meter ? max(1 - planCapLen / (span / 2), 0.5) : 1;
        if (definition.areaDefinition == AreaDefinition.DEVELOPED)
        {
            // developed/projected ratio depends on span (drop is absolute), so iterate
            for (var k = 0; k < 12; k += 1)
            {
                const b = sqrt(definition.aspectRatio * sProj);
                pl.capEta = planCapLen > 0 * meter ? max(1 - planCapLen / (b / 2), 0.5) : 1;
                const r = shapeIntegral(pl, 2, definition.tipDrop / (b / 2), tan(definition.rootDihedral)) / shapeIntegral(pl, 0, 0, 0);
                sProj = target / r;
            }
            span = sqrt(definition.aspectRatio * sProj);
            pl.capEta = planCapLen > 0 * meter ? max(1 - planCapLen / (span / 2), 0.5) : 1;
        }
        c0 = sProj / (span * shapeIntegral(pl, 0, 0, 0));
    }
    else
    {
        span = definition.span;
        c0 = definition.rootChord;
        pl.capEta = planCapLen > 0 * meter ? max(1 - planCapLen / (span / 2), 0.5) : 1;
    }
    return { "G" : shapeIntegral(pl, 0, 0, 0), "G2" : shapeIntegral(pl, 1, 0, 0), "span" : span, "c0" : c0, "pl" : pl };
}

/** Names every solid the feature has left in the Part Studio (the sketch and tool bodies are gone by then). */
function nameSolids(context is Context, id is Id, name is string)
{
    setProperty(context, { "entities" : qBodyType(qCreatedBy(id, EntityType.BODY), BodyType.SOLID),
                "propertyType" : PropertyType.NAME, "value" : name });
}

function buildFoil(context is Context, id is Id, rawDefinition is map, base is Vector) returns map
{
    var definition = rawDefinition;
    if (definition.stabLink != undefined && definition.stabLink == StabLink.LINKED)
    {
        var wingArea;
        var wingAR;
        var wingRootT;
        var wingTipT;
        var wingInc;
        try silent
        {
            wingArea = getVariable(context, "foilWingArea");
            wingAR = getVariable(context, "foilWingAR");
            wingRootT = getVariable(context, "foilWingRootThickness");
            wingTipT = getVariable(context, "foilWingTipThickness");
            wingInc = getVariable(context, "foilWingIncidence");
        }
        if (wingArea != undefined && wingAR != undefined && wingRootT != undefined
            && wingTipT != undefined && wingInc != undefined)
        {
            definition.targetArea = wingArea / (centimeter * centimeter) * definition.linkAreaRatio;
            definition.aspectRatio = wingAR + definition.linkAROffset;
            definition.rootThickness = wingRootT + definition.linkThicknessOffset;
            definition.tipThickness = wingTipT + definition.linkThicknessOffset;
            definition.incidence = wingInc - definition.linkDecalage;
            definition.planformMode = PlanformMode.AREA_AR;
            definition.areaDefinition = AreaDefinition.PROJECTED;
        }
    }
    // a stab's tabulated profile may be mounted inverted (its own field); the wing never is
    definition.invertSection = definition.invertSection == true && definition.profile != FoilProfile.NACA4;
    // ================= planform solve =================
    const n = definition.chordShape == ChordShape.SUPERELLIPSE ? definition.superN : 2;
    const ratioIn = definition.chordShape == ChordShape.SUPERELLIPSE ? definition.endRatio : definition.tipRatio;
    const shape = definition.chordShape;
    const isDouble = shape == ChordShape.DOUBLE;
    const brk = isDouble ? definition.breakPct / 100 : 0.3;
    const mid = isDouble ? definition.midRatio : 0.6;
    // blend half-width, kept inside (0, brk) and (brk, 1) so the curve never reaches root or tip
    const blend = isDouble ? min(min(definition.blendPct / 100, 0.95 * brk), 0.95 * (1 - brk)) : 0;
    if (isDouble && ratioIn > mid)
        throw regenError("Tip ratio (" ~ fmt(ratioIn, 2) ~ ") exceeds Mid ratio (" ~ fmt(mid, 2) ~ "): the outer taper would widen towards the tip", ["tipRatio", "midRatio"]);
    const capOn = definition.tipCap != TipCap.FLAT;
    const planRound = definition.tipCap == TipCap.ROUND_PLAN;
    const capLen = capOn ? definition.capLength : 0 * meter;
    // root tail (stab only): a fraction of c0, so it has to be re-derived from the mm value as c0
    // moves through the solve; the solve loop below does that
    const tailOn = definition.rootTailOn == true && definition.rootTailLen != undefined;
    const tailEta = tailOn ? definition.rootTailSpan / 100 : 0.3;
    const dropFrom = definition.dropFrom == undefined ? 0 : definition.dropFrom / 100;
    const dropTo = definition.dropTo == undefined ? 1 : max(definition.dropTo / 100, dropFrom + 0.05);
    const dl = { "dropExp" : definition.dropExp, "dropFrom" : dropFrom, "dropTo" : dropTo, "dropSmooth" : definition.dropLaw == DropLaw.SCURVE ? 1 : 0 };
    const bumpOn = definition.bumpOn == true && definition.bumpAmp != undefined;
    const bumpKeys = { "bumpOn" : bumpOn ? 1 : 0, "bumpAmp" : bumpOn ? definition.bumpAmp / meter : 0, "bumpPitch" : bumpOn ? definition.bumpPitch / meter : 0.07,
                       "bumpFrom" : bumpOn ? definition.bumpFrom / 100 : 0, "bumpTo" : bumpOn ? definition.bumpTo / 100 : 0 };

    // Min tip: widen the tip chord (raise the ratio) until the section at the cap start reaches
    // Min tip mm. The root chord moves a little with the ratio in area mode, so iterate.
    const minTipOn = definition.minTipOn == true && definition.minTip != undefined;
    var ratio = ratioIn;
    var tipRaised = false;
    var G;
    var G2;
    var span;
    var c0;
    var pl;
    var tail = 0;
    for (var pass = 0; pass < 8; pass += 1)
    {
        const ps = solvePlanform(definition, { "shape" : shape, "ratio" : ratio, "n" : n, "brk" : brk, "mid" : mid, "blend" : blend, "capEnd" : definition.capEnd / 100, "dropFrom" : dropFrom, "dropTo" : dropTo, "dropSmooth" : dl.dropSmooth, "dropExp" : definition.dropExp,
                                              "tail" : tail, "tailEta" : tailEta },
                                 planRound ? capLen : 0 * meter);
        G = ps.G;
        G2 = ps.G2;
        span = ps.span;
        c0 = ps.c0;
        pl = mergeMaps(ps.pl, bumpKeys);
        var settled = true;
        if (tailOn)
        {
            // the tail is Tail length in mm: as a fraction of c0 it changes as c0 changes, so pass again
            const tailNew = definition.rootTailLen / c0;
            settled = abs(tailNew - tail) < 1e-4;
            tail = tailNew;
        }
        if (!minTipOn && settled)
            break;
        if (!minTipOn)
            continue;
        const tipChord = c0 * chordFactor(pl, pl.capEta);   // the last full section before the cap
        const need = definition.minTip / (definition.tipThickness / 100);
        if (tipChord >= need - 1e-6 * meter)
        {
            // thick enough: only ever RAISE the ratio, never shrink it back down to the minimum
            // (build 145-146 did, while the root tail was still settling: 0.21 became 0.128)
            if (settled)
                break;
            continue;
        }
        ratio = min(isDouble ? mid : 0.95, ratio * need / tipChord); // double taper: never wider than the break
        tipRaised = true;
    }

    const h = span / 2;
    const dropK = definition.tipDrop / h;
    const areaProj = span * c0 * G;
    const areaDev = span * c0 * shapeIntegral(pl, 2, dropK, tan(definition.rootDihedral));
    const mac = span * c0 * c0 * G2 / areaProj;
    const aspect = span ^ 2 / areaProj;
    const tipChord = c0 * chordFactor(pl, pl.capEta);

    // ================= validation =================
    if (definition.teThickness > 0.03 * c0)
        throw regenError("Trailing edge thickness exceeds 3% of the root chord (" ~ toString(round(c0 / millimeter)) ~ " mm)",
            ["teThickness"]);
    if (capOn && capLen > 0.3 * h)
        throw regenError("Tip cap is longer than 30% of the half span", ["capLength"]);

    // ================= winglet =================
    // the outer (1 - wEta) of the developed half span bends through wAng on radius wR; the chord
    // law is unchanged along it, so the planform solve above already includes the winglet's area
    const wingletOn = definition.winglet != undefined && definition.winglet != Winglet.OFF;
    var wEta = 1;
    var wSign = 0;
    var wAng = 0 * degree;
    var wR = 0 * meter;
    var wRClamped = false;
    var wS0 = h;
    var wZ0 = 0 * meter;
    var wPhi0 = 0 * degree;
    if (wingletOn)
    {
        wSign = definition.winglet == Winglet.UP ? 1 : -1;
        wAng = definition.wingletAngle;
        const target = definition.wingletArea * centimeter * centimeter;
        var lo = 0.3;
        var hi = 1;
        for (var it = 0; it < 40; it += 1)
        {
            const em = 0.5 * (lo + hi);
            if (shapeIntegralFrom(pl, em) * c0 * h > target)
                lo = em;
            else
                hi = em;
        }
        wEta = 0.5 * (lo + hi);
        if (wEta < 0.3 + 1e-4)
            throw regenError("Winglet area " ~ fmt(definition.wingletArea, 1) ~ " cm² would start the bend inside 30 % of the half span - reduce it (the outer 70 % holds " ~
                fmt(shapeIntegralFrom(pl, 0.3) * c0 * h / (centimeter * centimeter), 1) ~ " cm²)", ["wingletArea"]);
        wS0 = wEta * h;
        const ps0 = dropSlope(dl, wEta);
        const f0 = dropShape(dl, wEta);
        wZ0 = -definition.tipDrop * f0 + h * tan(definition.rootDihedral) * (wEta - f0);
        wPhi0 = atan((-definition.tipDrop * ps0 + h * tan(definition.rootDihedral) * (1 - ps0)) / h);
        wR = definition.wingletRadius;
        const wLen = h - wS0;
        if (wR * (wAng / radian) > wLen)
        {
            wR = wLen / (wAng / radian);
            wRClamped = true;
        }
    }

    // ================= stations =================
    const secDef = sectionDefFromDefinition(definition);
    const capStart = h - capLen;
    // one list, shared with the mold's parting (foilStationEtas): the same map keys the model publishes
    const stMap = mergeMaps(pl, { "span" : span / meter, "stations" : definition.stations, "tail" : tail, "tailEta" : tailEta,
                                  "tipOn" : secDef.tipOn ? 1 : 0, "blendFrom" : secDef.blendFrom,
                                  "wingletOn" : wingletOn ? 1 : 0, "wingletEta" : wEta, "wingletR" : wR / meter, "wingletAngle" : wAng / radian,
                                  "capOn" : capOn ? 1 : 0, "capLength" : capLen / meter });
    var stations = [];
    for (var e in foilStationEtas(stMap))
        stations = append(stations, e * h);

    // ================= sections =================
    const pivotFrac = pivotFraction(definition.pivot);
    var profiles = [];
    var sketchBodies = [];
    var rootPts = [];
    for (var i = 0; i < size(stations); i += 1)
    {
        const y = stations[i];
        const eta = min(max(y / h, 0), 1);

        const chord = c0 * chordFactor(pl, eta);
        const tailAdd = c0 * tailFactor(pl, eta);           // root tail: all of it behind the trailing edge

        var thick = (definition.rootThickness + (definition.tipThickness - definition.rootThickness) * eta ^ definition.thicknessExp) / 100;
        thick = thick * (chord - tailAdd) / chord;           // keep the thickness in mm; the tail only stretches the section aft
        if (capOn && y > capStart)
        {
            const d = min((y - capStart) / capLen, 1);
            const endFrac = definition.capEnd / 100;
            // Rounded + plan: the chord already shrinks along the same curve, so divide it back out;
            // the end face is then Cap end % of the cap-start thickness, not Cap end % squared
            // (build 150: 20 % of 20 % left a 0.06 mm end that the mold could not cut)
            thick = thick * (endFrac + (1 - endFrac) * sqrt(max(1 - d * d, 0))) / (planRound ? capPlanFactor(pl, eta) : 1);
        }

        const twist = definition.incidence - definition.washout * eta ^ definition.washoutExp;
        // alignment line follows the sweep curve; pivot shifted so the root pivot stays at the origin
        // alignment line follows the sweep curve on the chord before tip rounding; the rounding's
        // shrink is centred on the mid-chord so the leading and trailing corners both round, and
        // the root tail is all aft (build 146 / 145)
        const capF = capPlanFactor(pl, eta);
        const chordBase = (chord - tailAdd) / capF;
        const alignShift = (pivotFrac - definition.planformAlign / 100) * (chordBase - c0) + pivotFrac * tailAdd + (0.5 - pivotFrac) * (chordBase - (chord - tailAdd));
        const xOff = definition.sweepTip * eta ^ definition.sweepExp + alignShift;
        const fDrop = dropShape(dl, eta);
        var zOff = -definition.tipDrop * fDrop + h * tan(definition.rootDihedral) * (eta - fDrop);
        var yPos = y;
        var phi = 0 * degree;                      // section plane rotation about X (0 = vertical plane)
        if (wingletOn && y > wS0)
        {
            const wp = wingletPath(y, wS0, wZ0, wPhi0, wSign, wAng, wR);
            yPos = wp.y;
            zOff = wp.z;
            phi = wp.phi;
        }

        // leading-edge bumps: the LE moves forward by the bump, the TE stays, thickness in mm stays
        const bump = bumpOffset(pl, eta, h);
        const chordB = chord + bump;
        thick = thick * chord / chordB;
        const xOffB = xOff - (1 - pivotFrac) * bump;
        const teLocal = min(definition.teThickness, 0.03 * chordB);
        const section = buildSectionAt(secDef, thick, teLocal / chordB, definition.pointsPerSurface, sectionWeightAt(secDef, eta));
        const pts = placeSection(section, chordB, pivotFrac, cos(twist), sin(twist));
        if (i == 0)
            rootPts = pts;

        const sketchId = id + ("section" ~ i);
        var sketch = newSketchOnPlane(context, sketchId, {
                    "sketchPlane" : plane(base + vector(xOffB, yPos, zOff), vector(0, -cos(phi), -sin(phi)), X_DIRECTION)
                });
        skFitSpline(sketch, "surface", { "points" : pts });
        skLineSegment(sketch, "trailingEdge", { "start" : pts[0], "end" : pts[size(pts) - 1] });
        skSolve(sketch);

        profiles = append(profiles, qSketchRegion(sketchId));
        sketchBodies = append(sketchBodies, qCreatedBy(sketchId, EntityType.BODY));
    }

    // winglet height above the bend start and the projected span, for the notice and the analysis
    var wHeight = 0 * meter;
    var spanProj = span;
    var wAreaProj = 0 * meter * meter;             // projected area of one winglet
    if (wingletOn)
    {
        const tipP = wingletPath(h, wS0, wZ0, wPhi0, wSign, wAng, wR);
        wHeight = abs(tipP.z - wZ0);
        spanProj = 2 * tipP.y;
        const NW = 40;
        for (var q = 0; q < NW; q += 1)
        {
            const sm = wS0 + (h - wS0) * (q + 0.5) / NW;
            const wp = wingletPath(sm, wS0, wZ0, wPhi0, wSign, wAng, wR);
            wAreaProj += c0 * chordFactor(pl, sm / h) * cos(wp.phi) * (h - wS0) / NW;
        }
    }

    // ================= solid =================
    opLoft(context, id + "loft", { "profileSubqueries" : profiles });
    opDeleteBodies(context, id + "deleteSections", { "entities" : qUnion(sketchBodies) });

    if (definition.mirror)
    {
        opPattern(context, id + "mirror", {
                    "entities" : qCreatedBy(id + "loft", EntityType.BODY),
                    "transforms" : [mirrorAcross(plane(WORLD_ORIGIN, Y_DIRECTION))],
                    "instanceNames" : ["left"]
                });
        opBoolean(context, id + "join", {
                    "tools" : qUnion([qCreatedBy(id + "loft", EntityType.BODY), qCreatedBy(id + "mirror", EntityType.BODY)]),
                    "operationType" : BooleanOperationType.UNION
                });
    }

    // ================= analysis model (SI numbers) =================
    const solidQ = qBodyType(qCreatedBy(id, EntityType.BODY), BodyType.SOLID);
    var wetted = evArea(context, { "entities" : qOwnedByBody(solidQ, EntityType.FACE) });
    if (!definition.mirror)
        wetted = wetted * 2;
    const thinAero = sectionAlpha0Cm0(definition, definition.rootThickness / 100);
    const alpha0Thin = thinAero[0];
    const cm0Thin = thinAero[1];
    var pd = resolvePolar(definition); // undefined for Analytic
    const polarOn = pd != undefined;
    if (polarOn && definition.invertSection == true)
    {
        // section upside down: zero-lift angle, moment and the drag-bucket centre change sign
        pd.alpha0Deg = -pd.alpha0Deg;
        pd.cm0 = -pd.cm0;
        pd.clcd1 = -pd.clcd1;
        pd.clcd2 = -pd.clcd2;
    }
    const alpha0 = polarOn ? pd.alpha0Deg * degree : alpha0Thin;
    const cm0Root = polarOn ? pd.cm0 : cm0Thin;
    const claSection = polarOn ? pd.cla : 2 * PI * 0.95;
    // tip section (build 166): its own zero-lift angle and moment, its own built-in polar when the
    // root has one, and the share of the area it covers (for blending the drag bucket and cm0)
    var alpha0Tip = alpha0;
    var cm0Tip = cm0Root;
    var pdTip = pd;
    var tipAreaFrac = 0;
    if (secDef.tipOn)
    {
        const tipAero = sectionAlpha0Cm0(tipSectionDef(secDef), definition.tipThickness / 100);
        alpha0Tip = tipAero[0];
        cm0Tip = tipAero[1];
        if (definition.polarSource == PolarSource.BUILTIN)
        {
            pdTip = builtinPolar(secDef.tipProfile, secDef.tipCamber / 100, secDef.tipCamberPos / 100, definition.tipThickness / 100);
            if (pdTip == undefined)
                throw regenError("Built-in polar data exists only for NACA 4-digit, E817, E818, NACA 63-412 and Clark Y - choose one of those as Tip profile, or set Section data to Polar summary or Analytic", ["tipProfile"]);
            if (definition.invertSection == true)
            {
                pdTip.alpha0Deg = -pdTip.alpha0Deg;
                pdTip.cm0 = -pdTip.cm0;
                pdTip.clcd1 = -pdTip.clcd1;
                pdTip.clcd2 = -pdTip.clcd2;
            }
        }
        if (polarOn)
        {
            alpha0Tip = pdTip.alpha0Deg * degree;
            cm0Tip = pdTip.cm0;
        }
        var num = 0;
        var den = 0;
        for (var i = 0; i <= 200; i += 1)
        {
            const e = i / 200;
            const wS = (i == 0 || i == 200) ? 1 : ((i % 2 == 1) ? 4 : 2);
            const g = chordFactor(pl, e);
            num += wS * g * sectionWeightAt(secDef, e);
            den += wS * g;
        }
        tipAreaFrac = den > 0 ? num / den : 0;
    }
    const cm0 = cm0Root * (1 - tipAreaFrac) + cm0Tip * tipAreaFrac;
    const fT = tipAreaFrac;
    const model = {
            "span" : span / meter, "stations" : definition.stations, "c0" : c0 / meter, "shape" : shape, "ratio" : ratio, "n" : n, "brk" : brk, "mid" : mid, "blend" : blend, "capEta" : pl.capEta, "planRound" : planRound ? 1 : 0, "tail" : tail, "tailEta" : tailEta, "tipRaised" : tipRaised ? 1 : 0,
            "area" : areaProj / (meter * meter), "mac" : mac / meter,
            "incidence" : definition.incidence / radian, "washout" : definition.washout / radian, "washoutExp" : definition.washoutExp,
            "alpha0" : alpha0 / radian, "cm0" : cm0, "claSection" : claSection,
            "tipOn" : secDef.tipOn ? 1 : 0, "tipProfileName" : enumStr_profile(secDef.tipProfile), "tipCamber" : secDef.tipCamber, "tipCamberPos" : secDef.tipCamberPos, "blendFrom" : secDef.blendFrom,
            "alpha0Tip" : alpha0Tip / radian, "cm0Tip" : cm0Tip, "tipAreaFrac" : fT,
            "polarClmax1Tip" : polarOn ? pdTip.clmax1 : 0, "polarClmax2Tip" : polarOn ? pdTip.clmax2 : 0,
            "rootT" : definition.rootThickness / 100, "tipT" : definition.tipThickness / 100, "thicknessExp" : definition.thicknessExp,
            "sweepTip" : definition.sweepTip / meter, "sweepExp" : definition.sweepExp, "align" : definition.planformAlign / 100,
            "pivotFrac" : pivotFrac, "baseX" : base[0] / meter, "baseZ" : base[2] / meter,
            "profileName" : enumStr_profile(definition.profile), "camber" : definition.camber, "camberPos" : definition.camberPos, "mirror" : definition.mirror ? 1 : 0,
            "inverted" : definition.invertSection == true ? 1 : 0, "teThick" : definition.teThickness / meter,
            "wetted" : wetted / (meter * meter),
            "capOn" : capOn ? 1 : 0, "capLength" : capLen / meter, "capEnd" : definition.capEnd / 100,
            "tipDrop" : definition.tipDrop / meter, "dropExp" : definition.dropExp, "dropFrom" : dropFrom, "dropTo" : dropTo, "dropSmooth" : dl.dropSmooth, "rootDihedral" : definition.rootDihedral / radian,
            "wingletOn" : wingletOn ? 1 : 0, "wingletSign" : wSign, "wingletEta" : wEta, "wingletAngle" : wAng / radian, "wingletR" : wR / meter,
            "bumpOn" : bumpOn ? 1 : 0, "bumpAmp" : bumpKeys.bumpAmp, "bumpPitch" : bumpKeys.bumpPitch, "bumpFrom" : bumpKeys.bumpFrom, "bumpTo" : bumpKeys.bumpTo,
            "wingletHeight" : wHeight / meter, "spanProj" : spanProj / meter,
            "polarOn" : polarOn ? 1 : 0,
            "polarRe1" : (polarOn ? pd.re1M : 0) * 1e6, "polarClmax1" : polarOn ? pd.clmax1 : 0,
            "polarCdmin1" : polarOn ? pd.cdmin1 * (1 - fT) + pdTip.cdmin1 * fT : 0, "polarClcd1" : polarOn ? pd.clcd1 * (1 - fT) + pdTip.clcd1 * fT : 0, "polarK1" : polarOn ? pd.k1 * (1 - fT) + pdTip.k1 * fT : 0,
            "polarRe2" : (polarOn ? pd.re2M : 0) * 1e6, "polarClmax2" : polarOn ? pd.clmax2 : 0,
            "polarCdmin2" : polarOn ? pd.cdmin2 * (1 - fT) + pdTip.cdmin2 * fT : 0, "polarClcd2" : polarOn ? pd.clcd2 * (1 - fT) + pdTip.clcd2 * fT : 0, "polarK2" : polarOn ? pd.k2 * (1 - fT) + pdTip.k2 * fT : 0
        };

    return {
            "span" : span, "rootChord" : c0 * (1 + tail), "tipChord" : tipChord, "ratioUsed" : ratio, "tipRaised" : tipRaised,
            "areaProj" : areaProj, "areaDev" : areaDev, "mac" : mac, "aspect" : aspect,
            "wingletOn" : wingletOn, "wingletHeight" : wHeight, "spanProj" : spanProj, "wingletAreaProj" : wAreaProj, "wingletRClamped" : wRClamped, "wingletR" : wR,
            "rootThickness" : definition.rootThickness, "tipThickness" : definition.tipThickness,
            "incidence" : definition.incidence, "alpha0" : alpha0, "model" : model,
            "rootPts" : rootPts   // root section outline (X, Z) relative to the root pivot, as built
        };
}

/** One-line planform summary for the feature notice. */
function planformSummary(definition is map, m is map) returns string
{
    const cm2 = centimeter * centimeter;
    var msg = "Area " ~ toString(round(m.areaProj / cm2)) ~ " cm² projected";
    if (abs(definition.tipDrop) > 0 * meter || abs(definition.rootDihedral) > 0 * degree)
        msg = msg ~ " (" ~ toString(round(m.areaDev / cm2)) ~ " developed)";
    msg = msg ~ " · span " ~ toString(round(m.span / millimeter)) ~ " mm" ~
        " · AR " ~ toString(round(m.aspect * 100) / 100) ~
        " · root " ~ toString(round(m.rootChord / millimeter)) ~ " mm" ~
        (definition.chordShape == ChordShape.SUPERELLIPSE ? " · end " : " · tip ") ~ toString(round(m.tipChord / millimeter)) ~ " mm" ~
        " · MAC " ~ toString(round(m.mac / millimeter)) ~ " mm";
    if (m.tipRaised)
        msg = msg ~ " · " ~ (definition.chordShape == ChordShape.SUPERELLIPSE ? "End ratio" : "Tip ratio") ~ " raised to " ~ fmt(m.ratioUsed, 3) ~
            " for a " ~ fmt(definition.minTip / millimeter, 1) ~ " mm tip" ~ (m.ratioUsed >= 0.95 ? " (at the 0.95 limit - still thinner than Min tip mm)" : "");
    if (m.wingletOn)
        msg = msg ~ " | winglets " ~ (definition.winglet == Winglet.UP ? "up" : "down") ~ " " ~ fmt(definition.wingletArea, 1) ~ " cm² each (" ~
            fmt(m.wingletAreaProj / cm2, 1) ~ " projected), " ~ toString(round(m.wingletHeight / millimeter)) ~ " mm high at " ~ fmt(definition.wingletAngle / degree, 0) ~
            "°, projected span " ~ toString(round(m.spanProj / millimeter)) ~ " mm" ~
            (m.wingletRClamped ? " - bend radius reduced to " ~ fmt(m.wingletR / millimeter, 0) ~ " mm so the arc fits the winglet" : "");
    if (definition.tipProfile != undefined && definition.tipProfile != TipProfile.SAME)
        msg = msg ~ " · tip section " ~ enumStr_tipProfile(definition.tipProfile) ~ (definition.tipProfile == TipProfile.NACA4 ? " " ~ fmt(definition.tipCamber, 1) ~ "% camber" : "") ~
            " from " ~ fmt(definition.blendFrom, 0) ~ "% span";
    if (!definition.mirror)
        msg = msg ~ " (full-span values, half built)";
    return msg;
}

/**
 * Zero-lift angle of a NACA 4-digit mean line from thin-aerofoil theory:
 * alpha0 = -(1/pi) * integral over theta of dyc/dx (cos(theta) - 1).
 * Negative for positive camber (e.g. about -2.1 deg for a 2412).
 */
function zeroLiftAngle(m is number, p is number) returns ValueWithUnits
{
    if (m == 0)
        return 0 * degree;
    const N = 400;
    var sum = 0;
    for (var i = 1; i <= N; i += 1)
    {
        const th = PI * (i - 0.5) / N;
        const c = cos(th * radian);
        const x = 0.5 * (1 - c);
        const dyc = x < p ? 2 * m / p ^ 2 * (p - x) : 2 * m / (1 - p) ^ 2 * (p - x);
        sum += dyc * (c - 1);
    }
    return -(sum * PI / N) / PI * radian;
}


function pivotFraction(pivot is FoilPivot) returns number
{
    if (pivot == FoilPivot.LEADING_EDGE)
        return 0;
    if (pivot == FoilPivot.TRAILING_EDGE)
        return 1;
    return 0.25;
}

/**
 * Normalised chord g(eta), eta = 2y/b in [0, 1], g(0) = 1, from a planform law map pl (the same
 * keys live in the published model maps, so a model map can be passed directly):
 *   shape (ChordShape), ratio (end/tip ratio), n (superellipse exponent),
 *   brk, mid, blend (double taper: break eta, chord ratio at the break, blend half-width in eta),
 *   capEta, capEnd (plan-view tip rounding: chord shrinks along a quarter-ellipse from eta = capEta
 *   to capEnd x the cap-start chord at eta = 1; capEta = 1 means none),
 *   tail, tailEta (root tail: the chord grows by tail x c0 at the centreline, fading to nothing at
 *   eta = tailEta with a smoothstep, flat at both ends; tail = 0 means none). g(0) = 1 + tail, so
 *   c0 stays the base root chord and the tail is all trailing-edge extension (see tailFactor).
 * Superellipse is truncated at eta = 1 where g = ratio. Double taper: 1 -> mid over [0, brk], then
 * mid -> ratio over [brk, 1]; within blend of the break the two lines are joined by a quadratic
 * Bezier with its control point at the corner, so it is tangent to both. Missing keys (an older
 * model map) default to no blend and no plan rounding.
 */
function chordFactor(pl is map, eta is number) returns number
{
    const ratio = pl.ratio;
    var g;
    if (pl.shape == ChordShape.LINEAR)
        g = 1 - (1 - ratio) * eta;
    else if (pl.shape == ChordShape.DOUBLE)
    {
        const brk = pl.brk;
        const mid = pl.mid;
        const d = pl.blend == undefined ? 0 : pl.blend;
        if (d > 0 && abs(eta - brk) < d)
        {
            const t = (eta - (brk - d)) / (2 * d);
            const p0 = 1 - (1 - mid) * (brk - d) / brk;
            const p2 = mid - (mid - ratio) * d / (1 - brk);
            g = (1 - t) * (1 - t) * p0 + 2 * t * (1 - t) * mid + t * t * p2;
        }
        else
            g = eta < brk ? 1 - (1 - mid) * eta / brk : mid - (mid - ratio) * (eta - brk) / (1 - brk);
    }
    else
    {
        const v = 1 - (seScale(ratio, pl.n) * eta) ^ pl.n;
        g = v <= 0 ? 0 : v ^ (1 / pl.n);
    }
    return g * capPlanFactor(pl, eta) + tailFactor(pl, eta);
}

/**
 * Plan-view tip rounding multiplier: 1 up to eta = capEta, then a quarter-ellipse down to capEnd
 * at eta = 1. Kept separate so the section placement can centre the shrink on the mid-chord
 * (both corners round) instead of on the alignment line (build 146).
 */
function capPlanFactor(pl is map, eta is number) returns number
{
    const capEta = pl.capEta == undefined ? 1 : pl.capEta;
    if (capEta >= 1 || eta <= capEta)
        return 1;
    const u = min((eta - capEta) / (1 - capEta), 1);
    return pl.capEnd + (1 - pl.capEnd) * sqrt(max(1 - u * u, 0));
}

/**
 * Leading-edge bump (tubercle) offset at eta: how far the leading edge is forward of the smooth
 * outline, up to +/- Bump height / 2, sinusoidal along the span with Bump pitch between Bumps from
 * and Bumps to, fading in and out over half a pitch at each end. The trailing edge is unchanged, so
 * the local chord grows by this. Zero when off. pl / model map keys: bumpOn (true or 1), bumpAmp and
 * bumpPitch in metres (numbers), bumpFrom and bumpTo as fractions of the half span h.
 */
function bumpOffset(pl is map, eta is number, h is ValueWithUnits) returns ValueWithUnits
{
    if (pl.bumpOn != true && pl.bumpOn != 1)
        return 0 * meter;
    const y = eta * h;
    const y0 = pl.bumpFrom * h;
    const y1 = pl.bumpTo * h;
    const lam = pl.bumpPitch * meter;
    if (y < y0 || y > y1 || lam <= 0 * meter)
        return 0 * meter;
    const ramp = lam / 2;
    var w = 1;
    if (y - y0 < ramp)
        w = 0.5 * (1 - cos((PI * (y - y0) / ramp) * radian));
    if (y1 - y < ramp)
        w = min(w, 0.5 * (1 - cos((PI * (y1 - y) / ramp) * radian)));
    return 0.5 * pl.bumpAmp * meter * cos((2 * PI * (y - y0) / lam) * radian) * w;
}

/** The root tail's share of g(eta): tail x (2u^3 - 3u^2 + 1), u = eta / tailEta, zero beyond it. */
function tailFactor(pl is map, eta is number) returns number
{
    if (pl.tail == undefined || pl.tail <= 0 || eta >= pl.tailEta)
        return 0;
    const u = eta / pl.tailEta;
    return pl.tail * (2 * u * u * u - 3 * u * u + 1);
}

/** Scale so the truncated superellipse (1 - (s*eta)^n)^(1/n) equals ratio at eta = 1. */
function seScale(ratio is number, n is number) returns number
{
    return (1 - ratio ^ n) ^ (1 / n);
}

/**
 * Drop shape f(eta) for the tip drop, from a map d carrying dropExp, dropFrom (b), dropTo (t) and
 * dropSmooth (1 = S-curve) - the planform law map, a published model map or the buildFoil literal.
 * f = 0 out to b, 1 from t, and between them u = (eta - b)/(t - b) as u^e (power law) or the
 * smoothstep 3u^2 - 2u^3 (S-curve, flat at both ends). b = 0, t = 1, power e is the original
 * eta^e law. The gull term uses eta - f(eta), so the root dihedral line runs straight to the
 * break, then fades. Missing keys (an older model map) mean the original law.
 */
function dropShape(d is map, eta is number) returns number
{
    const b = d.dropFrom == undefined ? 0 : d.dropFrom;
    const t = d.dropTo == undefined ? 1 : d.dropTo;
    if (eta <= b)
        return 0;
    if (eta >= t)
        return 1;
    const u = (eta - b) / (t - b);
    if (d.dropSmooth == 1)
        return u * u * (3 - 2 * u);
    return u ^ (d.dropExp == undefined ? 2 : d.dropExp);
}

/** d/deta of dropShape. */
function dropSlope(d is map, eta is number) returns number
{
    const b = d.dropFrom == undefined ? 0 : d.dropFrom;
    const t = d.dropTo == undefined ? 1 : d.dropTo;
    if (eta <= b || eta >= t)
        return 0;
    const u = (eta - b) / (t - b);
    if (d.dropSmooth == 1)
        return 6 * u * (1 - u) / (t - b);
    const e = d.dropExp == undefined ? 2 : d.dropExp;
    if (e == 1)
        return 1 / (t - b);
    return e * u ^ (e - 1) / (t - b);
}

/**
 * The foil's loft stations as etas in [0, 1], from a map with the keys the model maps carry (span in
 * metres, stations, shape, ratio, n, brk, blend, tail, tailEta, bumpOn/Pitch/From/To, tipOn,
 * blendFrom, wingletOn/Eta/R/Angle, capOn, capLength). buildFoil lofts through exactly these; the
 * mold adds them to its own parting stations, so the parting is ruled between the same stations
 * the loft interpolates (build 169: a Clark Y tip section failed the cavity cut whenever the two
 * sets differed, whatever Split stations was). Sorted, deduped at 0.3 mm, first 0 and last 1.
 */
function foilStationEtas(m is map) returns array
{
    const h = m.span / 2;
    const nMain = m.stations;
    var es = [];
    if (m.shape == ChordShape.SUPERELLIPSE)
    {
        // superellipse parametric angle: eta = sin(phi)^(2/n) / sc; equal phi steps put stations
        // evenly around the curved outline
        const sc = seScale(m.ratio, m.n);
        const phiEnd = asin(min(sc ^ (m.n / 2), 1));
        for (var i = 0; i < nMain; i += 1)
        {
            const phi = phiEnd * i / (nMain - 1);
            es = append(es, min(sin(phi) ^ (2 / m.n) / sc, 1));
        }
    }
    else
    {
        for (var i = 0; i < nMain; i += 1)
            es = append(es, sin((PI / 2 * i / (nMain - 1)) * radian));
        if (m.shape == ChordShape.DOUBLE)
        {
            // through the break: sharp -> at it and just either side; blended -> five across the blend
            const d = m.blend > 0 ? m.blend : 0.03;
            for (var e in [m.brk - d, m.brk - d / 2, m.brk, m.brk + d / 2, m.brk + d])
                es = append(es, min(max(e, 0), 1));
        }
    }
    if (m.tail != undefined && m.tail > 0)
        for (var e in [m.tailEta / 3, 2 * m.tailEta / 3, m.tailEta])
            es = append(es, min(e, 1));
    if (m.bumpOn == 1)
    {
        // six stations per pitch through the bumps
        var yb = m.bumpFrom * h;
        const yEnd = min(m.bumpTo * h, h);
        while (yb <= yEnd)
        {
            es = append(es, yb / h);
            yb += m.bumpPitch / 6;
        }
    }
    if (m.tipOn == 1)
        for (var k = 0; k <= 6; k += 1)
            es = append(es, m.blendFrom + (1 - m.blendFrom) * k / 6);   // six across the section blend
    if (m.wingletOn == 1)
    {
        // the bend start and four around the arc
        const arcLen = m.wingletR * m.wingletAngle;
        for (var k = 0; k <= 4; k += 1)
            es = append(es, min((m.wingletEta * h + arcLen * k / 4) / h, 1));
    }
    if (m.capOn == 1 && m.capLength > 0)
    {
        const capStart = h - m.capLength;
        for (var j = 0; j <= 4; j += 1)
            es = append(es, (capStart + m.capLength * sin((PI / 2 * j / 4) * radian)) / h);
    }
    es = sort(es, function(a, b) { return a - b; });
    var out = [];
    for (var e in es)
    {
        const ec = min(max(e, 0), 1);
        if (size(out) == 0 || ec - out[size(out) - 1] > 0.0003 / h)
            out = append(out, ec);
    }
    out[0] = 0;
    out[size(out) - 1] = 1;
    return out;
}

/** Integral of g from eta0 to 1 (Simpson, 200 intervals): the normalised area outboard of eta0. */
function shapeIntegralFrom(pl is map, eta0 is number) returns number
{
    const N = 200;
    var sum = 0;
    for (var i = 0; i <= N; i += 1)
    {
        const w = (i == 0 || i == N) ? 1 : ((i % 2 == 1) ? 4 : 2);
        sum += w * chordFactor(pl, eta0 + (1 - eta0) * i / N);
    }
    return sum * (1 - eta0) / (3 * N);
}

/**
 * Winglet path: position (y, z) and direction angle phi of the span line at developed distance s
 * from the root, for s beyond the bend start s0. The inboard drop law ends at (s0, z0) with slope
 * angle phi0; the bend turns by sign x ang over an arc of length r x ang, then runs straight.
 */
function wingletPath(s is ValueWithUnits, s0 is ValueWithUnits, z0 is ValueWithUnits, phi0 is ValueWithUnits, sign is number, ang is ValueWithUnits, r is ValueWithUnits) returns map
{
    const ds = s - s0;
    const arcLen = r * (ang / radian);
    var yy = s0;
    var zz = z0;
    const N = 24;
    for (var q = 0; q < N; q += 1)
    {
        const sm = ds * (q + 0.5) / N;
        const ph = phi0 + sign * ang * min(sm / arcLen, 1);
        yy += ds / N * cos(ph);
        zz += ds / N * sin(ph);
    }
    return { "y" : yy, "z" : zz, "phi" : phi0 + sign * ang * min(ds / arcLen, 1) };
}

/**
 * Winglet frame at developed station eta from a published model map (foilWingModel / foilStabModel):
 * origin y and z of the span line (SI numbers x meter), the section-plane tilt phi, and whether the
 * station is in the winglet. eta may exceed 1: the path continues straight beyond the tip, which the
 * mold uses for its beyond-tip parting station. Inboard of the bend (or with no winglet) it returns
 * the drop law's y = eta h and z, phi = 0, so callers can use it for every station.
 */
function wingletFrame(m is map, eta is number) returns map
{
    const h = m.span / 2 * meter;
    const on = m.wingletOn == 1 && eta > m.wingletEta;
    if (!on)
    {
        const f = dropShape(m, eta);
        return { "on" : false, "y" : h * eta, "z" : -m.tipDrop * meter * f + h * tan(m.rootDihedral * radian) * (eta - f), "phi" : 0 * degree };
    }
    const wEta = m.wingletEta;
    const ps0 = dropSlope(m, wEta);
    const f0 = dropShape(m, wEta);
    const z0 = -m.tipDrop * meter * f0 + h * tan(m.rootDihedral * radian) * (wEta - f0);
    const phi0 = atan((-m.tipDrop * meter * ps0 + h * tan(m.rootDihedral * radian) * (1 - ps0)) / h);
    const wp = wingletPath(eta * h, wEta * h, z0, phi0, m.wingletSign, m.wingletAngle * radian, m.wingletR * meter);
    return { "on" : true, "y" : wp.y, "z" : wp.z, "phi" : wp.phi };
}

/**
 * Simpson integration over η in [0, 1].
 * kind 0: integral of g   kind 1: integral of g^2   kind 2: integral of g * sqrt(1 + (dz/dy)^2)  (developed area)
 * z(eta) = -drop * eta^e + h * td * (eta - eta^e);  k = drop / h,  td = tan(root dihedral).
 */
function shapeIntegral(pl is map, kind is number, k is number, td is number) returns number
{
    const N = 400;
    var sum = 0;
    for (var i = 0; i <= N; i += 1)
    {
        const eta = i / N;
        const w = (i == 0 || i == N) ? 1 : ((i % 2 == 1) ? 4 : 2);
        const g = chordFactor(pl, eta);
        var v = g;
        if (kind == 1)
            v = g * g;
        else if (kind == 2)
        {
            const ps = dropSlope(pl, eta);
            const s = -k * ps + td * (1 - ps); // dz/dy of the drop + gull law
            v = g * sqrt(1 + s * s);
        }
        sum += w * v;
    }
    return sum / (3 * N);
}

// ---------------------------------------------------------------------------
// Tabulated section tables (chord-normalised x, y; upper and lower, LE -> TE).
// Source: UIUC Airfoil Coordinates Database, via airfoiltools.com (Lednicer format).
//   E817:    Eppler E817 hydrofoil.       Published: 11.0% thick at 32.9%c, 2.9% camber at 66.7%c.
//   E818:    Eppler E818 hydrofoil.       Published: 9.4% thick at 33.1%c, 2.8% camber at 67%c.
//   NACA63412: NACA 63(1)-412.            Published: 12.0% thick at 34.9%c, 2.2% camber at 50%c.
//   CLARKY:  Clark Y (UIUC clarky.dat).   Published: 11.7% thick at 28%c, 3.4% camber at 42%c.
//            The classic flat-bottomed section: its lower surface is a straight line from 30%c
//            to the trailing edge, so a stab in it mounts flat side to the fuselage (Invert on).
//            Thickness is scaled about that flat lower surface (tableSection keepLower), not the
//            camber line, so it stays flat at 7 % as at 11.7 %; camber scales with thickness.
// Checked (Python twin): resampling + max-thickness/camber recovery matches each published
// value to within rounding for all four tables.
// ---------------------------------------------------------------------------

const E817_UPPER = [vector(1e-05, -5e-05), vector(0.00016, 0.00087), vector(0.00093, 0.00242), vector(0.00273, 0.00472), vector(0.00695, 0.00848), vector(0.0118, 0.01175), vector(0.02521, 0.0185), vector(0.04342, 0.02533), vector(0.06626, 0.03213), vector(0.09345, 0.03877), vector(0.12469, 0.04512), vector(0.15965, 0.05105), vector(0.19797, 0.05645), vector(0.23925, 0.06124), vector(0.28307, 0.06533), vector(0.32896, 0.06864), vector(0.37645, 0.07111), vector(0.42505, 0.07271), vector(0.47424, 0.07337), vector(0.52353, 0.07309), vector(0.57238, 0.07183), vector(0.6203, 0.06956), vector(0.66676, 0.06627), vector(0.71125, 0.06181), vector(0.75361, 0.05591), vector(0.79402, 0.04878), vector(0.83232, 0.04107), vector(0.86796, 0.03335), vector(0.90035, 0.02596), vector(0.92892, 0.01919), vector(0.95309, 0.01315), vector(0.97254, 0.00783), vector(0.98723, 0.00352), vector(0.99668, 0.00085), vector(1, 0)];
const E817_LOWER = [vector(1e-05, -5e-05), vector(0.0002, -0.00096), vector(0.00103, -0.00248), vector(0.00293, -0.0047), vector(0.00729, -0.00827), vector(0.01232, -0.01136), vector(0.0259, -0.01749), vector(0.04416, -0.02344), vector(0.06686, -0.02906), vector(0.09368, -0.03419), vector(0.12428, -0.0386), vector(0.15828, -0.04202), vector(0.19548, -0.04404), vector(0.23588, -0.04452), vector(0.27935, -0.0436), vector(0.32555, -0.04142), vector(0.3741, -0.0381), vector(0.4246, -0.03383), vector(0.4766, -0.0288), vector(0.5296, -0.02328), vector(0.58304, -0.01752), vector(0.63631, -0.01183), vector(0.68875, -0.0065), vector(0.73965, -0.00181), vector(0.78823, 0.00199), vector(0.83369, 0.00472), vector(0.87521, 0.00627), vector(0.91198, 0.00662), vector(0.94322, 0.00585), vector(0.96811, 0.00417), vector(0.98594, 0.00216), vector(0.99652, 0.00059), vector(1, 0)];
const E818_UPPER = [vector(1e-05, -3e-05), vector(0.00017, 0.00066), vector(0.00096, 0.00186), vector(0.0028, 0.0037), vector(0.00709, 0.00682), vector(0.01211, 0.00955), vector(0.02587, 0.01539), vector(0.04438, 0.02148), vector(0.06747, 0.02762), vector(0.09485, 0.03367), vector(0.12626, 0.03947), vector(0.16137, 0.04492), vector(0.19983, 0.0499), vector(0.24124, 0.05433), vector(0.28517, 0.05812), vector(0.33117, 0.06122), vector(0.37877, 0.06355), vector(0.42746, 0.06508), vector(0.47676, 0.06575), vector(0.52615, 0.06557), vector(0.57511, 0.06448), vector(0.62313, 0.06249), vector(0.66972, 0.05955), vector(0.71435, 0.05558), vector(0.75683, 0.05033), vector(0.79725, 0.04401), vector(0.8354, 0.03718), vector(0.87074, 0.03034), vector(0.90271, 0.02376), vector(0.9307801, 0.0177), vector(0.95442, 0.01223), vector(0.97339, 0.00734), vector(0.98765, 0.00333), vector(0.9968, 0.00081), vector(1, 0)];
const E818_LOWER = [vector(1e-05, -3e-05), vector(0.0002, -0.00071), vector(0.00104, -0.00187), vector(0.00295, -0.00363), vector(0.00735, -0.00655), vector(0.01248, -0.00906), vector(0.02633, -0.01424), vector(0.0448, -0.01939), vector(0.06765, -0.02427), vector(0.09456, -0.02866), vector(0.12523, -0.03228), vector(0.15943, -0.03479), vector(0.19714, -0.03599), vector(0.23818, -0.03599), vector(0.28226, -0.03483), vector(0.32901, -0.03261), vector(0.37806, -0.02944), vector(0.42898, -0.02549), vector(0.4813, -0.02093), vector(0.53451, -0.01602), vector(0.58803, -0.01098), vector(0.64124, -0.0061), vector(0.69351, -0.00163), vector(0.74409, 0.00219), vector(0.79222, 0.00515), vector(0.83713, 0.0071), vector(0.87803, 0.00796), vector(0.91416, 0.00773), vector(0.94478, 0.00651), vector(0.96909, 0.00448), vector(0.98642, 0.00226), vector(0.99664, 0.0006), vector(1, 0)];
const NACA63412_UPPER = [vector(0, 0), vector(0.00336, 0.01071), vector(0.00567, 0.0132), vector(0.01041, 0.01719), vector(0.02257, 0.0246), vector(0.04727, 0.03544), vector(0.07218, 0.04379), vector(0.09718, 0.05063), vector(0.14735, 0.06138), vector(0.19765, 0.06929), vector(0.248, 0.07499), vector(0.2984, 0.07872), vector(0.34882, 0.08059), vector(0.39924, 0.08062), vector(0.44964, 0.07894), vector(0.5, 0.07567), vector(0.55031, 0.07125), vector(0.60057, 0.06562), vector(0.65076, 0.05899), vector(0.70087, 0.05153), vector(0.75089, 0.04344), vector(0.80084, 0.03492), vector(0.8507, 0.02618), vector(0.90049, 0.01739), vector(0.95023, 0.00881), vector(1, 0)];
const NACA63412_LOWER = [vector(0, 0), vector(0.00664, -0.00871), vector(0.00933, -0.0104), vector(0.01459, -0.01291), vector(0.02743, -0.01716), vector(0.05273, -0.0228), vector(0.07782, -0.02685), vector(0.10282, -0.02995), vector(0.15265, -0.03446), vector(0.20235, -0.03745), vector(0.252, -0.03919), vector(0.3016, -0.03984), vector(0.351118, -0.03939), vector(0.40076, -0.03778), vector(0.45035, -0.03514), vector(0.5, -0.03164), vector(0.54969, -0.02745), vector(0.59943, -0.02278), vector(0.64924, -0.01799), vector(0.69913, -0.01265), vector(0.74911, -0.00764), vector(0.79916, -0.00308), vector(0.8493, 0.00074), vector(0.89951, 0.00329), vector(0.94977, 0.0033), vector(1, 0)];

const CLARKY_UPPER = [vector(0.0, 0.0), vector(0.0005, 0.00234), vector(0.001, 0.00373), vector(0.002, 0.0058), vector(0.004, 0.00892), vector(0.008, 0.01374), vector(0.012, 0.01786), vector(0.02, 0.02537), vector(0.03, 0.03302), vector(0.04, 0.03913), vector(0.05, 0.04428), vector(0.06, 0.04876), vector(0.08, 0.05643), vector(0.1, 0.063), vector(0.12, 0.06862), vector(0.14, 0.07344), vector(0.16, 0.07757), vector(0.18, 0.08107), vector(0.2, 0.08392), vector(0.22, 0.08614), vector(0.24, 0.08783), vector(0.26, 0.08908), vector(0.28, 0.09), vector(0.3, 0.09068), vector(0.32, 0.09119), vector(0.34, 0.09151), vector(0.36, 0.09163), vector(0.38, 0.09152), vector(0.4, 0.09117), vector(0.42, 0.09057), vector(0.44, 0.08972), vector(0.46, 0.08864), vector(0.48, 0.08736), vector(0.5, 0.08588), vector(0.52, 0.08421), vector(0.54, 0.08237), vector(0.56, 0.08035), vector(0.58, 0.07815), vector(0.6, 0.07576), vector(0.62, 0.07321), vector(0.64, 0.07048), vector(0.66, 0.0676), vector(0.68, 0.06458), vector(0.7, 0.06143), vector(0.72, 0.05816), vector(0.74, 0.05477), vector(0.76, 0.05126), vector(0.78, 0.04763), vector(0.8, 0.04388), vector(0.82, 0.04002), vector(0.84, 0.03605), vector(0.86, 0.03197), vector(0.88, 0.02779), vector(0.9, 0.0235), vector(0.92, 0.01912), vector(0.94, 0.01462), vector(0.96, 0.01002), vector(0.97, 0.00769), vector(0.98, 0.00533), vector(0.99, 0.00297), vector(1.0, 0.0006)];
const CLARKY_LOWER = [vector(0.0, 0.0), vector(0.0005, -0.00467), vector(0.001, -0.00594), vector(0.002, -0.00781), vector(0.004, -0.01051), vector(0.008, -0.01429), vector(0.012, -0.01697), vector(0.02, -0.02027), vector(0.03, -0.02261), vector(0.04, -0.02452), vector(0.05, -0.02605), vector(0.06, -0.02713), vector(0.08, -0.02846), vector(0.1, -0.02938), vector(0.12, -0.02996), vector(0.14, -0.03024), vector(0.16, -0.03025), vector(0.18, -0.03005), vector(0.2, -0.02967), vector(0.22, -0.02914), vector(0.24, -0.02852), vector(0.26, -0.02782), vector(0.28, -0.02707), vector(0.3, -0.02631), vector(0.32, -0.02556), vector(0.34, -0.02482), vector(0.36, -0.02409), vector(0.38, -0.02336), vector(0.4, -0.02263), vector(0.42, -0.0219), vector(0.44, -0.02117), vector(0.46, -0.02044), vector(0.48, -0.0197), vector(0.5, -0.01896), vector(0.52, -0.01823), vector(0.54, -0.01749), vector(0.56, -0.01676), vector(0.58, -0.01602), vector(0.6, -0.01529), vector(0.62, -0.01456), vector(0.64, -0.01382), vector(0.66, -0.01309), vector(0.68, -0.01235), vector(0.7, -0.01162), vector(0.72, -0.01088), vector(0.74, -0.01015), vector(0.76, -0.00941), vector(0.78, -0.00868), vector(0.8, -0.00794), vector(0.82, -0.00721), vector(0.84, -0.00648), vector(0.86, -0.00574), vector(0.88, -0.00501), vector(0.9, -0.00427), vector(0.92, -0.00354), vector(0.94, -0.0028), vector(0.96, -0.00207), vector(0.97, -0.0017), vector(0.98, -0.00133), vector(0.99, -0.00097), vector(1.0, -0.0006)];

/** Linear interpolation of y at x from a sorted (x, y) table (vectors), clamped at the ends. */
function tableInterp(table is array, x is number) returns number
{
    if (x <= table[0][0])
        return table[0][1];
    const last = size(table) - 1;
    if (x >= table[last][0])
        return table[last][1];
    for (var i = 0; i < last; i += 1)
    {
        const x0 = table[i][0];
        const x1 = table[i + 1][0];
        if (x >= x0 && x <= x1 && x1 > x0)
        {
            const t = (x - x0) / (x1 - x0);
            return table[i][1] + t * (table[i + 1][1] - table[i][1]);
        }
    }
    return table[last][1];
}

/** Highest thickness (upper - lower) found across a fine cosine-spaced sweep of the table. */
function tableMaxThickness(upper is array, lower is array) returns number
{
    var best = 0;
    for (var i = 0; i <= 200; i += 1)
    {
        const x = 0.5 * (1 - cos((PI * i / 200) * radian));
        best = max(best, tableInterp(upper, x) - tableInterp(lower, x));
    }
    return best;
}

/**
 * Build a section from a digitised table, scaled to a target thickness fraction, with the same
 * cosine spacing, point ordering and finite-TE-thickness ramp as naca4Section, so the result is
 * a drop-in replacement in placeSection and the rest of the loft pipeline. The table's own
 * camber line is used unscaled - only thickness is a free parameter, matching how thin/thick
 * variants of a published family are conventionally derived.
 */
function tableSection(upper is array, lower is array, thicknessFrac is number, teFrac is number, n is number, keepLower is boolean) returns array
{
    const scale = thicknessFrac / tableMaxThickness(upper, lower);
    var up = [];
    var lo = [];
    for (var i = 0; i < n; i += 1)
    {
        const x = 0.5 * (1 - cos((PI * i / (n - 1)) * radian));
        const yu = tableInterp(upper, x);
        const yl = tableInterp(lower, x);
        if (keepLower)
        {
            // flat-bottomed section (Clark Y): the WHOLE section is scaled vertically, so the flat
            // lower surface stays a straight line at any thickness and the camber scales with the
            // thickness; the TE ramp goes on top. Build 143 kept the lower surface fixed and shrank
            // only the upper one, which left a thin tip section shaped like the Clark Y's dipped
            // underside (3 % of reflexed camber on a 2.5 % thick sliver): the wing's loft and the
            // mold's parting disagreed there and the cavity cut failed (build 167)
            up = append(up, vector(x, yu * scale + teFrac * x));
            lo = append(lo, vector(x, yl * scale));
            continue;
        }
        const yc = 0.5 * (yu + yl);
        var yt = 0.5 * (yu - yl) * scale;
        yt = yt + 0.5 * teFrac * x; // same linear TE-thickness ramp as naca4Section
        up = append(up, vector(x, yc + yt));
        lo = append(lo, vector(x, yc - yt));
    }
    var pts = [];
    for (var i = n - 1; i >= 0; i -= 1)
        pts = append(pts, up[i]);
    for (var i = 1; i < n; i += 1)
        pts = append(pts, lo[i]);
    return pts;
}

/**
 * Thin-aerofoil zero-lift angle and quarter-chord Cm for a digitised camber line, using the same
 * integrals as zeroLiftAngle/momentCoefficient but with dyc/dx found by central difference on
 * the table instead of the closed-form NACA formula. This is still thin-aerofoil theory (the
 * same approximation used everywhere else in Analytic mode) - for a real prediction on a
 * published section, use Section polar (Polar summary) instead.
 */
function tableAlpha0Cm0(upper is array, lower is array) returns array
{
    const N = 400;
    const h = 0.0001;
    var sA0 = 0;
    var sCm = 0;
    for (var i = 1; i <= N; i += 1)
    {
        const th = PI * (i - 0.5) / N;
        const c = cos(th * radian);
        const x = 0.5 * (1 - c);
        const x0 = max(x - h, 0);
        const x1 = min(x + h, 1);
        const yc0 = 0.5 * (tableInterp(upper, x0) + tableInterp(lower, x0));
        const yc1 = 0.5 * (tableInterp(upper, x1) + tableInterp(lower, x1));
        const dyc = (yc1 - yc0) / (x1 - x0);
        sA0 += dyc * (c - 1);
        sCm += dyc * (cos(2 * th * radian) - c);
    }
    return [-(sA0 / N) * radian, 0.5 * sCm * PI / N];
}

/** Section geometry, dispatched by Profile: the NACA 4-digit formula, or a digitised table. */
function buildSection(definition is map, thick is number, teFrac is number, n is number) returns array
{
    var pts;
    if (definition.profile == FoilProfile.NACA4)
        pts = naca4Section(definition.camber / 100, definition.camberPos / 100, thick, teFrac, n);
    else if (definition.profile == FoilProfile.E817)
        pts = tableSection(E817_UPPER, E817_LOWER, thick, teFrac, n, false);
    else if (definition.profile == FoilProfile.E818)
        pts = tableSection(E818_UPPER, E818_LOWER, thick, teFrac, n, false);
    else if (definition.profile == FoilProfile.CLARKY)
        pts = tableSection(CLARKY_UPPER, CLARKY_LOWER, thick, teFrac, n, true);
    else
        pts = tableSection(NACA63412_UPPER, NACA63412_LOWER, thick, teFrac, n, false); // NACA63412
    if (definition.invertSection == true)
    {
        // upside down: mirror in z. The loop stays closed and the upper/lower pairing by index
        // (used for the mold's camber line) still holds, the two surfaces just swap roles
        var flipped = [];
        for (var p in pts)
            flipped = append(flipped, vector(p[0], -p[1]));
        pts = flipped;
    }
    return pts;
}

/** [alpha0 (angle), cm0 (unitless)], dispatched by Profile the same way as buildSection. */
function sectionAlpha0Cm0(definition is map, thickFrac is number) returns array
{
    var r;
    if (definition.profile == FoilProfile.NACA4)
        r = [zeroLiftAngle(definition.camber / 100, definition.camberPos / 100),
             momentCoefficient(definition.camber / 100, definition.camberPos / 100)];
    else if (definition.profile == FoilProfile.E817)
        r = tableAlpha0Cm0(E817_UPPER, E817_LOWER);
    else if (definition.profile == FoilProfile.E818)
        r = tableAlpha0Cm0(E818_UPPER, E818_LOWER);
    else if (definition.profile == FoilProfile.CLARKY)
    {
        // the whole Clark Y section is scaled with its thickness (build 168), camber included, so its
        // thin-aerofoil angle and moment scale by the same factor
        r = tableAlpha0Cm0(CLARKY_UPPER, CLARKY_LOWER);
        const k = thickFrac / tableMaxThickness(CLARKY_UPPER, CLARKY_LOWER);
        r = [r[0] * k, r[1] * k];
    }
    else
        r = tableAlpha0Cm0(NACA63412_UPPER, NACA63412_LOWER); // NACA63412
    if (definition.invertSection == true)
        r = [-r[0], -r[1]];
    return r;
}

/**
 * NACA 4-digit section in chord-normalised coordinates.
 * m = max camber (fraction), p = camber position (fraction), t = thickness (fraction),
 * teFrac = trailing edge thickness / chord, n = points per surface (cosine spaced).
 * Closed-TE thickness polynomial plus a linear ramp so the TE thickness is exactly teFrac.
 * Returns one ordered list: upper TE -> LE -> lower TE (LE point appears once).
 */
function naca4Section(m is number, p is number, t is number, teFrac is number, n is number) returns array
{
    var upper = [];
    var lower = [];
    for (var i = 0; i < n; i += 1)
    {
        const x = 0.5 * (1 - cos((PI * i / (n - 1)) * radian));

        var yc = 0;
        var dyc = 0;
        if (m != 0) // negative camber = inverted section
        {
            if (x < p)
            {
                yc = m / p ^ 2 * (2 * p * x - x ^ 2);
                dyc = 2 * m / p ^ 2 * (p - x);
            }
            else
            {
                yc = m / (1 - p) ^ 2 * ((1 - 2 * p) + 2 * p * x - x ^ 2);
                dyc = 2 * m / (1 - p) ^ 2 * (p - x);
            }
        }

        const yt = 5 * t * (0.2969 * sqrt(x) - 0.1260 * x - 0.3516 * x ^ 2 + 0.2843 * x ^ 3 - 0.1036 * x ^ 4)
            + 0.5 * teFrac * x;

        const k = 1 / sqrt(1 + dyc * dyc);
        const s = dyc * k;

        upper = append(upper, vector(x - yt * s, yc + yt * k));
        lower = append(lower, vector(x + yt * s, yc - yt * k));
    }

    var pts = [];
    for (var i = n - 1; i >= 0; i -= 1)
        pts = append(pts, upper[i]);
    for (var i = 1; i < n; i += 1)
        pts = append(pts, lower[i]);
    return pts;
}

/**
 * Scale a normalised section to chord, shift so the pivot is at the origin,
 * and rotate by the local angle (positive = LE up, X downstream).
 */
function placeSection(section is array, chord is ValueWithUnits, pivotFrac is number, cosA is number, sinA is number) returns array
{
    var pts = [];
    for (var q in section)
    {
        const xs = q[0] - pivotFrac;
        const zs = q[1];
        pts = append(pts, vector(xs * cosA + zs * sinA, -xs * sinA + zs * cosA) * chord);
    }
    return pts;
}
