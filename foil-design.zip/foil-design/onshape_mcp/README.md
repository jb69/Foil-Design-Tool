# Onshape MCP server for the foil tool

Lets Claude read and write your Onshape document directly: replace the Feature Studio's
FeatureScript, list and set feature parameters, add features, evaluate FeatureScript in the
Part Studio, read every feature's status plus the foil tool's notices and console logs
(build 202 and later keep them in variables), and export STL. Standard-library Python 3.9,
no packages to install.

## 1. API keys

Onshape > your avatar > **My account** > **Developer** (API keys): create a key with read and
write scopes. Put them in `~/.onshape/keys.json` (outside the repo, never committed):

```json
{"access_key": "YOUR_ACCESS_KEY", "secret_key": "YOUR_SECRET_KEY", "auth": "basic"}
```

`"auth": "basic"` is simplest and fine for your own machine; `"hmac"` signs every request
the way Onshape's docs recommend.

## 2. Document ids

Open the document in Onshape. The URL is
`https://cad.onshape.com/documents/<documentId>/w/<workspaceId>/e/<elementId>`. Copy
`onshape_mcp/config.example.json` to `onshape_mcp/config.json` and fill in the document,
workspace, the Feature Studio tab's element id and the Part Studio's element id (click each tab
and read its `e/...` from the URL). Tool calls can also pass `did`, `wid`, `eid` explicitly,
so several documents work.

## 3. Check it

```bash
python3 onshape_mcp/server.py --test
```

prints who the keys sign in as, the document's tabs, the Part Studio's features and the
notices.

## 4. Register with Claude Code

The repo's `.mcp.json` already declares the server; Claude Code picks it up when a session
starts in this folder (approve it once when asked). To register it for every project instead:

```bash
claude mcp add onshape -- python3 /Users/jasonbird/Documents/efoil/onshape_mcp/server.py
```

Restart the session; the tools appear as `onshape_whoami`, `onshape_get_studio`,
`onshape_put_studio`, `onshape_list_features`, `onshape_set_parameters`, `onshape_add_feature`,
`onshape_eval_featurescript`, `onshape_get_notices`, `onshape_export_stl`, `onshape_list_elements`.

## Typical loop

1. `onshape_put_studio` with `file_path` = the new `foil_design_bNNN.fs`. Onshape recompiles;
   the Part Studio regenerates.
2. `onshape_get_notices`: every feature's status (a compile or regeneration failure shows as
   ERROR) and the WING_INPUTS line's toolVersion shows whether the new build is running.
3. `onshape_set_parameters` on a feature, then `onshape_get_notices` again to read the result.
4. `onshape_eval_featurescript` for anything else: `return getVariable(context, "foilWingHub");`
   or `return evBox3d(context, {"topology": qEverything(EntityType.BODY), "tight": true});`.

## Notes

- Feature ids come from `onshape_list_features`; parameter ids are the FeatureScript
  `definition.xxx` names (the developer skill's parameters reference maps labels to ids).
  Hidden parameters (a collapsed choice's fields) are not on the feature until their group shows.
- Quantities are set as expressions with units: `"12 mm"`, `"3 deg"`; unitless numbers as
  `"0.25"`; booleans as true/false; enums as their value name (`"HUB"`, `"BAG"`).
- A failed FeatureScript paste does not raise an error on `put_studio`: the features keep
  running the previous build, which `get_notices` shows through the version in the log line.
- STL export follows Onshape's redirect; with `"auth": "hmac"` the redirect is re-signed.
- After `put_studio`, the first features or notices call waits for Onshape to recompile the studio and regenerate the Part Studio: two to four minutes for this tool. The request timeout is ten minutes.
- Confirmed working 2026-09-25: builds 204 and 205 pushed, regenerated, notices and logs read back, parameters set on two molds (status INFO).

## Speed, and several sessions at once

- `list_features`, `get_variables` and `get_notices` read the studio's last regeneration: one to
  three seconds when the studio is up to date.
- Any call has to wait for a regeneration in progress. A studio push or a parameter change
  regenerates the whole Part Studio, and with two mold features that is two to four minutes on
  Onshape's side. The first read after a change pays that wait; later reads are cheap.
- `eval_featurescript` regenerates the studio for every call (30 s to minutes). Use it only for
  geometry questions; published values come from `get_variables`.
- Iterate on a studio without active molds. Measured on the Silk V2 studio (wing mold with a printed core, stab mold), one wing parameter change:

  | Molds | Regeneration |
  |---|---|
  | both suppressed | 12 to 21 s |
  | both in Preview | 110 s |
  | both in Print | 135 s |

  So suppress the molds while changing the design (`set_parameters` with `{"suppressed": true}`), and unsuppress them once at the end (about 100 s for the wing mold, 45 s for the stab mold). Preview only trims the tiling, keys, groove and templates; the parting and cavity cuts are the bulk of a mold's time.
- Several Claude sessions share one document. Only one session should push builds or change
  parameters at a time; the others should read. Two sessions pushing different builds overwrite
  each other, and every push makes every session's next read wait.

## Moving a feature between documents (2026-09-25)

A custom feature copied from one Part Studio into another document needs its namespace rewritten to the
published version of the Feature Studio (`d<did>::v<vid>::e<eid>::m<microversion>`), and so does every enum
parameter's own `namespace` field. A feature taken from the Feature Studio's home document carries same-document
enum namespaces (`e<eid>::m000...`), which resolve to nothing elsewhere: the feature shows ERROR with
"enum e...::m000000000000000000000000::FoilProfile not found" and "Precondition failed (definition.profile is
FoilProfile)" in the console, while the API's feature state says only ERROR. Fix: set each enum parameter's
namespace to the same string as the feature's. The Feature Studio microversion for a version comes from
`GET /documents/d/{did}/v/{vid}/elements` (`microversionId` of the Feature Studio element). Also: a copied
Part Studio keeps its feature ids, and a definition from an older build may carry stale parameters; take the
definition from a Part Studio that already runs the target version.
