#!/usr/bin/env python3
"""Onshape MCP server: lets Claude read and write an Onshape document through the REST API.

Standard library only (Python 3.9+), stdio transport, newline-delimited JSON-RPC 2.0 as the
Model Context Protocol specifies. Tools: whoami, list_elements, get_studio, put_studio,
list_features, set_parameters, add_feature, eval_featurescript, get_notices, export_stl.

Keys:   ~/.onshape/keys.json   {"access_key": "...", "secret_key": "...", "auth": "basic" | "hmac"}
Config: onshape_mcp/config.json (beside this file) with the document, workspace and element ids
        that the tools use when a call does not name them.

Smoke test without Claude:  python3 server.py --test
"""
import base64
import datetime
import hashlib
import hmac
import json
import os
import random
import string
import sys
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = "https://cad.onshape.com/api/v10"
KEYS_PATH = os.path.expanduser("~/.onshape/keys.json")
CONFIG_PATH = os.path.join(HERE, "config.json")

NOTICE_KEYS = [
    "foilWingNotice", "foilWingLog", "foilStabNotice", "foilStabLog", "foilPerfNotice", "foilPerfLog",
    "foilMastNotice", "foilMastLog", "foilFuselageNotice", "foilFuselageLog",
    "foilMoldNotice_WING", "foilMoldLog_WING", "foilMoldNotice_STAB", "foilMoldLog_STAB",
    "foilMoldNotice_MAST", "foilMoldLog_MAST",
]


def log(msg):
    sys.stderr.write("[onshape-mcp] " + str(msg) + "\n")
    sys.stderr.flush()


def load_json(path, default=None):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return default


class Onshape:
    def __init__(self):
        keys = load_json(KEYS_PATH)
        if not keys or "access_key" not in keys or "secret_key" not in keys:
            raise RuntimeError("no API keys: create %s with access_key and secret_key (Onshape > My account > Developer)" % KEYS_PATH)
        self.access = keys["access_key"]
        self.secret = keys["secret_key"]
        self.auth = keys.get("auth", "basic")
        self.config = load_json(CONFIG_PATH, {}) or {}

    # ---- ids from the call or the config ----
    def ids(self, args, element_key):
        did = args.get("did") or self.config.get("documentId")
        wid = args.get("wid") or self.config.get("workspaceId")
        eid = args.get("eid") or self.config.get(element_key)
        missing = [n for n, v in (("did", did), ("wid", wid), ("eid", eid)) if not v or str(v).startswith("PASTE") or " " in str(v)]
        if missing:
            raise RuntimeError("missing %s: pass them or set documentId / workspaceId / %s in %s" % (", ".join(missing), element_key, CONFIG_PATH))
        return did, wid, eid

    # ---- one signed request ----
    def request(self, method, path, query=None, body=None, raw=False, follow=True):
        q = urllib.parse.urlencode(query or {}, doseq=True)
        url = BASE + path + ("?" + q if q else "")
        data = json.dumps(body).encode("utf-8") if body is not None else None
        headers = {"Accept": "application/json;charset=UTF-8; qs=0.09" if not raw else "*/*",
                   "Content-Type": "application/json;charset=UTF-8; qs=0.09"}
        headers.update(self.auth_headers(method, "/api/v10" + path, q, headers["Content-Type"]))
        req = urllib.request.Request(url, data=data, method=method, headers=headers)
        opener = urllib.request.build_opener(NoRedirect())
        try:
            with opener.open(req, timeout=600) as r:
                content = r.read()
                return self.decode(content, raw)
        except urllib.error.HTTPError as e:
            if e.code in (301, 302, 303, 307, 308) and follow:
                loc = e.headers.get("Location")
                if not loc:
                    raise
                return self.get_absolute(loc, raw)
            detail = e.read().decode("utf-8", "replace")
            raise RuntimeError("HTTP %d on %s %s: %s" % (e.code, method, path, detail[:2000]))

    def get_absolute(self, url, raw):
        u = urllib.parse.urlparse(url)
        headers = {"Accept": "*/*"}
        if u.netloc.endswith("onshape.com"):
            headers.update(self.auth_headers("GET", u.path, u.query, "application/json"))
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=300) as r:
            return self.decode(r.read(), raw)

    @staticmethod
    def decode(content, raw):
        if raw:
            return content
        if not content:
            return {}
        try:
            return json.loads(content.decode("utf-8"))
        except ValueError:
            return {"raw": content.decode("utf-8", "replace")}

    def auth_headers(self, method, path, query, content_type):
        if self.auth == "hmac":
            nonce = "".join(random.choice(string.ascii_letters + string.digits) for _ in range(25))
            date = datetime.datetime.utcnow().strftime("%a, %d %b %Y %H:%M:%S GMT")
            msg = (method + "\n" + nonce + "\n" + date + "\n" + content_type + "\n" + path + "\n" + query + "\n").lower()
            sig = base64.b64encode(hmac.new(self.secret.encode(), msg.encode(), hashlib.sha256).digest()).decode()
            return {"Date": date, "On-Nonce": nonce, "Authorization": "On %s:HmacSHA256:%s" % (self.access, sig)}
        token = base64.b64encode((self.access + ":" + self.secret).encode()).decode()
        return {"Authorization": "Basic " + token}


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


# ---- FeatureScript value decoding (BTFSValue*) ----
def fsval(v):
    if not isinstance(v, dict):
        return v
    t = v.get("btType", "")
    if t.endswith("BTFSValueMap"):
        out = {}
        for entry in v.get("value", []):
            out[str(fsval(entry.get("key")))] = fsval(entry.get("value"))
        return out
    if t.endswith("BTFSValueArray"):
        return [fsval(x) for x in v.get("value", [])]
    if t.endswith("BTFSValueWithUnits"):
        return {"value": v.get("value"), "units": v.get("unitToPower") or v.get("units")}
    if "value" in v:
        return v["value"]
    return v


def param_summary(p):
    t = p.get("btType", "")
    pid = p.get("parameterId")
    if "Quantity" in t:
        return pid, p.get("expression")
    if "Enum" in t:
        return pid, p.get("value")
    if "Boolean" in t:
        return pid, p.get("value")
    if "String" in t:
        return pid, p.get("value")
    if "QueryList" in t:
        return pid, "<query: %d item(s)>" % len(p.get("queries", []))
    return pid, "<%s>" % t


def apply_updates(feature, updates):
    seen = set()
    for p in feature.get("parameters", []):
        pid = p.get("parameterId")
        if pid not in updates:
            continue
        val = updates[pid]
        t = p.get("btType", "")
        if "Quantity" in t:
            p["expression"] = val if isinstance(val, str) else str(val)
        elif "Boolean" in t:
            p["value"] = bool(val) if not isinstance(val, str) else val.strip().lower() in ("1", "true", "on", "yes")
        elif "Enum" in t or "String" in t:
            p["value"] = str(val)
        else:
            raise RuntimeError("parameter %s is a %s: not settable here" % (pid, t))
        seen.add(pid)
    missing = [k for k in updates if k not in seen]
    if missing:
        raise RuntimeError("parameter id(s) not on this feature: %s (hidden parameters do not appear until their group is shown)" % ", ".join(missing))


# ---- tools ----
class Tools:
    def __init__(self, api):
        self.api = api

    def whoami(self, args):
        # /users/sessioninfo answers an empty 204 whether or not the keys are valid; the documents
        # list is a real test of them
        r = self.api.request("GET", "/documents", query={"limit": 3, "sortColumn": "modifiedAt", "sortOrder": "desc"})
        items = r.get("items", []) if isinstance(r, dict) else []
        who = ""
        if items:
            o = items[0].get("owner") or {}
            who = " for %s" % (o.get("name") or o.get("id")) if o else ""
        return "API keys accepted%s; %d recent document(s): %s" % (who, len(items), ", ".join(d.get("name", "?") for d in items))

    def list_elements(self, args):
        did = args.get("did") or self.api.config.get("documentId")
        wid = args.get("wid") or self.api.config.get("workspaceId")
        if not did or not wid or str(did).startswith("PASTE") or str(wid).startswith("PASTE"):
            raise RuntimeError("pass did and wid, or set documentId and workspaceId in %s (still the PASTE placeholders)" % CONFIG_PATH)
        els = self.api.request("GET", "/documents/d/%s/w/%s/elements" % (did, wid))
        lines = ["%s  %s  %s" % (e.get("id"), e.get("elementType"), e.get("name")) for e in els]
        return "\n".join(lines) or "(no elements)"

    def get_studio(self, args):
        did, wid, eid = self.api.ids(args, "featureStudioId")
        r = self.api.request("GET", "/featurestudios/d/%s/w/%s/e/%s" % (did, wid, eid))
        text = r.get("contents", "")
        out = args.get("out_path")
        if out:
            with open(os.path.expanduser(out), "w", encoding="utf-8") as f:
                f.write(text)
            return "Feature Studio %s: %d characters written to %s" % (eid, len(text), out)
        return text

    def put_studio(self, args):
        did, wid, eid = self.api.ids(args, "featureStudioId")
        path = args.get("file_path")
        if path:
            with open(os.path.expanduser(path), encoding="utf-8") as f:
                text = f.read()
        else:
            text = args.get("contents")
        if not text:
            raise RuntimeError("give file_path (preferred) or contents")
        r = self.api.request("POST", "/featurestudios/d/%s/w/%s/e/%s" % (did, wid, eid),
                             body={"btType": "BTFeatureStudioContents-2239", "contents": text})
        return "Feature Studio %s updated with %d characters (response keys: %s). Regenerate and read get_notices to see the new versions." % (
            eid, len(text), ", ".join(sorted(r.keys())) if isinstance(r, dict) else "?")

    def _features(self, did, wid, eid):
        return self.api.request("GET", "/partstudios/d/%s/w/%s/e/%s/features" % (did, wid, eid),
                                query={"rollbackBarIndex": -1, "noSketchGeometry": "true"})

    def list_features(self, args):
        did, wid, eid = self.api.ids(args, "partStudioId")
        r = self._features(did, wid, eid)
        states = r.get("featureStates", {})
        lines = []
        for f in r.get("features", []):
            fid = f.get("featureId")
            st = states.get(fid, {}).get("featureStatus", "?")
            head = "%s  %s  [%s]%s%s" % (fid, f.get("name"), f.get("featureType"), "  " + st if st != "OK" else "",
                                        "  (suppressed)" if f.get("suppressed") else "")
            lines.append(head)
            if args.get("parameters", True):
                for p in f.get("parameters", []):
                    pid, val = param_summary(p)
                    lines.append("    %s = %s" % (pid, val))
        return "\n".join(lines) or "(no features)"

    def set_parameters(self, args):
        did, wid, eid = self.api.ids(args, "partStudioId")
        fid = args["featureId"]
        updates = args["parameters"]
        if isinstance(updates, str):
            updates = json.loads(updates)
        r = self._features(did, wid, eid)
        feature = next((f for f in r.get("features", []) if f.get("featureId") == fid), None)
        if feature is None:
            raise RuntimeError("no feature with id %s (list_features shows the ids)" % fid)
        apply_updates(feature, updates)
        body = {"btType": "BTFeatureDefinitionCall-1406", "feature": feature,
                "serializationVersion": r.get("serializationVersion"), "sourceMicroversion": r.get("sourceMicroversion"),
                "rejectMicroversionSkew": False}
        resp = self.api.request("POST", "/partstudios/d/%s/w/%s/e/%s/features/featureid/%s" % (did, wid, eid, fid), body=body)
        st = resp.get("featureState", {}).get("featureStatus", "?")
        return "Feature %s (%s) updated: %s -> status %s" % (fid, feature.get("name"), ", ".join("%s=%s" % kv for kv in updates.items()), st)

    def add_feature(self, args):
        did, wid, eid = self.api.ids(args, "partStudioId")
        ftype = args["featureType"]
        r = self._features(did, wid, eid)
        template = next((f for f in r.get("features", []) if f.get("featureType") == ftype), None)
        if template is None:
            raise RuntimeError("no existing %s feature to copy the definition from: add the first one in Onshape, then this tool can add more" % ftype)
        feature = json.loads(json.dumps(template))
        for k in ("featureId", "nodeId"):
            feature.pop(k, None)
        for p in feature.get("parameters", []):
            p.pop("nodeId", None)
        feature["name"] = args.get("name") or (ftype + " (added)")
        feature["suppressed"] = False
        updates = args.get("parameters") or {}
        if isinstance(updates, str):
            updates = json.loads(updates)
        if updates:
            apply_updates(feature, updates)
        body = {"btType": "BTFeatureDefinitionCall-1406", "feature": feature,
                "serializationVersion": r.get("serializationVersion"), "sourceMicroversion": r.get("sourceMicroversion"),
                "rejectMicroversionSkew": False}
        resp = self.api.request("POST", "/partstudios/d/%s/w/%s/e/%s/features" % (did, wid, eid), body=body)
        st = resp.get("featureState", {}).get("featureStatus", "?")
        return "Added %s '%s' as %s, status %s" % (ftype, feature["name"], resp.get("feature", {}).get("featureId"), st)

    def eval_featurescript(self, args):
        did, wid, eid = self.api.ids(args, "partStudioId")
        script = args["script"]
        if "function" not in script:
            script = "function(context is Context, queries) { " + script + " }"
        body = {"script": script}
        r = self.api.request("POST", "/partstudios/d/%s/w/%s/e/%s/featurescript" % (did, wid, eid),
                             query={"rollbackBarIndex": -1}, body=body)
        out = {"result": fsval(r.get("result"))}
        if r.get("console"):
            out["console"] = r["console"]
        if r.get("notices"):
            out["notices"] = [{"level": n.get("level"), "message": n.get("message")} for n in r["notices"]]
        return json.dumps(out, indent=1, default=str)

    def _variables(self, did, wid, eid):
        # the variables endpoint reads the studio's last regeneration (about a second); the
        # featurescript evaluation regenerates the whole studio and takes minutes on a mold
        r = self.api.request("GET", "/variables/d/%s/w/%s/e/%s/variables" % (did, wid, eid),
                             query={"includeValuesAndReferencedVariables": "true"})
        out = {}
        for tbl in (r if isinstance(r, list) else [r]):
            for v in (tbl.get("variables", []) if isinstance(tbl, dict) else []):
                out[v.get("name")] = v.get("value")
        return out

    @staticmethod
    def unquote(v):
        # FeatureScript strings come back printed: quoted, with \n and \" escaped
        if isinstance(v, str) and len(v) >= 2 and v[0] == '"' and v[-1] == '"':
            return v[1:-1].replace('\\n', '\n').replace('\\"', '"')
        return v

    def get_variables(self, args):
        did, wid, eid = self.api.ids(args, "partStudioId")
        vals = self._variables(did, wid, eid)
        prefix = args.get("prefix", "foil")
        lines = []
        for k in sorted(vals):
            if k.startswith(prefix) and not ("Log" in k or "Notice" in k):
                lines.append("%s = %s" % (k, str(vals[k])[:4000]))
        return "\n".join(lines) or "(no variables starting with %s)" % prefix

    def get_notices(self, args):
        did, wid, eid = self.api.ids(args, "partStudioId")
        r = self._features(did, wid, eid)
        states = r.get("featureStates", {})
        lines = ["FEATURES:"]
        for f in r.get("features", []):
            st = states.get(f.get("featureId"), {}).get("featureStatus", "?")
            lines.append("  %s (%s): %s" % (f.get("name"), f.get("featureType"), st))
        keys = args.get("keys") or NOTICE_KEYS
        vals = self._variables(did, wid, eid)
        for k in keys:
            v = self.unquote(vals.get(k))
            if v not in ("", None):
                lines.append("")
                lines.append("== %s ==" % k)
                lines.append(str(v))
        if not any(k in vals for k in keys):
            lines.append("")
            lines.append("(no foil*Notice / foil*Log variables: the studio is older than build 202, or the features have not regenerated yet)")
        return "\n".join(lines)

    def export_stl(self, args):
        did, wid, eid = self.api.ids(args, "partStudioId")
        out = os.path.expanduser(args.get("out_path") or "onshape_export.stl")
        q = {"mode": "binary", "units": "millimeter", "grouping": "true"}
        if args.get("partId"):
            q["partId"] = args["partId"]
        data = self.api.request("GET", "/partstudios/d/%s/w/%s/e/%s/stl" % (did, wid, eid), query=q, raw=True)
        with open(out, "wb") as f:
            f.write(data)
        return "%d bytes written to %s" % (len(data), out)


TOOL_DEFS = [
    ("whoami", "Who the API keys sign in as (checks the keys).", {}),
    ("list_elements", "List the tabs (elements) of a document: id, type, name.",
     {"did": {"type": "string"}, "wid": {"type": "string"}}),
    ("get_studio", "Read a Feature Studio's FeatureScript source. With out_path it is written to that file instead of returned.",
     {"did": {"type": "string"}, "wid": {"type": "string"}, "eid": {"type": "string", "description": "Feature Studio element id (default: featureStudioId in config)"},
      "out_path": {"type": "string"}}),
    ("put_studio", "Replace a Feature Studio's FeatureScript source from a local file (file_path) or a string (contents).",
     {"did": {"type": "string"}, "wid": {"type": "string"}, "eid": {"type": "string"}, "file_path": {"type": "string"}, "contents": {"type": "string"}}),
    ("list_features", "List a Part Studio's features with ids, types, status and (by default) every parameter's current value.",
     {"did": {"type": "string"}, "wid": {"type": "string"}, "eid": {"type": "string", "description": "Part Studio element id (default: partStudioId in config)"},
      "parameters": {"type": "boolean", "description": "include parameter values (default true)"}}),
    ("set_parameters", "Set parameters on one feature and regenerate. parameters is an object of parameterId -> value: quantities as expressions ('12 mm', '3 deg', '0.25'), booleans, enum values ('HUB').",
     {"did": {"type": "string"}, "wid": {"type": "string"}, "eid": {"type": "string"}, "featureId": {"type": "string"},
      "parameters": {"type": "object"}}, ["featureId", "parameters"]),
    ("add_feature", "Add a feature of a type that already exists in the Part Studio (its definition is copied), with optional parameter overrides.",
     {"did": {"type": "string"}, "wid": {"type": "string"}, "eid": {"type": "string"}, "featureType": {"type": "string"},
      "name": {"type": "string"}, "parameters": {"type": "object"}}, ["featureType"]),
    ("get_variables", "Every variable the foil tool publishes (foilWingHub, foilStabRoot, foilWingModel ...) from the studio's last regeneration, about a second. Use this before eval_featurescript.",
     {"did": {"type": "string"}, "wid": {"type": "string"}, "eid": {"type": "string"}, "prefix": {"type": "string", "description": "name prefix filter (default foil)"}}),
    ("eval_featurescript", "Evaluate FeatureScript in the Part Studio after all features: pass a whole 'function(context is Context, queries) { ... }' or just its body. Returns the value, console output and notices. SLOW: Onshape regenerates the whole studio for it (30 s to minutes with molds); for published variables use get_variables or get_notices instead.",
     {"did": {"type": "string"}, "wid": {"type": "string"}, "eid": {"type": "string"}, "script": {"type": "string"}}, ["script"]),
    ("get_notices", "Every feature's status plus the foil tool's notices and console logs (the foil*Notice / foil*Log variables from build 202 on). About two seconds; call it once after a change, not in a loop.",
     {"did": {"type": "string"}, "wid": {"type": "string"}, "eid": {"type": "string"}, "keys": {"type": "array", "items": {"type": "string"}}}),
    ("export_stl", "Export the Part Studio (or one partId) as a binary STL in millimetres to out_path.",
     {"did": {"type": "string"}, "wid": {"type": "string"}, "eid": {"type": "string"}, "partId": {"type": "string"}, "out_path": {"type": "string"}}),
]


def tool_list():
    out = []
    for name, desc, props, *req in TOOL_DEFS:
        schema = {"type": "object", "properties": props}
        if req:
            schema["required"] = req[0]
        out.append({"name": "onshape_" + name, "description": desc, "inputSchema": schema})
    return out


def serve():
    api = None
    tools = None
    err = None
    try:
        api = Onshape()
        tools = Tools(api)
    except Exception as e:  # keep serving so the error reaches Claude
        err = str(e)
        log(err)

    def send(obj):
        sys.stdout.write(json.dumps(obj) + "\n")
        sys.stdout.flush()

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except ValueError:
            continue
        mid = msg.get("id")
        method = msg.get("method")
        if method == "initialize":
            send({"jsonrpc": "2.0", "id": mid, "result": {
                "protocolVersion": msg.get("params", {}).get("protocolVersion", "2025-06-18"),
                "capabilities": {"tools": {}},
                "serverInfo": {"name": "onshape", "version": "1.0"}}})
        elif method == "tools/list":
            send({"jsonrpc": "2.0", "id": mid, "result": {"tools": tool_list()}})
        elif method == "tools/call":
            name = msg.get("params", {}).get("name", "")
            args = msg.get("params", {}).get("arguments") or {}
            try:
                if err:
                    raise RuntimeError(err)
                fn = getattr(tools, name.replace("onshape_", "", 1), None)
                if fn is None:
                    raise RuntimeError("unknown tool " + name)
                text = fn(args)
                send({"jsonrpc": "2.0", "id": mid, "result": {"content": [{"type": "text", "text": text}]}})
            except Exception as e:
                log("tool %s failed: %s" % (name, e))
                send({"jsonrpc": "2.0", "id": mid, "result": {"content": [{"type": "text", "text": "Error: %s" % e}], "isError": True}})
        elif method == "ping":
            send({"jsonrpc": "2.0", "id": mid, "result": {}})
        elif mid is not None:
            send({"jsonrpc": "2.0", "id": mid, "error": {"code": -32601, "message": "method not found: %s" % method}})
        # notifications (no id) are ignored


def smoke_test():
    api = Onshape()
    if api.access.startswith("PASTE") or api.secret.startswith("PASTE"):
        print("keys.json still holds the PASTE placeholders: %s" % KEYS_PATH)
        return
    t = Tools(api)
    print(t.whoami({}))
    ok = lambda k: api.config.get(k) and not str(api.config.get(k)).startswith("PASTE")
    if ok("documentId") and ok("workspaceId"):
        print(t.list_elements({}))
        if ok("partStudioId"):
            print(t.list_features({"parameters": False}))
            print(t.get_notices({}))
        else:
            print("(set partStudioId in config.json to list features and notices)")
    else:
        print("(set documentId and workspaceId in config.json to list the document)")


if __name__ == "__main__":
    if "--test" in sys.argv:
        smoke_test()
    else:
        serve()
