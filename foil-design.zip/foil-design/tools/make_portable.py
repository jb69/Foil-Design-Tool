#!/usr/bin/env python3
"""Fold the skill into one Markdown file for assistants that don't load skill folders
(ChatGPT custom GPTs, Gemini, local models). parameters.md is left out - it is large and
goes alongside as its own file.

    python3 tools/make_portable.py [skill_folder]   # writes foil-design-assistant-portable.md in the skill folder
"""
import os
import re

import sys

HERE = os.path.dirname(os.path.abspath(__file__))
# the assistant skill folder: given on the command line, else found beside tools/ (repository
# layout: ../assistant) or in the working tree (../da/foil-design-assistant)
if len(sys.argv) > 1:
    ROOT = os.path.abspath(sys.argv[1])
else:
    for cand in ("../assistant", "../da/foil-design-assistant"):
        ROOT = os.path.abspath(os.path.join(HERE, cand))
        if os.path.exists(os.path.join(ROOT, "SKILL.md")):
            break
ORDER = ["outputs.md", "targets.md", "levers.md", "propulsion.md", "model-limits.md", "examples.md"]

skill = open(os.path.join(ROOT, "SKILL.md"), encoding="utf-8").read()
skill = re.sub(r"\A---\n.*?\n---\n", "", skill, flags=re.S)       # drop the Claude front matter
note = ("> Portable version: the reference files are included below this point, except "
        "`parameters.md` (every dialog field), which comes as a separate file. Where the "
        "instructions say `references/x.md`, read the section of that name below. If you "
        "cannot run Python, use the manual method given next to each script.\n")
parts = [note + "\n" + skill.strip()]
for name in ORDER:
    body = open(os.path.join(ROOT, "references", name), encoding="utf-8").read().strip()
    body = re.sub(r"^(#+) ", lambda m: "#" + m.group(1) + " ", body, flags=re.M)   # one level down under the file heading
    parts.append("---\n\n# references/%s\n\n%s" % (name, body))
out = os.path.join(ROOT, "foil-design-assistant-portable.md")
open(out, "w", encoding="utf-8").write("\n\n".join(parts) + "\n")
print("wrote", out, os.path.getsize(out), "bytes")
